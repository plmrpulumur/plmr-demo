PLMR JUSTPERGOLA V15 — GELİŞTİRME TESLİMİ
=======================================
Başlangıç V14 korunmuştur. Bu paket nihai kabulü tamamlanmış production sürümü değildir.

Çalıştırma:
  python3 -m http.server 8000 --directory Uygulama
  Tarayıcı: http://localhost:8000

Yeniden derleme:
  python3 Development_Protocol/build.py

Kaynak/build ve mantık/CAD kontrolleri:
  python3 -m pip install -r Test-Mantik/requirements.txt
  python3 Test-Mantik/run-v15-checks.py --full --out work/test-output

Tarayıcı ve ana uygulama entegrasyonu: Test-Mantik/KABUL.md ve BAGLANTI_REHBERI.md.
Tek güncel devir kaydı: DEVIR_NOTU.md.

Doğrulanan başlıca değişiklikler: gizlenen ara ölçüyü yeniden gösterebilme,
profil kenarlarına DXF ilişki desteği, görünüş/kanat ayrımı, ana modele bağlı
Pergola çalışma alanı ve geçmiş/kilit/kayıt bağlantısının yerel testleri.

DXF: 70 gerçek DIMENSION içinde 33 yapısal/koordinat ilişkisi; 37 ilişkilendirme açık.
AutoCAD STRETCH çalıştırılmadı. Ayrı ticari ürünlerin UUID/kod/fiyat/üretim
sözleşmesi kurulmadı; Antero kimliği kullanılmadı. Canlı dağıtım yapılmadı.
