# JustPergola V11

V10'da türetilmiş 2D görünüşlerin genel 3D kutulardan çıkarılması; özgün ön ray siluetini, birleşik oluk/mekanizma bloklarını ve bazı çoklu modül referanslarını kaybettiriyordu. V11 native PERI01 üst/ön/yan üreticilerini kullanır. Yeni kullanıcı DXF'indeki dokuz tip/13 montaj örneğiyle profil çizgileri, özgün aksesuar blokları, renkler ve yerleşimler karşılaştırıldı. Önizleme/PDF/DXF aynı çizim entity'lerinden beslenir; kavis DXF'te gerçek yaydır.

Curve-Quad-Wing Curved seçimine, hafif kartına, normalizasyona, 2D/3D ve kayıt/çıktı yollarına eklendi. İki ayrı kavisli kanadı merkez çeliğin iki yüzüne monte olur; Curve-Quad'ın tek sürekli kemerinden ayrıdır. Bağımsız grupların görünür POZ sırası düzeltildi. Curve-Suspend kullanıcı kararıyla dikmesiz kalır.

Özgün Lean matematiği/gerçek bloklar korunur. Referansta bulunmayan sonradan eklenmiş trapez yan çizgisi çıkarıldı. Elle düzenlenmiş ikinci DXF'teki bazı kavis uç/teğet farklılıkları fiziksel boşluk olarak yeniden üretilmez; native montaj verisi önceliklidir. Geçerli kararlar ve sayısal karşılaştırma sınırı devir/kabul belgelerindedir.

Doğrulanan kapsam: dokuz tip, iki seri ve yedi yerleşimde 126 model; normal/doğrama/özel çelik seçenekleriyle üç ayrı durum; 56 modül/görünüş sahiplik deneyi; altı native koruma fixture'ı; gerçek UI, 2D ölçü düzenleme, history/kayıt, kumaş hareketi, 27 tip çıktısı ve altı karma yerleşim DXF/PDF'i. Bağımsız format okuyucuları, görsel inceleme ve temiz paket açılışı ayrıntıları `Test-Mantik/KABUL.md` içindedir. Bu kontroller statik veya üretim onayı değildir.

Şema 3, eski kayıtlar, snapshot/checksum, mevcut arayüz ve ortak davranış sahipleri korunur. Canlı hosta bağlanmadı; entegrasyon rehberi ve buton haritası güncellendi.

Ürün adları, uzun Curve-Quad-Wing adı dahil, ait olduğu modülün genişliğine sığdırılır; komşu pozun içine taşmaz. Bu sunum boyutu fiziksel profil ölçüsü değildir.
