# PLMR JustPergola V15 — devam kaydı

CURRENT VERSION: 15.0.0; DEVELOPMENT, zorunlu kabuller açık.
IMMUTABLE BASELINE: V14 ZIP SHA256 fa84ac53359b1421a53899ab9ce41ac0a33410f14513be51521bb17a33562e8c; PLMR main 4430d5f4013159236d4a5a0856b1c15eb6442d56.
OBJECTIVE: Kullanıcının kapsamlı denetim, düzeltme, entegrasyon ve kanıtlı teslim hedefi sürüyor.
CURRENT TASK: V15 geliştirme paketi ve kanıtlar hazırlandı; açık CAD/ticari/kimlikli kabul sürüyor.
LOCKED: Ayrı Andes/Avila ticari ürünler; Antero eşlemesi yok. Özgün DXF/native bloklar, fiziksel ray ve montaj kararları, ana arayüz/veri sahipliği korunur.
IMPLEMENTED: Geri gösterilebilir ölçü menüsü, güvenli düz kenar/LINE DXF referansları, görünüş/kanat ayrımı, boş model sahne temizliği, mevcut ana snapshot/history/kilit/metadata/çıktı adaptörü.
VERIFIED: Test-Mantik/KABUL.md ve v15-output; gerçek 2D/3D çelik ve ölçü kayıt akışları; yerel ana motor kayıt/aç/geçmiş/kilit; statik build.
MAIN BRANCH: codex/justpergola-v15 @ 715eb1e03802528d341bc4f895d7750e5e9597b5 (yerel, bundle/yama; remote push/PR/merge/deploy yok).
KNOWN OPEN: 37 DXF ilişkilendirme; AutoCAD STRETCH/kayıt ve semantik bağ doğrulaması; ayrı ticari kayıt/fiyat/üretim sözleşmesi; güncel tam V51 istemci/build kaynağı; kimlikli sunucu/rol/PIN/revizyon kabulü.
SOURCE ACCESS: Main ve backup dalları tarandı; V46 kısmi TS/Cloud bulundu fakat tam V51 değildir. Supabase yayımdaki 3 fonksiyon kaynağı salt okunur alındı.
DO NOT CHANGE: Canlı müşteri verisi, production tabloları ve deployment. Açık onay olmadan deploy/yıkıcı migration yok.
NEXT ACTION: Tam güncel kaynakla merkezi ürün ve sunucu sözleşmesini tamamlamak; gerçek CAD ortamında açık ölçü kabulünü çalıştırmak. Ayrıntı DEVIR_NOTU.md.
