# V15 değişiklik ve doğrulama raporu

Sürüm 15.0.0; durum DEVELOPMENT. Ana kullanıcı hedefi henüz tamamlanmadı. Başlangıç V14 korunur.

Kök neden → düzeltme → test:

- Görünür ölçülerden türetilen menü, gizlenen satırı kaldırıyordu → gizlilikten bağımsız, kimliğe göre tekil menü → V14 hata tekrarı ve V15 gerçek 2D/3D/gizle/göster/kayıt-aç testi geçti.
- DXF köşe-only araması kenar ortasındaki fiziksel referansı bulamıyordu; görünüş kimliği sağ/solu ayırmıyordu → LINE/düz kenar referansı, gerçek WCS/parametre ve görünüş/kanat ayrımı → 70 DIMENSION/33 koordinat bağı; yanlış ölçülen koordinat ve başka görünüş negatif testleri geçti. 37 ilişkilendirme ve AutoCAD kabulü açık.
- Üst model boşaltılırken native viewer önceki modeli tutabiliyordu → model/sahne/seçim temizleme yolu → ana undo ile boş duruma dönüş ve redo gerçek WebGL'de geçti.
- Bağımsız Pergola'nın ana kayıt/geçmiş/kilit bağı yoktu → mevcut host snapshot/history/ürün arabiriminde adaptör → yerel ana .plmr kayıt/aç, eski yazma reddi, kilit, metadata, SVG ve görüntü/camera testleri geçti. Ticari ürün ve kimlikli sunucu E2E hâlâ bloke.

- İlk görünüm/birim işlemi boş fiziksel sahneyi varsayılan nesneye dönüştürüyordu → görünüm ayrımından önce native sahne kanonikleştirmesi → gerçek host mm/inch işlemlerinde fiziksel snapshot birebir korundu.

- Native Gizle komutunun geri gösterme düğümü gizlenen eski toolbar'da kalıyordu → mevcut native komut görünür ölçü menüsüne taşındı → gerçek 2D seç/Gizle/göster, 3D ve DXF kontrolü geçti.
- Boş store'a rağmen eski form girdileri Yenile ile eski modeli üretebiliyordu → mevcut boş snapshot form/runtime restorasyonu → ana undo/boş/Yenile/redo testi geçti.

Kaynak/build: aynı kaynak 141 runtime dosyasına üretildi; 96 JS dosyası sözdizimi kontrolünden geçti. Ana statik build ve 1077 dosyalık yayın manifesti doğrulandı; yayın yapılmadı. Başlangıç React dosyaları/CSS byte olarak değişmedi. Native fiziksel parça/geometri ve referanslar korundu.

Kapsam ve sınırlar için tek giriş `Test-Mantik/KABUL.md`, devam için `DEVIR_NOTU.md`. Canlı Supabase/GitHub main değişikliği, migration veya gerçek müşteri veri yazması yok. Git dalı yerelde hazırlanmış ve bundle/yama olarak teslim edilmiştir; remote PR veya yayın yok.
