# Ayrı ticari ürün kararı ve açık sınır

Kullanıcının 17.11.2026 tarihli kararı: Andes/Avila JustPergola çeşitleri **ayrı ticari ürünler** olacak. V51'deki Antero Pergola UUID/kodu yeniden kullanılmaz. Yerleşim seçeneği ürün kimliği değildir.

Yeni UUID/kod/fiyat/üretim kayıtları canlıya eklenmedi. Ayrı ürünlerin tam kapsamı, merkezi katalog kayıtları, fiyat motoru girdileri ve üretim kuralları mevcut ana sözleşmede tanımlanmalı. Kayıt oluşturmak tek başına çizim/teklif/üretim motoru bağlantısı değildir.

Mevcut merkezi ürün sözleşmesi güncel istemci runtime'ında ve yayımdaki platform sunucusunda incelendi. Yeni `justpergola:seri:tip` motor anahtarları ticari kimlik yerine geçirilmez. Yayımdaki `finalIdentity` bu anahtarları reddediyor; yerel sunucu mantığı testi bunu gösterir. Ürün sessizce Antero'ya dönüştürülmez veya tekliften başarılı biçimde çıkarılmış sayılmaz.

İstemci ve sunucu eşlemesi, kimlikli kayıt/revizyon/teklif/üretim ve firma yetki testleri açık kabul kriteridir. V46 yedek dalındaki kısmi kaynak, bu değişikliği V51'e güvenle yeniden derlemek için yeterli değildir. Yeni ayrı kayıt sistemi, paralel auth veya production migration oluşturulmadı.
