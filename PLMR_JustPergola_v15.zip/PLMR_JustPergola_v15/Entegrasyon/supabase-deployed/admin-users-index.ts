import { createClient } from 'npm:@supabase/supabase-js@2.95.0'

const url = Deno.env.get('SUPABASE_URL')!
const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const publishableKey = Deno.env.get('SUPABASE_ANON_KEY')!
const pepper = Deno.env.get('PLMR_PIN_PEPPER')!
const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } })
const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization,apikey,content-type',
  'Access-Control-Allow-Methods': 'POST,OPTIONS',
  'Cache-Control': 'no-store',
  'Content-Type': 'application/json; charset=utf-8',
  'X-Content-Type-Options': 'nosniff',
}
function reply(value: unknown, status = 200) {
  return new Response(JSON.stringify(value), { status, headers })
}
function check<T>(result: { data: T; error: { message: string } | null }): T {
  if (result.error) throw new Error(result.error.message)
  return result.data
}
async function hashPassword(username: string, pin: string): Promise<string> {
  const bytes = new TextEncoder().encode(`${pepper}|${username}|${pin}`)
  const result = await crypto.subtle.digest('SHA-256', bytes)
  return 'P!' + [...new Uint8Array(result)].map(b => b.toString(16).padStart(2, '0')).join('')
}
function jwtSession(token: string): string {
  const encoded = token.split('.')[1]
  if (!encoded) throw new Error('INVALID_TOKEN')
  const payload = JSON.parse(atob(encoded.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(encoded.length / 4) * 4, '=')))
  const session = String(payload.session_id || '')
  if (!/^[a-f0-9-]{36}$/i.test(session)) throw new Error('MISSING_SESSION_ID')
  return session
}
async function authenticatedActor(request: Request) {
  const token = (request.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '')
  if (!token) throw new Error('SESSION_REQUIRED')
  const user = check(await admin.auth.getUser(token)).user
  if (!user) throw new Error('SESSION_REQUIRED')
  const live = createClient(url, publishableKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  })
  check(await live.rpc('assert_current_session_v2'))
  const profile = check(await admin.from('profiles').select('id,role,is_active,organization_id').eq('id', user.id).single())
  if (!profile.is_active) throw new Error('ACCOUNT_INACTIVE')
  return profile
}
const validUsername = (s: unknown) => typeof s === 'string' && /^[a-z0-9_.-]{3,40}$/.test(s)
const validPin = (s: unknown) => typeof s === 'string' && /^\d{4}$/.test(s)

Deno.serve(async request => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers })
  if (request.method !== 'POST') return reply({ error: 'METHOD_NOT_ALLOWED' }, 405)
  try {
    if (!pepper || !serviceKey || !publishableKey || !url) return reply({ error: 'SERVER_NOT_CONFIGURED' }, 503)
    const raw = await request.text()
    if (raw.length > 4096) return reply({ error: 'BAD_REQUEST' }, 400)
    const input = JSON.parse(raw)
    if (!input || typeof input !== 'object') return reply({ error: 'BAD_REQUEST' }, 400)
    const action = input.action
    if (action === 'login') {
      const username = String(input.username || '').trim().toLowerCase()
      const pin = input.pin
      if (!validUsername(username) || !validPin(pin)) return reply({ error: 'INCORRECT_CREDENTIALS' }, 401)
      // Rate limiting is in PostgreSQL, not in browser-local storage.
      const allowed = check(await admin.rpc('plmr_pin_attempt', { p_username: username }))
      if (!allowed) return reply({ error: 'TRY_AGAIN_LATER' }, 429)
      const profile = check(await admin.from('profiles')
        .select('id,username,email,role,is_active,organization_id')
        .eq('username', username).maybeSingle())
      if (!profile || !profile.is_active) return reply({ error: 'INCORRECT_CREDENTIALS' }, 401)
      if (profile.role !== 'system_admin' && !profile.organization_id) return reply({ error: 'INCORRECT_CREDENTIALS' }, 401)
      if (profile.organization_id) {
        const organization = check(await admin.from('organizations').select('is_active').eq('id', profile.organization_id).single())
        if (!organization.is_active) return reply({ error: 'INCORRECT_CREDENTIALS' }, 401)
      }
      const userClient = createClient(url, publishableKey, { auth: { persistSession: false, autoRefreshToken: false } })
      const auth = await userClient.auth.signInWithPassword({ email: profile.email, password: await hashPassword(username, pin) })
      if (auth.error || !auth.data.session || auth.data.user?.id !== profile.id) return reply({ error: 'INCORRECT_CREDENTIALS' }, 401)
      check(await admin.from('plmr_active_sessions').upsert({
        user_id: profile.id,
        session_id: jwtSession(auth.data.session.access_token),
        updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id' }))
      check(await admin.rpc('plmr_pin_success', { p_username: username }))
      return reply({ session: { access_token: auth.data.session.access_token, refresh_token: auth.data.session.refresh_token } })
    }
    if (action === 'create' || action === 'set_pin') {
      const actor = await authenticatedActor(request)
      const pin = input.pin
      if (!validPin(pin)) return reply({ error: 'INVALID_PIN' }, 400)
      if (action === 'set_pin') {
        if (!/^[a-f0-9-]{36}$/i.test(String(input.userId || ''))) return reply({ error: 'INVALID_USER' }, 400)
        const target = check(await admin.from('profiles').select('id,username,role,organization_id').eq('id', input.userId).single())
        if (actor.role !== 'system_admin' && !(actor.role === 'company_admin' && target.role !== 'system_admin' && actor.organization_id && actor.organization_id === target.organization_id)) {
          return reply({ error: 'FORBIDDEN' }, 403)
        }
        check(await admin.auth.admin.updateUserById(target.id, { password: await hashPassword(target.username, pin) }))
        return reply({ ok: true })
      }
      const username = String(input.username || '').trim().toLowerCase()
      const role = String(input.role || '')
      const organizationId = String(input.organizationId || '')
      const name = String(input.fullName || '').trim()
      if (!validUsername(username) || !/^[a-f0-9-]{36}$/i.test(organizationId) || name.length < 3 || name.length > 250 || !['company_admin','designer','viewer'].includes(role)) {
        return reply({ error: 'INVALID_USER' }, 400)
      }
      if (actor.role !== 'system_admin' && !(actor.role === 'company_admin' && actor.organization_id === organizationId && role !== 'company_admin')) {
        return reply({ error: 'FORBIDDEN' }, 403)
      }
      const organization = check(await admin.from('organizations').select('id,is_active,max_users').eq('id', organizationId).single())
      if (!organization.is_active) return reply({ error: 'COMPANY_INACTIVE' }, 403)
      // Check seat count separately because PostgREST's head selection returns no data.
      const seats = await admin.from('profiles').select('id', { count: 'exact', head: true }).eq('organization_id', organizationId).eq('is_active', true)
      if (seats.error) throw Error(seats.error.message)
      if ((seats.count || 0) >= organization.max_users) return reply({ error: 'USER_LIMIT' }, 403)
      const email = `plmr.${crypto.randomUUID().replaceAll('-', '')}@auth.pulumur.app`
      const created = check(await admin.auth.admin.createUser({ email, password: await hashPassword(username, pin), email_confirm: true }))
      if (!created.user) throw new Error('CREATE_USER_FAILED')
      try {
        check(await admin.from('profiles').insert({
          id: created.user.id, organization_id: organizationId,
          full_name: name, username, email, role, is_active: true,
          user_code: String(Date.now()).slice(-4),
        }))
      } catch (err) {
        const removed = await admin.auth.admin.deleteUser(created.user.id)
        if (removed.error) throw Error('PROFILE_FAILED_USER_NEEDS_REVIEW')
        throw err
      }
      return reply({ user: { id: created.user.id } })
    }
    return reply({ error: 'INVALID_ACTION' }, 400)
  } catch (err) {
    // Do not expose vendor/internal SQL/Auth errors in a public login endpoint.
    console.error('admin-users failure', err)
    return reply({ error: 'REQUEST_FAILED' }, 400)
  }
})

