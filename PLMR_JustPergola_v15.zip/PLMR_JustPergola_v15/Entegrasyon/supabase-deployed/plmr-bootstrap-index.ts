Deno.serve(() => new Response(JSON.stringify({ error: 'BOOTSTRAP_DISABLED' }), { status: 410, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } }));

