var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// domain/projectOverview.ts
function projectOverview(record) {
  if (!record) return null;
  const workflow = record.workflow, quote = workflow?.quote, a = workflow?.approvals;
  const p = a?.package;
  const approvals = a ? {
    quote: a.quote,
    production: a.production,
    shipment: a.shipment,
    ...p ? { package: { at: p.at, by: p.by, name: p.name, document: { sourceRevisionId: p.document.sourceRevisionId } } } : {}
  } : void 0;
  return {
    projectInfo: record.projectInfo,
    updatedAt: record.updatedAt,
    workflowVersion: workflow?.version,
    approvals,
    quote: quote ? { issuerCompany: quote.issuerCompany, country: quote.country, customerContactId: quote.customerContactId, revision: quote.revision } : void 0
  };
}
var init_projectOverview = __esm({
  "domain/projectOverview.ts"() {
    "use strict";
  }
});

// ../drawing-engine/src/v29-share-contract.js
var require_v29_share_contract = __commonJS({
  "../drawing-engine/src/v29-share-contract.js"(exports, module) {
    (function(root, factory) {
      const api = factory();
      if (typeof module === "object" && module.exports)
        module.exports = api;
      root.PLMRShareContract = api;
    })(typeof globalThis !== "undefined" ? globalThis : exports, function() {
      "use strict";
      const TYPES = ["guillotine", "sliding", "door", "fixed", "zip", "folding", "balcony"];
      const own = (v, k) => Object.prototype.hasOwnProperty.call(v || {}, k);
      function object4(v) {
        if (!v || typeof v !== "object" || Array.isArray(v))
          throw Error("Sunum nesnesi ge\xE7ersiz.");
        return v;
      }
      function primitive(v) {
        if (v === null || typeof v === "boolean" || typeof v === "string" && v.length <= 1e4 || typeof v === "number" && Number.isFinite(v))
          return v;
        throw Error("Sunum alan\u0131 ge\xE7ersiz.");
      }
      function fields(raw, keys) {
        const out = {};
        object4(raw);
        for (const k of keys.split(" "))
          if (own(raw, k))
            out[k] = primitive(raw[k]);
        return out;
      }
      function vector(v) {
        if (!Array.isArray(v) || v.length > 1e3)
          throw Error("Sunum dizisi ge\xE7ersiz.");
        return v.map(primitive);
      }
      function map(raw, fn) {
        object4(raw);
        const out = {};
        for (const [key, value] of Object.entries(raw)) {
          if (["__proto__", "constructor", "prototype"].includes(key))
            throw Error("Sunum anahtar\u0131 ge\xE7ersiz.");
          out[key] = fn(value);
        }
        return out;
      }
      function optional(out, raw, key, fn) {
        if (own(raw, key) && raw[key] != null)
          out[key] = fn(raw[key]);
      }
      function pose(v) {
        return fields(v, "x y z angle");
      }
      function color(v) {
        return fields(v, "hex code kind finish texture image schematic");
      }
      const PHYSICAL_KEYS = new Set("positionRatio positionYRatio scopeStartRatio scopeEndRatio originX originY originZ positionX positionY positionZ span surface zoneId facadeId profileSourceId beamBottomY startBoundaryId endBoundaryId globalBaseWidth globalStartRatio globalEndRatio postBounded boundaryKinds physicalBoundaryKeys boundaryOwners boundaryModuleIndices group connection physicalKey ownerIds frameAngle frameCenter center x1 x2 y1 y2 z1 z2 scope minN maxN nmin nmax normalAxis added profileId memberId source baseX baseZ moduleIndices axisIndex extents delta positions step lineAxes moduleWidths moduleDepths modulePanelCounts id uid type version schemaVersion width depth height x y z w h u v axis sign at uAxis vAxis u0 u1 v0 v1 cellId row lineIndex sourceIndex moduleIndex sharedBoundary outerLine top bottom length value angle rotation elevation thickness defaultDepth nextSolid templateId templateRole orientation inward defaultInward outerFaceV bottomY topY cx cz owner ownerId start end offset deleted sharedWith sharedX sharedZ commonGroup min max a b section pose origin frame t normal startX startZ endX endZ left right front back rear vertical horizontal thickness depthOffset gap count index fixed postId startPostId endPostId wallId supportWallId startBoundary endBoundary startBoundaryWidth endBoundaryWidth leftBoundaryWidth rightBoundaryWidth custom widthMode heightMode colorMode colorCode color finish parapet minX maxX minY maxY minZ maxZ boundary ownerType side moduleId startMemberId endMemberId isPost isBeam isGutter isWall isRoofZone isConnectionZone isInternalZone plane solids segments zone hiddenRoles verticalCuts horizontalCuts".split(" "));
      function physical(v, depth = 0) {
        if (depth > 24)
          throw Error("Sunum geometrisi \xE7ok derin.");
        if (v === null || typeof v !== "object")
          return primitive(v);
        if (Array.isArray(v))
          return v.map((x) => physical(x, depth + 1));
        const out = {};
        for (const [key, value] of Object.entries(v))
          if (PHYSICAL_KEYS.has(key))
            out[key] = physical(value, depth + 1);
        return out;
      }
      function numericMap(v) {
        return map(v, (x) => {
          if (typeof x !== "number" && typeof x !== "boolean")
            throw Error("Sunum hareketi ge\xE7ersiz.");
          return primitive(x);
        });
      }
      function partition(value) {
        if (!value)
          return "";
        const raw = JSON.parse(value);
        if (raw.version !== 1)
          throw Error("B\xF6lme d\xFCzeni desteklenmiyor.");
        function node(n, depth = 0) {
          if (n === null)
            return null;
          if (depth > 16 || !["H", "V"].includes(n?.axis) || !Number.isFinite(n.ratio) || n.ratio <= 0 || n.ratio >= 1)
            throw Error("B\xF6lme d\xFCzeni ge\xE7ersiz.");
          return { axis: n.axis, ratio: n.ratio, a: node(n.a, depth + 1), b: node(n.b, depth + 1) };
        }
        return JSON.stringify({ version: 1, regions: map(raw.regions, (n) => node(n)) });
      }
      const OPTION_KEYS = "systemType mechanism glassType glassThickness glassThicknessOther glassColor glassColorOther panelLayout fixedPanelHeightMode fixedPanelHeightCustom systemColor surface defaultView defaultMotorDirection motor remote remoteQuantity series type customGlassThickness customGlassColor slidingView openingType openingDirection panelCountMode panelCount doorType hingeDirection activeLeaf doorOpenDirection handleType movingLeafWidth movingLeafHeight verticalDivisions horizontalDivisions horizontalHeightMode horizontalHeights placementLocation motorDirection cableDirection fabricColor motorType remoteSelections openingMode subtype panels foldingView foldingOpenDirection fabric side opening view motorSide panelType fixedHeight fixedPanelHeight colorCode collectionState bottomPanelState swingDirection";
      function options(raw = {}) {
        const out = fields(raw, OPTION_KEYS.split(" ").filter((k) => k !== "systemColor").join(" "));
        if (own(raw, "systemColor"))
          out.systemColor = raw.systemColor && typeof raw.systemColor === "object" ? color(raw.systemColor) : primitive(raw.systemColor);
        if (own(raw, "divisionLayout"))
          out.divisionLayout = partition(raw.divisionLayout);
        optional(out, raw, "variableSelections", (v) => numericMap(v));
        return out;
      }
      function layout(raw = {}) {
        const out = fields(raw, "columns previewMode openState showDimensions");
        optional(out, raw, "dimensionUnits", (v) => fields(v, "mm inch ft"));
        optional(out, raw, "positionOrder", vector);
        return out;
      }
      function workspace(raw) {
        const out = fields(raw, "schema version productId applicationVersion inputUnit");
        out.projectInfo = {};
        out.settings = options(raw.settings);
        if (!Array.isArray(raw.positions) || raw.positions.length > 200)
          throw Error("Sunum poz listesi ge\xE7ersiz.");
        out.positions = raw.positions.map((p) => ({ ...fields(p, "id positionNo width height quantity inputUnit open progress view motorDirection"), description: "", overrides: options(p.overrides) }));
        out.drawingLayout = layout(raw.drawingLayout);
        return out;
      }
      function placement(raw) {
        if (!TYPES.includes(raw.type))
          throw Error("Sunum \xFCr\xFCn t\xFCr\xFC desteklenmiyor.");
        const out = { ...options(raw), ...fields(raw, "type v07 productWidth productHeight positionCode fitRevision quantity id colorSource bioProfileColor autoFrontOnly") };
        optional(out, raw, "options", options);
        return out;
      }
      function editor(raw = {}, depth) {
        const out = fields(raw, "groundY mainDeleted facadeZonesGenerated initialRoofOpen zoneGraphVersion");
        optional(out, raw, "roofPose", pose);
        optional(out, raw, "dimensionUnits", (v) => fields(v, "mm inch ft"));
        optional(out, raw, "sharedProductLayout", layout);
        optional(out, raw, "members", (v) => map(v, physical));
        optional(out, raw, "zoneRotations", numericMap);
        optional(out, raw, "roofProducts", (v) => map(v, (x) => fields(x, "id rotation open initialOpen revision")));
        optional(out, raw, "bioCodes", (v) => map(v, primitive));
        optional(out, raw, "templates", (v) => v.map((x) => physical(x)));
        optional(out, raw, "presentation", (v) => fields(v, "environment floor"));
        if (raw.nativeWorkspaces) {
          out.nativeWorkspaces = {};
          for (const [type, w] of Object.entries(raw.nativeWorkspaces)) {
            if (!TYPES.includes(type))
              throw Error("Sunum \xFCr\xFCn t\xFCr\xFC desteklenmiyor.");
            out.nativeWorkspaces[type] = workspace(w);
          }
        }
        if (raw.roofCopies) {
          if (!Array.isArray(raw.roofCopies) || raw.roofCopies.length > 1e3 || depth > 2)
            throw Error("Sunum \xE7at\u0131 listesi ge\xE7ersiz.");
          out.roofCopies = raw.roofCopies.map((c) => ({ id: primitive(c.id), pose: pose(c.pose || {}), spec: model(c.spec, depth + 1) }));
        }
        return out;
      }
      function model(raw, depth = 0) {
        object4(raw);
        const out = fields(raw, "productGroup width depth height panelCount lamellaCount productsOpen panelMasterOpen colorMode systemCount multiAlignment rowAlignment panelCollection panelColorIndependent panelFill motor remote led dimmer parapet parapetHeight waterStandard pozNo nextZoneNumber nextSketchWallNumber");
        for (const key of ["moduleWidths", "moduleDepths", "modulePanelCounts", "orientations"])
          optional(out, raw, key, vector);
        for (const key of ["postSections", "beamSection", "facadeProfiles", "zoneDividers", "sketchWalls", "multiRows", "initialDimensions"])
          optional(out, raw, key, (v) => ["facadeProfiles", "zoneDividers"].includes(key) ? map(v, physical) : physical(v));
        for (const key of ["systemColor", "panelColor"])
          optional(out, raw, key, color);
        optional(out, raw, "inputDrafts", (v) => fields(v, "width depth height"));
        optional(out, raw, "glassPreferences", (v) => fields(v, "color customColor thickness"));
        for (const key of ["placements", "zipPlacements"])
          optional(out, raw, key, (v) => map(v, placement));
        for (const key of ["productOpenStates", "panelStates"])
          optional(out, raw, key, numericMap);
        optional(out, raw, "systemSelection", (v) => ({ ...fields(v, "id locked"), applied: numericMap(v.applied || {}) }));
        optional(out, raw, "zoneRegistry", (v) => map(v, (z) => ({ ...fields(z, "uid number code"), ...z.positionRefs ? { positionRefs: vector(z.positionRefs) } : {} })));
        optional(out, raw, "codeRegistry", (v) => ({ next: numericMap(v.next), items: map(v.items, (x) => fields(x, "code owner prefix active")) }));
        out.sceneEditor = editor(raw.sceneEditor, depth);
        out.extras = "";
        out.selectedZoneId = null;
        return out;
      }
      function snapshot2(raw) {
        object4(raw);
        if (raw.schema !== "p3dv-host-snapshot-v1")
          throw Error("Sunum proje t\xFCr\xFC desteklenmiyor.");
        return { schema: raw.schema, productInputSchema: typeof raw.productInputSchema === "string" ? raw.productInputSchema : "p3dv-product-input-v1", p3dvVersion: typeof raw.p3dvVersion === "string" ? raw.p3dvVersion : "3.86", modelState: model(raw.modelState), v24ActiveProduct: TYPES.includes(raw.v24ActiveProduct) ? raw.v24ActiveProduct : "rolling-roof", operationJournal: [], zonesVisible: false, dimensionVisibility: { main: false, intermediate: false, total: false, positions: false, information: false }, viewerCameraState: null };
      }
      return Object.freeze({ snapshot: snapshot2 });
    });
  }
});

// ../drawing-engine/src/v22-animation-core.js
var require_v22_animation_core = __commonJS({
  "../drawing-engine/src/v22-animation-core.js"(exports, module) {
    (function(root, factory) {
      const api = factory(typeof module === "object" && module.exports ? require_v29_share_contract() : root.PLMRShareContract);
      if (typeof module === "object" && module.exports) module.exports = api;
      root.PLMRAnimationCore = api;
    })(typeof globalThis !== "undefined" ? globalThis : exports, function(shareContract) {
      "use strict";
      const SCHEMA = "plmr-animation-presentation-v1", VERSION = 22, MAX_SCENES = 5, MAX_BYTES = 2 * 1024 * 1024;
      const clone = (x) => JSON.parse(JSON.stringify(x));
      const clamp = (x) => Math.max(0, Math.min(1, x)), ease = (x) => {
        x = clamp(x);
        return x * x * (3 - 2 * x);
      };
      function camera(raw) {
        if (!raw || !["position", "target"].every((k) => Array.isArray(raw[k]) && raw[k].length === 3 && raw[k].every((n) => typeof n === "number" && Number.isFinite(n) && Math.abs(n) <= 1e7))) throw Error("Kamera a\xE7\u0131s\u0131 ge\xE7ersiz.");
        const zoom = raw.zoom === void 0 ? 1 : raw.zoom;
        if (typeof zoom !== "number" || !Number.isFinite(zoom) || zoom < 0.01 || zoom > 100 || Math.hypot(...raw.position.map((v, i) => v - raw.target[i])) < 1) throw Error("Kamera uzakl\u0131\u011F\u0131 veya yak\u0131nla\u015Fmas\u0131 ge\xE7ersiz.");
        if (raw.aspect !== void 0 && (typeof raw.aspect !== "number" || !Number.isFinite(raw.aspect) || raw.aspect < 0.05 || raw.aspect > 20)) throw Error("Kamera ekran oran\u0131 ge\xE7ersiz.");
        if (raw.fov !== void 0 && (!Number.isFinite(raw.fov) || raw.fov < 20 || raw.fov > 120)) throw Error("Kamera g\xF6r\xFC\u015F a\xE7\u0131s\u0131 ge\xE7ersiz.");
        return { position: [...raw.position], target: [...raw.target], zoom, ...raw.fov !== void 0 ? { fov: raw.fov } : {}, ...raw.aspect !== void 0 ? { aspect: raw.aspect } : {} };
      }
      function scenes(raw) {
        if (!Array.isArray(raw) || raw.length < 1 || raw.length > MAX_SCENES) throw Error("Bir ile be\u015F aras\u0131nda sahne se\xE7in.");
        return raw.map((s, i) => ({ name: String(s.name || "Sahne " + (i + 1)).slice(0, 60), camera: camera(s.camera) }));
      }
      function snapshotForShare(raw) {
        return shareContract.snapshot(raw);
      }
      function create(snapshot2, selected, title = "3D Sistem Sunumu") {
        return { schema: SCHEMA, rendererVersion: VERSION, title: String(title || "3D Sistem Sunumu").slice(0, 100), scenes: scenes(selected), snapshot: snapshotForShare(snapshot2) };
      }
      function validate(raw, projectCore) {
        if (!raw || raw.schema !== SCHEMA || raw.rendererVersion !== VERSION) throw Error("Sunum s\xFCr\xFCm\xFC desteklenmiyor.");
        if (new TextEncoder().encode(JSON.stringify(raw)).byteLength > MAX_BYTES) throw Error("Sunum verisi en fazla 2 MB olabilir.");
        projectCore.validateProject({ schema: "plmr-bioclimatic-project-v1", version: 1, snapshot: raw.snapshot });
        return create(raw.snapshot, raw.scenes, raw.title);
      }
      function classifyFacade(items) {
        const opening = (p) => JSON.stringify([p.owner, p.zoneId]);
        const primary = new Set(items.filter((p) => p.type !== "zip").map(opening));
        return items.map((p) => ({ ...p, group: p.type === "zip" && primary.has(opening(p)) ? "canopy" : "sides", movable: p.type !== "fixed" }));
      }
      function timeline(selected, inventory, duration = 5200) {
        const ss = scenes(selected), canopy = inventory.some((p) => p.movable && p.group === "canopy"), sides = inventory.some((p) => p.movable && p.group === "sides"), stages = [];
        let cursor = 0;
        const push = (scene, phase, ms, from, to) => {
          stages.push({ scene, phase, start: cursor, end: cursor + ms, from, to });
          cursor += ms;
        };
        for (let i = 0; i < ss.length; i++) {
          push(i, "closed", 800, 0, 0);
          if (canopy) push(i, "canopy-open", duration, 0, 1);
          if (sides) push(i, "sides-open", duration, 0, 1);
          push(i, "open-hold", 1200, 1, 1);
          if (sides) push(i, "sides-close", duration, 1, 0);
          if (canopy) push(i, "canopy-close", duration, 1, 0);
          push(i, "closed-hold", 800, 0, 0);
          if (i < ss.length - 1) push(i, "transition", 3e3, 0, 1);
        }
        return { scenes: ss, stages, duration: cursor, canopy, sides };
      }
      function sample(plan, ms) {
        const time = Math.max(0, Math.min(plan.duration, Number(ms) || 0)), s = plan.stages.find((s2) => time < s2.end) || plan.stages.at(-1), t = clamp((time - s.start) / (s.end - s.start));
        let canopy = 0, sides = 0;
        if (s.phase === "canopy-open") canopy = t;
        if (["sides-open", "open-hold", "sides-close"].includes(s.phase)) canopy = plan.canopy ? 1 : 0;
        if (s.phase === "sides-open") sides = t;
        if (s.phase === "open-hold") sides = plan.sides ? 1 : 0;
        if (s.phase === "sides-close") sides = 1 - t;
        if (s.phase === "canopy-close") canopy = 1 - t;
        return { time, scene: s.scene, phase: s.phase, canopy, sides, camera: s.phase === "transition" ? interpolateCamera(plan.scenes[s.scene].camera, plan.scenes[s.scene + 1].camera, t) : plan.scenes[s.scene].camera, finished: time >= plan.duration };
      }
      function interpolateCamera(a, b, t) {
        t = ease(t);
        if (t === 0) return camera(a);
        if (t === 1) return camera(b);
        const lerp = (x, y) => x + (y - x) * t, target = a.target.map((x, i) => lerp(x, b.target[i])), spherical = (c) => {
          const v = c.position.map((x, i) => x - c.target[i]), r2 = Math.hypot(...v);
          return { r: r2, theta: Math.atan2(v[0], v[2]), phi: Math.acos(Math.max(-1, Math.min(1, v[1] / r2))) };
        }, A = spherical(a), B = spherical(b);
        const delta = Math.atan2(Math.sin(B.theta - A.theta), Math.cos(B.theta - A.theta)), theta = A.theta + delta * t, phi = lerp(A.phi, B.phi), r = lerp(A.r, B.r);
        return { target, position: [target[0] + r * Math.sin(phi) * Math.sin(theta), target[1] + r * Math.cos(phi), target[2] + r * Math.sin(phi) * Math.cos(theta)], zoom: lerp(a.zoom, b.zoom), ...a.fov !== void 0 || b.fov !== void 0 ? { fov: lerp(a.fov || 38, b.fov || 38) } : {}, ...a.aspect && b.aspect ? { aspect: lerp(a.aspect, b.aspect) } : {} };
      }
      return Object.freeze({ SCHEMA, VERSION, MAX_SCENES, MAX_BYTES, clone, ease, camera, scenes, create, validate, snapshotForShare, classifyFacade, timeline, sample, interpolateCamera });
    });
  }
});

// ../drawing-engine/src/v15-core.js
var require_v15_core = __commonJS({
  "../drawing-engine/src/v15-core.js"(exports, module) {
    (function(root, factory) {
      const api = factory();
      if (typeof module === "object" && module.exports) module.exports = api;
      root.PLMRV15Core = api;
    })(typeof globalThis !== "undefined" ? globalThis : exports, function() {
      "use strict";
      const clone = (x) => JSON.parse(JSON.stringify(x)), clamp = (x) => Math.max(0, Math.min(1, x)), ease = (x) => {
        x = clamp(x);
        return x * x * (3 - 2 * x);
      };
      function positionKey(owner, index) {
        return owner + ":" + (Number(index) || 0);
      }
      function allowed(state, owner, index, key) {
        const d = state || {}, p = d.byPosition?.[positionKey(owner, index)] || {};
        if (d.hiddenIds?.[(owner || "scene") + "|" + (Number(index) || 0) + "|" + key]) return false;
        if (key === "intermediate") return d.intermediate !== false && p.visible !== false && p.intermediate !== false;
        if (key.startsWith("total-")) return d.main !== false && d.total !== false;
        return d.main !== false && d.roofs !== false && d.positions !== false && p.visible !== false && p[key] !== false;
      }
      function balconyLeaf(progress, index, count) {
        const p = clamp(progress), steps = Math.max(1, count * 2 - 1);
        if (index === 0) return { slide: 0, turn: ease(p * steps) };
        return { slide: ease(p * steps - (2 * index - 1)), turn: ease(p * steps - 2 * index) };
      }
      function validateProject(raw) {
        if (!raw || raw.schema !== "plmr-bioclimatic-project-v1" || raw.version !== 1 || !raw.snapshot) throw Error("Bu dosya ge\xE7erli bir Bioclimatic .plmr projesi de\u011Fil.");
        const s = raw.snapshot, m = s.modelState;
        if (s.schema !== "p3dv-host-snapshot-v1" || !m || m.productGroup !== "b-cube") throw Error("Proje t\xFCr\xFC desteklenmiyor.");
        function spec(v) {
          if (!v || ![v.width, v.depth, v.height].every((n) => Number.isFinite(Number(n)) && Number(n) > 0 && Number(n) <= 1e6)) throw Error("Proje \xF6l\xE7\xFCleri ge\xE7ersiz.");
          if (!Number.isInteger(Number(v.systemCount)) || v.systemCount < 1 || v.systemCount > 1e3) throw Error("Proje sistem adedi ge\xE7ersiz.");
          for (const x of Object.values(v.placements || {})) if (!["sliding", "folding", "balcony", "guillotine", "zip", "door", "fixed"].includes(x.type)) throw Error("Proje \xFCr\xFCn t\xFCr\xFC ge\xE7ersiz.");
        }
        if (m.systemSelection) {
          const q = m.systemSelection;
          if (!["meru", "zagro", "artos", "suphan", "antero", "teton", "cervin", "jura"].includes(q.id) || typeof q.locked !== "boolean" || !q.applied || typeof q.applied !== "object" || Array.isArray(q.applied) || Object.values(q.applied).some((v) => typeof v !== "boolean")) throw Error("Proje sistem se\xE7imi ge\xE7ersiz.");
        }
        if (m.codeRegistry) {
          const q = m.codeRegistry, prefixes = ["BIO", "GU", "SL", "FG", "ZS", "AG", "FJ", "DO"];
          if (!q.items || !q.next || typeof q.items !== "object" || typeof q.next !== "object" || Array.isArray(q.items) || Array.isArray(q.next) || Object.values(q.items).some((e) => !e || !prefixes.includes(e.prefix) || typeof e.owner !== "string" || !new RegExp("^" + e.prefix + "-[0-9]+$").test(e.code) || Number(e.code.split("-")[1]) < 1) || Object.entries(q.next).some(([k, v]) => !prefixes.includes(k) || !Number.isSafeInteger(v) || v < 1)) throw Error("Proje \xFCr\xFCn kodlar\u0131 ge\xE7ersiz.");
        }
        const nativeWorks = m.sceneEditor?.nativeWorkspaces || {};
        for (const [type, w] of Object.entries(nativeWorks)) {
          globalThis.PLMRV24Native?.validateStoredWorkspace(type, w);
        }
        const nativeDrawing = Object.values(nativeWorks).some((w) => w.positions?.length);
        const emptyMain = [m.width, m.height].every((n) => n == null || Number(n) === 0) && Number.isFinite(Number(m.depth)) && Number(m.depth) >= 0 && Number(m.depth) <= 1e6 && !Object.keys(m.placements || {}).length && !Object.keys(m.zipPlacements || {}).length;
        if (!(emptyMain || nativeDrawing && ![m.width, m.depth, m.height].every((n) => Number(n) > 0))) spec(m);
        const copies = m.sceneEditor?.roofCopies || [];
        if (!Array.isArray(copies) || copies.length > 1e3) throw Error("Proje poz listesi ge\xE7ersiz.");
        const ids = /* @__PURE__ */ new Set(["roof-main"]);
        for (const c of copies) {
          if (!c.id || ids.has(c.id)) throw Error("Proje poz kimli\u011Fi ge\xE7ersiz.");
          ids.add(c.id);
          spec(c.spec);
          for (const n of Object.values(c.pose || {})) if (!Number.isFinite(Number(n))) throw Error("Proje konumu ge\xE7ersiz.");
        }
        function check(v) {
          if (!v || typeof v !== "object") return;
          for (const [k, x] of Object.entries(v)) {
            if (["__proto__", "constructor", "prototype"].includes(k)) throw Error("Proje alan\u0131 ge\xE7ersiz.");
            if (typeof x === "number" && !Number.isFinite(x)) throw Error("Proje de\u011Feri ge\xE7ersiz.");
            check(x);
          }
        }
        check(raw);
        return clone(raw);
      }
      function encode(snapshot2) {
        return JSON.stringify({ schema: "plmr-bioclimatic-project-v1", version: 1, applicationVersion: "1.29.0", savedAt: (/* @__PURE__ */ new Date()).toISOString(), snapshot: clone(snapshot2) }, null, 2);
      }
      function decode(text3) {
        if (typeof text3 !== "string" || text3.length > 20 * 1024 * 1024) throw Error("Proje dosyas\u0131 en fazla 20 MB olabilir.");
        let raw;
        try {
          raw = JSON.parse(text3.replace(/^\uFEFF/, ""));
        } catch (_) {
          throw Error("Proje dosyas\u0131 okunamad\u0131; ge\xE7erli metin bekleniyor.");
        }
        return validateProject(raw);
      }
      return Object.freeze({ clone, positionKey, allowed, balconyLeaf, validateProject, encode, decode });
    });
  }
});

// ../Cloud/catalogWebp.ts
function inspectCatalogWebp(bytes) {
  const text3 = (a, b) => new TextDecoder().decode(bytes.slice(a, b));
  if (bytes.length < 25 || bytes.length > 2 * 1024 * 1024 || text3(0, 4) !== "RIFF" || text3(8, 12) !== "WEBP")
    throw Error("INVALID_WEBP");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (view.getUint32(4, true) + 8 !== bytes.length)
    throw Error("INVALID_WEBP_SIZE");
  let width = 0, height = 0, lossless = false, frame = false;
  for (let offset = 12; offset + 8 <= bytes.length; ) {
    const size = view.getUint32(offset + 4, true), at = offset + 8;
    if (size > bytes.length - at) throw Error("INVALID_WEBP_CHUNK");
    const type = text3(offset, offset + 4);
    if (type === "ANIM" || type === "ANMF")
      throw Error("ANIMATED_CATALOG_IMAGE_NOT_ALLOWED");
    if (type === "VP8X" && size >= 10) {
      width = 1 + bytes[at + 4] + (bytes[at + 5] << 8) + (bytes[at + 6] << 16);
      height = 1 + bytes[at + 7] + (bytes[at + 8] << 8) + (bytes[at + 9] << 16);
    }
    if (type === "VP8L" && size >= 5 && bytes[at] === 47) {
      const bits = view.getUint32(at + 1, true);
      width = (bits & 16383) + 1;
      height = (bits >>> 14 & 16383) + 1;
      lossless = true;
      frame = true;
    }
    if (type === "VP8 " && size >= 10) {
      width = view.getUint16(at + 6, true) & 16383;
      height = view.getUint16(at + 8, true) & 16383;
      frame = true;
    }
    offset = at + size + size % 2;
  }
  if (!frame || width !== 512 || height !== 512)
    throw Error("CATALOG_IMAGE_MUST_BE_512_WEBP");
  return { width, height, lossless };
}

// ../Cloud/edge-v21.ts
import { createClient } from "npm:@supabase/supabase-js@2.95.0";

// domain/stock.ts
var stockCatalogKeys = {
  profile: "plmr.productMaster.profiles.v11",
  accessory: "plmr.productMaster.accessories.v11",
  glass: "plmr.productMaster.glass.v11"
};
var emptyStock = () => ({ balances: [], movements: [] });
var stockKey = (l) => [l.kind, l.materialId, l.lengthMm].join(":");
function validateStockCommand(command) {
  if (!command || typeof command.id !== "string" || !/^[a-f0-9-]{36}$/i.test(command.id) || !["IN", "OUT"].includes(command.direction) || typeof command.note !== "string" || command.note.length > 250 || !Array.isArray(command.lines) || command.lines.length < 1 || command.lines.length > 500)
    throw Error("Stok hareketi ge\xE7ersiz. Bir i\u015Flemde 1\u2013500 sat\u0131r girin.");
  const keys = /* @__PURE__ */ new Set();
  for (const l of command.lines) {
    if (!l || !Object.hasOwn(stockCatalogKeys, l.kind) || typeof l.materialId !== "string" || !/^[A-Za-z0-9_-]{1,160}$/.test(l.materialId) || !Number.isFinite(l.quantity) || l.quantity <= 0 || l.quantity > 1e6 || Number(l.quantity.toFixed(3)) !== l.quantity || (l.kind === "profile" ? !Number.isSafeInteger(l.lengthMm) || l.lengthMm < 1 || l.lengthMm > 3e4 || !Number.isSafeInteger(l.quantity) : l.lengthMm !== null))
      throw Error("Malzeme, boy veya miktar ge\xE7ersiz. Profil boyu mm, miktar\u0131 tam adet olmal\u0131d\u0131r.");
    const key = stockKey(l);
    if (keys.has(key)) throw Error("Ayn\u0131 malzeme ve boy birden fazla sat\u0131rda var.");
    keys.add(key);
  }
}
function existingStockMovement(state, command) {
  const existing = state.movements.find((m) => m.id === command.id);
  if (!existing) return false;
  const signature = (x) => JSON.stringify([x.direction, x.note, x.lines.map((l) => [stockKey(l), l.quantity]).sort((a, b) => String(a[0]).localeCompare(String(b[0])))]);
  if (signature(existing) !== signature(command)) throw Error("Hareket kimli\u011Fi daha \xF6nce farkl\u0131 bir i\u015Flemde kullan\u0131ld\u0131.");
  return true;
}
function applyStockMovement(state, command, by, at) {
  validateStockCommand(command);
  if (existingStockMovement(state, command)) return state;
  const balances = new Map(state.balances.map((l) => [stockKey(l), l])), sign = command.direction === "IN" ? 1 : -1;
  for (const l of command.lines) {
    const key = stockKey(l), quantity = Number(((balances.get(key)?.quantity || 0) + sign * l.quantity).toFixed(3));
    if (quantity < 0) throw Error("Stok miktar\u0131 yetersiz. Hareketin hi\xE7bir sat\u0131r\u0131 kaydedilmedi.");
    balances.set(key, { ...l, quantity });
  }
  return { balances: [...balances.values()], movements: [{ ...command, at, actorId: by.id, actorName: by.name }, ...state.movements] };
}

// domain/documentIdentity.ts
function sameDocument(a, b) {
  if (a === b) return true;
  if (Array.isArray(a) || Array.isArray(b))
    return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((value, i) => i in b && sameDocument(value, b[i])) && b.every((_, i) => i in a);
  if (a && typeof a === "object" || b && typeof b === "object") {
    if (!a || typeof a !== "object" || !b || typeof b !== "object") return false;
    const left = a, right = b;
    const keys = Object.keys(left).filter((key) => left[key] !== void 0);
    return keys.length === Object.keys(right).filter((key) => right[key] !== void 0).length && keys.every((key) => Object.hasOwn(right, key) && right[key] !== void 0 && sameDocument(left[key], right[key]));
  }
  return (JSON.stringify(a) ?? "null") === (JSON.stringify(b) ?? "null");
}

// ../Cloud/catalog.ts
var CATALOG_KEYS = [
  "plmr.productMaster.profiles.v11",
  "plmr.productMaster.accessories.v11",
  "plmr.productMaster.glass.v11"
];
var isMaterialCatalog = (key) => CATALOG_KEYS.includes(key);
async function visibleMaterials(value, can) {
  if (!Array.isArray(value)) throw Error("CATALOG_ARRAY_REQUIRED");
  const cost = await can("product.cost.view"), price = cost || await can("commercial.price.view");
  return value.map((row) => {
    const out = { ...row };
    if (!cost) delete out.cost;
    if (!price) {
      delete out.sellingPrice;
      delete out.legacySellingPrice;
    }
    return out;
  });
}
async function validateMaterials(db, cid, key, previous, next, can) {
  if (!isMaterialCatalog(key) || !Array.isArray(next) || next.length > 5e4)
    throw Error("INVALID_CATALOG");
  const old = Array.isArray(previous) ? previous : [], id = key.includes("profiles") ? "profileId" : key.includes("accessories") ? "accessoryId" : "glassId", codes = /* @__PURE__ */ new Set(), ids = /* @__PURE__ */ new Set();
  const cost = await can("product.cost.view"), price = cost || await can("commercial.price.view");
  const result = [];
  for (const input of next) {
    const row = { ...input }, before = old.find((r) => r[id] === row[id]);
    if (!row[id] || typeof row[id] !== "string" || ids.has(row[id]))
      throw Error("DUPLICATE_MATERIAL_ID");
    ids.add(row[id]);
    const code = String(row.code || "").trim().toLocaleUpperCase("tr-TR");
    if (!code || codes.has(code)) throw Error("DUPLICATE_MATERIAL_CODE");
    codes.add(code);
    row.code = code;
    if (!row.descriptionTr || !row.unit || !["active", "inactive"].includes(row.status) || !["TRY", "USD", "EUR", "GBP"].includes(row.costCurrency))
      throw Error("INVALID_MATERIAL");
    for (const field of [
      "cost",
      "sellingPrice",
      "legacySellingPrice",
      "unitWeight",
      "standardLength",
      "totalThickness"
    ])
      if (row[field] != null && (typeof row[field] !== "number" || !Number.isFinite(row[field]) || row[field] < 0))
        throw Error("INVALID_MATERIAL_NUMBER");
    if (before?.status !== row.status && before && !await can("product.deactivate"))
      throw Error("CATALOG_STATUS_DENIED");
    for (const field of ["cost", "sellingPrice", "legacySellingPrice"])
      if (!(field === "cost" ? cost : price)) {
        if (row[field] != null && row[field] !== before?.[field])
          throw Error("CATALOG_PRICE_DENIED");
        if (before && Object.prototype.hasOwnProperty.call(before, field))
          row[field] = before[field];
        else delete row[field];
      }
    const unchanged = before && Object.keys({ ...before, ...row }).every(
      (k) => JSON.stringify(before[k]) === JSON.stringify(row[k])
    );
    if (!unchanged && !await can(before ? "product.edit" : "product.create"))
      throw Error("CATALOG_WRITE_DENIED");
    if (row.image?.storage) {
      const ref = row.image.storage, media = await db.get(cid + ":catalog.media", String(ref.id));
      if (ref.companyId !== cid || !media.value || !sameDocument(media.value.storage, ref))
        throw Error("CATALOG_IMAGE_DENIED");
    } else if (row.image && JSON.stringify(row.image) !== JSON.stringify(before?.image))
      throw Error("CATALOG_STORAGE_IMAGE_REQUIRED");
    result.push(row);
  }
  for (const row of old)
    if (!ids.has(row[id])) {
      if (codes.has(String(row.code).toLocaleUpperCase("tr-TR")))
        throw Error("MATERIAL_ID_CHANGED");
      result.push(row);
    }
  return result;
}
async function catalogAction(db, input, cid, can) {
  if (input.action === "catalog_commit") {
    const key = String(input.key);
    if (!isMaterialCatalog(key)) throw Error("INVALID_CATALOG");
    const prior = await db.get(cid, key);
    if (prior.version !== input.expectedVersion)
      throw Error("Katalog ba\u015Fka bir oturumda de\u011Fi\u015Fti. Yeniden a\xE7\u0131p y\xFCkleyin.");
    const rows = await validateMaterials(
      db,
      cid,
      key,
      prior.value ? JSON.parse(String(prior.value)) : [],
      input.rows,
      can
    ), saved = await db.cas(cid, key, JSON.stringify(rows), prior.version);
    return {
      value: JSON.stringify(await visibleMaterials(rows, can)),
      version: saved.version
    };
  }
  if (input.action === "catalog_media_upload") {
    if (!await can("product.edit") && !await can("product.create"))
      throw Error("CATALOG_UPLOAD_DENIED");
    if (!db.uploadCatalogMedia) throw Error("CATALOG_STORAGE_NOT_INSTALLED");
    const image = await db.uploadCatalogMedia(cid, input);
    await db.cas(cid + ":catalog.media", image.storage.id, image, 0);
    return image;
  }
  if (input.action === "catalog_media_url" || input.action === "catalog_media_urls") {
    if (!await can("product.view") && !await can("operations.view"))
      throw Error("CATALOG_READ_DENIED");
    const bulk = input.action === "catalog_media_urls";
    const ids = bulk ? input.ids : [input.id];
    if (!Array.isArray(ids) || !ids.length || ids.length > 32 || ids.some((id) => typeof id !== "string" || !/^[a-f0-9-]{36}$/.test(id))) throw Error("INVALID_MEDIA_ID");
    const unique = [...new Set(ids)], scope = cid + ":catalog.media";
    const rows = db.getMany ? await db.getMany(scope, unique) : await Promise.all(unique.map((id) => db.get(scope, id)));
    const paths = /* @__PURE__ */ new Map();
    for (const row of rows) {
      if (!row.value) continue;
      const storage = row.value.storage;
      if (!storage || storage.companyId !== cid || !storage.path.startsWith(cid + "/")) throw Error("INVALID_MEDIA_PATH");
      paths.set(row.key, storage.path);
    }
    const wanted = [...paths.values()];
    const urls = !wanted.length ? [] : bulk && db.catalogMediaUrls ? await db.catalogMediaUrls(wanted) : await Promise.all(wanted.map((path) => {
      if (!db.catalogMediaUrl) throw Error("CATALOG_STORAGE_NOT_INSTALLED");
      return db.catalogMediaUrl(path);
    }));
    const byPath = new Map(wanted.map((path, i) => [path, urls[i]]));
    const result = Object.fromEntries(unique.map((id) => {
      const url2 = byPath.get(paths.get(id) ?? "");
      return [id, url2 ? { url: url2 } : { url: null, missing: true }];
    }));
    return bulk ? result : result[unique[0]];
  }
  throw Error("INVALID_CATALOG_ACTION");
}

// domain/project.ts
function activeRevision(project) {
  const rows = project.revisions || [];
  return rows.find((row) => row.revisionId === project.revisionId) || rows.find((row) => row.label === project.revizyon);
}
function projectStatusAsProduction(status) {
  return status === 30 || status === 40 || status === 50 || status === 60 ? status : 20;
}
function syncProductionItemsFromActiveRevision(project, fallbackStatus) {
  const revision = activeRevision(project);
  const workspace = revision?.workspaceState || {};
  const workspaceRows = workspace.productWorkspaces && typeof workspace.productWorkspaces === "object" ? Object.values(workspace.productWorkspaces).map((row) => ({ product: String(row.product || "\xDCr\xFCn"), positions: Array.isArray(row.positions) ? row.positions : [] })) : [{ product: String(workspace.product || project.urunler?.[0] || "\xDCr\xFCn"), positions: Array.isArray(workspace.positions) ? workspace.positions : [] }];
  const canonical = workspaceRows.flatMap((row) => row.positions.map((position, index) => ({ product: row.product, position, index })));
  if (!canonical.length) return project.productionItems;
  const saved = revision?.revisionId ? project.productionPackages?.[revision.revisionId] : void 0;
  const savedPackage = saved?.package || {};
  const packagedIds = new Set(Array.isArray(savedPackage.positions) ? savedPackage.positions.map((row) => String(row.positionId || "")) : []);
  const packageErrors = /* @__PURE__ */ new Map();
  if (Array.isArray(savedPackage.validation?.errors)) for (const error of savedPackage.validation.errors) {
    if (error?.positionId) packageErrors.set(String(error.positionId), String(error.message || error.code || "\xDCretim paketi bu poz i\xE7in tamamlanamad\u0131."));
  }
  const existingBySource = new Map(project.productionItems.filter((item) => item.sourcePositionId).map((item) => [String(item.sourcePositionId), item]));
  const existingByCode = new Map(project.productionItems.map((item) => [`${item.urun}::${item.kod}`, item]));
  const legacySingleProduct = workspaceRows.length === 1;
  const existingByCodeOnly = new Map(project.productionItems.map((item) => [item.kod, item]));
  const defaultStatus = fallbackStatus || projectStatusAsProduction(project.status);
  return canonical.map(({ product, position, index }) => {
    const sourcePositionId = String(position.id || `legacy-${product}-${index + 1}`);
    const code = String(position.positionNo || `P${String(index + 1).padStart(2, "0")}`);
    const previous = existingBySource.get(sourcePositionId) || existingByCode.get(`${product}::${code}`) || (legacySingleProduct ? existingByCodeOnly.get(code) : void 0);
    const productionPackageCapable = product === "Giyotin";
    let teknikTamamlandi = productionPackageCapable ? "pending" : previous?.teknikTamamlandi || "drawing_attached";
    let technicalDetail = productionPackageCapable ? "\xC7izim ve poz verisi kay\u0131tl\u0131; aktif revizyonun \xFCretim paketi hen\xFCz kaydedilmedi." : previous?.technicalDetail || "Kaydedilmi\u015F \xE7izim ve poz verisi mevcut. Bu \xFCr\xFCn i\xE7in otomatik \xFCretim paketi re\xE7etesi hen\xFCz tan\u0131ml\u0131 de\u011Fil.";
    if (productionPackageCapable && saved) {
      const error = packageErrors.get(sourcePositionId);
      if (error) {
        teknikTamamlandi = "pending";
        technicalDetail = `\xDCretim paketi eksik: ${error}`;
      } else if (packagedIds.has(sourcePositionId)) {
        teknikTamamlandi = "complete";
        technicalDetail = `${revision?.label || project.revizyon} \xFCretim paketi kaydedildi.`;
      } else {
        teknikTamamlandi = "pending";
        technicalDetail = "\xDCretim paketi kaydedildi ancak bu poz pakete dahil edilmedi.";
      }
    }
    return {
      id: previous?.id || `${project.id}-POS-${sourcePositionId}`,
      sourcePositionId,
      kod: code,
      urun: product,
      miktar: Math.max(0, Number(position.quantity) || 0),
      status: previous?.status || defaultStatus,
      teknikTamamlandi,
      technicalDetail,
      milestones: { ...previous?.milestones || {} }
    };
  });
}
function assertLockedProductionHistory(existing, next) {
  if (!existing) return;
  for (const [revisionId, savedPackage] of Object.entries(existing.productionPackages || {})) {
    const oldRevision = existing.revisions?.find((revision) => revision.revisionId === revisionId);
    const nextRevision = next.revisions?.find((revision) => revision.revisionId === revisionId);
    if (!sameDocument(savedPackage, next.productionPackages?.[revisionId]) || oldRevision && !sameDocument(oldRevision, nextRevision)) {
      throw new Error("Kaydedilmi\u015F \xFCretim paketi ve kaynak revizyonu de\u011Fi\u015Ftirilemez.");
    }
  }
}

// domain/commercialProducts.ts
var COMMERCIAL_PRODUCTS = Object.freeze([
  {
    "id": "9ada7dd6-b452-5500-bcf4-70defd307958",
    "code": "PLMRSYSTEM01000100",
    "group": "01",
    "name": "Tilt & Retract Aluminium",
    "referenceKey": "zagro",
    "quoteEngine": "Zagro Motion"
  },
  {
    "id": "3d5baf86-3ec8-5266-8e41-818a678c9404",
    "code": "PLMRSYSTEM01000200",
    "group": "01",
    "name": "Tilt Aluminium",
    "referenceKey": "artos",
    "quoteEngine": "Artos Tilt"
  },
  {
    "id": "d83c7ceb-5f4e-525a-9f05-8bc1834bb35e",
    "code": "PLMRSYSTEM01000300",
    "group": "01",
    "name": "Retract Aluminium",
    "referenceKey": "suphan",
    "quoteEngine": "Suphan Glide"
  },
  {
    "id": "32f09a31-5a93-5c63-b31c-502dfce905ba",
    "code": "PLMRSYSTEM01000400",
    "group": "01",
    "name": "Retract uPVC Fabric",
    "referenceKey": "antero",
    "quoteEngine": "Antero Pergola"
  },
  {
    "id": "74c19415-9174-5874-add5-f22ae1892085",
    "code": "PLMRSYSTEM01000500",
    "group": "01",
    "name": "Tilt Aluminium (Eco)",
    "referenceKey": "teton",
    "quoteEngine": "Teton Eco Tilt"
  },
  {
    "id": "63cc5e11-76c7-52fd-a9ab-7020b5b0a36b",
    "code": "PLMRSYSTEM01000600",
    "group": "01",
    "name": "Veranda - Glass",
    "referenceKey": "cervin",
    "quoteEngine": "Cervin Fix"
  },
  {
    "id": "60897e30-7228-5df9-9825-2fa63a64d033",
    "code": "PLMRSYSTEM01000700",
    "group": "01",
    "name": "Veranda - Sandwich Panel",
    "referenceKey": "jura",
    "quoteEngine": "Jura Fix"
  },
  {
    "id": "61cd82d3-7b5d-5c73-98f7-33b2176a7419",
    "code": "PLMRSYSTEM02000100",
    "group": "02",
    "name": "Giyotin",
    "referenceKey": "guillotine",
    "quoteEngine": "Giyotin"
  },
  {
    "id": "7f97f427-5d22-5b7e-8f4a-a373a04eee26",
    "code": "PLMRSYSTEM02000200",
    "group": "02",
    "name": "S\xFCrme",
    "referenceKey": "sliding",
    "quoteEngine": "S\xFCrme"
  },
  {
    "id": "1b0301e2-3bf6-5557-b5bc-0fa982b8e21b",
    "code": "PLMRSYSTEM02000300",
    "group": "02",
    "name": "Katlan\u0131r Cam",
    "referenceKey": "balcony",
    "quoteEngine": "Katlan\u0131r Cam"
  },
  {
    "id": "6620f3b9-783c-54a4-8a12-dbfa94eaad92",
    "code": "PLMRSYSTEM02000400",
    "group": "02",
    "name": "Akordiyon Cam",
    "referenceKey": "folding",
    "quoteEngine": "Akordiyon Cam"
  },
  {
    "id": "f8832aac-d488-503c-9cd6-1b07c0befb7b",
    "code": "PLMRSYSTEM02000500",
    "group": "02",
    "name": "Sabit Do\u011Frama",
    "referenceKey": "fixed",
    "quoteEngine": "Sabit Do\u011Frama"
  },
  {
    "id": "ca12f963-d67e-58d5-811f-ddb59a62c131",
    "code": "PLMRSYSTEM02000600",
    "group": "02",
    "name": "Kap\u0131",
    "referenceKey": "door",
    "quoteEngine": "Kap\u0131"
  },
  {
    "id": "71206fb7-a7a7-5fe0-8677-8f9709587d0e",
    "code": "PLMRSYSTEM03000100",
    "group": "03",
    "name": "Zip Perde",
    "referenceKey": "zip",
    "quoteEngine": "Zip Perde"
  }
].map((product) => Object.freeze(product)));
function commercialProduct(id) {
  return commercialProducts().find((p) => p.id === id);
}
function requireCommercialProduct(id) {
  const product = commercialProduct(id);
  if (!product) throw new Error("\xDCr\xFCn ID merkezi listede bulunamad\u0131. Yeni \xFCr\xFCn i\xE7in merkezi kod tan\u0131m\u0131 istenmelidir.");
  return product;
}
function commercialProductForEngine(engine) {
  return commercialProducts().find((p) => p.quoteEngine === engine);
}
function assertCommercialIdentity(row) {
  if (row.productId && requireCommercialProduct(row.productId).quoteEngine !== row.engine) throw new Error("\xDCr\xFCn ID ve sistem tan\u0131m\u0131 uyu\u015Fmuyor.");
}
var COMMERCIAL_REGISTRY_KEY = "plmr.commercial.products.v75";
function commercialProducts() {
  if (typeof localStorage === "undefined") return COMMERCIAL_PRODUCTS;
  const raw = globalThis.localStorage.getItem(COMMERCIAL_REGISTRY_KEY);
  if (!raw) return COMMERCIAL_PRODUCTS;
  const custom = JSON.parse(raw);
  if (!Array.isArray(custom)) throw new Error("Merkezi \xFCr\xFCn listesi okunamad\u0131; kay\u0131tlar korunmu\u015Ftur.");
  const all2 = [...COMMERCIAL_PRODUCTS, ...custom], ids = /* @__PURE__ */ new Set(), codes = /* @__PURE__ */ new Set();
  for (const p of all2) {
    if (!p.id || !p.name?.trim() || !["01", "02", "03"].includes(p.group) || !new RegExp("^PLMRSYSTEM" + p.group + "[0-9]{4}00$").test(p.code) || !p.quoteEngine || ids.has(p.id) || codes.has(p.code)) throw new Error("Merkezi \xFCr\xFCn kimlikleri ge\xE7ersiz; kay\u0131tlar korunmu\u015Ftur.");
    ids.add(p.id);
    codes.add(p.code);
  }
  return all2.map((p) => Object.freeze({ ...p }));
}

// domain/glass.ts
var INSULATED_GLASS_COMBINATION = "4mm TEMP.+12mm HB+4mm TEMP.";

// domain/drawing.ts
var DEFAULT_GUILLOTINE_SETTINGS = {
  systemType: "Standart",
  mechanism: "Zincir",
  glassType: "Is\u0131cam",
  glassThickness: INSULATED_GLASS_COMBINATION,
  glassThicknessOther: "",
  glassColor: "\u015Eeffaf",
  glassColorOther: "",
  panelLayout: "1+2",
  fixedPanelHeightMode: "Standart",
  fixedPanelHeightCustom: "",
  systemColor: "Varsay\u0131lan",
  surface: "Varsay\u0131lan",
  defaultView: "Di\u011Fer",
  defaultMotorDirection: "Di\u011Fer",
  motor: "Somfy RTS",
  remote: "Di\u011Fer",
  remoteQuantity: "0"
};

// domain/finalProcess.ts
function finalIdentity(referenceKey) {
  const p = COMMERCIAL_PRODUCTS.find((p2) => p2.referenceKey === referenceKey);
  if (!p)
    throw Error("\xC7izim motorunun ticari \xFCr\xFCn kimli\u011Fi bulunamad\u0131: " + referenceKey);
  return p;
}
function isFinalProduct(engine) {
  return !!commercialProductForEngine(engine);
}
function assertFinalScene(value) {
  const s = value;
  if (!s || s.schema !== "p3dv-host-snapshot-v1" || !s.modelState || typeof s.modelState !== "object" || Array.isArray(s.modelState))
    throw Error("V29 \xE7izim kayd\u0131 ge\xE7ersiz; mevcut proje korunmu\u015Ftur.");
  if (JSON.stringify(s).length > 20 * 1024 * 1024)
    throw Error("\xC7izim kayd\u0131 en fazla 20 MB olabilir.");
  const model = s.modelState;
  for (const key of Object.keys(model.sceneEditor?.nativeWorkspaces || {}))
    if (!COMMERCIAL_PRODUCTS.some((p) => p.referenceKey === key))
      throw Error("Desteklenmeyen yan \xFCr\xFCn: " + key);
}
function finalTechnicalScene(snapshot2) {
  const model = structuredClone(snapshot2.modelState), m = model;
  function clean(spec) {
    for (const key of ["productsOpen", "productOpenStates", "panelStates", "panelMasterOpen", "inputDrafts", "initialDimensions"])
      delete spec[key];
    const scene = spec.sceneEditor;
    if (!scene)
      return;
    for (const key of ["sharedProductLayout", "dimensionUnits", "templates", "environment", "initialRoofOpen", "viewMode", "camera", "presentation"])
      delete scene[key];
    for (const config of Object.values(scene.roofProducts || {})) {
      delete config.open;
      delete config.initialOpen;
    }
    for (const ws of Object.values(scene.nativeWorkspaces || {})) {
      delete ws.projectInfo;
      delete ws.drawingLayout;
      for (const p of ws.positions || []) {
        delete p.open;
        delete p.progress;
      }
    }
    for (const c of scene.roofCopies || [])
      clean(c.spec);
  }
  clean(m);
  return model;
}
function assertFinalQuoteReady(record) {
  if (!record.drawingScene)
    return;
  const rows = record.sceneRows || [];
  const pending2 = rows.find((row) => row.placementStatus === "unresolved");
  if (pending2) throw Error(pending2.poz + ": \xD6nce yerle\u015Fimi bekleyen \xFCr\xFCn\xFC bir a\xE7\u0131kl\u0131\u011Fa yerle\u015Ftirin veya silin.");
  for (const row of rows) {
    if (row.kind === "frame" && !rows.some((r) => r.kind === "roof" && r.owner === row.owner && r.moduleIndex === row.moduleIndex))
      throw Error(row.poz + ": \xC7er\xE7eve i\xE7in tavan \xFCr\xFCn\xFC se\xE7in. Ticari kimli\u011Fi olmayan \xE7er\xE7eve fiyat teklifinden sessizce \xE7\u0131kar\u0131lamaz.");
  }
  for (const row of rows)
    if (row.referenceKey)
      finalIdentity(row.referenceKey);
}

// domain/giyotinColor.ts
var DEFAULT_COLOR_VALUE = "Varsay\u0131lan";
function isDefaultMaterialValue(value) {
  const normalized = String(value ?? "").trim().toLocaleUpperCase("tr-TR");
  return normalized === "DEFAULT" || normalized === "VARSAYILAN";
}
function resolveColorFamily(code) {
  return /^A-/i.test(String(code).trim()) ? "WOOD_TRANSFER" : "STANDARD_COLOR";
}
function canonicalSurface(code, surface) {
  if (isDefaultMaterialValue(code)) return DEFAULT_COLOR_VALUE;
  if (resolveColorFamily(code) === "WOOD_TRANSFER") return "Wood Transfer";
  return ["Parlak", "Mat", "Texture"].includes(surface) ? surface : "";
}

// domain/sliding.ts
var DEFAULT_SLIDING_SETTINGS = { systemColor: "Varsay\u0131lan", surface: "Varsay\u0131lan", series: "A SERIES", type: "OTHER", glassType: "OTHER", glassThickness: "OTHER", customGlassThickness: "", glassColor: "TRANSPARENT", customGlassColor: "", slidingView: "OTHER", openingType: "", openingDirection: "OTHER", panelCountMode: "AUTO", panelCount: 4, variableSelections: {} };
var slidingState = () => window.PLMRSurmeState;
function resolveSliding(settings, p) {
  const { systemColor, surface, variableSelections, ...options } = settings;
  const { systemColor: positionColor, surface: positionSurface, ...positionOptions } = p?.overrides || {};
  const { collectionState, ...resolved } = slidingState().normalizeOptions({ ...options, ...positionOptions }, { width: Number(p?.width) || 3e3 });
  return resolved;
}
function resolveSlidingMaterial(settings, p) {
  const systemColor = p?.overrides?.systemColor ?? settings.systemColor;
  return { systemColor, surface: canonicalSurface(systemColor, p?.overrides?.surface ?? settings.surface) };
}

// domain/giyotinRemotes.ts
var remoteLabel = (value) => value.replace(/ Kanal$/, " Kanall\u0131");
function remoteSelections(settings) {
  return [{ remote: settings.remote, quantity: settings.remoteQuantity }, ...settings.additionalRemotes || []].map((item) => ({ ...item }));
}
function validateAdditionalRemotes(settings) {
  return (settings.additionalRemotes || []).every((item) => Boolean(item.remote.trim()) && /^\d+$/.test(item.quantity) && Number.isSafeInteger(Number(item.quantity)) && Number(item.quantity) > 0);
}

// domain/giyotinValidation.ts
function validateGiyotinSettings(next) {
  if (!canonicalSurface(next.systemColor, next.surface)) return "Y\xFCzey se\xE7imi zorunludur.";
  if (!/^\d+$/.test(next.remoteQuantity)) return "Kumanda adedi yaln\u0131z tam say\u0131 olabilir.";
  if (!validateAdditionalRemotes(next)) return "Ek kumandalar i\xE7in t\xFCr ve pozitif tam say\u0131 adet girin.";
  if (next.glassThickness === "Di\u011Fer" && !next.glassThicknessOther?.trim()) return "Cam Kal\u0131nl\u0131\u011F\u0131 = Di\u011Fer i\xE7in cam kal\u0131nl\u0131\u011F\u0131 veya kombinasyonunu girin.";
  if (next.glassColor === "Di\u011Fer" && !next.glassColorOther.trim()) return "Cam Rengi = Di\u011Fer se\xE7ildi\u011Finde \xF6zel cam rengi girilmelidir.";
  if (next.fixedPanelHeightMode === "Di\u011Fer" && (!/^\d+$/.test(next.fixedPanelHeightCustom) || Number(next.fixedPanelHeightCustom) <= 0 || next.fixedPanelHeightCustom.length > 4)) return "\xD6zel Sabit Panel Y\xFCksekli\u011Fi 1-9999 mm aras\u0131nda pozitif tam say\u0131 olmal\u0131d\u0131r.";
  return null;
}

// domain/customer.ts
function uuidv7(now = Date.now()) {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  let timestamp = BigInt(now);
  for (let i = 5; i >= 0; i--) {
    bytes[i] = Number(timestamp & 0xffn);
    timestamp >>= 8n;
  }
  bytes[6] = bytes[6] & 15 | 112;
  bytes[8] = bytes[8] & 63 | 128;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0"));
  return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10).join("")}`;
}

// domain/companyPricing.ts
var round = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
function validatePriceRow(row) {
  assertCommercialIdentity(row);
  if (!row.productId && !row.productCode.trim() || !row.productName.trim() || !row.engine.trim()) throw new Error("\xDCr\xFCn se\xE7imi, \xFCr\xFCn kodu ve ad\u0131 zorunludur.");
  if (!["TRY", "USD", "EUR", "GBP"].includes(row.currency)) throw new Error("Ge\xE7erli para birimi se\xE7in.");
  for (const value of [row.areaPrice, row.listPrice, row.discountPercent, row.costPrice]) if (!Number.isFinite(value) || value < 0) throw new Error("Fiyat ve iskonto s\u0131f\u0131r veya pozitif say\u0131 olmal\u0131d\u0131r.");
  if (row.discountPercent > 100) throw new Error("Liste iskontosu %0\u2013100 olmal\u0131d\u0131r.");
  for (const item of row.additions) {
    if (!item.label.trim() || !["PERCENT", "AMOUNT"].includes(item.mode) || !["FACTORY", "SUBTOTAL"].includes(item.basis) || !Number.isFinite(item.value) || item.value < 0) throw new Error("Ek fiyat kalemini kontrol edin.");
  }
  if (new Set(row.additions.map((a) => a.id)).size !== row.additions.length) throw new Error("Ek fiyat kalemleri tekrar edemez.");
}
function calculateProductPrice(snapshot2, widthMm, heightMm) {
  const row = snapshot2.row;
  validatePriceRow(row);
  const area = widthMm * heightMm / 1e6;
  if (!(widthMm > 0 && heightMm > 0 && Number.isFinite(area))) throw new Error("Fiyat i\xE7in ge\xE7erli geni\u015Flik ve y\xFCkseklik girin.");
  let factory = snapshot2.method === "AREA" ? area * row.areaPrice : snapshot2.method === "LIST_DISCOUNT" ? row.listPrice * (1 - row.discountPercent / 100) : snapshot2.method === "COST_PLUS" ? row.costPrice : NaN;
  if (snapshot2.factoryOverride !== void 0) factory = snapshot2.factoryOverride;
  if (!Number.isFinite(factory) || factory < 0) throw new Error("Fabrika fiyat\u0131 ge\xE7ersiz.");
  factory = round(factory);
  let subtotal = factory;
  const breakdown = row.additions.map((item) => {
    const basis = item.basis === "FACTORY" ? factory : subtotal, amount = round(item.mode === "PERCENT" ? basis * item.value / 100 : item.value);
    subtotal = round(subtotal + amount);
    return { ...item, basisAmount: basis, amount, subtotal };
  });
  const unitPrice = snapshot2.manualUnitPrice ?? subtotal;
  if (!Number.isFinite(unitPrice) || unitPrice < 0 || unitPrice > 1e9) throw new Error("Hesaplanan birim fiyat s\u0131n\u0131r\u0131 a\u015F\u0131yor.");
  return { area, factory, breakdown, calculatedUnitPrice: subtotal, unitPrice: round(unitPrice) };
}
function pricePosition(position) {
  if (!position.pricingSnapshot || !(Number(position.width) > 0 && Number(position.height) > 0)) return position;
  if (position.pricingSnapshot.manualUnitPrice !== void 0 && (!Number.isFinite(position.pricingSnapshot.manualUnitPrice) || position.pricingSnapshot.manualUnitPrice < 0)) return position;
  const result = calculateProductPrice(position.pricingSnapshot, Number(position.width), Number(position.height));
  return { ...position, lines: position.lines.map((line, i) => i === 0 ? { ...line, unitPrice: String(result.unitPrice), quantity: position.quantity } : line) };
}

// domain/quoteCalendar.ts
function quotationDate(now = /* @__PURE__ */ new Date()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
}

// domain/slidingPanelCount.ts
function readSlidingPanelCount(text3, openingType) {
  const raw = text3.trim(), value = Number(raw);
  if (!raw) return { value: 0, error: "Panel say\u0131s\u0131 zorunludur." };
  if (!/^\d+$/.test(raw) || !Number.isSafeInteger(value)) return { value: 0, error: "Panel say\u0131s\u0131 tam say\u0131 olmal\u0131d\u0131r." };
  if (openingType === "CENTER OPENING" && (value < 4 || value % 2)) return { value: 0, error: "Merkezden a\xE7\u0131l\u0131mda panel say\u0131s\u0131 en az 4 ve \xE7ift olmal\u0131d\u0131r." };
  if (value < 2) return { value: 0, error: "Panel say\u0131s\u0131 en az 2 olmal\u0131d\u0131r." };
  return { value, error: "" };
}

// domain/quickQuote.ts
function quoteId() {
  return uuidv7();
}
function createQuickQuote(ownerUserId, preparedBy) {
  const now = /* @__PURE__ */ new Date(), iso = quotationDate(now);
  return { schemaVersion: 1, adjustmentBasis: "AFTER_TAX", id: quoteId(), version: 0, revision: "QR00", ownerUserId, createdAt: now.toISOString(), updatedAt: now.toISOString(), customerId: "", customerName: "", projectName: "", projectCode: "", quoteNumber: "", date: iso, validityDays: "10", language: "TR", currency: "EUR", unit: "mm", positions: [], attachments: [], manualDiscount: "", finalAmount: "", notes: "", preparedBy };
}
function createQuoteLine(name = "", quantity = "1") {
  return { id: quoteId(), name, description: "", quantity, unit: "adet", unitPrice: "", discountPercent: "0" };
}
function createQuotePosition(product, settings) {
  return { commercialProductId: product ? commercialProductForEngine(product)?.id : void 0, id: quoteId(), kind: product ? "PRODUCT" : "COMMERCIAL", product, name: product || "", model: "", width: "", height: "", quantity: "1", description: "", settings: product ? structuredClone(settings || (product === "Giyotin" ? DEFAULT_GUILLOTINE_SETTINGS : product === "S\xFCrme" ? DEFAULT_SLIDING_SETTINGS : null)) : null, lines: [createQuoteLine(product ? "Ana Sistem" : "")] };
}
var numberValue = (raw) => {
  const s = String(raw).trim().replace(",", ".");
  return /^-?(?:\d+(?:\.\d*)?|\.\d+)$/.test(s) ? Number(s) : NaN;
};
var roundMoney = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
function lineAmounts(line) {
  const q = numberValue(line.quantity), price = numberValue(line.unitPrice), d = numberValue(line.discountPercent || "0");
  if (![q, price, d].every(Number.isFinite)) return { gross: 0, discount: 0, net: 0, discountUnit: 0, netUnit: 0 };
  const discountUnit = roundMoney(price * d / 100), netUnit = roundMoney(price - discountUnit), gross = roundMoney(q * price), net = roundMoney(q * netUnit);
  return { gross, discount: roundMoney(gross - net), net, discountUnit, netUnit };
}
function positionAmounts(p) {
  return p.lines.filter((l) => l.name.trim()).reduce((a, l) => {
    const v = lineAmounts(l);
    return { gross: roundMoney(a.gross + v.gross), discount: roundMoney(a.discount + v.discount), net: roundMoney(a.net + v.net) };
  }, { gross: 0, discount: 0, net: 0 });
}
function filledPositions(q) {
  return q.positions.filter((p) => Boolean(p.name.trim() && (p.kind === "COMMERCIAL" || p.product)));
}
function quoteAmounts(q) {
  const sums = filledPositions(q).reduce((a, p) => {
    const v = positionAmounts(p);
    return { gross: roundMoney(a.gross + v.gross), discount: roundMoney(a.discount + v.discount), net: roundMoney(a.net + v.net) };
  }, { gross: 0, discount: 0, net: 0 });
  const rate = q.taxEnabled && Number.isFinite(numberValue(q.taxRate ?? "20")) ? numberValue(q.taxRate ?? "20") : 0;
  if (q.adjustmentBasis === "AFTER_TAX") {
    const tax2 = roundMoney(sums.net * rate / 100), taxInclusive = roundMoney(sums.net + tax2), explicit2 = q.finalAmount.trim() && Number.isFinite(numberValue(q.finalAmount)), anchorFinal2 = (q.totalMode === "FINAL" || !q.totalMode && Boolean(explicit2)) && Boolean(explicit2), inputAdjustment2 = Number.isFinite(numberValue(q.manualDiscount)) ? numberValue(q.manualDiscount) : 0;
    const final = anchorFinal2 ? numberValue(q.finalAmount) : roundMoney(taxInclusive - inputAdjustment2), adjustment2 = anchorFinal2 ? roundMoney(taxInclusive - final) : inputAdjustment2;
    return { ...sums, adjustment: adjustment2, adjusted: roundMoney(taxInclusive - adjustment2), beforeTax: sums.net, tax: tax2, rate, taxInclusive, final };
  }
  const explicit = q.finalAmount.trim() && Number.isFinite(numberValue(q.finalAmount)), anchorFinal = q.totalMode === "FINAL" || !q.totalMode && Boolean(explicit);
  const inputAdjustment = Number.isFinite(numberValue(q.manualDiscount)) ? numberValue(q.manualDiscount) : 0;
  const beforeTax = anchorFinal && explicit ? roundMoney(numberValue(q.finalAmount) / (1 + rate / 100)) : roundMoney(sums.net - inputAdjustment);
  const adjustment = anchorFinal && explicit && q.totalMode === "FINAL" ? roundMoney(sums.net - beforeTax) : inputAdjustment;
  const tax = anchorFinal && explicit ? roundMoney(numberValue(q.finalAmount) - beforeTax) : roundMoney(beforeTax * rate / 100);
  return { ...sums, adjustment, adjusted: roundMoney(sums.net - adjustment), beforeTax, tax, rate, final: anchorFinal && explicit ? roundMoney(numberValue(q.finalAmount)) : roundMoney(beforeTax + tax) };
}
function validateQuote(q, complete = false) {
  const errors = [];
  if (complete && q.reviewRequired) errors.push("\xC7izimden haz\u0131rlanan teklifin fiyat kontrol\xFCn\xFC tamamlay\u0131n.");
  if (!q.customerId || !q.customerName.trim()) errors.push("Cari se\xE7in.");
  if (!q.projectName.trim()) errors.push("Proje ad\u0131 zorunludur.");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(q.date) || !Number.isFinite(Date.parse(q.date))) errors.push("Teklif tarihi ge\xE7ersiz.");
  if (!Number.isInteger(numberValue(q.validityDays)) || numberValue(q.validityDays) < 1 || numberValue(q.validityDays) > 3650) errors.push("Ge\xE7erlilik s\xFCresi 1\u20133650 g\xFCn olmal\u0131d\u0131r.");
  if (!["TR", "EN", "DE", "FR"].includes(q.language) || !["EUR", "USD", "GBP", "TRY"].includes(q.currency) || !["mm", "inch", "dual"].includes(q.unit)) errors.push("Teklif \xE7\u0131kt\u0131 ayarlar\u0131 ge\xE7ersiz.");
  const positions = filledPositions(q);
  if (complete && !positions.length) errors.push("En az bir poz ekleyin.");
  positions.forEach((p, i) => {
    const prefix = "Poz " + String(i + 1).padStart(2, "0") + ": ";
    if (p.commercialProductId) {
      try {
        const identity2 = requireCommercialProduct(p.commercialProductId);
        if (identity2.quoteEngine !== p.product) errors.push(prefix + "\xDCr\xFCn ID se\xE7ilen sistem ile uyu\u015Fmuyor.");
        if (p.pricingSnapshot?.row.productId !== void 0 && p.pricingSnapshot.row.productId !== identity2.id) errors.push(prefix + "\xDCr\xFCn ID ve fiyat tan\u0131m\u0131 uyu\u015Fmuyor.");
      } catch (e) {
        errors.push(prefix + e.message);
      }
    }
    if (p.pricingSnapshot) {
      try {
        if (p.pricingSnapshot.row.currency !== q.currency) errors.push(prefix + "fiyat para birimi teklif ile uyu\u015Fmuyor.");
        const calculated = calculateProductPrice(p.pricingSnapshot, numberValue(p.width), numberValue(p.height));
        if (Math.abs(calculated.unitPrice - numberValue(p.lines[0]?.unitPrice || "")) > 5e-3) errors.push(prefix + "\xFCr\xFCn fiyat hesab\u0131 g\xFCncel \xF6l\xE7\xFClerle uyu\u015Fmuyor.");
      } catch (e) {
        errors.push(prefix + e.message);
      }
    }
    if (p.kind === "PRODUCT" && !commercialProductForEngine(p.product || "")) errors.push(prefix + "\xFCr\xFCn tan\u0131ml\u0131 de\u011Fil.");
    if (!Number.isInteger(numberValue(p.quantity)) || numberValue(p.quantity) < 1) errors.push(prefix + "adet pozitif tam say\u0131 olmal\u0131d\u0131r.");
    if (p.kind === "PRODUCT") {
      for (const [name, val] of [["geni\u015Flik", p.width], ["y\xFCkseklik", p.height]]) if (!(numberValue(val) > 0 && numberValue(val) <= (p.product === "Giyotin" ? 5e3 : 1e6))) errors.push(prefix + name + " ge\xE7ersiz.");
      if (!p.settings && !p.productOptions) errors.push(prefix + "ortak ayarlar eksik.");
      if (commercialProductForEngine(p.product || "")?.group === "01" && !(numberValue(p.legHeight || String(p.finalRow?.height || "")) > 0)) errors.push(prefix + "ayak y\xFCksekli\u011Fi ge\xE7ersiz.");
      if (p.product === "S\xFCrme" && p.settings) {
        const s = p.settings;
        if (s.panelCountMode === "MANUAL") {
          const v = readSlidingPanelCount(String(s.panelCount), s.openingType);
          if (v.error) errors.push(prefix + v.error);
        }
      }
    }
    const lines = p.lines.filter((l) => l.name.trim());
    if (complete && !lines.length) errors.push(prefix + "fiyat sat\u0131r\u0131 ekleyin.");
    p.lines.forEach((l, j) => {
      if (!l.name.trim()) {
        if (l.source === "GIYOTIN_REMOTE" || l.unitPrice.trim() || l.description.trim()) errors.push(prefix + "fiyat sat\u0131r\u0131 " + (j + 1) + " a\xE7\u0131klamas\u0131 eksik.");
        return;
      }
      const qty = numberValue(l.quantity), price = numberValue(l.unitPrice), discount = numberValue(l.discountPercent || "0");
      if (!(qty > 0 && qty <= 1e6) || l.source === "GIYOTIN_REMOTE" && !Number.isSafeInteger(qty)) errors.push(prefix + "sat\u0131r " + (j + 1) + " miktar\u0131 ge\xE7ersiz.");
      if (l.unitPrice.trim() ? !(price >= 0 && price <= 1e9) : complete && !(l.legacyRemote && l.source === "GIYOTIN_REMOTE")) errors.push(prefix + "sat\u0131r " + (j + 1) + " birim fiyat\u0131 girin.");
      if (!(discount >= 0 && discount <= 100)) errors.push(prefix + "iskonto %0\u2013100 olmal\u0131d\u0131r.");
      if (!l.unit.trim()) errors.push(prefix + "sat\u0131r birimi zorunludur.");
    });
  });
  if (q.taxEnabled && (!(numberValue(q.taxRate ?? "20") >= 0) || numberValue(q.taxRate ?? "20") > 100)) errors.push("KDV oran\u0131 %0\u2013100 olmal\u0131d\u0131r.");
  const t = quoteAmounts(q);
  if (q.manualDiscount.trim() && (!Number.isFinite(numberValue(q.manualDiscount)) || Math.abs(numberValue(q.manualDiscount)) > 1e9 || t.adjusted < 0)) errors.push("Manuel iskonto / yuvarlama ge\xE7ersiz.");
  if (q.finalAmount.trim() && (!(numberValue(q.finalAmount) >= 0) || numberValue(q.finalAmount) > 1e9)) errors.push("Son tutar ge\xE7ersiz.");
  return errors;
}

// domain/positionUnits.ts
var positionInputUnit = (unit, fallback = "mm") => unit === "in" ? "inch" : unit === "mm" || unit === "inch" || unit === "ft" ? unit : fallback === "inch" || fallback === "ft" ? fallback : "mm";

// domain/quoteWorkspace.ts
function quoteFromWorkspace(product, base, p, existing) {
  const quote = existing ? structuredClone(existing) : createQuotePosition(product, base);
  if (p.finalRow) {
    quote.finalRow = structuredClone(p.finalRow);
    quote.commercialProductId = commercialProductForEngine(product)?.id;
  }
  const identity2 = commercialProductForEngine(product);
  if (!identity2) throw new Error("Teklif \xFCr\xFCn\xFCn\xFCn ticari kimli\u011Fi bulunamad\u0131.");
  quote.commercialProductId = identity2.id;
  if (!p.finalRow) {
    quote.finalRow = {
      ...quote.finalRow,
      key: quote.finalRow?.key || "quote:" + p.id,
      kind: "native",
      referenceKey: identity2.referenceKey,
      nativeType: identity2.referenceKey,
      nativeId: quote.finalRow?.nativeId || p.id,
      owner: quote.finalRow?.owner || "quote:" + p.id,
      moduleIndex: 0,
      poz: p.positionNo,
      width: numberValue(p.width),
      height: numberValue(p.height),
      quantity: numberValue(p.quantity),
      description: p.description,
      lines: [],
      settings: structuredClone(base),
      overrides: structuredClone(p.overrides)
    };
  }
  const settings = product === "S\xFCrme" ? { ...base, ...resolveSliding(base, p), ...resolveSlidingMaterial(base, p) } : { ...base, ...p.overrides };
  return pricePosition({ ...quote, id: p.id, positionNo: p.positionNo, inputUnit: positionInputUnit(p.inputUnit), width: p.width, height: p.height, quantity: p.quantity, description: p.description, baseSettings: structuredClone(base), overrides: structuredClone(p.overrides), settings, lines: quote.lines.map((l, i) => i === 0 && l.quantity === quote.quantity ? { ...l, quantity: p.quantity } : l) });
}

// domain/quoteRemotes.ts
function groupQuoteRemotes(items) {
  const groups = /* @__PURE__ */ new Map();
  for (const item of items) {
    const remote = item.remote.trim();
    if (!remote) continue;
    const group = groups.get(remote) || [];
    group.push(item);
    groups.set(remote, group);
  }
  return [...groups].map(([remote, items2]) => ({ remote, quantity: items2.length === 1 ? items2[0].quantity : items2.every((i) => /^\d+$/.test(i.quantity) && Number.isSafeInteger(Number(i.quantity))) ? String(items2.reduce((n, i) => n + Number(i.quantity), 0)) : items2.find((i) => !/^\d+$/.test(i.quantity))?.quantity || items2[0].quantity }));
}
function quoteRemoteName(remote, language = "TR") {
  const name = { TR: "Kumanda", EN: "Remote Control", DE: "Fernbedienung", FR: "T\xE9l\xE9commande" }[language];
  const channel = language === "TR" ? remoteLabel(remote) : remote === "Di\u011Fer" ? { EN: "Other", DE: "Andere", FR: "Autre" }[language] : remote.replace(/ Kanal$/, { EN: " channel", DE: " Kanal", FR: " canal" }[language]);
  return name + " \u2014 " + channel;
}
function syncQuoteRemotes(quote, previous = quote, legacy = false) {
  if (quote.giyotinRemotes === void 0) return quote;
  const first = quote.positions.find((p) => p.kind === "PRODUCT" && p.product === "Giyotin" && p.name.trim());
  const existing = /* @__PURE__ */ new Map();
  for (const p of [...quote.positions, ...previous.positions]) for (const line of p.lines) if (line.source === "GIYOTIN_REMOTE" && line.remote && !existing.has(line.remote)) existing.set(line.remote, line);
  const rows = first ? groupQuoteRemotes(quote.giyotinRemotes).filter((item) => !/^0+$/.test(item.quantity)).map((item) => {
    const old = existing.get(item.remote);
    return { ...old || { ...createQuoteLine(quoteRemoteName(item.remote)), source: "GIYOTIN_REMOTE", remote: item.remote, ...legacy ? { legacyRemote: true } : {} }, quantity: item.quantity };
  }) : [];
  return { ...quote, positions: quote.positions.map((p) => ({ ...p, lines: [...p.lines.filter((l) => l.source !== "GIYOTIN_REMOTE"), ...p.id === first?.id ? rows : []] })) };
}

// utils/projectDate.ts
function projectDate(value) {
  if (value instanceof Date) return Number.isFinite(value.getTime()) ? value : null;
  const raw = String(value || "").trim();
  if (!raw) return null;
  const legacy = raw.match(/^(\d{1,2})\.(\d{1,2})\.(\d{2,4})(?:[, ]+(\d{1,2}):(\d{2})(?::\d{2})?)?$/);
  if (legacy) {
    const [, d, m, y, h = "0", min = "0"] = legacy;
    const year = Number(y) < 100 ? 2e3 + Number(y) : Number(y);
    const date2 = new Date(year, Number(m) - 1, Number(d), Number(h), Number(min));
    return date2.getFullYear() === year && date2.getMonth() === Number(m) - 1 && date2.getDate() === Number(d) && Number(h) < 24 && Number(min) < 60 ? date2 : null;
  }
  if (!/^\d{4}-\d{2}-\d{2}(?:T|$)/.test(raw)) return null;
  const date = new Date(raw);
  return Number.isFinite(date.getTime()) ? date : null;
}
function displayProjectDate(value, locale = "tr-TR", includeTime = true) {
  const date = projectDate(value);
  if (!date) return String(value || "\u2014");
  return new Intl.DateTimeFormat(locale, { day: "2-digit", month: "2-digit", year: "numeric", ...includeTime ? { hour: "2-digit", minute: "2-digit" } : {} }).format(date).replace(", ", " ");
}

// services/operationProgress.ts
var operations = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var sequence = 0;
var snapshot = null;
function notify() {
  snapshot = [...operations.values()].at(-1) || null;
  for (const listener of listeners) listener();
}
function beginOperation(label, progress = 0) {
  const id = ++sequence;
  operations.set(id, { id, label, progress });
  notify();
  return {
    update(progress2, nextLabel = label) {
      if (!operations.has(id)) return;
      operations.set(id, { id, label: nextLabel, progress: Math.max(0, Math.min(100, progress2)) });
      notify();
    },
    end() {
      operations.delete(id);
      notify();
    }
  };
}

// services/cloudRequest.ts
var CloudRequestError = class extends Error {
  constructor(message, status = 0, transient = false, requestId) {
    super(message);
    this.status = status;
    this.transient = transient;
    this.requestId = requestId;
    this.name = "CloudRequestError";
  }
  status;
  transient;
  requestId;
};
async function cloudRequest(url2, init, options) {
  const operation = options.foreground === false ? null : beginOperation(options.label);
  try {
    for (let attempt = 0; ; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), options.timeoutMs ?? 6e4);
      try {
        const response = await fetch(url2, { ...init, signal: controller.signal });
        operation?.update(50);
        const text3 = await response.text();
        let result;
        try {
          result = text3 ? JSON.parse(text3) : {};
        } catch {
          if (response.ok) throw new CloudRequestError("Bulut yan\u0131t\u0131 okunamad\u0131. L\xFCtfen tekrar deneyin.", response.status);
          result = {};
        }
        if (!response.ok) {
          const message = ["PROJECT_INDEX_MODE_CHANGED", "PROJECT_EPOCH_CHANGED", "ARRAY_VALUE_REQUIRED", "COMPANY_DELETE_REQUIRED", "COMPANY_NOT_FOUND", "COMPANY_MAINTENANCE", "COMPANY_REMOVED", "COMPANY_DELETE_UNAVAILABLE", "DIRECTORY_NOT_READY"].includes(result?.code) ? result.error : response.status === 409 ? "Kay\u0131t ba\u015Fka bir oturumda de\u011Fi\u015Fti. Tasla\u011F\u0131n\u0131z korundu; g\xFCncel kayd\u0131 a\xE7\u0131n." : response.status === 429 ? "\xC7ok fazla deneme. Bir dakika sonra tekrar deneyin." : response.status === 401 ? "Oturumunuz do\u011Frulanamad\u0131. Yeniden giri\u015F yap\u0131n." : response.status === 403 ? typeof result.error === "string" && result.error.length <= 500 ? result.error : "Bu i\u015Flem i\xE7in yetkiniz yok." : response.status === 404 ? "Bulut hizmeti bulunamad\u0131. Ba\u011Flant\u0131 ayarlar\u0131n\u0131 kontrol edin." : response.status === 546 ? "Bulut i\u015Flemi kaynak s\u0131n\u0131r\u0131na ula\u015Ft\u0131. Kay\u0131t durumunu do\u011Frulay\u0131p tekrar deneyin." : result?.code === "STATEMENT_TIMEOUT" ? "Veritaban\u0131 i\u015Flemi zaman s\u0131n\u0131r\u0131n\u0131 a\u015Ft\u0131. Kay\u0131t durumunu do\u011Frulay\u0131p tekrar deneyin." : response.status >= 500 ? "Bulut hizmeti \u015Fu anda yan\u0131t veremiyor. L\xFCtfen tekrar deneyin." : result.error || "Bulut i\u015Flemi ba\u015Far\u0131s\u0131z.";
          const requestId = response.headers.get("x-plmr-request-id") || void 0;
          const detail = requestId && response.status >= 500 ? message + " \u0130stek kodu " + requestId + "." : message;
          throw new CloudRequestError(detail, response.status, [502, 503, 504].includes(response.status) && result?.code !== "STATEMENT_TIMEOUT", requestId);
        }
        operation?.update(100);
        return result;
      } catch (error) {
        const failure = error instanceof CloudRequestError ? error : new CloudRequestError(
          controller.signal.aborted || error?.name === "TimeoutError" ? "Bulut ba\u011Flant\u0131s\u0131 zaman a\u015F\u0131m\u0131na u\u011Frad\u0131. \u0130nternet ba\u011Flant\u0131n\u0131z\u0131 kontrol edip tekrar deneyin. Tasla\u011F\u0131n\u0131z korunuyor." : "Bulut ba\u011Flant\u0131s\u0131 kurulamad\u0131. \u0130nternet ba\u011Flant\u0131n\u0131z\u0131 kontrol edip tekrar deneyin.",
          0,
          true
        );
        if (!(options.safeRead && attempt === 0 && failure.transient)) throw failure;
        operation?.update(0);
      } finally {
        clearTimeout(timer);
      }
    }
  } finally {
    operation?.end();
  }
}

// domain/cloudPolicy.ts
function cloudPolicy(key) {
  if (/^plmr\.(table\.|quick-start\.|locale|entry-panel\.)/.test(key))
    return { read: ["dashboard.view"], write: ["dashboard.view"], personal: true };
  if (key === "plmr.roles.v13")
    return { read: ["dashboard.view"], write: ["admin.roles.edit"] };
  if (key === "plmr.audit.v13")
    return { read: ["dashboard.view"], write: ["dashboard.view"], family: "OPERATIONS" };
  if (key === "plmr.sessions.v13")
    return { read: ["dashboard.view"], write: ["dashboard.view"], personal: true };
  if (key === "plmr.task-reminder.v12")
    return { read: ["task.view"], write: ["task.create", "task.edit", "task.complete", "task.cancel"], family: "OPERATIONS" };
  if (/^plmr\.(productMaster\.|catalog\.|central-products|commercial.products)/.test(key))
    return { read: ["product.view"], write: ["product.edit"] };
  if (/^plmr\.(company.pricing|system.prices|help.rules)/.test(key))
    return { read: ["commercial.price.view", "admin.company_settings.view"], write: ["admin.company_settings.edit"] };
  if (key === "plmr.company.limits.v13")
    return { read: ["dashboard.view"], write: ["admin.company_limits.edit"] };
  if (key === "plmr.cloud.library.meta.v12")
    return { read: ["cloud.view"], write: ["cloud.upload", "cloud.edit", "cloud.move", "cloud.archive", "cloud.folder.manage", "cloud.version.manage"], family: "PROJECTS" };
  if (/^plmr\.customer\.master/.test(key))
    return { read: ["customer.view"], write: ["customer.create", "customer.edit", "customer.deactivate"], family: "CUSTOMERS" };
  if (/^plmr\.(customer.transactions|orders|payments|proforma.snapshots)/.test(key))
    return { read: ["customer.orders.view", "customer.payments.view", "commercial.proforma.create"], write: ["customer.orders.create", "customer.payments.create", "commercial.proforma.create", "commercial.order.manage"], family: "CUSTOMERS" };
  if (key === "plmr.project.attachments.v10")
    return { read: ["project.files.view"], write: ["project.files.upload", "project.files.manage"], family: "PROJECTS" };
  if (/^plmr\.(project\.index|v7.project.index|v8.project.index)/.test(key))
    return { read: ["project.view", "commercial.quote.view"], write: ["project.create", "project.edit", "project.status.change", "commercial.quote.create"], family: "PROJECTS" };
  if (/^plmr\.project\.sequence\.user\.\d{4}$/.test(key))
    return { read: ["project.view"], write: ["project.create"], personal: true };
  throw Error("Desteklenmeyen bulut kay\u0131t anahtar\u0131: " + key);
}
function requiresArrayCloudValue(key) {
  return key === "plmr.users.v13" || key === "plmr.companies.v68" || key === "plmr.platform.audit.v68" || /^plmr\.tenant\.v68\.[^.]+\.plmr\.audit\.v13$/.test(key);
}

// services/cloudOutbox.ts
var opened;
function database() {
  if (!opened) opened = new Promise((resolve, reject) => {
    const request = indexedDB.open("plmr.cloud.outbox", 2);
    request.onupgradeneeded = (event) => {
      if (event.oldVersion < 1) {
        const operations2 = request.result.createObjectStore("operations", { keyPath: ["owner", "companyId", "id"] });
        operations2.createIndex("owner", "owner");
      }
      const writes = request.result.createObjectStore("writes", { keyPath: ["owner", "id"] });
      writes.createIndex("owner", "owner");
    };
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(Error("Yerel kay\u0131t alan\u0131 ba\u015Fka bir sekmede a\xE7\u0131k."));
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => {
        db.close();
        opened = void 0;
      };
      resolve(db);
    };
  }).catch((error) => {
    opened = void 0;
    throw error;
  });
  return opened;
}
async function transact(mode, operation, name = "operations") {
  const db = await database();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(name, mode, mode === "readwrite" ? { durability: "strict" } : void 0);
    const request = operation(tx.objectStore(name));
    tx.oncomplete = () => resolve(request.result);
    tx.onabort = () => reject(tx.error ?? request.error ?? Error("Yerel kay\u0131t i\u015Flemi kesildi."));
  });
}
var stageOperation = (entry) => transact("readwrite", (store) => store.put(entry));
var listOperations = async (owner) => (await transact("readonly", (store) => store.index("owner").getAll(owner))).sort((a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id));
var removeOperation = (entry) => transact("readwrite", (store) => store.delete([entry.owner, entry.companyId, entry.id]));
var stageGenericWrite = (entry) => transact("readwrite", (store) => store.put(entry), "writes");
var removeGenericWrite = (entry) => transact("readwrite", (store) => store.delete([entry.owner, entry.id]), "writes");

// data/cloudPublicConfig.ts
var cloudPublicConfig_default = {
  "supabaseUrl": "https://yackwdxdyajejtdxvncu.supabase.co",
  "supabasePublishableKey": "sb_publishable_IXfqhBIsQSlMqlAlgi9Bbg_HMn4fg_k"
};

// services/cloudPlatform.ts
var sessionKey = "plmr.cloud.session.v12";
var values = /* @__PURE__ */ Object.create(null);
var versions = /* @__PURE__ */ new Map();
var session = null;
var queue = Promise.resolve();
var pending = 0;
var epoch = 0;
var durableOwner = "";
var journalError = "";
var indexError = "";
var indexQueue = Promise.resolve();
var indexVersions = /* @__PURE__ */ new Map();
var indexDocuments = /* @__PURE__ */ new Map();
var journal = /* @__PURE__ */ new Map();
var projectEpochs = {};
var projectEpochFor = (cid) => cid && Object.hasOwn(projectEpochs, cid) ? projectEpochs[cid] : 0;
var matchesProjectEpoch = (entry) => (entry.projectEpoch ?? 0) === projectEpochFor(entry.companyId);
var volatileJournal = /* @__PURE__ */ new Map();
var recoveringIndex = /* @__PURE__ */ new Set();
var refreshIndex = /* @__PURE__ */ new Set();
var blockedIndexProjects = /* @__PURE__ */ new Map();
var attempts = /* @__PURE__ */ new Map();
var companyId = () => null;
var allowWrite = () => true;
var listeners2 = /* @__PURE__ */ new Set();
var notify2 = () => listeners2.forEach((fn) => fn());
var cloudEnabled = () => typeof location !== "undefined" && location.protocol !== "file:";
var cloudHasSession = () => !!session;
function configureCloudAccess(company2, guard) {
  companyId = company2;
  allowWrite = guard;
}
function remember(tokens) {
  session = tokens;
  if (tokens)
    sessionStorage.setItem(sessionKey, JSON.stringify(tokens));
  else
    sessionStorage.removeItem(sessionKey);
}
function tokenExpiry() {
  try {
    return Number(JSON.parse(atob(session.access_token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))).exp) * 1e3;
  } catch {
    return 0;
  }
}
var refreshing;
async function refresh() {
  if (!session || tokenExpiry() > Date.now() + 6e4)
    return;
  if (!refreshing) {
    const current = epoch, token = session.refresh_token;
    refreshing = (async () => {
      const next = await cloudRequest(cloudPublicConfig_default.supabaseUrl + "/auth/v1/token?grant_type=refresh_token", {
        method: "POST",
        headers: { apikey: cloudPublicConfig_default.supabasePublishableKey, "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: token })
      }, { label: "Oturum yenileniyor\u2026" });
      if (current !== epoch) throw Error("Giri\u015F i\u015Flemi iptal edildi.");
      remember(next);
    })().finally(() => {
      refreshing = void 0;
    });
  }
  await refreshing;
}
async function cloudCall(action, data = {}, projectEpoch) {
  const generation = epoch;
  const cid = typeof data.companyId === "string" ? data.companyId : companyId();
  const writeEpoch = projectEpoch ?? projectEpochFor(cid);
  if (!session)
    throw Error("Bulut oturumu gerekli.");
  await refresh();
  if (generation !== epoch || !session) throw Error("Oturum de\u011Fi\u015Fti.");
  const result = await cloudRequest(cloudPublicConfig_default.supabaseUrl + "/functions/v1/plmr-platform", {
    method: "POST",
    headers: {
      apikey: cloudPublicConfig_default.supabasePublishableKey,
      Authorization: "Bearer " + session.access_token,
      "Content-Type": "application/json",
      ...writeEpoch ? { "x-plmr-project-epoch": String(writeEpoch) } : {}
    },
    body: JSON.stringify({ action, ...data })
  }, {
    foreground: false,
    label: ["write", "record_put", "record_delete_many"].includes(action) ? "Buluta kaydediliyor\u2026" : action === "snapshot" ? "\xC7al\u0131\u015Fma alan\u0131 y\xFCkleniyor\u2026" : "Bulut i\u015Flemi s\xFCr\xFCyor\u2026",
    safeRead: ["snapshot", "record_get", "record_list", "project_headers", "project_content", "project_overview", "drawing_workspace", "stock_read", "project_files_read", "project_master_detail", "library_file_read", "company_directory", "company_delete_jobs", "production_page", "production_items", "production_export"].includes(action)
  });
  if (generation !== epoch) throw Error("Oturum de\u011Fi\u015Fti.");
  return result;
}
async function persistOperation(entry) {
  volatileJournal.set(entry.id, entry);
  try {
    await stageOperation(entry);
  } catch {
    throw Error("Taslak diske yaz\u0131lamad\u0131. Bu sekmeden tasla\u011F\u0131 indirin.");
  }
  if (entry.owner !== durableOwner) throw Error("Oturum de\u011Fi\u015Fti. Taslak \xF6nceki oturumda korunuyor.");
  volatileJournal.delete(entry.id);
  journal.set(entry.id, entry);
  notify2();
}
function sendOperation(entry) {
  const existing = attempts.get(entry.id);
  if (existing) return existing;
  const request = (async () => {
    if (entry.owner !== durableOwner) throw Error("Oturum de\u011Fi\u015Fti.");
    if (!matchesProjectEpoch(entry)) throw Error("Eski proje tasla\u011F\u0131 yeni veri d\xF6nemine g\xF6nderilemez.");
    let data = entry.data;
    if (entry.action === "record_put" && entry.data.retainedHistory?.length) {
      const value = entry.data.value;
      const workflow = { ...value.workflow };
      for (const field of entry.data.retainedHistory) delete workflow[field];
      data = { ...entry.data, value: { ...value, workflow } };
    }
    const result = await cloudCall(entry.action, { ...data, companyId: entry.companyId, operationId: entry.id }, entry.projectEpoch ?? 0);
    const valid = entry.action === "record_put" ? result && "version" in result && Number.isSafeInteger(result.version) && result.version > entry.data.expectedVersion : result && "projects" in result && Array.isArray(result.projects) && result.projects.length === entry.data.entries.length && entry.data.entries.every(({ id, expectedVersion }) => result.projects.some((item) => item.id === id && item.version === expectedVersion + 1));
    if (result?.operationId !== entry.id || !valid) throw Error("Bulut i\u015Flem onay\u0131 do\u011Frulanamad\u0131. Tasla\u011F\u0131n\u0131z korunuyor.");
    await removeOperation(entry).catch(() => {
    });
    journal.delete(entry.id);
    notify2();
    return result;
  })().finally(() => attempts.delete(entry.id));
  attempts.set(entry.id, request);
  return request;
}
function indexTargets(entry) {
  return entry.action !== "record_put" ? entry.data.entries.map(({ id }) => id) : [];
}
function blockIndex(entry) {
  if (entry.action === "record_put") return;
  const ids = blockedIndexProjects.get(entry.companyId) ?? /* @__PURE__ */ new Set();
  for (const id of indexTargets(entry)) ids.add(id);
  blockedIndexProjects.set(entry.companyId, ids);
}
async function resumeJournal() {
  if (!journal.size && !volatileJournal.size && !refreshIndex.size) return;
  const owner = durableOwner, generation = epoch;
  const run = async () => {
    for (const entry of volatileJournal.values()) await persistOperation(entry);
    const entries = (await listOperations(owner)).filter(matchesProjectEpoch);
    if (generation !== epoch) return;
    for (const entry of entries) if (entry.action !== "record_put") recoveringIndex.add(entry.companyId);
    let firstError = "";
    const failedTargets = /* @__PURE__ */ new Set();
    for (const entry of entries) {
      if (generation !== epoch) break;
      const targets = entry.action === "record_put" ? [JSON.stringify([entry.companyId, "drawing", entry.data.key])] : indexTargets(entry).map((id) => JSON.stringify([entry.companyId, "index", id]));
      if (targets.some((target) => failedTargets.has(target))) continue;
      try {
        await sendOperation(entry);
        if (entry.action !== "record_put") refreshIndex.add(entry.companyId);
        else invalidateCloudReads();
      } catch (error) {
        firstError ||= error.message;
        for (const target of targets) failedTargets.add(target);
      }
    }
    if (generation !== epoch) return;
    if (refreshIndex.size) {
      const keys = [...refreshIndex].map((cid) => "plmr.tenant.v68." + cid + ".plmr.project.index.v11");
      const snapshot2 = await cloudCall("snapshot", { keys, projectSummaries: true, deferProjectFiles: true });
      if (generation !== epoch) return;
      if ([...refreshIndex].some((cid) => (snapshot2.projectEpochs?.[cid] ?? 0) !== projectEpochFor(cid)))
        throw Error("Proje veri d\xF6nemi de\u011Fi\u015Fti. Uygulamay\u0131 yeniden a\xE7\u0131n.");
      for (const row of snapshot2.rows) if (row.value !== null) {
        values[row.key] = row.value;
        indexDocuments.delete(row.key);
      }
      for (const [cid, projects] of Object.entries(snapshot2.splitIndexVersions ?? {}))
        indexVersions.set(cid, new Map(projects.map(({ id, version }) => [id, version])));
      refreshIndex.clear();
      if (typeof window !== "undefined") window.dispatchEvent(new Event("plmr-project-index-replayed"));
    }
    const remaining = (await listOperations(owner)).filter(matchesProjectEpoch);
    if (generation !== epoch) return;
    journal.clear();
    recoveringIndex.clear();
    blockedIndexProjects.clear();
    for (const entry of remaining) {
      journal.set(entry.id, entry);
      blockIndex(entry);
    }
    journalError = firstError;
    indexError = remaining.some((entry) => entry.action !== "record_put") ? firstError : "";
    if (typeof window !== "undefined" && remaining.length < entries.length) window.dispatchEvent(new Event("plmr-cloud-recovered"));
    notify2();
    if (firstError) throw Error(firstError);
  };
  if (typeof navigator !== "undefined" && navigator.locks) await navigator.locks.request("plmr-cloud-replay:" + owner, run);
  else await run();
}
var unsaved = /* @__PURE__ */ new Set();
var tenantFromKey = (key) => /^plmr\.tenant\.v68\.([^.]+)\./.exec(key)?.[1] ?? null;
function draftDocument(job) {
  const { owner, id, createdAt, key, value, companyId: companyId2, projectEpoch, index, expectedVersion } = job;
  return { owner, id, createdAt, key, value, companyId: companyId2, projectEpoch, index, expectedVersion };
}
function stageWrite(job) {
  job.durable = false;
  if (!job.owner || typeof indexedDB === "undefined") return;
  const document = draftDocument(job);
  const staging = (job.staging ?? Promise.resolve()).then(async () => {
    if (!unsaved.has(job)) return;
    await stageGenericWrite(document);
    job.stored = true;
    if (job.staging === staging) job.durable = true;
  }).catch(() => {
    job.durable = false;
  });
  job.staging = staging;
}
async function forgetWrite(job) {
  await job.staging;
  if (job.stored) await removeGenericWrite(job);
  unsaved.delete(job);
}
function enqueue(key, value, index) {
  const cid = tenantFromKey(key) ?? companyId();
  const waiting = [...unsaved].find((job2) => !job2.started && job2.key === key && job2.companyId === cid && job2.generation === epoch);
  if (waiting) {
    waiting.value = value;
    waiting.index = waiting.index && index ? { base: waiting.index.base, rows: index.rows } : void 0;
    stageWrite(waiting);
    return;
  }
  const job = {
    owner: durableOwner,
    id: crypto.randomUUID(),
    createdAt: Math.max(Date.now(), ++lastGenericAt),
    key,
    value,
    index,
    companyId: cid,
    generation: epoch,
    projectEpoch: projectEpochFor(cid)
  };
  lastGenericAt = job.createdAt;
  unsaved.add(job);
  stageWrite(job);
  pending++;
  notify2();
  queue = queue.then(async () => {
    if (!unsaved.has(job) || job.generation !== epoch) return;
    if ([...unsaved].some((other) => other !== job && other.key === key && other.error)) return;
    await sendGenericWrite(job);
  }).catch((error) => {
    job.error = error.message;
  }).finally(() => {
    pending--;
    notify2();
  });
}
var lastGenericAt = 0;
async function sendGenericWrite(job) {
  job.started = true;
  job.expectedVersion ??= versions.get(job.key) ?? 0;
  stageWrite(job);
  await job.staging;
  if (!unsaved.has(job) || job.generation !== epoch) return;
  const row = await persistCloudWrite(job, job.expectedVersion);
  if (job.generation !== epoch) return;
  versions.set(job.key, row.version);
  await forgetWrite(job);
}
function projectIndexChanges({ base, rows }) {
  const previous = new Map(base.map((project) => [project.id, project])), remaining = new Set(rows.map((project) => project.id));
  return {
    upserts: rows.filter((project) => previous.get(project.id) !== project),
    remove: base.filter((project) => !remaining.has(project.id)).map((project) => project.id)
  };
}
function persistedIndexChanges(index, raw) {
  const projects = new Map(JSON.parse(raw ?? "[]").map((project) => [project.id, project]));
  const { upserts, remove } = projectIndexChanges(index);
  return upserts.every((project) => sameDocument(projects.get(project.id), project)) && remove.every((id) => !projects.has(id));
}
function persistCloudWrite(job, expectedVersion) {
  if (job.index) {
    const { upserts, remove } = projectIndexChanges(job.index);
    if (!upserts.length && !remove.length) return Promise.resolve({ version: expectedVersion });
    return cloudCall("project_index_patch", { companyId: job.companyId, expectedVersion, upserts, remove }, job.projectEpoch);
  }
  return cloudCall("write", { key: job.key, value: job.value, companyId: job.companyId, expectedVersion, versionOnly: true }, job.projectEpoch);
}
var recovering;
function retryCloudWrites() {
  if (!recovering) recovering = recoverCloudWrites().finally(() => {
    recovering = void 0;
  });
  return recovering;
}
async function recoverCloudWrites() {
  await awaitCloudDispatch();
  let durableFailure;
  try {
    await resumeJournal();
  } catch (error) {
    durableFailure = error;
    journalError = error.message;
    notify2();
  }
  const jobs = [...unsaved], blocked = /* @__PURE__ */ new Set();
  let failure;
  const attempt = queue.then(async () => {
    for (const job of jobs) {
      if (job.generation !== epoch || !unsaved.has(job) || blocked.has(job.key)) continue;
      pending++;
      notify2();
      try {
        if (job.started) {
          const snapshot2 = await cloudCall("snapshot", { projectSummaries: true, keys: [job.key] });
          const row = snapshot2.rows.find((row2) => row2.key === job.key), version = row?.version ?? 0;
          if ((row?.value ?? null) === job.value || job.index && persistedIndexChanges(job.index, row?.value ?? null)) {
            versions.set(job.key, version);
            await forgetWrite(job);
            continue;
          }
          if (version !== job.expectedVersion) throw Error("Kay\u0131t ba\u015Fka bir oturumda de\u011Fi\u015Fti. Tasla\u011F\u0131n\u0131z korundu.");
        }
        await sendGenericWrite(job);
      } catch (error) {
        job.error = error.message;
        blocked.add(job.key);
        failure ??= error;
      } finally {
        pending--;
        notify2();
      }
    }
  });
  queue = attempt;
  await attempt;
  if (failure || durableFailure) throw failure ?? durableFailure;
}
function cloudStoredValue(key) {
  const document = indexDocuments.get(key);
  if (document) {
    values[key] = JSON.stringify(document);
    indexDocuments.delete(key);
  }
  return values[key] ?? null;
}
var cloudStorage = Object.defineProperties(values, {
  length: { get: () => Object.keys(values).length },
  key: { value: (i) => Object.keys(values)[i] ?? null },
  getItem: { value: cloudStoredValue },
  setItem: { value: (k, v) => {
    v = String(v);
    if (cloudStoredValue(k) === v)
      return;
    if (!allowWrite(k)) {
      if (values[k] === void 0) {
        values[k] = v;
        return;
      }
      throw Error("Bu kayd\u0131 de\u011Fi\u015Ftirme yetkiniz yok.");
    }
    indexDocuments.delete(k);
    values[k] = v;
    enqueue(k, v);
  } },
  removeItem: { value: (k) => {
    if (!(k in values))
      return;
    if (!allowWrite(k))
      throw Error("Bu kayd\u0131 de\u011Fi\u015Ftirme yetkiniz yok.");
    if (requiresArrayCloudValue(k)) throw Error("Bu kay\u0131t bir dizi bekliyor. Bo\u015F kay\u0131t i\xE7in bo\u015F dizi kullan\u0131n.");
    indexDocuments.delete(k);
    delete values[k];
    enqueue(k, null);
  } },
  clear: { value: () => {
    throw Error("Bulut kay\u0131tlar\u0131 topluca temizlenemez.");
  } }
});
async function awaitCloudDispatch() {
  await Promise.all([queue, indexQueue]);
}
var recordReads = /* @__PURE__ */ new Map();
var listReads = /* @__PURE__ */ new Map();
var pendingReads = /* @__PURE__ */ new Map();
var readRevision = 0;
function invalidateCloudReads() {
  readRevision++;
  recordReads.clear();
  listReads.clear();
  pendingReads.clear();
}
async function cloudAccessToken() {
  await awaitCloudDispatch();
  await refresh();
  return session?.access_token || null;
}
if (typeof window !== "undefined") {
  window.addEventListener("focus", invalidateCloudReads);
  window.addEventListener("online", () => {
    if (journal.size) void retryCloudWrites().catch(() => {
    });
  });
  window.addEventListener("beforeunload", (e) => {
    if (pending || [...unsaved].some((job) => !job.durable) || indexError) {
      e.preventDefault();
      e.returnValue = "";
    }
  });
  window.PLMRCloud = { getAccessToken: cloudAccessToken, getCompanyId: () => companyId(), endpoint: cloudPublicConfig_default.supabaseUrl + "/functions/v1/plmr-platform", key: cloudPublicConfig_default.supabasePublishableKey };
}

// domain/authorization.ts
var ROLE_LABELS = {
  SYSTEM_ADMIN: "System Admin",
  COMPANY_ADMIN: "Firma Y\xF6neticisi",
  DESIGNER: "Tasar\u0131mc\u0131",
  SALES_REPRESENTATIVE: "Sat\u0131\u015F Temsilcisi",
  DEALER: "Bayi",
  VIEWER: "G\xF6r\xFCnt\xFCleyici",
  OPERATIONS_CONTROL: "Operasyon Kontrol",
  PRODUCTION_OPERATOR: "\xDCretim Operat\xF6r\xFC",
  INSTALLATION_SERVICE: "Montaj / Servis",
  FINANCE_COLLECTIONS: "Finans / Tahsilat"
};
var PERMISSIONS = [
  "dashboard.view",
  "dashboard.widget.quote_7d",
  "dashboard.widget.approved_projects",
  "dashboard.widget.ready_to_ship",
  "dashboard.widget.shipped",
  "dashboard.widget.order_total",
  "dashboard.widget.alerts",
  "project.view",
  "project.create",
  "project.edit",
  "project.status.change",
  "project.approve",
  "project.revision.create",
  "project.archive",
  "project.export",
  "project.files.view",
  "project.files.upload",
  "project.files.manage",
  "commercial.quote.view",
  "commercial.quote.create",
  "commercial.price.view",
  "commercial.price.edit",
  "commercial.discount.override",
  "commercial.proforma.create",
  "commercial.order.view",
  "commercial.order.manage",
  "customer.view",
  "customer.create",
  "customer.edit",
  "customer.deactivate",
  "customer.export",
  "customer.orders.view",
  "customer.orders.create",
  "customer.payments.view",
  "customer.payments.create",
  "customer.credit.view",
  "customer.credit.edit",
  "product.view",
  "product.create",
  "product.edit",
  "product.deactivate",
  "product.export",
  "product.cost.view",
  "cloud.view",
  "cloud.download",
  "cloud.upload",
  "cloud.edit",
  "cloud.move",
  "cloud.archive",
  "cloud.folder.manage",
  "cloud.version.manage",
  "operations.view",
  "operations.start_production",
  "operations.mark_ready_to_ship",
  "operations.mark_shipped",
  "operations.checklist.manage",
  "operations.files.upload",
  "operations.notes.edit",
  "task.view",
  "task.create",
  "task.edit",
  "task.complete",
  "task.cancel",
  "admin.companies.view",
  "admin.companies.manage",
  "admin.users.view",
  "admin.users.create",
  "admin.users.edit",
  "admin.users.disable",
  "admin.users.sessions.manage",
  "admin.roles.view",
  "admin.roles.edit",
  "admin.audit.view",
  "admin.company_settings.view",
  "admin.company_settings.edit",
  "admin.advanced_settings.view",
  "admin.company_limits.edit"
];
var def = (id, group, label, dependsOn) => ({ id, group, label, dependsOn });
var PERMISSION_DEFINITIONS = [
  def("dashboard.view", "DASHBOARD", "Ana Men\xFC / Dashboard"),
  def("dashboard.widget.quote_7d", "DASHBOARD", "Son 7 G\xFCnde Teklifler", "dashboard.view"),
  def("dashboard.widget.approved_projects", "DASHBOARD", "Onaylanan Projeler", "dashboard.view"),
  def("dashboard.widget.ready_to_ship", "DASHBOARD", "Sevke Haz\u0131r", "dashboard.view"),
  def("dashboard.widget.shipped", "DASHBOARD", "Sevk Edilen", "dashboard.view"),
  def("dashboard.widget.order_total", "DASHBOARD", "Sipari\u015F Toplam\u0131", "dashboard.view"),
  def("dashboard.widget.alerts", "DASHBOARD", "Dikkat Gerektirenler", "dashboard.view"),
  def("project.view", "PROJECTS", "Projeleri G\xF6r\xFCnt\xFCle"),
  def("project.create", "PROJECTS", "Yeni Proje"),
  def("project.edit", "PROJECTS", "Projeyi D\xFCzenle", "project.view"),
  def("project.status.change", "PROJECTS", "Durum De\u011Fi\u015Ftir", "project.view"),
  def("project.approve", "PROJECTS", "Projeyi Onayla", "project.view"),
  def("project.revision.create", "PROJECTS", "Revizyon Olu\u015Ftur", "project.edit"),
  def("project.archive", "PROJECTS", "Ar\u015Fivle", "project.view"),
  def("project.export", "PROJECTS", "D\u0131\u015Fa Aktar", "project.view"),
  def("project.files.view", "PROJECTS", "Proje Dosyalar\u0131n\u0131 G\xF6r", "project.view"),
  def("project.files.upload", "PROJECTS", "Proje Dosyas\u0131 Y\xFCkle", "project.files.view"),
  def("project.files.manage", "PROJECTS", "Proje Dosyalar\u0131n\u0131 Y\xF6net", "project.files.view"),
  def("commercial.quote.view", "COMMERCIAL", "Teklif G\xF6r"),
  def("commercial.quote.create", "COMMERCIAL", "Teklif Olu\u015Ftur", "commercial.quote.view"),
  def("commercial.price.view", "COMMERCIAL", "Sat\u0131\u015F Fiyat\u0131n\u0131 G\xF6r"),
  def("commercial.price.edit", "COMMERCIAL", "Sat\u0131\u015F Fiyat\u0131n\u0131 D\xFCzenle", "commercial.price.view"),
  def("commercial.discount.override", "COMMERCIAL", "\u0130skonto De\u011Fi\u015Ftir", "commercial.price.edit"),
  def("commercial.proforma.create", "COMMERCIAL", "Proforma Olu\u015Ftur", "commercial.quote.view"),
  def("commercial.order.view", "COMMERCIAL", "Sipari\u015Fleri G\xF6r"),
  def("commercial.order.manage", "COMMERCIAL", "Sipari\u015Fleri Y\xF6net", "commercial.order.view"),
  def("customer.view", "CUSTOMERS", "Carileri G\xF6r\xFCnt\xFCle"),
  def("customer.create", "CUSTOMERS", "Yeni Cari"),
  def("customer.edit", "CUSTOMERS", "Cari D\xFCzenle", "customer.view"),
  def("customer.deactivate", "CUSTOMERS", "Cari Pasife Al", "customer.view"),
  def("customer.export", "CUSTOMERS", "Cari D\u0131\u015Fa Aktar", "customer.view"),
  def("customer.orders.view", "CUSTOMERS", "Cari Sipari\u015Flerini G\xF6r", "customer.view"),
  def("customer.orders.create", "CUSTOMERS", "Cari Sipari\u015F Ekle", "customer.orders.view"),
  def("customer.payments.view", "CUSTOMERS", "\xD6demeleri G\xF6r", "customer.view"),
  def("customer.payments.create", "CUSTOMERS", "Gelen \xD6deme Ekle", "customer.payments.view"),
  def("customer.credit.view", "CUSTOMERS", "Kredi Limitini G\xF6r", "customer.view"),
  def("customer.credit.edit", "CUSTOMERS", "Kredi Limitini D\xFCzenle", "customer.credit.view"),
  def("product.view", "PRODUCTS", "\xDCr\xFCn/Malzeme Ana Verisini G\xF6r"),
  def("product.create", "PRODUCTS", "Yeni \xDCr\xFCn/Malzeme"),
  def("product.edit", "PRODUCTS", "\xDCr\xFCn/Malzeme D\xFCzenle", "product.view"),
  def("product.deactivate", "PRODUCTS", "\xDCr\xFCn/Malzeme Pasife Al", "product.view"),
  def("product.export", "PRODUCTS", "\xDCr\xFCn/Malzeme D\u0131\u015Fa Aktar", "product.view"),
  def("product.cost.view", "PRODUCTS", "Maliyetleri G\xF6r", "product.view"),
  def("cloud.view", "CLOUD", "Bulut G\xF6r\xFCnt\xFCle"),
  def("cloud.download", "CLOUD", "Dosya \u0130ndir", "cloud.view"),
  def("cloud.upload", "CLOUD", "Dosya Y\xFCkle", "cloud.view"),
  def("cloud.edit", "CLOUD", "Dosya/Link D\xFCzenle", "cloud.view"),
  def("cloud.move", "CLOUD", "Kay\u0131t Ta\u015F\u0131", "cloud.edit"),
  def("cloud.archive", "CLOUD", "Kay\u0131t Sil", "cloud.edit"),
  def("cloud.folder.manage", "CLOUD", "Klas\xF6r Y\xF6net", "cloud.view"),
  def("cloud.version.manage", "CLOUD", "Versiyon Y\xF6net", "cloud.edit"),
  def("operations.view", "OPERATIONS", "\xDCretim Bilgilerini G\xF6r"),
  def("operations.start_production", "OPERATIONS", "Onayland\u0131 \u2192 \xDCretimde", "operations.view"),
  def("operations.mark_ready_to_ship", "OPERATIONS", "\xDCretimde \u2192 Sevke Haz\u0131r", "operations.view"),
  def("operations.mark_shipped", "OPERATIONS", "Sevke Haz\u0131r \u2192 Sevk Edildi", "operations.view"),
  def("operations.checklist.manage", "OPERATIONS", "Kontrol Listesi Y\xF6net", "operations.view"),
  def("operations.files.upload", "OPERATIONS", "Operasyon Dosyas\u0131 Y\xFCkle", "operations.view"),
  def("operations.notes.edit", "OPERATIONS", "Operasyon Notu D\xFCzenle", "operations.view"),
  def("task.view", "TASKS", "G\xF6revleri G\xF6r"),
  def("task.create", "TASKS", "G\xF6rev Ata"),
  def("task.edit", "TASKS", "G\xF6rev D\xFCzenle", "task.view"),
  def("task.complete", "TASKS", "G\xF6rev Tamamla", "task.view"),
  def("task.cancel", "TASKS", "G\xF6rev \u0130ptal Et", "task.view"),
  def("admin.companies.view", "ADMINISTRATION", "Firmalar\u0131 G\xF6r"),
  def("admin.companies.manage", "ADMINISTRATION", "Firma ve Lisans Y\xF6netimi"),
  def("admin.users.view", "ADMINISTRATION", "Kullan\u0131c\u0131lar\u0131 G\xF6r"),
  def("admin.users.create", "ADMINISTRATION", "Kullan\u0131c\u0131 Olu\u015Ftur", "admin.users.view"),
  def("admin.users.edit", "ADMINISTRATION", "Kullan\u0131c\u0131 D\xFCzenle", "admin.users.view"),
  def("admin.users.disable", "ADMINISTRATION", "Kullan\u0131c\u0131 Pasife Al", "admin.users.view"),
  def("admin.users.sessions.manage", "ADMINISTRATION", "Oturumlar\u0131 Y\xF6net", "admin.users.view"),
  def("admin.roles.view", "ADMINISTRATION", "Rolleri G\xF6r"),
  def("admin.roles.edit", "ADMINISTRATION", "Rolleri D\xFCzenle", "admin.roles.view"),
  def("admin.audit.view", "ADMINISTRATION", "\u0130\u015Flem Ge\xE7mi\u015Fini G\xF6r"),
  def("admin.company_settings.view", "ADMINISTRATION", "Firma Ayarlar\u0131n\u0131 G\xF6r"),
  def("admin.company_settings.edit", "ADMINISTRATION", "Firma Ayarlar\u0131n\u0131 D\xFCzenle", "admin.company_settings.view"),
  def("admin.advanced_settings.view", "ADMINISTRATION", "Geli\u015Fmi\u015F Ayarlar\u0131 G\xF6r"),
  def("admin.company_limits.edit", "ADMINISTRATION", "Firma Limitlerini D\xFCzenle", "admin.advanced_settings.view")
];
function mapPermissions(allow) {
  const out = {};
  for (const id of PERMISSIONS) out[id] = allow.includes(id);
  return out;
}
var commonView = ["dashboard.view", "dashboard.widget.quote_7d", "dashboard.widget.approved_projects", "dashboard.widget.ready_to_ship", "dashboard.widget.shipped", "project.view", "project.files.view", "product.view", "cloud.view", "cloud.download", "task.view", "task.create", "task.edit", "task.complete", "task.cancel"];
var all = PERMISSIONS.slice();
var scopes = (value) => ({ PROJECTS: value, CUSTOMERS: value, OPERATIONS: value, DASHBOARD: value });
function createDefaultRoles() {
  const role = (roleId, allow, scope, locked = false) => ({ roleId, label: ROLE_LABELS[roleId], locked, permissions: mapPermissions(allow), dataScopes: scopes(scope) });
  return [
    role("SYSTEM_ADMIN", all, "ALL_COMPANY", true),
    role("COMPANY_ADMIN", all.filter((p) => !p.startsWith("admin.companies.")), "ALL_COMPANY", true),
    role("DESIGNER", [...commonView, "project.create", "project.edit", "project.revision.create", "project.export", "project.files.upload", "operations.view", "product.export"], "OWN_OR_ASSIGNED"),
    role("SALES_REPRESENTATIVE", [...commonView, "project.create", "project.edit", "commercial.quote.view", "commercial.quote.create", "commercial.price.view", "commercial.price.edit", "commercial.proforma.create", "commercial.order.view", "customer.view", "customer.create", "customer.edit", "customer.orders.view", "customer.orders.create", "customer.payments.view", "customer.payments.create", "product.export"], "OWN_OR_ASSIGNED"),
    role("DEALER", ["dashboard.view", "dashboard.widget.quote_7d", "dashboard.widget.approved_projects", "project.view", "project.create", "project.edit", "commercial.quote.view", "commercial.quote.create", "customer.view", "product.view", "cloud.view", "cloud.download", "task.view", "task.create", "task.edit", "task.complete", "task.cancel"], "OWN"),
    role("VIEWER", ["dashboard.view", "project.view", "project.files.view", "commercial.quote.view", "customer.view", "product.view", "cloud.view", "cloud.download", "task.view"], "OWN_OR_ASSIGNED"),
    role("OPERATIONS_CONTROL", ["dashboard.view", "dashboard.widget.approved_projects", "dashboard.widget.ready_to_ship", "dashboard.widget.shipped", "project.view", "project.files.view", "operations.view", "operations.start_production", "operations.mark_ready_to_ship", "operations.checklist.manage", "operations.files.upload", "operations.notes.edit", "cloud.view", "cloud.download", "task.view", "task.create", "task.edit", "task.complete", "task.cancel"], "ALL_COMPANY"),
    role("PRODUCTION_OPERATOR", ["dashboard.view", "project.view", "project.files.view", "operations.view", "operations.checklist.manage", "cloud.view", "cloud.download", "task.view", "task.create", "task.edit", "task.complete", "task.cancel"], "ASSIGNED"),
    role("INSTALLATION_SERVICE", ["dashboard.view", "project.view", "project.files.view", "operations.view", "operations.files.upload", "operations.notes.edit", "cloud.view", "cloud.download", "task.view", "task.create", "task.edit", "task.complete", "task.cancel"], "ASSIGNED"),
    role("FINANCE_COLLECTIONS", ["dashboard.view", "dashboard.widget.order_total", "project.view", "commercial.price.view", "commercial.order.view", "customer.view", "customer.orders.view", "customer.payments.view", "customer.payments.create", "customer.credit.view", "task.view", "task.create", "task.edit", "task.complete", "task.cancel"], "ALL_COMPANY")
  ];
}
function resolvePermission(role, userOverrides, permissionId) {
  const override = userOverrides[permissionId] || "INHERIT";
  let allowed = override === "ALLOW" ? true : override === "DENY" ? false : !!role.permissions[permissionId];
  const dependency = PERMISSION_DEFINITIONS.find((row) => row.id === permissionId)?.dependsOn;
  if (allowed && dependency) allowed = resolvePermission(role, userOverrides, dependency);
  return allowed;
}

// services/storageSnapshot.ts
function freeze(value) {
  if (value && typeof value === "object") {
    Object.freeze(value);
    for (const child of Object.values(value)) freeze(child);
  }
  return value;
}
function createStorageSnapshot(key, fallback) {
  let previous;
  let snapshot2 = fallback;
  return (storage) => {
    try {
      const raw = storage.getItem(key);
      if (raw !== previous) {
        snapshot2 = raw ? freeze(JSON.parse(raw)) : fallback;
        previous = raw;
      }
      return snapshot2;
    } catch {
      previous = void 0;
      return fallback;
    }
  };
}

// services/platformAccess.ts
var PLATFORM_KEYS = { users: "plmr.users.v13", companies: "plmr.companies.v68", credentials: "plmr.credentials.v68", session: "plmr.auth.session.v68", attempts: "plmr.auth.attempts.v68", audit: "plmr.platform.audit.v68", initialized: "plmr.clean-start.v68" };
var nativeStorage = () => cloudEnabled() ? cloudStorage : globalThis.localStorage;
function readGlobal(key, fallback) {
  try {
    const raw = nativeStorage().getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
var userSnapshot = createStorageSnapshot(PLATFORM_KEYS.users, []);
var companySnapshot = createStorageSnapshot(PLATFORM_KEYS.companies, []);
var platformUsers = () => userSnapshot(nativeStorage());
var platformCompanies = () => companySnapshot(nativeStorage());
var sessionSnapshot = createStorageSnapshot(PLATFORM_KEYS.session, null);
function loginSession() {
  return sessionSnapshot(sessionStorage);
}
configureCloudAccess(() => loginSession()?.companyId || null, (key) => {
  if (isSystem()) return true;
  if (key === PLATFORM_KEYS.users) return ["admin.users.create", "admin.users.edit", "admin.users.disable"].some((p) => actorCan(p));
  const m = /^plmr\.tenant\.v68\.[^.]+\.(.+)$/.exec(key);
  if (!m) return false;
  try {
    return cloudPolicy(m[1]).write.some(actorCan);
  } catch {
    return false;
  }
});
var actor = () => platformUsers().find((u) => u.userId === loginSession()?.userId);
var isSystem = () => actor()?.roleId === "SYSTEM_ADMIN";
var activeCompany = () => platformCompanies().find((c) => c.companyId === loginSession()?.companyId);
var memberships = (u) => u.memberships || [];
function effectiveUser(u, companyId2 = loginSession()?.companyId) {
  if (u.roleId === "SYSTEM_ADMIN") return u;
  const m = memberships(u).find((m2) => m2.companyId === companyId2);
  return { ...u, roleId: m?.roleId || "VIEWER", status: u.status === "ACTIVE" && m?.status === "ACTIVE" ? "ACTIVE" : "INACTIVE", permissionOverrides: m?.permissionOverrides || {}, dataScopeOverrides: m?.dataScopeOverrides || {} };
}
function companyAllowed(u, c) {
  return u.status === "ACTIVE" && (u.roleId === "SYSTEM_ADMIN" || c.status === "ACTIVE" && memberships(u).some((m) => m.companyId === c.companyId && m.status === "ACTIVE"));
}
function licenseExpired(c = activeCompany()) {
  if (!c) return true;
  const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA", { timeZone: "Europe/Istanbul" });
  return today < c.licenseStart || today > c.licenseEnd;
}
function writePermission(permission) {
  return /\.(create|edit|manage|change|approve|disable|archive|override|deactivate|upload|complete|cancel|start_production|mark_ready_to_ship|mark_shipped)$/.test(permission);
}
function currentRole() {
  const user2 = actor();
  const roleId = user2 ? effectiveUser(user2).roleId : "VIEWER";
  const defaults = createDefaultRoles();
  const custom = readGlobal(tenantKey("plmr.roles.v13"), []);
  return defaults.find((r) => r.roleId === roleId && r.locked) || [...custom, ...defaults].find((r) => r.roleId === roleId) || defaults.find((r) => r.roleId === "VIEWER");
}
function actorCan(permission) {
  const u = actor();
  if (!sessionValid() || !u || u.status !== "ACTIVE" || frozenCompany !== void 0 && frozenCompany !== (loginSession()?.companyId || "none")) return false;
  if (u.roleId === "SYSTEM_ADMIN") return true;
  const c = activeCompany();
  if (!c || !companyAllowed(u, c)) return false;
  if (permission.startsWith("admin.companies.")) return false;
  if (licenseExpired(c) && writePermission(permission)) return false;
  return resolvePermission(currentRole(), effectiveUser(u).permissionOverrides, permission);
}
var frozenCompany;
function scopedCompanyId() {
  if (frozenCompany === void 0) frozenCompany = loginSession()?.companyId || "none";
  return frozenCompany;
}
function tenantKey(key, companyId2 = scopedCompanyId()) {
  return `plmr.tenant.v68.${companyId2}.${key}`;
}
function assertTenantReadable() {
  const s = loginSession(), u = actor(), c = activeCompany();
  if (!sessionValid() || !s || s.expiresAt < Date.now() || !u || !c || scopedCompanyId() !== c.companyId || !companyAllowed(u, c)) throw new Error("Bu firman\u0131n kay\u0131tlar\u0131na eri\u015Fim yetkiniz yok.");
  return c.companyId;
}
var tenantStorage = { getItem(key) {
  if (!activeCompany()) return null;
  assertTenantReadable();
  return nativeStorage().getItem(tenantKey(key));
}, setItem(key, value) {
  if (!activeCompany()) return;
  assertTenantReadable();
  nativeStorage().setItem(tenantKey(key), value);
}, removeItem(key) {
  if (!activeCompany()) return;
  assertTenantReadable();
  nativeStorage().removeItem(tenantKey(key));
} };
function availableCompanies(u = actor()) {
  return u ? platformCompanies().filter((c) => companyAllowed(u, c)) : [];
}
function sessionValid() {
  if (cloudEnabled() && !cloudHasSession()) return false;
  const s = loginSession(), u = actor();
  if (!s || !u || u.status !== "ACTIVE" || s.expiresAt < Date.now()) return false;
  const credential = readGlobal(PLATFORM_KEYS.credentials, {})[u.userId];
  if (!credential || credential.version !== s.authVersion) return false;
  return !s.companyId ? u.roleId === "SYSTEM_ADMIN" : availableCompanies(u).some((c) => c.companyId === s.companyId);
}

// utils/formatters.ts
function getAppLocale() {
  try {
    return tenantStorage.getItem("plmr.locale") === "en-US" ? "en-US" : "tr-TR";
  } catch {
    return "tr-TR";
  }
}
function formatDateTime(value, locale = getAppLocale()) {
  return displayProjectDate(value, locale);
}

// domain/quickQuoteProject.ts
function projectFromQuickQuote(q, existing, representative = "") {
  if (existing?.hasTechnicalDrawing) return existing;
  const amounts = quoteAmounts(q), now = q.updatedAt;
  const lines = filledPositions(q).flatMap((p, index) => p.lines.filter((l) => l.name.trim()).map((l) => {
    const a = lineAmounts(l);
    return { quoteUnitRounding: true, lineId: l.id, sourceType: "MANUAL", priceSource: "MANUAL", sourcePositionId: p.id, positionNo: String(index + 1), description: p.name + " \u2014 " + l.name + (l.description ? " \xB7 " + l.description : ""), sizeDisplay: p.kind === "PRODUCT" ? p.width + " x " + p.height + " mm" : "", quantity: numberValue(l.quantity) || 0, unit: l.unit, unitPrice: numberValue(l.unitPrice) || 0, discountPercent: numberValue(l.discountPercent) || 0, grossAmount: a.gross, discountAmount: a.discount, netAmount: a.net };
  }));
  const correction = amounts.final - lines.reduce((total, line) => total + line.netAmount, 0);
  if (Math.abs(correction) > 5e-3) lines.push({ lineId: q.id + "-adjustment", sourceType: "MANUAL", priceSource: "MANUAL", description: "Manuel iskonto / yuvarlama", sizeDisplay: "", quantity: 1, unit: "adet", unitPrice: correction, discountPercent: 0, grossAmount: correction, discountAmount: 0, netAmount: correction });
  const pricing = { lines, terms: { currency: q.currency, paymentMethod: "", paymentTerm: "", incoterm: "", deliveryPlace: "", shipping: "", installation: "", leadTime: "", quoteValidityDays: Number(q.validityDays) || 30, taxEnabled: false, taxName: "", taxRate: 0, defaultDiscountPercent: 0 }, subtotal: amounts.final, taxAmount: 0, total: amounts.final, updatedAt: now, updatedBy: q.ownerUserId };
  const projectId = existing?.projectId || uuidv7(), revisionId = existing?.revisionId || uuidv7(), revision = existing?.revizyon || "R00";
  const quoteSnapshot = { ...q, attachments: q.attachments.map(({ dataUrl, ...metadata }) => metadata) };
  const snapshot2 = { revisionId, label: revision, createdAt: now, createdBy: q.ownerUserId, technicalSignature: "QUICK_QUOTE:" + q.version, workspaceState: { quickQuote: quoteSnapshot }, pricing, customerSnapshot: { id: q.customerId, name: q.customerName }, masterSnapshot: { projKodu: q.projectCode, projeAdi: q.projectName, musteriAdi: q.customerName }, previousCurrentRevisionId: null, derivedFromRevisionId: null };
  return { ...existing, id: existing?.id || Date.now() + Math.floor(Math.random() * 1e6), projectId, revisionId, sourceQuickQuoteId: q.id, sourceQuickQuoteVersion: q.version, hasTechnicalDrawing: false, statusSchemaVersion: 54, createdByUserId: q.ownerUserId, ownerUserId: q.ownerUserId, siraNo: existing?.siraNo || String(Number(q.projectCode.slice(-6))).padStart(3, "0"), projKodu: q.projectCode, musteriAdi: q.customerName, customerId: q.customerId, projeAdi: q.projectName, urunler: [...new Set(filledPositions(q).flatMap((p) => p.product ? [p.product] : []))], revizyon: revision, musteriTemsilcisi: representative || existing?.musteriTemsilcisi || "", cizen: "", teklifVeren: q.issuerCompany || q.preparedBy, uretimiAcan: null, olusturmaTarihi: existing?.olusturmaTarihi || formatDateTime(new Date(q.createdAt)), sonIslemTarihi: formatDateTime(new Date(now)), status: existing?.status || 10, productionItems: existing?.productionItems || [], quotes: [{ id: q.id, kind: "quick", sourceQuoteId: q.id, date: q.date, amount: amounts.final, currency: q.currency, approved: false }], pricing, revisions: [...(existing?.revisions || []).filter((r) => r.revisionId !== revisionId), snapshot2], recordVersion: (existing?.recordVersion || 0) + 1, updatedAt: now, updatedBy: q.ownerUserId };
}

// domain/projectWorkflow.ts
var drLabel = (n) => "DR" + String(n).padStart(2, "0");
var qrLabel = (n) => "QR" + String(n).padStart(2, "0");
var revisionNumber = (v) => {
  const match = String(v ?? "").match(/^(?:DR|QR|R)?(\d+)$/i);
  return match ? Number(match[1]) : 0;
};
function stable(v) {
  if (Array.isArray(v)) return "[" + v.map(stable).join(",") + "]";
  if (v && typeof v === "object") return "{" + Object.keys(v).filter((k) => v[k] !== void 0).sort().map((k) => JSON.stringify(k) + ":" + stable(v[k])).join(",") + "}";
  return JSON.stringify(v) ?? "null";
}
function drawingFingerprint(record) {
  const map = record.productWorkspaces || { [record.product]: { product: record.product, module1: record.module1, submodule: record.submodule, settings: record.settings, positions: record.positions } };
  return stable({ scene: record.drawingScene ? finalTechnicalScene(record.drawingScene) : void 0, workspaces: Object.keys(map).sort().filter((k) => map[k].positions.length).map((k) => {
    const w = map[k];
    return { product: k, module1: w.module1, submodule: w.submodule, settings: w.settings, positions: w.positions.map((p) => ({ ...p, inputUnit: void 0 })), layout: { columns: w.drawingLayout?.columns } };
  }), layout: { columns: record.drawingLayout?.columns, positionOrder: record.drawingLayout?.positionOrder } });
}
function quoteFingerprint(q) {
  const { version, id, createdAt, updatedAt, revision, quoteNumber, state, reviewRequired, ...content } = q;
  return stable(content);
}
function withoutWorkflow(record) {
  const { workflow, ...rest } = record;
  return structuredClone(rest);
}
function initialWorkflow(record, origin, quote) {
  const current = quote ? { ...structuredClone(quote), revision: qrLabel(revisionNumber(quote.revision)), quoteNumber: qrLabel(revisionNumber(quote.revision)), workflowManaged: true, state: quote.state || (quote.version > 0 ? "FINAL" : "DRAFT") } : void 0;
  return { schemaVersion: 58, version: 0, origin, drawingLocked: false, drawingRevision: revisionNumber(record.projectInfo.revision), drawings: [], quote: current, quotes: current?.state === "FINAL" ? [structuredClone(current)] : [], links: [], events: [] };
}
function workflowOf(record, origin = "DRAWING", quote) {
  return structuredClone(record.workflow || initialWorkflow(record, origin, quote));
}
function recordWorkflowEvent(w, type, actor2, at = (/* @__PURE__ */ new Date()).toISOString()) {
  w.events.push({ id: uuidv7(), at, actor: actor2, type, drawingRevision: drLabel(w.drawingRevision), quoteRevision: w.quote ? qrLabel(revisionNumber(w.quote.revision)) : null });
  w.version++;
  return w;
}
function archiveQuote(w, q) {
  if (!w.quotes.some((old) => old.id === q.id)) w.quotes.push(structuredClone(q));
}
function canKeepQuote(w) {
  return Boolean(w.quote && (w.origin === "QUOTE" || w.drawings.length));
}
function nextDrawingRevision(record, w) {
  const last = Math.max(w.drawingRevision, ...w.drawings.map((row) => row.revision));
  return w.continuedFromRevisionId || w.activeDrawingRevisionId && w.lockedSignature !== drawingFingerprint(record) ? last + 1 : last;
}
function quoteSourceFields(record, base, hasPrevious = true) {
  const info = record.projectInfo;
  return {
    customerName: record.customerSnapshot?.name || base.customerName,
    customerDocumentName: record.customerSnapshot?.documentBrandName || record.customerSnapshot?.name || base.customerDocumentName,
    customerAccountCode: record.customerSnapshot?.customerAccountCode || base.customerAccountCode,
    currency: hasPrevious ? base.currency : record.quoteCurrency || base.currency,
    projectCode: record.projectCode,
    projectName: info.projectName,
    customerId: info.customerId,
    issuerCompany: info.issuerCompany,
    customerContactId: info.customerContactId,
    projectRepresentative: info.projectRepresentative,
    projectDescription: info.description,
    country: info.country,
    unit: info.outputUnit
  };
}
function quoteSourceUnchanged(record, quote) {
  return Object.entries(quoteSourceFields(record, quote)).every(([key, value]) => stable(value ?? "") === stable(quote[key] ?? ""));
}
function quoteFromDrawing(record, w, actor2) {
  const prev = w.quote, next = prev ? structuredClone(prev) : createQuickQuote(actor2, record.projectInfo.projectRepresentative);
  const previous = prev?.positions || [], positions = [], matched = /* @__PURE__ */ new Set();
  for (const [name, ws] of Object.entries(record.productWorkspaces || { [record.product]: { product: record.product, settings: record.settings, positions: record.positions } })) {
    if (!isFinalProduct(name)) throw Error("Desteklenmeyen \xFCr\xFCn tekliften \xE7\u0131kar\u0131lamaz: " + name);
    for (const p of ws.positions) {
      const link = w.links.find((l) => l.product === name && l.drawingPositionId === p.id), old = previous.find((q2) => q2.sourceDrawingPositionId === p.id && q2.sourceDrawingProduct === name) || previous.find((q2) => q2.id === link?.quotePositionId);
      if (old) matched.add(old.id);
      const base = old ? { ...structuredClone(old), id: old.id } : createQuotePosition(name, ws.settings);
      const output = quoteFromWorkspace(name, ws.settings, p, base);
      delete output.finalSnapshot;
      if (record.drawingScene) output.finalRow = structuredClone(p.finalRow);
      output.id = base.id;
      output.sourceDrawingPositionId = p.id;
      output.sourceDrawingProduct = name;
      output.sourceQuotePositionId = link?.quotePositionId;
      positions.push(output);
    }
  }
  const preservedFees = previous.filter((p) => p.kind === "PRODUCT" && !matched.has(p.id) && p.lines.slice(1).some((l) => l.source !== "GIYOTIN_REMOTE")).map((p) => ({ ...structuredClone(p), id: p.id + "-commercial", kind: "COMMERCIAL", pricingSnapshot: void 0, product: null, name: p.name + " \xB7 Ek Kalemler", width: "", height: "", settings: null, baseSettings: void 0, overrides: void 0, sourceDrawingPositionId: void 0, sourceDrawingProduct: void 0, lines: p.lines.slice(1).filter((l) => l.source !== "GIYOTIN_REMOTE") }));
  const revision = prev ? Math.max(revisionNumber(prev.revision), ...w.quotes.map((q2) => revisionNumber(q2.revision))) + 1 : 0;
  const q = { ...next, ...quoteSourceFields(record, next, !!prev), id: uuidv7(), version: 1, workflowManaged: true, state: "DRAFT", revision: qrLabel(revision), quoteNumber: qrLabel(revision), positions: [...positions, ...previous.filter((p) => p.kind === "COMMERCIAL").map((p) => structuredClone(p)), ...preservedFees], finalAmount: "", totalMode: next.totalMode ? "ADJUSTMENT" : void 0, reviewRequired: true, sourceDrawingRevisionId: w.activeDrawingRevisionId, sourceDrawingRevision: drLabel(w.drawingRevision), createdAt: (/* @__PURE__ */ new Date()).toISOString(), updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  const g = record.productWorkspaces?.Giyotin?.settings || (record.product === "Giyotin" ? record.settings : null);
  if (g) q.giyotinRemotes = remoteSelections(g);
  return syncQuoteRemotes(q, prev || q);
}
function lockDrawingRecord(record, action, actor2) {
  assertFinalQuoteReady(record);
  const w = workflowOf(record), signature = drawingFingerprint(record);
  if (w.drawingLocked) throw new Error("\xC7izim zaten kilitli.");
  if (!Object.values(record.productWorkspaces || { [record.product]: { positions: record.positions } }).some((ws) => ws.positions.length)) throw new Error("Kilitlemek i\xE7in en az bir \xE7izim pozu ekleyin.");
  if (action === "KEEP" && !canKeepQuote(w)) throw new Error("Bu ak\u0131\u015Fta korunabilecek bir fiyat teklifi bulunmuyor.");
  for (const ws of Object.values(record.productWorkspaces || { [record.product]: record })) {
    if (!ws.positions.length) continue;
    if (ws.product === "Giyotin") {
      const error = validateGiyotinSettings(ws.settings);
      if (error) throw new Error(error);
    }
    if (ws.product === "S\xFCrme" && ws.positions.some((p) => !["SIDE OPENING", "CENTER OPENING"].includes(resolveSliding(ws.settings, p).openingType))) throw new Error("S\xFCrme \xE7izimi i\xE7in a\xE7\u0131l\u0131m d\xFCzenini kenardan veya merkezden olarak se\xE7in.");
    const sample = createQuickQuote(actor2, "");
    const check = validateQuote({ ...sample, customerId: "check", customerName: "check", projectName: "check", positions: ws.positions.map((p) => quoteFromWorkspace(ws.product, ws.settings, p)) });
    if (check.length) throw new Error(check[0]);
  }
  const n = nextDrawingRevision(record, w);
  if (!w.activeDrawingRevisionId || n !== w.drawingRevision) {
    w.drawingRevision = n;
    w.activeDrawingRevisionId = uuidv7();
    const snapshot2 = withoutWorkflow(record);
    snapshot2.projectInfo.revision = n;
    w.drawings.push({ id: w.activeDrawingRevisionId, revision: n, signature, lockedAt: (/* @__PURE__ */ new Date()).toISOString(), lockedBy: actor2, sourceQuoteId: w.sourceQuoteForDrawing?.id, sourceDrawingRevisionId: w.continuedFromRevisionId, record: snapshot2 });
  }
  delete w.continuedFromRevisionId;
  delete w.workingRevisionId;
  w.lockedSignature = signature;
  w.drawingLocked = true;
  const generate = action === "GENERATE" && (!w.quote || w.quote.sourceDrawingRevisionId !== w.activeDrawingRevisionId || !quoteSourceUnchanged(record, w.quote));
  if (generate) {
    if (w.quote) archiveQuote(w, w.quote);
    w.quote = quoteFromDrawing(record, w, actor2);
  }
  recordWorkflowEvent(w, generate ? "DRAWING_LOCKED_NEW_QUOTE" : action === "ONLY" ? "DRAWING_LOCKED_ONLY" : "DRAWING_LOCKED_KEEP_QUOTE", actor2);
  return { ...record, projectInfo: { ...record.projectInfo, revision: w.drawingRevision }, workflow: w, technicalCommitted: true, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function saveWorkflowQuote(record, input, finalize = false) {
  const w = workflowOf(record, "QUOTE"), old = w.quote;
  if (old && (old.id !== input.id || old.version !== input.version)) throw new Error("Teklif ba\u015Fka bir sekmede veya revizyonda de\u011Fi\u015Fti. G\xFCncel teklifi a\xE7\u0131n.");
  let q = structuredClone(input);
  if (finalize) {
    const history = w.quotes.filter((quote) => quote.state === "FINAL");
    if (old?.state === "FINAL") history.push(old);
    const last = history.reduce((best, quote) => !best || revisionNumber(quote.revision) >= revisionNumber(best.revision) ? quote : best, void 0);
    if (last && revisionNumber(q.revision) === revisionNumber(last.revision) && quoteFingerprint(q) === quoteFingerprint(last)) {
      q = { ...q, id: last.id, revision: last.revision, version: Math.max(old?.version || 0, last.version), state: "FINAL" };
    } else {
      const number = revisionNumber(q.revision);
      const revision = last ? Math.max(number, revisionNumber(last.revision) + 1) : number;
      q = { ...q, id: uuidv7(), revision: qrLabel(revision), state: "FINAL", version: 0 };
    }
  } else if (old?.state === "FINAL") {
    if (input.state !== "DRAFT") throw new Error("Teklif kilitli. \xD6nce Teklifi D\xFCzenle i\u015Flemini kullan\u0131n.");
    archiveQuote(w, old);
    q = { ...q, id: uuidv7(), state: "DRAFT", version: 0 };
  }
  q = { ...q, workflowManaged: true, revision: qrLabel(revisionNumber(q.revision)), quoteNumber: qrLabel(revisionNumber(q.revision)), version: (old?.id === q.id ? old.version : q.version) + 1, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), state: finalize ? "FINAL" : q.state || "DRAFT" };
  w.quote = q;
  if (finalize) archiveQuote(w, q);
  recordWorkflowEvent(w, finalize ? "QUOTE_FINALIZED" : "QUOTE_SAVED", q.ownerUserId);
  return { ...record, workflow: w, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function projectFromWorkflow(record, existing) {
  const w = record.workflow;
  if (!w) return existing;
  let master = { ...existing };
  if (w.quote) {
    master = projectFromQuickQuote(w.quote, { ...existing, hasTechnicalDrawing: false }, existing.musteriTemsilcisi);
    master = { ...master, productionItems: existing.productionItems, productionPackages: existing.productionPackages };
  }
  const legacy = (existing.revisions || []).filter((r) => !r.label.startsWith("DR"));
  const rows = w.drawings.map((d) => existing.revisions?.find((r) => r.revisionId === d.id) || { revisionId: d.id, label: drLabel(d.revision), createdAt: d.lockedAt, createdBy: d.lockedBy, technicalSignature: d.signature, workspaceState: { ...d.record, quickQuote: void 0 }, pricing: void 0, masterSnapshot: { projKodu: existing.projKodu, projeAdi: d.record.projectInfo.projectName, musteriAdi: existing.musteriAdi }, previousCurrentRevisionId: null });
  return approvalMasterProjection(record, { ...master, projeAdi: record.projectInfo.projectName, customerId: record.projectInfo.customerId, urunler: [.../* @__PURE__ */ new Set([...Object.entries(record.productWorkspaces || {}).filter(([, ws]) => ws.positions.length).map(([name]) => name), ...w.quote?.positions.flatMap((p) => p.product ? [p.product] : []) || []])], projectId: existing.projectId, id: existing.id, siraNo: existing.siraNo, workflowVersion: w.version, workflowOrigin: w.origin, quoteRevision: w.quote ? qrLabel(revisionNumber(w.quote.revision)) : void 0, drawingRevision: drLabel(w.drawingRevision), drawingLocked: w.drawingLocked, revizyon: drLabel(w.drawingRevision), revisionId: w.workingRevisionId || w.activeDrawingRevisionId || existing.revisionId, revisions: [...legacy, ...rows], sourceQuickQuoteId: w.quote?.id || existing.sourceQuickQuoteId, sourceQuickQuoteVersion: w.quote?.version || existing.sourceQuickQuoteVersion, quotes: [...new Map([...w.quotes, ...w.quote ? [w.quote] : []].map((q) => [q.id, { id: q.id, kind: "quick", sourceQuoteId: q.id, date: q.date, amount: quoteAmounts(q).final, currency: q.currency, approved: q.state === "FINAL" }])).values()], hasTechnicalDrawing: Object.values(record.productWorkspaces || { [record.product]: { positions: record.positions } }).some((ws) => ws.positions.length), cizen: record.projectInfo.projectRepresentative || existing.cizen, updatedAt: record.updatedAt });
}

// domain/projectApprovals.ts
var APPROVAL_STAGES = ["quote", "package", "production", "shipment"];
function approvalMarkers(a) {
  const { package: p, ...stamps } = a;
  return { ...structuredClone(stamps), ...p ? { package: { at: p.at, by: p.by, name: p.name, document: { sourceRevisionId: p.document.sourceRevisionId } } } : {} };
}
var approvalPermissions = { quote: "project.approve", package: "operations.start_production", production: "operations.mark_ready_to_ship", shipment: "operations.mark_shipped" };
function approvalStage(value) {
  if (!APPROVAL_STAGES.includes(value)) throw Error("Onay a\u015Famas\u0131 ge\xE7ersiz.");
  return value;
}
function object(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw Error("\xDCretim paketi ge\xE7ersiz.");
  return value;
}
function list(value) {
  if (!Array.isArray(value)) throw Error("\xDCretim paketi eksik.");
  return value;
}
function approveProjectRecord(input, stage, by, name, document) {
  let next = input;
  const previous = input.workflow?.approvals || {};
  if (previous[stage]) return input;
  let w = input.workflow || workflowOf(input);
  const index = APPROVAL_STAGES.indexOf(stage);
  if (index > 0 && !previous[APPROVAL_STAGES[index - 1]]) throw Error("\xD6nce bir \xF6nceki a\u015Famay\u0131 onaylay\u0131n.");
  if (previous.shipment) throw Error("Sevkiyat onayland\u0131. Proje salt okunurdur.");
  const stamp = { at: (/* @__PURE__ */ new Date()).toISOString(), by, name };
  if (stage === "quote") {
    if (!w.quote) throw Error("Onaylanacak teklif bulunamad\u0131. \xD6nce teklif olu\u015Fturun.");
    const errors = validateQuote(w.quote);
    if (errors.length) throw Error(errors[0]);
    if (w.quote.state !== "FINAL") next = saveWorkflowQuote({ ...next, workflow: w }, w.quote, true);
    w = next.workflow || w;
  }
  if (stage === "package") {
    if (!w.drawingLocked) next = lockDrawingRecord({ ...next, workflow: w }, "ONLY", by);
    w = next.workflow || w;
    if (!document) throw Error("Onaylanacak \xFCretim paketi bulunamad\u0131.");
    const pkg = object(document.package), validation = object(pkg.validation);
    if (list(validation.errors).length) throw Error("\xDCretim paketindeki hatalar\u0131 tamamlay\u0131n.");
    const positions = list(pkg.positions).map(object);
    const workspaces = Object.values(next.productWorkspaces || { [next.product]: next });
    const source = workspaces.flatMap((ws) => ws.positions.map((p) => ({ product: ws.product, position: p, settings: { ...ws.settings, ...p.overrides } })));
    if (!source.length || source.some((row) => row.product !== "Giyotin") || source.length !== positions.length) throw Error("T\xFCm pozlar i\xE7in desteklenen ve tamamlanm\u0131\u015F bir \xFCretim paketi gerekli.");
    if (new Set(positions.map((p) => p.positionId)).size !== positions.length) throw Error("\xDCretim paketinde tekrarlanan poz var.");
    for (const row of source) {
      const position = positions.find((p) => p.positionId === row.position.id);
      if (!position) throw Error("\xDCretim paketinde eksik poz var.");
      const frozen = object(position.source);
      if (Number(frozen.width) !== Number(row.position.width) || Number(frozen.height) !== Number(row.position.height) || Number(frozen.quantity) !== Number(row.position.quantity)) throw Error("\xDCretim paketi g\xFCncel \xE7izimle e\u015Fle\u015Fmiyor.");
      for (const raw of list(position.lines)) {
        const line = object(raw);
        if (line.status === "MANUAL_REQUIRED" || Object.values(object(line.fieldStatus)).includes("MANUAL_REQUIRED")) throw Error("\xDCretim paketinde zorunlu giri\u015F eksik.");
      }
    }
    if (!document.sourceSignature || !Number.isSafeInteger(document.packageVersion) || document.packageVersion < 1) throw Error("\xDCretim paketi s\xFCr\xFCm\xFC ge\xE7ersiz.");
    document = { ...structuredClone(document), sourceRevisionId: w.activeDrawingRevisionId };
  }
  w = { ...w, events: [...w.events] };
  delete w.withdrawnStatus;
  w.approvals = { ...previous, [stage]: stage === "package" ? { ...stamp, document } : stamp };
  recordWorkflowEvent(w, "APPROVED_" + stage.toUpperCase(), by, stamp.at);
  return { ...next, workflow: w, updatedAt: stamp.at };
}
function canWithdrawProject(from, to) {
  return typeof from === "number" && from < 60 && typeof to === "number" && [10, 20, 30, 40].includes(to) && to < from;
}
function withdrawProjectRecord(record, target, actor2, note) {
  const current = record.workflow, approvals = current?.approvals;
  const from = current?.withdrawnStatus ?? (approvals?.shipment ? 60 : approvals?.production ? 50 : approvals?.package ? 30 : approvals?.quote ? 20 : 10);
  const reason = note.trim();
  if (!reason || reason.length > 2e3) throw Error("Geri \xE7ekme i\xE7in 1\u20132000 karakterlik a\xE7\u0131klama girin.");
  if (!current || !canWithdrawProject(from, target)) throw Error("Proje bu a\u015Famaya geri \xE7ekilemez.");
  const workflow = workflowOf(record);
  const retained = workflow.approvals || {};
  delete retained.production;
  if (target < 30 && retained.package) {
    const document = retained.package.document;
    workflow.withdrawnPackages = { ...workflow.withdrawnPackages, [document.sourceRevisionId]: document };
    workflow.continuedFromRevisionId = workflow.activeDrawingRevisionId;
    workflow.workingRevisionId = uuidv7();
    workflow.drawingLocked = false;
    delete retained.package;
  }
  if (target < 20) delete retained.quote;
  workflow.approvals = Object.keys(retained).length ? retained : void 0;
  workflow.withdrawnStatus = target;
  const at = (/* @__PURE__ */ new Date()).toISOString();
  recordWorkflowEvent(workflow, "PROJECT_WITHDRAWN", actor2, at);
  Object.assign(workflow.events.at(-1), { note: reason, fromStatus: from, toStatus: target });
  return { ...record, workflow, updatedAt: at };
}
function sameTechnicalDrawing(before, next) {
  return before.drawingScene === next.drawingScene && before.productWorkspaces === next.productWorkspaces && before.positions === next.positions && before.settings === next.settings && before.drawingLayout === next.drawingLayout && before.product === next.product && before.module1 === next.module1 && before.submodule === next.submodule || drawingFingerprint(before) === drawingFingerprint(next);
}
function assertApprovedRecordUnchanged(before, next, approvalCommand = false) {
  const a = before?.workflow?.approvals, b = next?.workflow?.approvals;
  if (!sameDocument(before?.workflow?.withdrawnPackages, next?.workflow?.withdrawnPackages)) throw Error("Geri \xE7ekilen \xFCretim paketleri de\u011Fi\u015Ftirilemez.");
  if (!approvalCommand && before?.workflow?.withdrawnStatus !== next?.workflow?.withdrawnStatus) throw Error("Geri \xE7ekme durumu yaln\u0131z i\u015F ak\u0131\u015F\u0131 i\u015Flemiyle de\u011Fi\u015Ftirilebilir.");
  if (!approvalCommand && !sameDocument(a, b)) throw Error("Onaylar yaln\u0131z onay i\u015Flemiyle de\u011Fi\u015Ftirilebilir.");
  if (!a) return;
  for (const stage of APPROVAL_STAGES) if (a[stage] && !sameDocument(a[stage], b?.[stage])) throw Error("Kaydedilmi\u015F onay de\u011Fi\u015Ftirilemez.");
  if (!next) throw Error("Onaylanm\u0131\u015F proje silinemez.");
  if (a.shipment && !sameDocument(before, next)) throw Error("Sevkiyat onayland\u0131. Proje salt okunurdur.");
  if (a.quote) {
    const old = before.workflow.quote, current = next.workflow?.quote;
    if (!old || !current || current.state !== "FINAL" || !sameDocument(old, current)) throw Error("Onaylanm\u0131\u015F teklif salt okunurdur.");
  }
  if (a.package && (!next.workflow?.drawingLocked || before.workflow.activeDrawingRevisionId !== next.workflow.activeDrawingRevisionId || !sameTechnicalDrawing(before, next) || !sameDocument(before.projectInfo, next.projectInfo))) throw Error("\xDCretim paketi onayland\u0131. \xC7izim ve \xFCretim dosyalar\u0131 salt okunurdur.");
}
function approvalMasterProjection(record, master) {
  const workflow = record.workflow, a = workflow?.approvals, withdrawn = workflow?.withdrawnStatus;
  if (!a && withdrawn === void 0) return master;
  const last = a?.shipment || a?.production || a?.package || a?.quote;
  let next = {
    ...master,
    approvals: a ? approvalMarkers(a) : void 0,
    status: withdrawn ?? (a?.shipment ? 60 : a?.production ? 50 : a?.package ? 30 : 20),
    orderApprovedAt: withdrawn === 10 ? void 0 : a?.quote?.at || master.orderApprovedAt,
    uretimiAcan: withdrawn !== void 0 && withdrawn < 30 ? null : a?.package?.name || master.uretimiAcan,
    sonIslemTarihi: withdrawn !== void 0 ? record.updatedAt : last?.at || master.sonIslemTarihi
  };
  if (workflow?.withdrawnPackages) next.productionPackages = { ...master.productionPackages, ...workflow.withdrawnPackages };
  if (a?.package) {
    const saved = a.package.document;
    next.productionPackages = { ...master.productionPackages, [saved.sourceRevisionId]: structuredClone(saved) };
  }
  next.productionItems = syncProductionItemsFromActiveRevision(next).map((item) => ({ ...item, status: withdrawn !== void 0 ? Math.max(20, withdrawn) : a?.shipment ? 60 : a?.production ? 50 : a?.package ? 30 : item.status, milestones: { ...item.milestones, onaylandi: a?.quote?.at || item.milestones.onaylandi, uretimde: a?.package?.at || item.milestones.uretimde, delivery: a?.production?.at || item.milestones.delivery, delivered: a?.shipment?.at || item.milestones.delivered } }));
  return next;
}
function assertApprovedMasterChange(before, next, canonical) {
  const a = canonical?.workflow ? canonical.workflow.approvals && approvalMarkers(canonical.workflow.approvals) : before?.approvals;
  if (!a) {
    if (next?.approvals) throw Error("Proje onay\u0131 ana kay\u0131tta bulunamad\u0131.");
    return;
  }
  if (!next) throw Error("Onaylanm\u0131\u015F proje silinemez.");
  const expected = canonical ? approvalMasterProjection(canonical, next) : before;
  if (next.status !== expected.status) throw Error("Onaylanm\u0131\u015F projenin a\u015Famas\u0131 yaln\u0131z onay d\xFC\u011Fmeleriyle ilerletilebilir.");
  if (!sameDocument(next.approvals, a)) throw Error("Onaylanm\u0131\u015F proje g\xFCncel de\u011Fil. Yeniden a\xE7\u0131n.");
  if (a.shipment && before) {
    const { recordVersion, updatedAt, updatedBy, ...old } = before;
    const { recordVersion: v, updatedAt: at, updatedBy: by, ...current } = next;
    const projected = canonical ? projectFromWorkflow(canonical, before) : before;
    const { recordVersion: pv, updatedAt: pa, updatedBy: pb, ...frozen } = projected;
    if (!sameDocument(old, current) && !sameDocument(frozen, current)) throw Error("Sevkiyat onayland\u0131. Proje salt okunurdur.");
  }
  if (a.package) {
    const id = a.package.document.sourceRevisionId, document = canonical?.workflow?.approvals?.package?.document || before?.productionPackages?.[id];
    if (!document || !next.drawingLocked || !sameDocument(next.productionPackages?.[id], document)) throw Error("Onaylanm\u0131\u015F \xFCretim paketi de\u011Fi\u015Ftirilemez.");
  }
  if (a.production && (!sameDocument(next.productionItems, expected.productionItems) || ["productionChecklist", "cratingPackages", "shipmentPackages", "operations"].some((key) => !sameDocument(before?.[key], next[key])))) throw Error("\xDCretim onayland\u0131. \xDCretim i\u015Flemleri salt okunurdur.");
}

// domain/drawingContinuation.ts
function continueDrawingRecord(record, revisionId, actor2) {
  const workflow = workflowOf(record);
  const frozen = workflow.drawings.find((row) => row.id === revisionId);
  if (!frozen) throw Error("Se\xE7ilen \xE7izim revizyonu bulunamad\u0131.");
  const source = structuredClone(frozen.record);
  if (source.drawingScene) assertFinalScene(source.drawingScene);
  const last = Math.max(workflow.drawingRevision, ...workflow.drawings.map((row) => row.revision));
  workflow.drawingRevision = last;
  workflow.drawingLocked = false;
  workflow.continuedFromRevisionId = revisionId;
  const positions = new Set(Object.entries(source.productWorkspaces || { [source.product]: source }).flatMap(([product, work]) => work.positions.map((position) => product + "|" + position.id)));
  workflow.links = workflow.links.filter((link) => positions.has(link.product + "|" + link.drawingPositionId));
  recordWorkflowEvent(workflow, "DRAWING_CONTINUED_FROM_REVISION", actor2);
  return { ...record, product: source.product, module1: source.module1, submodule: source.submodule, settings: source.settings, positions: source.positions, productWorkspaces: source.productWorkspaces, drawingScene: source.drawingScene, sceneRows: source.sceneRows, drawingLayout: source.drawingLayout, pricing: source.pricing, technicalCommitted: source.technicalCommitted, projectInfo: { ...record.projectInfo, revision: last }, workflow, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
}

// services/projectSearch.ts
function object2(value) {
  if (value === null || value === void 0) return void 0;
  if (typeof value !== "object" || Array.isArray(value)) throw Error("Proje arama kayd\u0131 ge\xE7ersiz.");
  return value;
}
function array(value) {
  if (value === void 0 || value === null) return [];
  if (!Array.isArray(value)) throw Error("Proje arama listesi ge\xE7ersiz.");
  return value;
}
function text(value) {
  if (value === null || value === void 0) return "";
  if (typeof value !== "string") throw Error("Proje arama metni ge\xE7ersiz.");
  return value;
}
function quoteText(q) {
  return [q.projectDescription, q.notes, ...array(q.positions).flatMap((p) => {
    const position = object2(p);
    return [position.description, ...array(position.lines).map((l) => object2(l).description)];
  })].map(text).filter(Boolean).join(" ");
}
function projectContent(record, quote, includeCommercial) {
  const r = object2(record), info = object2(r?.projectInfo), workspaces = object2(r?.productWorkspaces);
  const positions = workspaces ? Object.values(workspaces).flatMap((w) => array(object2(w)?.positions)) : array(r?.positions);
  const currentQuote = object2(object2(r?.workflow)?.quote) || object2(quote);
  return { text: [info?.description, ...positions.map((p) => object2(p)?.description), ...includeCommercial && currentQuote ? [quoteText(currentQuote)] : []].map(text).filter(Boolean).join(" "), representative: text(info?.projectRepresentative) || text(currentQuote?.projectRepresentative) };
}

// ../Cloud/recordProjection.ts
var ownershipFields = ["ownerUserId", "createdByUserId", "createdBy", "uploadedBy", "actorUserId", "representativeUserId", "userId", "assignedUserIds", "assigneeUserId", "projectId", "customerId"];

// ../Cloud/handler.ts
init_projectOverview();

// ../Cloud/projectFiles.ts
var projectFileActions = [
  "project_file_list",
  "project_file_begin",
  "project_file_finish",
  "project_file_download",
  "project_file_rename",
  "project_file_delete",
  "project_file_restore",
  "project_file_copy"
];
var projectFileBucket = "plmr-project-files";
var extensions = new Set("pdf dwg dxf dae xls xlsx doc docx jpg jpeg png webp step stp stl zip rar txt csv".split(" "));
var uuid = /^[a-f\d]{8}-[a-f\d]{4}-[a-f\d]{4}-[a-f\d]{4}-[a-f\d]{12}$/i;
var hash = /^[a-f\d]{64}$/;
var retention = 30 * 864e5;
var uploadLifetime = 864e5;
var inlineMime = {
  pdf: "application/pdf",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  txt: "text/plain",
  csv: "text/csv"
};
async function projectFileAction(db, action, input, cid, actor2, visible, fail, maxBytes = 50 * 1024 * 1024) {
  function field(value, max = 200) {
    if (typeof value !== "string" || !value.trim() || value.length > max || /[\x00-\x1f\x7f]/.test(value))
      return fail("INVALID_FILE_FIELD", 400);
    return value;
  }
  async function project(ref, write = false) {
    const id2 = field(ref), row2 = await db.fileProject(cid, id2);
    if (!row2 || !await visible(row2)) return fail("PROJECT_FILE_ACCESS_DENIED");
    if (write && (row2.locked || row2.deletedAt)) return fail("PROJECT_FILES_READ_ONLY");
    return row2;
  }
  if (action === "project_file_list" && input.projectIds !== void 0) {
    if (!Array.isArray(input.projectIds) || input.projectIds.length > 128) return fail("INVALID_FILE_SEARCH", 400);
    const projects = [...new Set(input.projectIds.map((id2) => field(id2)))];
    const owners = await db.fileOwners(cid, projects);
    const allowed = (await Promise.all(owners.map(async (row2) => await visible(row2) ? String(row2.projectId) : null))).filter((id2) => id2 !== null);
    return allowed.length ? db.searchFiles(cid, allowed) : [];
  }
  const writable = !["project_file_list", "project_file_download"].includes(action);
  const target = await project(input.projectId, writable);
  const projectId = String(target.projectId);
  if (action === "project_file_list") {
    const [legacy, current] = await Promise.all([db.legacyProjectFiles(cid, projectId), db.projectFileList(cid, projectId)]);
    return [...legacy, ...current];
  }
  const id = field(input.id);
  if (!uuid.test(id)) return fail("INVALID_FILE_ID", 400);
  let row = await db.projectFileGet(cid, id);
  if (row && row.metadata.projectId !== projectId) return fail("PROJECT_FILE_ACCESS_DENIED");
  const now = (/* @__PURE__ */ new Date()).toISOString();
  if (action === "project_file_begin" || action === "project_file_copy") {
    const sourceId = action === "project_file_copy" ? field(input.sourceId) : void 0;
    let source;
    if (sourceId) {
      const sourceProject = await project(input.sourceProjectId);
      source = (await db.projectFileGet(cid, sourceId))?.metadata;
      if (!source || source.projectId !== sourceProject.projectId || source.status !== "active")
        return fail("PROJECT_FILE_NOT_FOUND", 404);
    }
    const originalFileName = field(source?.originalFileName ?? input.name);
    const extension = originalFileName.split(".").at(-1).toLowerCase();
    const sizeBytes = Number(source?.sizeBytes ?? input.sizeBytes), sha256 = field(source?.sha256 ?? input.sha256, 64);
    if (!extensions.has(extension) || !Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || !hash.test(sha256))
      return fail("INVALID_FILE_METADATA", 400);
    if (sizeBytes > maxBytes) return fail("Proje dosyas\u0131 izin verilen boyutu a\u015F\u0131yor.", 413);
    const revisionId = input.revisionId == null ? null : field(input.revisionId);
    if (revisionId && revisionId !== target.revisionId) return fail("PROJECT_FILE_REVISION_CHANGED", 409);
    const path = [cid, projectId, id].map((part) => encodeURIComponent(part)).join("/");
    const proposed = {
      attachmentId: id,
      projectId,
      revisionId,
      originalFileName,
      displayName: source?.displayName ?? originalFileName,
      mimeType: inlineMime[extension] ?? "application/octet-stream",
      extension,
      sizeBytes,
      sha256,
      category: "project-level",
      description: "",
      storagePath: path,
      uploadedBy: actor2,
      uploadedAt: now,
      status: "pending"
    };
    if (!row) {
      await db.projectFileInsert(cid, proposed);
      row = await db.projectFileGet(cid, id);
    }
    const existing2 = row?.metadata;
    if (!row || !existing2 || existing2.projectId !== projectId || existing2.uploadedBy !== actor2 || existing2.originalFileName !== originalFileName || existing2.sizeBytes !== sizeBytes || existing2.sha256 !== sha256 || existing2.revisionId !== revisionId || existing2.status === "deleted")
      return fail("PROJECT_FILE_OPERATION_REUSED", 409);
    if (existing2.status === "active") return { file: existing2 };
    if (Date.now() - Date.parse(existing2.uploadedAt) >= uploadLifetime) return fail("PROJECT_FILE_UPLOAD_EXPIRED", 410);
    if (!source) return db.projectFileUpload(existing2.storagePath);
    if (!await db.projectFileVerify(existing2.storagePath, sizeBytes, sha256)) {
      await db.projectFileCopy(source.storagePath, existing2.storagePath);
      if (!await db.projectFileVerify(existing2.storagePath, sizeBytes, sha256))
        return fail("PROJECT_FILE_INTEGRITY_FAILED", 422);
    }
    const saved = { ...existing2, status: "active" };
    await db.projectFileUpdate(cid, row, saved);
    return { file: saved };
  }
  if (action === "project_file_download" && !row) {
    const legacy = (await db.legacyProjectFiles(cid, projectId, id))[0];
    if (!legacy?.dataUrl) return fail("PROJECT_FILE_NOT_FOUND", 404);
    return { url: legacy.dataUrl };
  }
  if (!row) return fail("PROJECT_FILE_NOT_FOUND", 404);
  const existing = row.metadata;
  if (action === "project_file_download") {
    if (existing.status !== "active") return fail("PROJECT_FILE_NOT_FOUND", 404);
    return { url: await db.projectFileUrl(existing.storagePath, input.download === true ? existing.displayName : void 0) };
  }
  if (writable && existing.revisionId && target.revisionId && existing.revisionId !== target.revisionId)
    return fail("PROJECT_FILES_READ_ONLY");
  let next;
  if (action === "project_file_finish") {
    if (existing.uploadedBy !== actor2 || existing.status === "deleted") return fail("PROJECT_FILE_ACCESS_DENIED");
    if (existing.status === "active") return { file: existing };
    if (Date.now() - Date.parse(existing.uploadedAt) >= uploadLifetime) return fail("PROJECT_FILE_UPLOAD_EXPIRED", 410);
    if (!await db.projectFileVerify(existing.storagePath, existing.sizeBytes, existing.sha256))
      return fail("PROJECT_FILE_INTEGRITY_FAILED", 422);
    await project(projectId, true);
    next = { ...existing, status: "active" };
  } else if (action === "project_file_delete") {
    if (existing.status === "deleted") return { file: existing };
    if (existing.status !== "active") return fail("PROJECT_FILE_NOT_FOUND", 404);
    next = { ...existing, status: "deleted", deletedAt: now };
  } else if (action === "project_file_restore") {
    if (existing.status === "active") return { file: existing };
    if (existing.status !== "deleted" || !existing.deletedAt || Date.now() - Date.parse(existing.deletedAt) >= retention)
      return fail("PROJECT_FILE_RETENTION_EXPIRED", 410);
    if (!await db.projectFileVerify(existing.storagePath, existing.sizeBytes, existing.sha256))
      return fail("PROJECT_FILE_INTEGRITY_FAILED", 422);
    const { deletedAt: _, ...restored } = existing;
    next = { ...restored, status: "active" };
  } else if (action === "project_file_rename") {
    if (existing.status !== "active") return fail("PROJECT_FILE_NOT_FOUND", 404);
    next = { ...existing, displayName: field(input.name) };
  } else return fail("INVALID_ACTION", 400);
  await db.projectFileUpdate(cid, row, next);
  return { file: next };
}

// domain/cloud.ts
var CLOUD_ALLOWED_EXTENSIONS = /* @__PURE__ */ new Set([
  "pdf",
  "dwg",
  "dxf",
  "xls",
  "xlsx",
  "doc",
  "docx",
  "jpg",
  "jpeg",
  "png",
  "webp",
  "mp4",
  "mov",
  "step",
  "stp",
  "stl",
  "zip",
  "rar",
  "txt",
  "csv"
]);
function cloudExtension(fileName) {
  const part = fileName.split(".").pop();
  return part && part !== fileName ? part.toLowerCase() : "";
}

// ../Cloud/libraryFiles.ts
var libraryBucket = "plmr-library-files";
var libraryMaxBytes = 50 * 1024 * 1024;
var libraryActions = ["library_file_begin", "library_file_finish", "library_file_read", "library_file_migrate"];
var keyPattern = /^cloud\/[\w-]{1,80}\/[\w-]{1,80}\/[\w-]{1,80}\/[\w.-]{1,220}$/;
var inline = {
  pdf: "application/pdf",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  txt: "text/plain",
  csv: "text/csv",
  mp4: "video/mp4",
  mov: "video/quicktime"
};
function libraryPointer(value) {
  if (!value || typeof value !== "object" || value.format !== "storage-v45") return null;
  return value;
}
async function libraryFileAction(objects, ctx, action, input, cid, actor2, maxBytes) {
  const key = typeof input.key === "string" ? input.key : "";
  if (!keyPattern.test(key) || key.endsWith("/.") || key.endsWith("/..")) return ctx.fail("INVALID_LIBRARY_FILE_KEY", 400);
  const scope = cid + ":binary", shadow = cid + ":library.migration";
  const row = await ctx.get(scope, key);
  const prior = libraryPointer(row.value);
  const path = (sha) => encodeURIComponent(cid) + "/" + key + "/" + sha;
  async function requireLinked() {
    const link = await ctx.linked(key);
    if (!link || !row.value || !await ctx.visible(row.value)) return ctx.fail("LIBRARY_FILE_ACCESS_DENIED", 403);
    return link;
  }
  if (action === "library_file_read") {
    await requireLinked();
    const pointer = prior ?? libraryPointer((await ctx.get(shadow, key)).value);
    if (pointer?.state === "active") {
      if (pointer.storagePath !== path(pointer.sha256)) return ctx.fail("INVALID_LIBRARY_FILE_PATH", 409);
      try {
        return { url: await objects.projectFileUrl(pointer.storagePath), sizeBytes: pointer.sizeBytes, sha256: pointer.sha256 };
      } catch (error) {
        if (prior) throw error;
      }
    }
    const legacy = row.value;
    if (!legacy.data) return ctx.fail("LIBRARY_FILE_NOT_READY", 404);
    return { data: legacy.data };
  }
  if (action === "library_file_migrate") {
    const link = await requireLinked();
    if (prior?.state === "active") return { verified: true, committed: true };
    const legacy = row.value;
    const match = /^data:[\w.+/-]*;base64,([A-Za-z0-9+/]+={0,2})$/.exec(legacy.data ?? "");
    if (!match || link.sizeBytes < 1 || link.sizeBytes > libraryMaxBytes || match[1].length !== Math.ceil(link.sizeBytes / 3) * 4) return ctx.fail("INVALID_LEGACY_LIBRARY_FILE", 422);
    const bytes = Uint8Array.from(atob(match[1]), (value2) => value2.charCodeAt(0));
    if (bytes.length !== link.sizeBytes) return ctx.fail("LIBRARY_FILE_INTEGRITY_FAILED", 422);
    const sha256 = objects.sha256(bytes), storagePath = path(sha256);
    const value = {
      format: "storage-v45",
      state: "active",
      storagePath,
      sizeBytes: bytes.length,
      sha256,
      mimeType: inline[cloudExtension(link.name)] || "application/octet-stream",
      ownerUserId: legacy.ownerUserId
    };
    const candidate = await ctx.get(shadow, key);
    if (input.commit === true) {
      const prepared = libraryPointer(candidate.value);
      if (prepared?.sha256 !== sha256 || prepared.storagePath !== storagePath || input.sha256 !== sha256 || input.sizeBytes !== bytes.length)
        return ctx.fail("LIBRARY_MIGRATION_NOT_PREPARED", 409);
    } else if (candidate.value && libraryPointer(candidate.value)?.sha256 !== sha256) {
      return ctx.fail("LIBRARY_MIGRATION_SOURCE_CHANGED", 409);
    } else if (!await objects.projectFileVerify(storagePath, bytes.length, sha256)) {
      await objects.importLegacy(storagePath, bytes, value.mimeType);
    }
    if (!await objects.projectFileVerify(storagePath, bytes.length, sha256))
      return ctx.fail("LIBRARY_FILE_INTEGRITY_FAILED", 422);
    if (input.commit === true) await ctx.cas(scope, key, value, row.version);
    else if (!candidate.value) await ctx.cas(shadow, key, value, candidate.version);
    return { verified: true, committed: input.commit === true, sizeBytes: bytes.length, sha256 };
  }
  await ctx.uploadAllowed(key);
  if (action === "library_file_begin") {
    const sha256 = typeof input.sha256 === "string" ? input.sha256 : "";
    const sizeBytes = typeof input.sizeBytes === "number" ? input.sizeBytes : 0;
    const extension = typeof input.name === "string" ? cloudExtension(input.name) : "";
    if (!/^[a-f\d]{64}$/.test(sha256) || !Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || !CLOUD_ALLOWED_EXTENSIONS.has(extension)) return ctx.fail("INVALID_LIBRARY_FILE_METADATA", 400);
    if (sizeBytes > maxBytes) return ctx.fail("Bulut dosyas\u0131 izin verilen boyutu a\u015F\u0131yor.", 413);
    const value = {
      format: "storage-v45",
      state: "pending",
      storagePath: path(sha256),
      sha256,
      sizeBytes,
      mimeType: inline[extension] || "application/octet-stream",
      ownerUserId: actor2
    };
    if (row.value === null) await ctx.cas(scope, key, value, row.version);
    else if (!prior || prior.ownerUserId !== actor2 || prior.sha256 !== sha256 || prior.sizeBytes !== sizeBytes || prior.mimeType !== value.mimeType || prior.storagePath !== value.storagePath)
      return ctx.fail("LIBRARY_FILE_OPERATION_REUSED", 409);
    if (prior?.state === "active") return { ready: true };
    return { ...await objects.projectFileUpload(value.storagePath), mimeType: value.mimeType };
  }
  if (action !== "library_file_finish" || !prior || prior.ownerUserId !== actor2 || prior.storagePath !== path(prior.sha256))
    return ctx.fail("LIBRARY_FILE_NOT_READY", 404);
  if (prior.state === "active") return { ready: true };
  if (!await objects.projectFileVerify(prior.storagePath, prior.sizeBytes, prior.sha256))
    return ctx.fail("LIBRARY_FILE_INTEGRITY_FAILED", 422);
  await ctx.cas(scope, key, { ...prior, state: "active" }, row.version);
  return { ready: true };
}

// domain/limits.ts
var SYSTEM_HARD_LIMITS = {
  maxPositionsPerProject: 500,
  maxQuantityPerPosition: 1e3,
  maxTotalProductQuantity: 1e4,
  maxGeneratedDrawingsPerOperation: 500,
  maxBatchCalculationSize: 1e3,
  maxRepeatedSystemGeneration: 500,
  projectAttachmentMaxFileSizeBytes: 100 * 1024 * 1024,
  cloudFileMaxFileSizeBytes: 250 * 1024 * 1024,
  multiUploadMaxBatchSizeBytes: 500 * 1024 * 1024,
  maxFileCountPerBatch: 50
};
var DEFAULT_COMPANY_LIMITS = {
  maxPositionsPerProject: 200,
  maxQuantityPerPosition: 250,
  maxTotalProductQuantity: 2500,
  maxGeneratedDrawingsPerOperation: 200,
  maxBatchCalculationSize: 500,
  maxRepeatedSystemGeneration: 200,
  projectAttachmentMaxFileSizeBytes: 50 * 1024 * 1024,
  cloudFileMaxFileSizeBytes: 100 * 1024 * 1024,
  multiUploadMaxBatchSizeBytes: 250 * 1024 * 1024,
  maxFileCountPerBatch: 25
};

// domain/quoteBranding.ts
var quoteBrandFields = ["logoDataUrl", "letterheadDataUrl", "signatureDataUrl"];
var quoteBrandBucket = "plmr-quote-branding";
var quoteBrandMaxBytes = 5 * 1024 * 1024;
var quoteBrandHash = /^[a-f0-9]{64}$/;

// ../Cloud/handler.ts
var USERS = "plmr.users.v13";
var COMPANIES = "plmr.companies.v68";
var CREDS = "plmr.credentials.v68";
var Failure = class extends Error {
  constructor(message, status = 403) {
    super(message);
    this.status = status;
  }
  status;
};
function object3(v) {
  if (!v || typeof v !== "object" || Array.isArray(v))
    throw new Failure("INVALID_OBJECT", 400);
  return v;
}
function text2(v, max = 600) {
  if (typeof v !== "string" || v.length > max)
    throw new Failure("INVALID_TEXT", 400);
  return v;
}
function integer(v) {
  if (typeof v !== "number" || !Number.isSafeInteger(v) || v < 0)
    throw new Failure("INVALID_VERSION", 400);
  return v;
}
function operationId(v) {
  if (typeof v !== "string" || !/^([a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12})$/i.test(v))
    throw new Failure("INVALID_OPERATION_ID", 400);
  return v;
}
function array2(v) {
  if (!Array.isArray(v))
    throw new Failure("INVALID_ARRAY", 400);
  return v;
}
function parse(v) {
  return v === null ? null : JSON.parse(text2(v, 64 * 1024 * 1024));
}
var same = sameDocument;
function identity(value) {
  const r = object3(value);
  return String(r.userId || r.companyId || r.attachmentId || r.auditEventId || r.orderId || r.paymentId || r.transactionId || r.proformaId || r.itemId || r.versionId || r.taskId || r.reminderId || r.id || r.projectId || r.projKodu || r.projectCode || "");
}
function user(value) {
  const u = object3(value);
  for (const k of ["userId", "username", "fullName", "roleId", "status"])
    text2(u[k], 200);
  if (!/^[A-Za-z0-9_.-]{3,40}$/.test(String(u.username)) || !createDefaultRoles().some((r) => r.roleId === u.roleId) || !["ACTIVE", "INACTIVE"].includes(String(u.status)))
    throw new Failure("INVALID_USER", 400);
  for (const v of array2(u.memberships)) {
    const m = object3(v);
    text2(m.companyId);
    if (!createDefaultRoles().some((r) => r.roleId === m.roleId && r.roleId !== "SYSTEM_ADMIN") || !["ACTIVE", "INACTIVE"].includes(String(m.status)))
      throw new Failure("INVALID_MEMBERSHIP", 400);
  }
  return u;
}
function company(value) {
  const c = object3(value);
  for (const k of ["companyId", "code", "status", "licenseStart", "licenseEnd"])
    text2(c[k], 160);
  if (!/^[A-Za-z0-9_-]{2,24}$/.test(String(c.code)) || !["ACTIVE", "INACTIVE"].includes(String(c.status)) || !Number.isSafeInteger(c.userLimit) || Number(c.userLimit) < 1 || Number(c.userLimit) > 9999)
    throw new Failure("INVALID_COMPANY", 400);
  text2(object3(c.settings).companyName, 500);
  return c;
}
function createCloudHandler(db, validatePresentation) {
  const headers = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization,apikey,content-type,x-plmr-project-epoch", "Access-Control-Allow-Methods": "GET,POST,OPTIONS", "Cache-Control": "no-store", "Content-Type": "application/json; charset=utf-8", "Referrer-Policy": "no-referrer", "X-Content-Type-Options": "nosniff" };
  return async (request) => {
    const requestId = globalThis.crypto?.randomUUID(), startedAt = Date.now();
    let bytes = 0, actionLabel = "unknown";
    const timings = {};
    function reply(value, status = 200) {
      const serializeAt = Date.now(), body = JSON.stringify(value);
      const serializeMs = Math.round(Date.now() - serializeAt), durationMs = Date.now() - startedAt;
      if (requestId && (status >= 400 || durationMs >= 1e3 || Object.keys(timings).length))
        console.info(JSON.stringify({
          event: "plmr_request",
          requestId,
          action: actionLabel,
          status,
          durationMs,
          requestBytes: bytes,
          responseBytes: new TextEncoder().encode(body).byteLength,
          serializeMs,
          ...timings
        }));
      return new Response(body, { status, headers: requestId ? {
        ...headers,
        "x-plmr-request-id": requestId,
        "Access-Control-Expose-Headers": "x-plmr-request-id"
      } : headers });
    }
    if (request.method === "OPTIONS")
      return new Response("ok", { headers });
    try {
      let accessible = function(cid, write = false) {
        const c = allowed.find((c2) => c2.companyId === cid);
        if (!c)
          throw new Failure("Firma eri\u015Fimi tan\u0131ml\u0131 de\u011Fil.");
        const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA", { timeZone: "Europe/Istanbul" });
        if (write && !system && (today < c.licenseStart || today > c.licenseEnd))
          throw new Failure("Lisans s\xFCresi d\u0131\u015F\u0131nda kay\u0131tlar yaln\u0131z g\xF6r\xFCnt\xFClenebilir.");
        return c;
      };
      if (request.method === "GET") {
        const url2 = new URL(request.url), id = url2.searchParams.get("share") || url2.pathname.split("/").at(-1) || "";
        if (!/^[a-f0-9]{32}$/.test(id))
          throw new Failure("Sunum ba\u011Flant\u0131s\u0131 ge\xE7ersiz.", 400);
        const result = await db.shareGet(id);
        return result ? reply(result) : reply({ error: "Sunum bulunamad\u0131 veya s\xFCresi doldu." }, 404);
      }
      if (request.method !== "POST")
        throw new Failure("METHOD_NOT_ALLOWED", 405);
      const maxBodyBytes = 64 * 1024 * 1024;
      if (Number(request.headers.get("Content-Length") || 0) > maxBodyBytes)
        throw new Failure("Dosya \xE7ok b\xFCy\xFCk.", 413);
      const principal = await db.authenticate(request);
      if (!principal.profile.is_active)
        throw new Failure("ACCOUNT_DISABLED");
      if (!request.body) throw new Failure("INVALID_OBJECT", 400);
      const bounded = request.body.pipeThrough(new TransformStream({
        transform(chunk, controller) {
          bytes += chunk.byteLength;
          if (bytes > maxBodyBytes) throw new Failure("Dosya \xE7ok b\xFCy\xFCk.", 413);
          controller.enqueue(chunk);
        }
      }));
      const input = object3(await new Response(bounded).json());
      const reads = /* @__PURE__ */ new Map();
      const get = (scope, key) => {
        const id = JSON.stringify([scope, key]);
        if (!reads.has(id)) reads.set(id, db.get(scope, key));
        return reads.get(id);
      };
      const platformKeys = [USERS, COMPANIES, "@auth:" + principal.id];
      const snapshot2 = input.action === "snapshot";
      const directoryOnly = input.action === "company_directory";
      const deletionActions = ["company_delete", "company_delete_jobs", "company_delete_cleanup"];
      if (typeof input.action === "string" && ["company_directory", ...deletionActions, "snapshot", "record_put", "record_get", "record_list", "write", "project_index_patch", "project_index_commit", "project_overview", "project_headers", "project_content", "project_files_read", "drawing_workspace", "project_approve", "project_withdraw", "continue_drawing", "stock_read"].includes(input.action))
        actionLabel = input.action;
      const [platformRows, snapshotDirectory] = await Promise.all([
        snapshot2 ? db.list("platform") : db.getMany ? db.getMany("platform", platformKeys) : Promise.all(platformKeys.map((key) => get("platform", key))),
        snapshot2 ? db.directory() : Promise.resolve(void 0)
      ]);
      const [usersRow, companiesRow, map] = platformKeys.map((key) => platformRows.find((row) => row.key === key) || { key, value: null, version: 0 });
      const base = snapshotDirectory ?? (usersRow.value === null || companiesRow.value === null ? await db.directory() : { users: [], companies: [] });
      const users = usersRow.value === null ? base.users : array2(parse(usersRow.value)).map(user), companies = companiesRow.value === null ? base.companies : array2(parse(companiesRow.value)).map(company);
      const appId = typeof map.value === "string" ? map.value : principal.id, actor2 = users.find((u) => u.userId === appId);
      if (!actor2 || actor2.status !== "ACTIVE")
        throw new Failure("ACCOUNT_DISABLED");
      const system = actor2.roleId === "SYSTEM_ADMIN" && principal.profile.role === "system_admin", membership = (cid) => actor2.memberships.find((m) => m.companyId === cid && m.status === "ACTIVE");
      const allowed = companies.filter((c) => system || c.status === "ACTIVE" && !!membership(c.companyId));
      const roleCache = /* @__PURE__ */ new Map();
      async function roles(cid) {
        if (!roleCache.has(cid)) roleCache.set(cid, get(cid, "plmr.roles.v13").then((row) => {
          const custom = row.value ? array2(parse(row.value)) : [];
          return createDefaultRoles().map((r) => r.locked ? r : custom.find((c) => c.roleId === r.roleId) || r);
        }));
        return roleCache.get(cid);
      }
      async function can(cid, permission) {
        accessible(cid);
        if (system)
          return true;
        const m = membership(cid), r = (await roles(cid)).find((r2) => r2.roleId === m.roleId);
        return !!r && resolvePermission(r, m.permissionOverrides, permission);
      }
      async function requireAny(cid, permissions, write = false) {
        accessible(cid, write);
        if (!(await Promise.all(permissions.map((p) => can(cid, p)))).some(Boolean))
          throw new Failure("Bu i\u015Flem i\xE7in yetkiniz yok.");
      }
      const projectOwners = /* @__PURE__ */ new Map();
      async function projectOwner(cid, reference) {
        if (db.masterOwner && typeof reference === "string") {
          const result = await db.masterOwner(cid, reference);
          if (result) return result.value ?? void 0;
        }
        if (!projectOwners.has(cid)) projectOwners.set(cid, get(cid, "plmr.project.index.v11").then((index) => {
          const owners = /* @__PURE__ */ new Map();
          for (const value of array2(index.value ? parse(index.value) : [])) {
            const row = object3(value), owner = Object.fromEntries(ownershipFields.map((field) => [field, row[field]]));
            for (const key of [row.projectId, row.projKodu]) if (key && !owners.has(key)) owners.set(key, owner);
          }
          return owners;
        }));
        return projectOwners.get(cid).then((owners) => owners.get(reference));
      }
      async function visible(cid, value, family = "PROJECTS", ancestors = /* @__PURE__ */ new Set()) {
        if (system || membership(cid)?.roleId === "COMPANY_ADMIN")
          return true;
        const r = object3(value), m = membership(cid), role = (await roles(cid)).find((r2) => r2.roleId === m.roleId), scope = m.dataScopeOverrides?.[family] || role.dataScopes[family];
        const projectRef = JSON.stringify([cid, "PROJECTS", r.projectId]);
        if (r.projectId && !r.ownerUserId && !r.createdByUserId && !ancestors.has(projectRef)) {
          const parent = await projectOwner(cid, r.projectId);
          if (parent)
            return visible(cid, parent, family, /* @__PURE__ */ new Set([...ancestors, projectRef]));
        }
        const customerRef = JSON.stringify([cid, "CUSTOMERS", r.customerId]);
        if (r.customerId && !r.ownerUserId && !r.createdByUserId && !ancestors.has(customerRef)) {
          const index = await get(cid, "plmr.customer.master.v10"), parent = array2(index.value ? parse(index.value) : []).find((v) => object3(v).id === r.customerId);
          if (parent)
            return visible(cid, parent, "CUSTOMERS", /* @__PURE__ */ new Set([...ancestors, customerRef]));
        }
        const own = [r.ownerUserId, r.createdByUserId, r.createdBy, r.uploadedBy, r.actorUserId, r.representativeUserId, r.userId].includes(actor2.userId), assigned = Array.isArray(r.assignedUserIds) && r.assignedUserIds.includes(actor2.userId) || r.assigneeUserId === actor2.userId;
        return scope === "ALL_COMPANY" || scope === "OWN" && own || scope === "ASSIGNED" && assigned || scope === "OWN_OR_ASSIGNED" && (own || assigned);
      }
      async function subset(cid, items, family) {
        return (await Promise.all(array2(items).map(async (v) => await visible(cid, v, family) ? v : null))).filter((v) => v !== null);
      }
      async function filter(cid, key, value) {
        const p = cloudPolicy(key);
        if (!(await Promise.all(p.read.map((x) => can(cid, x)))).some(Boolean))
          return null;
        if (isMaterialCatalog(key)) return visibleMaterials(value, (p2) => can(cid, p2));
        if (p.family && Array.isArray(value))
          return subset(cid, value, p.family);
        if (key === "plmr.task-reminder.v12" && value) {
          const v = object3(value);
          return { ...v, tasks: await subset(cid, v.tasks || [], "OPERATIONS"), reminders: await subset(cid, v.reminders || [], "OPERATIONS") };
        }
        if (key === "plmr.cloud.library.meta.v12" && value) {
          const v = object3(value), items = await subset(cid, v.items || [], "PROJECTS"), ids = new Set(items.map(identity));
          return { ...v, items, versions: array2(v.versions || []).filter((x) => ids.has(String(object3(x).itemId))) };
        }
        return value;
      }
      async function mergeVisible(cid, old, next, family) {
        const permitted = /* @__PURE__ */ new Set(), previous = /* @__PURE__ */ new Map();
        for (const value of old) {
          const id = identity(value);
          if (!previous.has(id)) previous.set(id, value);
          if (await visible(cid, value, family)) permitted.add(id);
        }
        for (const value of next) {
          const id = identity(value), prior = previous.get(id);
          if (prior && !permitted.has(id) && !same(prior, value)) throw new Failure("Bu kayda eri\u015Fim yetkiniz yok.");
          if (!prior && !system && !await visible(cid, value, family)) throw new Failure("Kay\u0131t sahipli\u011Fi ge\xE7ersiz.");
        }
        return [...old.filter((v) => !permitted.has(identity(v))), ...next.filter((v) => !previous.has(identity(v)) || permitted.has(identity(v)))];
      }
      async function validateProjectIndexChange(cid, before, after, overviews) {
        const oldProject = before, newProject = after;
        if (oldProject && newProject && oldProject.projKodu !== newProject.projKodu)
          throw new Failure("Proje kodu de\u011Fi\u015Ftirilemez.", 400);
        if (oldProject && newProject) {
          const from = oldProject.status, to = newProject.status;
          if (from !== to && (from === "arsivlendi" || to === "arsivlendi")) {
            await requireAny(cid, ["project.archive"], true);
            if (to === "arsivlendi" && newProject.archivedFromStatus !== void 0 && newProject.archivedFromStatus !== from || from === "arsivlendi" && (newProject.archivedFromStatus !== void 0 || oldProject.archivedFromStatus !== void 0 && to !== oldProject.archivedFromStatus))
              throw new Failure("Ar\u015Fiv durumu g\xFCncel de\u011Fil. Projeyi yeniden a\xE7\u0131n.", 409);
          } else if (oldProject.archivedFromStatus !== newProject.archivedFromStatus) {
            throw new Failure("Ar\u015Fiv durumu ge\xE7ersiz.", 400);
          }
          if (from !== to && to === "iptal" && from !== "arsivlendi")
            await requireAny(cid, ["project.status.change"], true);
        }
        const code = text2(object3(after ?? before).projKodu);
        const scope = cid + ":drawing.projects";
        const overview = !oldProject?.approvals && !newProject?.approvals ? overviews?.get(code) ?? (overviews ? { key: code, value: null, version: 0 } : await db.overview?.(scope, code)) : void 0;
        const overviewRecord = overview?.value;
        const canonical = overview && !Object.values(overviewRecord?.workflow?.approvals ?? {}).some(Boolean) ? overview : await get(scope, code);
        assertApprovedMasterChange(oldProject, newProject, canonical.value);
        if (oldProject && newProject) assertLockedProductionHistory(oldProject, newProject);
      }
      const action = text2(input.action, 40);
      if (action === "quote_brand_store" || action === "quote_brand_url") {
        actionLabel = action;
        if (!db.quoteBranding) throw new Failure("INVALID_ACTION", 400);
        const cid = text2(input.companyId, 100);
        if (!/^[A-Za-z0-9_-]+$/.test(cid)) throw new Failure("INVALID_COMPANY", 400);
        if (action === "quote_brand_url") {
          await requireAny(cid, ["commercial.quote.view", "commercial.quote.create", "admin.company_settings.view", "project.export"]);
          const hash2 = text2(input.sha256, 64);
          if (!quoteBrandHash.test(hash2)) throw new Failure("QUOTE_BRAND_INVALID_REFERENCE", 400);
          return reply({ url: await db.quoteBranding.url(cid, hash2) });
        }
        const settings = accessible(cid, true).settings;
        const field = text2(input.field, 40);
        if (!quoteBrandFields.includes(field)) throw new Failure("QUOTE_BRAND_INVALID_FIELD", 400);
        const image = text2(input.image, Math.ceil(quoteBrandMaxBytes / 3) * 4 + 32);
        if (!await can(cid, "admin.company_settings.edit")) {
          await requireAny(cid, ["commercial.quote.create"], true);
          if (settings[field] !== image) throw new Failure("Firma belge g\xF6rseli de\u011Fi\u015Fti. Firma ayarlar\u0131n\u0131 yenileyin.", 409);
        }
        const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(image);
        if (!match) throw new Failure("QUOTE_BRAND_INVALID_IMAGE", 400);
        let data;
        try {
          data = Uint8Array.from(atob(match[2]), (c) => c.charCodeAt(0));
        } catch {
          throw new Failure("QUOTE_BRAND_INVALID_IMAGE", 400);
        }
        const ascii = (start, end) => String.fromCharCode(...data.subarray(start, end));
        const valid = match[1] === "image/png" ? data[0] === 137 && ascii(1, 4) === "PNG" && ascii(12, 16) === "IHDR" : match[1] === "image/jpeg" ? data[0] === 255 && data[1] === 216 && data[2] === 255 : ascii(0, 4) === "RIFF" && ascii(8, 12) === "WEBP";
        if (!valid || data.length > quoteBrandMaxBytes) throw new Failure("QUOTE_BRAND_INVALID_IMAGE", 400);
        return reply({ sha256: await db.quoteBranding.store(cid, data, match[1]) });
      }
      if (action === "production_page" || action === "production_items" || action === "production_export") {
        actionLabel = action;
        const cid = text2(input.companyId);
        await requireAny(cid, ["operations.view"]);
        await requireAny(cid, ["project.view", "commercial.quote.view"]);
        if (action === "production_export") await requireAny(cid, ["project.export"]);
        if (!db.productionPage) throw new Failure("INVALID_ACTION", 400);
        const m = membership(cid);
        const role = m ? (await roles(cid)).find((r) => r.roleId === m.roleId) : void 0;
        const scope = (family) => {
          if (system) return "ALL_COMPANY";
          return m?.dataScopeOverrides?.[family] ?? role?.dataScopes[family] ?? "OWN";
        };
        const requestQuery = action === "production_page" ? object3(input.query ?? {}) : {};
        const columns = object3(requestQuery.columns ?? {});
        if (Object.keys(columns).length > 20) throw new Failure("INVALID_FILTERS", 400);
        const query = {
          search: text2(requestQuery.search ?? "", 200).trim(),
          status: text2(requestQuery.status ?? "", 20),
          customer: text2(requestQuery.customer ?? "", 400),
          sort: text2(requestQuery.sort ?? "created", 40),
          direction: requestQuery.direction === "asc" ? "asc" : "desc",
          columns: Object.fromEntries(Object.entries(columns).map(([key, value]) => [key, text2(value, 200)]))
        };
        const offset = integer(input.offset ?? 0);
        if (offset > 1e7) throw new Failure("INVALID_PAGE", 400);
        const dbAt = Date.now();
        const result = await db.productionPage(
          cid,
          actor2.userId,
          scope("PROJECTS"),
          scope("OPERATIONS"),
          await can(cid, "project.view"),
          query,
          offset,
          action === "production_export" ? 100 : 5,
          action !== "production_page",
          action === "production_items" ? integer(input.id) : null,
          action === "production_page" && input.facets === true
        );
        timings.databaseMs = Date.now() - dbAt;
        return reply(result);
      }
      if (libraryActions.includes(action)) {
        actionLabel = action;
        const cid = text2(input.companyId), metaKey = "plmr.cloud.library.meta.v12";
        if (!db.libraryObjects) throw new Failure("INVALID_ACTION", 400);
        if (action === "library_file_migrate" && !system) throw new Failure("LIBRARY_MIGRATION_ADMIN_ONLY");
        if (action === "library_file_read" || action === "library_file_migrate")
          await requireAny(cid, ["cloud.download"], action === "library_file_migrate");
        else await requireAny(cid, ["cloud.upload", "cloud.version.manage"], true);
        async function libraryMeta() {
          const row = await get(cid, metaKey);
          const value = row.value ? object3(parse(row.value)) : {};
          return { items: array2(value.items || []).map(object3), versions: array2(value.versions || []).map(object3), folders: array2(value.folders || []).map(object3) };
        }
        const maxBytes = action === "library_file_begin" ? Math.min(libraryMaxBytes, ...(await Promise.all([
          get("platform", "plmr.system.hardLimits.v13"),
          get(cid, "plmr.company.limits.v13")
        ])).map((row, index) => {
          const raw = row.value ? object3(parse(row.value)).cloudFileMaxFileSizeBytes : void 0;
          return typeof raw === "number" && Number.isSafeInteger(raw) && raw > 0 ? raw : (index ? DEFAULT_COMPANY_LIMITS : SYSTEM_HARD_LIMITS).cloudFileMaxFileSizeBytes;
        })) : libraryMaxBytes;
        return reply(await libraryFileAction(db.libraryObjects, {
          get,
          cas: (scope, key, value, version) => db.cas(scope, key, value, version, true),
          visible: (value) => visible(cid, value),
          fail: (message, status) => {
            throw new Failure(message, status);
          },
          linked: async (key) => {
            const meta = await libraryMeta();
            const version = meta.versions.find((v) => v.storagePath === key);
            const item = meta.items.find((i) => i.type === "FILE" && (i.storagePath === key || i.itemId === version?.itemId));
            if (!item || !await visible(cid, { ownerUserId: item.createdBy })) return null;
            const source = version ?? item;
            return { ownerUserId: String(item.createdBy), sizeBytes: Number(source.sizeBytes), name: String(source.fileName ?? "") };
          },
          uploadAllowed: async (key) => {
            const [, folderId, itemId] = key.split("/");
            const meta = await libraryMeta(), item = meta.items.find((i) => i.itemId === itemId);
            if (item) {
              await requireAny(cid, ["cloud.version.manage"], true);
              if (item.type !== "FILE" || item.folderId !== folderId || !await visible(cid, { ownerUserId: item.createdBy }))
                throw new Failure("LIBRARY_FILE_ACCESS_DENIED");
            } else {
              await requireAny(cid, ["cloud.upload"], true);
              if (!meta.folders.some((f) => f.folderId === folderId && f.status === "ACTIVE")) throw new Failure("LIBRARY_FOLDER_NOT_FOUND", 404);
            }
          }
        }, action, input, cid, actor2.userId, maxBytes));
      }
      if (projectFileActions.includes(action)) {
        actionLabel = action;
        if (!db.projectFiles) throw new Failure("INVALID_ACTION", 400);
        const cid = text2(input.companyId);
        const reading = ["project_file_list", "project_file_download"].includes(action);
        const uploading = ["project_file_begin", "project_file_finish", "project_file_copy"].includes(action);
        await requireAny(cid, reading ? ["project.files.view"] : uploading ? ["project.files.upload"] : ["project.files.manage"], !reading);
        if (action === "project_file_copy") {
          await requireAny(cid, ["project.files.view"]);
          await requireAny(cid, ["project.create"], true);
        }
        let maxBytes;
        if (action === "project_file_begin" || action === "project_file_copy") {
          const [hard, company2] = await Promise.all([get("platform", "plmr.system.hardLimits.v13"), get(cid, "plmr.company.limits.v13")]);
          const limit = "projectAttachmentMaxFileSizeBytes";
          const size = (row, fallback) => {
            const value = row.value === null ? void 0 : object3(parse(row.value))[limit];
            return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : fallback;
          };
          maxBytes = Math.min(50 * 1024 * 1024, size(hard, SYSTEM_HARD_LIMITS[limit]), size(company2, DEFAULT_COMPANY_LIMITS[limit]));
        }
        return reply(await projectFileAction(
          db.projectFiles,
          action,
          input,
          cid,
          actor2.userId,
          (row) => visible(cid, row),
          (message, status) => {
            throw new Failure(message, status);
          },
          maxBytes
        ));
      }
      if (["catalog_commit", "catalog_media_upload", "catalog_media_url", "catalog_media_urls"].includes(action)) {
        actionLabel = action;
        const reading = action === "catalog_media_url" || action === "catalog_media_urls";
        const cid = text2(input.companyId);
        accessible(cid, !reading);
        if (reading) await requireAny(cid, ["product.view", "operations.view"]);
        return reply(await catalogAction(db, input, cid, (p) => can(cid, p)));
      }
      if (action === "project_headers" || action === "project_content") {
        const cid = text2(input.companyId);
        await requireAny(cid, ["project.view", "commercial.quote.view"]);
        const commercial = input.commercial === true && await can(cid, "commercial.quote.view");
        const codes = input.codes === void 0 ? void 0 : [...new Set(array2(input.codes).map((code) => text2(code, 200)))];
        if (codes && (codes.length > 128 || !db.projectRowsForKeys)) throw new Failure("INVALID_PROJECT_READ_SCOPE", 400);
        const select = async (store, legacy = false) => {
          const scope = cid + ":" + store;
          if (codes && !legacy) return db.projectRowsForKeys(scope, action === "project_headers" ? "header" : "search", commercial, false, codes);
          return db.projectRows ? db.projectRows(scope, action === "project_headers" ? "header" : "search", commercial, legacy) : db.list(scope);
        };
        const dbAt = Date.now();
        const drawingRead = action === "project_headers" && input.onlyUnlinked === true && db.unlinkedProjectHeaders ? db.unlinkedProjectHeaders(cid) : select("drawing.projects");
        const [records, commercialRows] = await Promise.all([
          drawingRead,
          action === "project_content" && commercial ? select("quote.quotes", true) : Promise.resolve([])
        ]);
        timings.dbProjectionMs = Math.round(Date.now() - dbAt);
        const processAt = Date.now();
        if (action === "project_headers") {
          const result = [];
          for (const row of records) if (row.value !== null && await visible(cid, row.value)) {
            const record = object3(row.value), workflow = record.workflow ? object3(record.workflow) : null;
            result.push({ key: row.key, version: row.version, projectCode: record.projectCode || row.key, workflowVersion: workflow?.version ?? null });
          }
          timings.projectionProcessingMs = Math.round(Date.now() - processAt);
          return reply(result);
        }
        const index = /* @__PURE__ */ Object.create(null), canonicalQuotes = /* @__PURE__ */ new Set();
        for (const row of records) if (row.value !== null && await visible(cid, row.value)) {
          const record = object3(row.value), code = text2(record.projectCode);
          index[code] = projectContent(record, void 0, commercial);
          if (record.workflow && object3(record.workflow).quote) canonicalQuotes.add(code);
        }
        const legacyQuotes = /* @__PURE__ */ new Map();
        for (const row of commercialRows) if (row.value !== null && await visible(cid, row.value)) {
          const quote = object3(row.value), code = text2(quote.projectCode);
          if (canonicalQuotes.has(code) || codes && !codes.includes(code)) continue;
          legacyQuotes.set(code, quote);
        }
        for (const [code, quote] of legacyQuotes) {
          const legacy = projectContent(void 0, quote, true), prior = index[code];
          index[code] = { text: [prior?.text, legacy.text].filter(Boolean).join(" "), representative: prior?.representative || legacy.representative };
        }
        timings.projectionProcessingMs = Math.round(Date.now() - processAt);
        return reply(index);
      }
      if (deletionActions.includes(String(action))) {
        if (!system) throw new Failure("SYSTEM_ADMIN_REQUIRED");
        if (action === "company_delete_jobs") {
          if (!db.companyDeletionJobs) throw new Failure("COMPANY_DELETE_UNAVAILABLE", 503);
          return reply(await db.companyDeletionJobs());
        }
        const cid = text2(input.companyId, 36).toLowerCase();
        if (!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(cid))
          throw new Failure("INVALID_COMPANY_ID", 400);
        if (action === "company_delete_cleanup") {
          if (!db.companyCleanup) throw new Failure("COMPANY_DELETE_UNAVAILABLE", 503);
          return reply(await db.companyCleanup(cid));
        }
        if (!db.companyDelete) throw new Failure("COMPANY_DELETE_UNAVAILABLE", 503);
        return reply(await db.companyDelete(cid, principal.id));
      }
      if (directoryOnly) {
        const selectedUsers = users.filter((u) => system || u.userId === actor2.userId || u.memberships.some((m) => allowed.some((c) => c.companyId === m.companyId)));
        return reply({ rows: [
          { key: USERS, value: JSON.stringify(selectedUsers.map((u) => system ? u : { ...u, memberships: u.memberships.filter((m) => allowed.some((c) => c.companyId === m.companyId)) })), version: usersRow.version },
          { key: COMPANIES, value: JSON.stringify(allowed), version: companiesRow.version }
        ], userId: actor2.userId });
      }
      if (action === "snapshot") {
        const keys = input.keys === void 0 ? void 0 : new Set(array2(input.keys).map((key) => text2(key, 300)));
        if (keys && keys.size > 250) throw new Failure("Kay\u0131t do\u011Frulama s\u0131n\u0131r\u0131 a\u015F\u0131ld\u0131.", 400);
        const deferFiles = !keys && input.deferProjectFiles === true;
        const filesKey = "plmr.project.attachments.v10";
        const selectedUsers = users.filter((u) => system || u.userId === actor2.userId || u.memberships.some((m) => allowed.some((c) => c.companyId === m.companyId)));
        const provisioned = /* @__PURE__ */ new Set([...base.users.map((u) => u.userId), ...platformRows.filter((r) => r.key.startsWith("@auth:")).map((r) => r.value)]);
        const pinReady = (u) => provisioned.has(u.userId);
        const result = [{ key: USERS, value: JSON.stringify(selectedUsers.map((u) => system ? u : { ...u, memberships: u.memberships.filter((m) => allowed.some((c) => c.companyId === m.companyId)) })), version: usersRow.version }, { key: COMPANIES, value: JSON.stringify(allowed), version: companiesRow.version }, { key: CREDS, value: JSON.stringify(Object.fromEntries(selectedUsers.filter(pinReady).map((u) => [u.userId, { version: 1 }]))), version: 0 }];
        for (const row of platformRows)
          if (![USERS, COMPANIES, CREDS].includes(row.key) && !row.key.startsWith("@") && (system || row.key === "plmr.help.shared.v73" || row.key === "plmr.system.hardLimits.v13"))
            result.push({ key: row.key, value: row.value, version: row.version });
        const splitIndexVersions = /* @__PURE__ */ Object.create(null);
        const normalizedProjectScopes = [];
        const companiesToLoad = !keys ? allowed : allowed.filter((c) => [...keys].some((key) => key.startsWith(`plmr.tenant.v68.${c.companyId}.`)));
        const snapshotScopes = companiesToLoad.map((c) => c.companyId);
        const projectEpochs2 = await db.projectEpochs?.(snapshotScopes);
        for (let i = 0; i < companiesToLoad.length; i += 3) {
          const groups = await Promise.all(companiesToLoad.slice(i, i + 3).map(async ({ companyId: cid }) => {
            const prefix = `plmr.tenant.v68.${cid}.`;
            const names = keys ? [...keys].filter((key) => key.startsWith(prefix)).map((key) => key.slice(prefix.length)) : void 0;
            const selected = (scope, wanted) => !wanted.length ? Promise.resolve([]) : db.getMany ? db.getMany(scope, wanted) : Promise.all(wanted.map((key) => get(scope, key)));
            const prefsScope = cid + ":prefs:" + actor2.userId;
            const indexKey = "plmr.project.index.v11";
            const split = (!names || names.includes(indexKey)) && db.splitIndex ? await db.splitIndex(cid, input.compactProjects === true) : null;
            const [tenant, prefs] = await (names ? Promise.all([
              selected(cid, names.filter((key) => !cloudPolicy(key).personal && (!split || key !== indexKey))),
              selected(prefsScope, names.filter((key) => cloudPolicy(key).personal))
            ]) : Promise.all([db.list(cid, deferFiles ? filesKey : void 0, split ? indexKey : void 0), db.list(prefsScope)]));
            const rows = [];
            if (split) {
              if (split.normalized) {
                if (input.projectSummaries !== true) throw new Failure("PROJECT_INDEX_UPGRADE_REQUIRED", 409);
                normalizedProjectScopes.push(cid);
              }
              const projects = split.projects;
              if ((await Promise.all(cloudPolicy(indexKey).read.map((permission) => can(cid, permission)))).some(Boolean)) {
                const canViewTechnical = !split.normalized || await can(cid, "project.view");
                const visibleProjects = (await Promise.all(projects.map(async (item) => {
                  const project = object3(item.value);
                  if (!canViewTechnical && (!project.sourceQuickQuoteId || project.hasTechnicalDrawing)) return null;
                  return await visible(cid, project, "PROJECTS") ? item : null;
                }))).filter((item) => item !== null);
                rows.push({ key: prefix + indexKey, value: JSON.stringify(visibleProjects.map((item) => split.normalized ? { ...object3(item.value), projectDetailsDeferred: true } : item.value)), version: split.version });
                splitIndexVersions[cid] = visibleProjects.map(({ id, version }) => ({ id, version }));
              }
            }
            for (const row of tenant) {
              if (deferFiles && row.key === filesKey) continue;
              if (row.key === "plmr.project.index.v11" && (system || membership(cid)?.roleId === "COMPANY_ADMIN")) {
                if ((await Promise.all(cloudPolicy(row.key).read.map((permission) => can(cid, permission)))).some(Boolean))
                  rows.push({ key: prefix + row.key, value: row.value, version: row.version });
                continue;
              }
              const value = row.value === null ? null : await filter(cid, row.key, parse(row.value));
              if (row.value === null || value !== null)
                rows.push({ key: `plmr.tenant.v68.${cid}.${row.key}`, value: value === null ? null : JSON.stringify(value), version: row.version });
            }
            for (const row of prefs)
              rows.push({ key: `plmr.tenant.v68.${cid}.${row.key}`, value: row.value, version: row.version });
            return rows;
          }));
          for (const rows of groups) for (const row of rows) result.push(row);
        }
        const latestEpochs = await db.projectEpochs?.(snapshotScopes);
        if (snapshotScopes.some((cid) => projectEpochs2?.[cid] !== latestEpochs?.[cid]))
          throw new Failure("PROJECT_EPOCH_CHANGED", 409);
        return reply({
          rows: keys ? result.filter((row) => keys.has(row.key)) : result,
          userId: actor2.userId,
          projectEpochs: projectEpochs2,
          projectIndexPatches: true,
          durableDrawingWrites: Boolean(db.drawingCommit && db.drawingWriteState),
          splitIndexVersions,
          normalizedProjectScopes,
          projectFileStorage: Boolean(db.projectFiles),
          ...deferFiles ? { projectFilesDeferred: true } : {}
        });
      }
      if (action === "project_files_read") {
        const cid = text2(input.companyId), key = "plmr.project.attachments.v10";
        await requireAny(cid, ["project.files.view"]);
        const row = await get(cid, key);
        return reply({ key: `plmr.tenant.v68.${cid}.${key}`, version: row.version, value: row.value === null ? null : JSON.stringify(await filter(cid, key, parse(row.value))) });
      }
      if (action === "project_master_detail") {
        actionLabel = action;
        const cid = text2(input.companyId), id = integer(input.id);
        await requireAny(cid, cloudPolicy("plmr.project.index.v11").read);
        if (!db.masterProject) throw new Failure("INVALID_ACTION", 400);
        const project = await db.masterProject(cid, id);
        if (!project || !await visible(cid, project.value)) throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
        const detail = object3(project.value);
        if (!detail.sourceQuickQuoteId || detail.hasTechnicalDrawing) await requireAny(cid, ["project.view"]);
        return reply(project);
      }
      if (action === "project_index_commit" || action === "project_master_commit") {
        actionLabel = action;
        const normalized = action === "project_master_commit";
        const cid = text2(input.companyId), operation = operationId(input.operationId);
        await requireAny(cid, cloudPolicy("plmr.project.index.v11").write, true);
        const stateRead = normalized ? db.masterState : db.splitIndexState;
        const commit = normalized ? db.masterCommit : db.splitIndexCommit;
        if (!stateRead || !commit) throw new Failure("INVALID_ACTION", 400);
        const entries = array2(input.entries).map((value) => {
          const row = object3(value), id = integer(row.id);
          if (row.value !== null && (identity(row.value) !== String(id) || object3(row.value).id !== id))
            throw new Failure("Proje kimli\u011Fi ge\xE7ersiz.", 400);
          return { id, expectedVersion: integer(row.expectedVersion), value: row.value };
        });
        if (!entries.length || entries.length > 250 || new Set(entries.map((row) => row.id)).size !== entries.length)
          throw new Failure("Proje de\u011Fi\u015Fiklik listesi ge\xE7ersiz.", 400);
        const details = normalized && entries.some((row) => row.value !== null && ["revisions", "productionPackages", "pricing", "approvals"].some((field) => Object.hasOwn(object3(row.value), field)));
        const state = await stateRead.call(db, cid, entries.map((row) => row.id), actor2.userId, operation, details);
        if (!state) throw new Failure("PROJECT_INDEX_MODE_CHANGED", 409);
        if (!state.receipt) {
          const previous = new Map(state.projects?.map((row) => [row.id, row]));
          let overviews;
          if (db.projectRowsForKeys && entries.length > 1) {
            const codes = entries.flatMap((row) => {
              const before = previous.get(row.id)?.value;
              const after = row.value;
              return !before?.approvals && !after?.approvals ? [text2((after ?? before)?.projKodu, 200)] : [];
            });
            const chunks = [];
            for (let i = 0; i < codes.length; i += 128) chunks.push(codes.slice(i, i + 128));
            const rows = await Promise.all(chunks.map((keys) => db.projectRowsForKeys(cid + ":drawing.projects", "overview", false, false, keys)));
            overviews = new Map(rows.flat().map((row) => [row.key, row]));
          }
          for (let i = 0; i < entries.length; i += 4) await Promise.all(entries.slice(i, i + 4).map(async (row) => {
            const prior = previous.get(row.id);
            if ((prior?.version ?? 0) !== row.expectedVersion) throw new Failure("VERSION_CONFLICT", 409);
            if (!prior?.value && row.value === null) throw new Failure("Proje de\u011Fi\u015Fiklik listesi ge\xE7ersiz.", 400);
            if (!await visible(cid, prior?.value ?? row.value, "PROJECTS")) throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
            let candidate = row.value ?? void 0;
            if (normalized && candidate) {
              const next = { ...object3(candidate) };
              delete next.projectDetailsDeferred;
              delete next.packageRevisionIds;
              for (const field of ["revisions", "productionPackages", "pricing", "productionItems"]) {
                if (!Object.hasOwn(next, field) && prior?.value && Object.hasOwn(object3(prior.value), field))
                  next[field] = object3(prior.value)[field];
              }
              if (next.pricing === null) delete next.pricing;
              candidate = next;
            }
            await validateProjectIndexChange(cid, prior?.value ?? void 0, candidate, overviews);
          }));
        }
        return reply({ operationId: operation, projects: await commit.call(db, cid, actor2.userId, operation, entries) });
      }
      if (action === "project_index_patch") {
        const cid = text2(input.companyId), key = "plmr.project.index.v11";
        const policy = cloudPolicy(key);
        await requireAny(cid, policy.write, true);
        const expected = integer(input.expectedVersion);
        const upserts = array2(input.upserts), remove = array2(input.remove).map((id) => String(integer(id)));
        const changes = /* @__PURE__ */ new Map();
        for (const project of upserts) {
          const id = String(integer(object3(project).id));
          if (changes.has(id) || identity(project) !== id) throw new Failure("Proje kimli\u011Fi ge\xE7ersiz veya tekrarlan\u0131yor.", 400);
          changes.set(id, project);
        }
        for (const id of remove) {
          if (changes.has(id)) throw new Failure("Proje de\u011Fi\u015Fiklik listesi ge\xE7ersiz.", 400);
          changes.set(id, void 0);
        }
        const targeted = db.projectIndexState && db.patchProjectIndex;
        const state = targeted ? await db.projectIndexState(cid, [...changes.keys()]) : void 0;
        const oldRow = state ? void 0 : await get(cid, key);
        const currentVersion = state?.version ?? oldRow.version;
        if (currentVersion !== expected) throw new Failure("VERSION_CONFLICT", 409);
        if (!changes.size) return reply({ version: currentVersion });
        const old = state?.projects ?? (oldRow.value === null ? [] : array2(parse(oldRow.value)));
        const before = new Map(old.map((project) => [identity(project), project]));
        if (remove.some((id) => !before.has(id))) throw new Failure("Proje de\u011Fi\u015Fiklik listesi ge\xE7ersiz.", 400);
        const touched = [...changes];
        for (let i = 0; i < touched.length; i += 4) await Promise.all(touched.slice(i, i + 4).map(async ([id, next]) => {
          const prior = before.get(id);
          if (!await visible(cid, prior ?? next, "PROJECTS")) throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
          await validateProjectIndexChange(cid, prior, next);
        }));
        if (targeted) return reply({ version: await db.patchProjectIndex(cid, expected, upserts, remove) });
        const inserted = touched.filter(([id]) => !before.has(id)).map(([, project]) => project);
        const updated = old.flatMap((project) => {
          const id = identity(project);
          if (!changes.has(id)) return [project];
          const next = changes.get(id);
          return next === void 0 ? [] : [next];
        });
        const saved = await db.cas(cid, key, JSON.stringify([...inserted, ...updated]), expected, true);
        return reply({ version: saved.version });
      }
      if (action === "write") {
        const key = text2(input.key), expected = integer(input.expectedVersion), rawValue = input.value === null ? null : text2(input.value, 64 * 1024 * 1024);
        const versionOnly = input.versionOnly === true;
        const written = (row) => reply(input.versionOnly === true ? { version: row.version } : row);
        if (key === CREDS || /credentials|auth\.attempts|clean-start/.test(key))
          throw new Failure("CREDENTIAL_WRITE_FORBIDDEN");
        if (requiresArrayCloudValue(key) && !Array.isArray(parse(rawValue)))
          throw new Failure("ARRAY_VALUE_REQUIRED", 400);
        if (key === USERS) {
          let proposed = array2(parse(rawValue)).map(user);
          if (!system) {
            const cid2 = text2(input.companyId);
            accessible(cid2, true);
            const visibleUsers = users.filter((u) => u.userId === actor2.userId || u.memberships.some((m) => allowed.some((c) => c.companyId === m.companyId)));
            if (visibleUsers.some((u) => !proposed.some((p) => p.userId === u.userId)))
              throw new Failure("Kullan\u0131c\u0131 silme yetkiniz yok.");
            const merged = users.slice();
            for (const next2 of proposed) {
              const old2 = users.find((u) => u.userId === next2.userId);
              const projected = old2 ? { ...old2, memberships: old2.memberships.filter((m) => allowed.some((c) => c.companyId === m.companyId)) } : null;
              if (projected && same(projected, next2))
                continue;
              if (next2.roleId === "SYSTEM_ADMIN" || old2?.roleId === "SYSTEM_ADMIN" || next2.roleId !== "VIEWER")
                throw new Failure("System Admin hesab\u0131 korunmaktad\u0131r.");
              await requireAny(cid2, [old2 ? "admin.users.edit" : "admin.users.create"], true);
              const changed = next2.memberships.find((m) => m.companyId === cid2);
              if (!changed || next2.memberships.some((m) => m.companyId !== cid2 && !same(m, old2?.memberships.find((o) => o.companyId === m.companyId))))
                throw new Failure("Firmalar aras\u0131 eri\u015Fimi yaln\u0131z System Admin tan\u0131mlayabilir.");
              if (old2 && !old2.memberships.some((m) => m.companyId === cid2))
                throw new Failure("Bu kullan\u0131c\u0131ya eri\u015Fim yetkiniz yok.");
              if (!old2 && next2.memberships.length !== 1)
                throw new Failure("Firma se\xE7imi ge\xE7ersiz.");
              if (membership(cid2)?.roleId !== "COMPANY_ADMIN" && (changed.roleId === "COMPANY_ADMIN" || old2?.memberships.find((m) => m.companyId === cid2)?.roleId === "COMPANY_ADMIN"))
                throw new Failure("Y\xF6netici hesab\u0131 korunmaktad\u0131r.");
              for (const [permission, value2] of Object.entries(changed.permissionOverrides || {}))
                if (value2 === "ALLOW" && !await can(cid2, permission))
                  throw new Failure("Sahip olmad\u0131\u011F\u0131n\u0131z yetkiyi veremezsiniz.");
              if (old2?.memberships.some((m) => m.companyId !== cid2) && !same({ ...old2, memberships: null, updatedAt: null, updatedBy: null }, { ...next2, memberships: null, updatedAt: null, updatedBy: null }))
                throw new Failure("Ortak hesap bilgilerini yaln\u0131z System Admin d\xFCzenleyebilir.");
              const saved = { ...next2, memberships: old2 ? [...old2.memberships.filter((m) => m.companyId !== cid2), changed] : [changed] };
              if (old2)
                merged[merged.findIndex((u) => u.userId === old2.userId)] = saved;
              else
                merged.push(saved);
            }
            proposed = merged;
          }
          if (!proposed.some((u) => u.roleId === "SYSTEM_ADMIN" && u.status === "ACTIVE"))
            throw new Failure("Son aktif System Admin korunmal\u0131d\u0131r.");
          for (const old2 of users) {
            const next2 = proposed.find((u) => u.userId === old2.userId);
            if (next2 && next2.username.toLowerCase() !== old2.username.toLowerCase())
              throw new Failure("Bulut hesab\u0131n\u0131n kullan\u0131c\u0131 ad\u0131 de\u011Fi\u015Ftirilemez. Yeni hesap olu\u015Fturun.");
          }
          if (new Set(proposed.map((u) => u.userId)).size !== proposed.length || new Set(proposed.map((u) => u.username.toLowerCase())).size !== proposed.length)
            throw new Failure("Kullan\u0131c\u0131 ad\u0131 kullan\u0131l\u0131yor.", 400);
          for (const c of companies)
            if (proposed.filter((u) => u.status === "ACTIVE" && u.memberships.some((m) => m.companyId === c.companyId && m.status === "ACTIVE")).length > c.userLimit)
              throw new Failure("Aktif kullan\u0131c\u0131 limiti dolu.");
          return written(await db.cas("platform", key, JSON.stringify(proposed), expected, versionOnly));
        }
        if (key === COMPANIES) {
          const proposed = array2(parse(rawValue)).map(company);
          if (system && companies.some((c) => !proposed.some((p) => p.companyId === c.companyId)))
            throw new Failure("COMPANY_DELETE_REQUIRED", 409);
          if (!system) {
            if (proposed.length !== allowed.length)
              throw new Failure("Firma listesi de\u011Fi\u015Ftirilemez.");
            for (const c of proposed) {
              await requireAny(c.companyId, ["admin.company_settings.edit"], true);
              const old2 = companies.find((x) => x.companyId === c.companyId);
              if (!old2 || !same({ ...c, settings: null, updatedAt: null }, { ...old2, settings: null, updatedAt: null }))
                throw new Failure("Firma lisans\u0131 de\u011Fi\u015Ftirilemez.");
            }
          }
          const merged = system ? proposed : companies.map((c) => proposed.find((p) => p.companyId === c.companyId) || c);
          if (new Set(merged.map((c) => c.companyId)).size !== merged.length || new Set(merged.map((c) => c.code.toLowerCase())).size !== merged.length)
            throw new Failure("Firma kodu kullan\u0131l\u0131yor.", 400);
          return written(await db.cas("platform", key, JSON.stringify(merged), expected, versionOnly));
        }
        if (!key.startsWith("plmr.tenant.")) {
          if (!system)
            throw new Failure("PLATFORM_ADMIN_REQUIRED");
          if (key === "plmr.platform.audit.v68")
            return written(await db.appendAudit("platform", key, array2(parse(rawValue)).filter((v) => object3(v).actorUserId === actor2.userId)));
          return written(await db.cas("platform", key, rawValue, expected, versionOnly));
        }
        const match = /^plmr\.tenant\.v68\.([^.]+)\.(.+)$/.exec(key);
        if (!match)
          throw new Failure("INVALID_TENANT_KEY", 400);
        const cid = match[1], name = match[2], policy = cloudPolicy(name);
        await requireAny(cid, isMaterialCatalog(name) ? ["product.edit", "product.create"] : policy.write, true);
        if (name === "plmr.audit.v13")
          return written(await db.appendAudit(cid, name, array2(parse(rawValue)).filter((v) => object3(v).actorUserId === actor2.userId)));
        if (policy.personal)
          return written(await db.cas(cid + ":prefs:" + actor2.userId, name, rawValue, expected, versionOnly));
        const oldRow = await db.get(cid, name), old = oldRow.value === null ? null : parse(oldRow.value), next = parse(rawValue);
        let value = isMaterialCatalog(name) ? await validateMaterials(db, cid, name, old, next, (p) => can(cid, p)) : next;
        if (name === "plmr.project.attachments.v10") {
          const index = await db.get(cid, "plmr.project.index.v11");
          const projects = array2(index.value ? parse(index.value) : []);
          const before = old ? array2(old) : [], after = next ? array2(next) : [];
          for (const attachment of [...before, ...after]) {
            const record = object3(attachment);
            if (same(before.find((v) => identity(v) === identity(record)), after.find((v) => identity(v) === identity(record)))) continue;
            const parent = projects.find((v) => {
              const p = object3(v);
              return p.projectId === record.projectId || p.projKodu === record.projectId;
            });
            if (!parent) continue;
            const project = object3(parent), packages = object3(project.productionPackages || {});
            const canonical = await get(cid + ":drawing.projects", String(project.projKodu));
            if (canonical.value?.workflow?.approvals?.package)
              throw new Failure("\xDCretim paketi onayland\u0131. Proje dosyalar\u0131 salt okunurdur.");
            if (packages[String(project.revisionId)] || packages[String(record.revisionId)])
              throw new Failure("\xDCretim paketi kaydedildi. Bu revizyonun dosyalar\u0131 salt okunurdur.");
          }
        }
        if (Array.isArray(next) && policy.family) {
          value = await mergeVisible(cid, old ? array2(old) : [], next, policy.family);
          if (/project.index/.test(name)) {
            const beforeById = new Map((old ? array2(old) : []).map((v) => [identity(v), v]));
            const afterById = new Map(array2(value).map((v) => [identity(v), v]));
            if (afterById.size !== array2(value).length) throw new Failure("Tekrarlanan proje kimli\u011Fi.", 400);
            const changes = [.../* @__PURE__ */ new Set([...beforeById.keys(), ...afterById.keys()])].map((id) => [beforeById.get(id), afterById.get(id)]).filter(([before, after]) => !same(before, after));
            for (let i = 0; i < changes.length; i += 4)
              await Promise.all(changes.slice(i, i + 4).map(([before, after]) => validateProjectIndexChange(cid, before, after)));
          }
        }
        if (name === "plmr.task-reminder.v12" && next) {
          const n = object3(next), o = old ? object3(old) : {};
          value = { ...n, tasks: await mergeVisible(cid, array2(o.tasks || []), array2(n.tasks || []), "OPERATIONS"), reminders: await mergeVisible(cid, array2(o.reminders || []), array2(n.reminders || []), "OPERATIONS") };
        }
        if (name === "plmr.cloud.library.meta.v12" && next) {
          const n = object3(next), o = old ? object3(old) : {}, items = await mergeVisible(cid, array2(o.items || []), array2(n.items || []), "PROJECTS"), visibleIds = new Set((await subset(cid, o.items || [], "PROJECTS")).map(identity));
          value = { ...n, items, versions: [...array2(o.versions || []).filter((v) => !visibleIds.has(String(object3(v).itemId))), ...array2(n.versions || [])] };
        }
        return written(await db.cas(cid, name, value === null ? null : JSON.stringify(value), expected, versionOnly));
      }
      if (action === "set_pin") {
        const target = users.find((u) => u.userId === text2(input.userId)), pin = text2(input.pin, 4);
        if (!target || !/^\d{4}$/.test(pin))
          throw new Failure("PIN tam 4 rakamdan olu\u015Fmal\u0131d\u0131r.", 400);
        if (!system) {
          const cid = text2(input.companyId);
          await requireAny(cid, ["admin.users.edit"], true);
          if (target.roleId === "SYSTEM_ADMIN" || target.memberships.length !== 1 || target.memberships[0].companyId !== cid)
            throw new Failure("Bu hesab\u0131n PIN\u2019ini yaln\u0131z System Admin belirleyebilir.");
        }
        await db.setPin(principal, target, pin);
        return reply({ ok: true });
      }
      if (action === "sequence") {
        const cid = text2(input.companyId), key = text2(input.key);
        await requireAny(cid, ["project.create", "commercial.quote.create"], true);
        if (!/^plmr\.project\.sequence\.user\.\d{4}$/.test(key))
          throw new Failure("INVALID_SEQUENCE", 400);
        return reply({ value: await db.sequence(cid + ":sequence", key, integer(input.minimum)) });
      }
      if (action === "share_create") {
        const cid = text2(input.companyId);
        await requireAny(cid, ["project.export"]);
        return reply(await db.sharePut(principal, cid, validatePresentation(input.presentation)), 201);
      }
      if (action === "continue_drawing") {
        const cid = text2(input.companyId), key = text2(input.key);
        await requireAny(cid, ["project.edit"], true);
        await requireAny(cid, ["project.revision.create"], true);
        const scope = cid + ":drawing.projects", row = await db.get(scope, key);
        if (!row.value || !await visible(cid, row.value)) throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
        const before = row.value;
        if (!before.workflow || before.workflow.version !== integer(input.expectedWorkflowVersion)) throw new Failure("Proje ba\u015Fka bir sekmede de\u011Fi\u015Fti. G\xFCncel kayd\u0131 a\xE7\u0131n.", 409);
        const next = continueDrawingRecord(before, text2(input.revisionId), actor2.userId);
        assertApprovedRecordUnchanged(before, next);
        const saved = await db.cas(scope, key, next, row.version, true);
        return reply({ value: next, version: saved.version });
      }
      if (action === "project_overview") {
        const cid = text2(input.companyId), key = text2(input.key);
        await requireAny(cid, ["project.view", "commercial.quote.view"]);
        const scope = cid + ":drawing.projects";
        const row = await (db.overview ? db.overview(scope, key) : db.get(scope, key));
        if (row.value && !await visible(cid, row.value)) throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
        return reply(projectOverview(row.value));
      }
      if (action === "drawing_workspace") {
        const cid = text2(input.companyId), key = text2(input.key);
        await requireAny(cid, ["project.view", "commercial.quote.view"]);
        const scope = cid + ":drawing.projects", known = input.knownVersion === void 0 ? void 0 : integer(input.knownVersion);
        const canonical = async () => {
          if (known !== void 0 && db.header) {
            const header = await db.header(scope, key);
            if (header.version === known) return { row: header, notModified: true };
          }
          return { row: await db.get(scope, key), notModified: false };
        };
        const [{ row, notModified }, draft] = await Promise.all([canonical(), db.get(cid + ":drawing.drafts:" + actor2.userId, key)]);
        if (row.value && !await visible(cid, row.value)) throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
        const current = row.value, candidate = draft.value ? object3(draft.value) : null;
        const recovery = current && !current.workflow?.drawingLocked && candidate && Date.parse(String(candidate.expiresAt)) > Date.now() && await visible(cid, candidate) ? candidate : null;
        return reply({ record: notModified ? { version: row.version, notModified: true } : row, recovery });
      }
      if (action === "stock_read" || action === "stock_move") {
        const cid = text2(input.companyId), writing = action === "stock_move";
        await requireAny(cid, writing ? ["product.edit"] : ["product.view", "operations.view"], writing);
        const scope = cid + ":stock", key = "ledger";
        if (!writing) {
          const row2 = await db.get(scope, key), state2 = row2.value || emptyStock();
          return reply(input.balancesOnly === true ? { balances: state2.balances, movements: [] } : state2);
        }
        const raw = object3(input.command);
        validateStockCommand(raw);
        const command = { id: raw.id, direction: raw.direction, note: raw.note, lines: raw.lines.map(({ kind, materialId, lengthMm, quantity }) => ({ kind, materialId, lengthMm, quantity })) };
        const kinds = [...new Set(command.lines.map((l) => l.kind))], keys = kinds.map((k) => stockCatalogKeys[k]);
        const [row, catalog] = await Promise.all([db.get(scope, key), db.getMany ? db.getMany(cid, keys) : Promise.all(keys.map((k) => get(cid, k)))]);
        const state = row.value || emptyStock();
        if (existingStockMovement(state, command)) return reply(state);
        const identities = new Map(kinds.map((kind) => {
          const value = catalog.find((r) => r.key === stockCatalogKeys[kind])?.value;
          const rows = value ? typeof value === "string" ? array2(parse(value)) : array2(value) : [];
          return [kind, new Set(rows.map((m) => object3(m)[kind + "Id"]))];
        }));
        if (command.lines.some((line) => !identities.get(line.kind)?.has(line.materialId))) throw new Failure("Firma katalo\u011Funda stok malzemesi bulunamad\u0131.", 400);
        const next = applyStockMovement(state, command, { id: actor2.userId, name: actor2.fullName }, (/* @__PURE__ */ new Date()).toISOString());
        await db.cas(scope, key, next, row.version, true);
        return reply(next);
      }
      if (action === "project_withdraw") {
        const cid = text2(input.companyId), key = text2(input.key), target = input.target;
        await requireAny(cid, ["project.status.change"], true);
        if (target !== 10 && target !== 20 && target !== 30 && target !== 40) throw new Failure("Geri \xE7ekme a\u015Famas\u0131 ge\xE7ersiz.", 400);
        const scope = cid + ":drawing.projects", row = await get(scope, key);
        if (!row.value || !await visible(cid, row.value)) throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
        const before = row.value;
        if (before.workflow?.version !== integer(input.expectedWorkflowVersion)) throw new Failure("Proje ba\u015Fka bir sekmede de\u011Fi\u015Fti. G\xFCncel kayd\u0131 a\xE7\u0131n.", 409);
        const next = withdrawProjectRecord(before, target, actor2.userId, text2(input.note, 2e3));
        const saved = await db.cas(scope, key, next, row.version, true);
        return reply({ value: next, version: saved.version });
      }
      if (action === "project_approve") {
        const cid = text2(input.companyId), key = text2(input.key), stage = approvalStage(input.stage);
        await requireAny(cid, [approvalPermissions[stage]], true);
        const scope = cid + ":drawing.projects";
        const row = await get(scope, key);
        if (!row.value || !await visible(cid, row.value)) throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
        const before = row.value;
        if (!before.workflow || before.workflow.version !== integer(input.expectedWorkflowVersion)) throw new Failure("Proje ba\u015Fka bir sekmede de\u011Fi\u015Fti. G\xFCncel kayd\u0131 a\xE7\u0131n.", 409);
        let document;
        if (stage === "package") {
          const signature = drawingFingerprint(before);
          if (input.sourceSignature !== signature) throw new Failure("\xC7izim de\u011Fi\u015Fti. G\xFCncel kayd\u0131 a\xE7\u0131n.", 409);
          const revision = before.workflow.activeDrawingRevisionId;
          if (revision && before.workflow.lockedSignature === signature) {
            if (db.projectPackage) document = await db.projectPackage(cid, key, revision) ?? void 0;
            else {
              const index = await get(cid, "plmr.project.index.v11");
              const master = (index.value ? array2(parse(index.value)) : []).find((v) => object3(v).projKodu === key);
              document = master?.productionPackages?.[revision];
            }
          }
          document ??= input.productionPackage;
        }
        const next = approveProjectRecord(before, stage, actor2.userId, actor2.fullName, document);
        assertApprovedRecordUnchanged(before, next, true);
        if (next === before) return reply({ value: before, version: row.version });
        const saved = await db.cas(scope, key, next, row.version, true);
        return reply({ value: next, version: saved.version });
      }
      if (action.startsWith("record_")) {
        const cid = text2(input.companyId), store = text2(input.store, 80), key = ["record_list", "record_delete_many"].includes(action) ? "" : text2(input.key);
        if (!["drawing.projects", "drawing.drafts", "drawing.meta", "drawing.audit", "quote.quotes", "quote.captures", "binary"].includes(store))
          throw new Failure("INVALID_STORE", 400);
        const writing = action === "record_put" || action === "record_delete_many";
        await requireAny(cid, writing ? store === "binary" ? action === "record_delete_many" || input.value === null ? ["cloud.archive"] : ["cloud.upload", "cloud.version.manage"] : ["project.edit", "project.create", "commercial.quote.create"] : store === "binary" ? ["cloud.download"] : ["project.view", "commercial.quote.view"], writing);
        const scope = cid + ":" + store + (/drafts|meta/.test(store) ? ":" + actor2.userId : "");
        const allowedRecord = async (v) => /projects|quotes|drafts|binary|captures/.test(store) ? visible(cid, v) : true;
        if (action === "record_delete_many") {
          if (store !== "binary")
            throw new Failure("INVALID_STORE", 400);
          const items = array2(input.items).map((v) => {
            const o = object3(v);
            return { key: text2(o.key), version: integer(o.version) };
          });
          if (items.length > 500 || new Set(items.map((i) => i.key)).size !== items.length)
            throw new Failure("INVALID_BATCH", 400);
          const rows = db.getMany ? await db.getMany(scope, items.map((i) => i.key)) : await Promise.all(items.map((item) => db.get(scope, item.key)));
          for (const row of rows) {
            if (row.value !== null && !await allowedRecord(row.value))
              throw new Failure("Bu dosyay\u0131 silme yetkiniz yok.");
          }
          await db.deleteMany(scope, items);
          const paths = rows.flatMap((row) => {
            const pointer = libraryPointer(row.value);
            return pointer && pointer.storagePath === encodeURIComponent(cid) + "/" + row.key + "/" + pointer.sha256 ? [pointer.storagePath] : [];
          });
          if (paths.length && db.libraryObjects) {
            try {
              await db.libraryObjects.remove(paths);
            } catch {
              console.warn(JSON.stringify({ event: "plmr_library_cleanup_pending", requestId, objects: paths.length }));
            }
          }
          return reply({ ok: true });
        }
        if (action === "record_list") {
          const result = [];
          for (const row of await db.list(scope))
            if (row.value !== null && await allowedRecord(row.value))
              result.push(row);
          return reply(result);
        }
        if (action === "record_get" && input.knownVersion !== void 0 && db.header) {
          const header = await db.header(scope, key);
          if (header.value !== null && !await allowedRecord(header.value))
            throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
          if (header.version === integer(input.knownVersion)) return reply({ key, version: header.version, notModified: true });
        }
        const insertingDrawing = action === "record_put" && store === "drawing.projects" && input.expectedVersion === 0 && input.value && object3(input.value).ownerUserId === actor2.userId && object3(input.value).createdByUserId === actor2.userId;
        const operation = action === "record_put" && store === "drawing.projects" && input.operationId !== void 0 ? operationId(input.operationId) : void 0;
        const retain = input.retainedHistory === void 0 ? void 0 : array2(input.retainedHistory).map((field) => text2(field, 24));
        if (retain && (!operation || !db.compactDrawingCommit || new Set(retain).size !== retain.length || retain.some((field) => !["drawings", "quotes", "withdrawnPackages"].includes(field))))
          throw new Failure("INVALID_RETAINED_HISTORY", 400);
        if (operation && (!db.drawingWriteState || !db.drawingCommit)) throw new Failure("INVALID_ACTION", 400);
        const commitDrawing = () => retain ? db.compactDrawingCommit(scope, key, actor2.userId, operation, integer(input.expectedVersion), input.value, retain) : db.drawingCommit(scope, key, actor2.userId, operation, integer(input.expectedVersion), input.value);
        const state = operation ? await db.drawingWriteState(scope, key, actor2.userId, operation, Boolean(insertingDrawing), retain) : void 0;
        if (state?.receipt) return reply({ operationId: operation, ...await commitDrawing() });
        const prior = state?.row ?? (insertingDrawing ? { key, value: null, version: 0 } : await db.get(scope, key));
        if (prior.value !== null && !await allowedRecord(prior.value))
          throw new Failure("Bu projeye eri\u015Fim yetkiniz yok.");
        if (action === "record_get")
          return reply(prior);
        if (action !== "record_put")
          throw new Failure("INVALID_ACTION", 400);
        if (operation && prior.version !== integer(input.expectedVersion)) throw new Failure("VERSION_CONFLICT", 409);
        let value = input.value;
        if (retain?.length) {
          const before = object3(object3(prior.value).workflow), next = { ...object3(object3(value).workflow) };
          for (const field of retain) {
            if (Object.hasOwn(next, field)) throw new Failure("INVALID_RETAINED_HISTORY", 400);
            if (Object.hasOwn(before, field)) next[field] = before[field];
          }
          value = { ...object3(value), workflow: next };
        }
        if (store === "drawing.projects") assertApprovedRecordUnchanged(prior.value, value);
        if (["drawing.drafts", "quote.quotes", "quote.captures"].includes(store)) {
          const projectCode = String((value ? object3(value).projectCode : prior.value ? object3(prior.value).projectCode : "") || key);
          const canonical = await get(cid + ":drawing.projects", projectCode);
          const a = canonical.value?.workflow?.approvals;
          if (["drawing.drafts", "quote.captures"].includes(store) && a?.package || store === "quote.quotes" && a?.quote) throw new Failure("Onaylanm\u0131\u015F belge salt okunurdur.");
        }
        if (value === null && ["drawing.projects", "quote.quotes"].includes(store))
          await requireAny(cid, ["project.archive"], true);
        if (value !== null && store === "binary") {
          if (libraryPointer(prior.value)) throw new Failure("LIBRARY_FILE_IMMUTABLE", 409);
          const binary = object3(value);
          if (typeof binary.data !== "string" || !/^data:[\w.+/-]*;base64,[A-Za-z0-9+/]*={0,2}$/.test(binary.data))
            throw new Failure("Dosya i\xE7eri\u011Fi ge\xE7ersiz.", 400);
        }
        if (value !== null && /binary|captures/.test(store)) {
          const r = object3(value);
          if (prior.value === null) {
            if (r.ownerUserId !== actor2.userId)
              throw new Failure("Kay\u0131t sahipli\u011Fi ge\xE7ersiz.");
          } else if (r.ownerUserId !== object3(prior.value).ownerUserId)
            throw new Failure("Kay\u0131t sahipli\u011Fi de\u011Fi\u015Ftirilemez.");
        }
        if (value !== null && /projects|quotes|drafts/.test(store)) {
          const r = object3(value);
          if (store === "drawing.projects" && r.projectCode !== key)
            throw new Failure("INVALID_PROJECT_KEY", 400);
          if (prior.value === null && !system && !await visible(cid, r))
            throw new Failure("Kay\u0131t sahipli\u011Fi ge\xE7ersiz.");
          if (prior.value !== null) {
            const before = object3(prior.value);
            if (before.ownerUserId && r.ownerUserId !== before.ownerUserId)
              throw new Failure("Proje sahibi de\u011Fi\u015Ftirilemez.");
            if (store === "drawing.projects" && before.workflow) {
              const oldWorkflow = object3(before.workflow), newWorkflow = object3(r.workflow);
              for (const list2 of ["drawings", "quotes"]) {
                if (retain?.includes(list2)) continue;
                const revisions = new Map(array2(newWorkflow[list2] || []).map((v) => [identity(v), v]));
                for (const frozen of array2(oldWorkflow[list2] || [])) {
                  const next = revisions.get(identity(frozen));
                  if (!same(frozen, next))
                    throw new Failure("Kaydedilmi\u015F revizyon de\u011Fi\u015Ftirilemez.");
                }
              }
              if (oldWorkflow.drawingLocked && drawingFingerprint(before) !== drawingFingerprint(r))
                throw new Failure("\xC7izim kilitli. \xD6nce \xC7izimi D\xFCzenle i\u015Flemini kullan\u0131n.");
            }
          }
        }
        if (operation) return reply({ operationId: operation, ...await commitDrawing() });
        const saved = await db.cas(scope, key, value, integer(input.expectedVersion), input.versionOnly === true);
        return reply(input.versionOnly === true ? { version: saved.version } : saved);
      }
      throw new Failure("INVALID_ACTION", 400);
    } catch (e) {
      const err = e;
      const companyError = {
        ARRAY_VALUE_REQUIRED: [400, "Bu kay\u0131t bir dizi bekliyor. Bo\u015F kay\u0131t i\xE7in bo\u015F dizi kullan\u0131n."],
        COMPANY_DELETE_REQUIRED: [409, "Firma yaln\u0131z Firma Sil i\u015Flemiyle kald\u0131r\u0131labilir."],
        COMPANY_NOT_FOUND: [404, "Firma bulunamad\u0131."],
        COMPANY_MAINTENANCE: [503, "Firman\u0131n silme i\u015Flemi s\xFCr\xFCyor."],
        COMPANY_REMOVED: [409, "Firma silinmi\u015F. Bu kay\u0131t buluta g\xF6nderilmedi."],
        COMPANY_DELETE_UNAVAILABLE: [503, "Firma silme servisi hen\xFCz haz\u0131r de\u011Fil."],
        DIRECTORY_NOT_READY: [409, "Firma veya kullan\u0131c\u0131 kay\u0131tlar\u0131 do\u011Frulanamad\u0131."],
        SYSTEM_ADMIN_REQUIRED: [403, "Bu i\u015Flemi yaln\u0131z System Admin yapabilir."],
        SESSION_INVALID: [403, "Oturum ge\xE7ersiz. Yeniden giri\u015F yap\u0131n."],
        ACCOUNT_DISABLED: [403, "Hesap eri\u015Fimi kald\u0131r\u0131ld\u0131."]
      };
      if (Object.hasOwn(companyError, err.message)) {
        const [status, error] = companyError[err.message];
        return reply({ error, code: err.message }, status);
      }
      if (/PROJECT_EPOCH_CHANGED/.test(err.message)) return reply({
        error: "Proje veri d\xF6nemi de\u011Fi\u015Fti. Eski taslak sunucuya g\xF6nderilmedi. Uygulamay\u0131 yeniden a\xE7\u0131n.",
        code: "PROJECT_EPOCH_CHANGED"
      }, 409);
      if (/PROJECT_MAINTENANCE/.test(err.message)) return reply({ error: "Proje bak\u0131m i\u015Flemi s\xFCr\xFCyor.", code: "PROJECT_MAINTENANCE" }, 503);
      if (/PROJECT_FILE_STORAGE_UNAVAILABLE/.test(err.message)) return reply({ error: "Dosya deposu \u015Fu anda yan\u0131t veremiyor.", code: "PROJECT_FILE_STORAGE_UNAVAILABLE" }, 503);
      if (/CATALOG_STORAGE_(UNAVAILABLE|NOT_INSTALLED)/.test(err.message)) return reply({ error: "Katalog g\xF6rsel deposu \u015Fu anda yan\u0131t veremiyor.", code: err.message }, 503);
      if (err.message === "PROJECT_FILES_READ_ONLY") return reply({ error: "Bu revizyonun dosyalar\u0131 salt okunurdur.", code: err.message }, 403);
      if (/PROJECT_INDEX_(UPGRADE_REQUIRED|MODE_CHANGED)/.test(err.message))
        return reply({ error: "Proje kay\u0131t bi\xE7imi de\u011Fi\u015Fti. Taslak korunuyor. Uygulamay\u0131 yeniden a\xE7\u0131n.", code: "PROJECT_INDEX_MODE_CHANGED" }, 409);
      if (/OPERATION_ID_REUSED/.test(err.message)) return reply({ error: "OPERATION_ID_REUSED" }, 409);
      if (/statement timeout/i.test(err.message))
        return reply({ error: "Veritaban\u0131 i\u015Flemi zaman s\u0131n\u0131r\u0131n\u0131 a\u015Ft\u0131.", code: "STATEMENT_TIMEOUT" }, 503);
      return reply({ error: err.message }, e instanceof Failure ? e.status : /VERSION_CONFLICT/.test(err.message) ? 409 : 400);
    }
  };
}

// ../Cloud/edge-v21.ts
import { createHash } from "node:crypto";
var import_v22_animation_core = __toESM(require_v22_animation_core());
var import_v15_core = __toESM(require_v15_core());
var url = Deno.env.get("SUPABASE_URL");
var secret = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
var anon = Deno.env.get("SUPABASE_ANON_KEY");
var admin = createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
function checked(result) {
  if (result.error)
    throw Error(result.error.message);
  return result.data;
}
function storageBackend(fileObjects) {
  return {
    async projectFileUpload(path) {
      return checked(await fileObjects.createSignedUploadUrl(path, { upsert: false }));
    },
    async projectFileUrl(path, download) {
      return checked(await fileObjects.createSignedUrl(path, 60, download ? { download } : void 0)).signedUrl;
    },
    async projectFileVerify(path, size, sha) {
      const signed = await fileObjects.createSignedUrl(path, 60);
      if (signed.error) {
        if (/not found|404/i.test(signed.error.message)) return false;
        checked(signed);
      }
      const response = await fetch(signed.data.signedUrl, { signal: AbortSignal.timeout(25e3) });
      if (!response.ok || !response.body) {
        await response.body?.cancel();
        if (response.status === 404) return false;
        throw Error("PROJECT_FILE_STORAGE_UNAVAILABLE");
      }
      const reader = response.body.getReader(), digest = createHash("sha256");
      let bytes = 0;
      try {
        for (; ; ) {
          const { value, done } = await reader.read();
          if (done) break;
          bytes += value.byteLength;
          if (bytes > size) {
            await reader.cancel();
            return false;
          }
          digest.update(value);
        }
        return bytes === size && digest.digest("hex") === sha;
      } finally {
        reader.releaseLock();
      }
    }
  };
}
function libraryBackend(admin2) {
  const objects = admin2.storage.from(libraryBucket);
  return {
    ...storageBackend(objects),
    sha256(bytes) {
      return createHash("sha256").update(bytes).digest("hex");
    },
    async importLegacy(path, bytes, mime) {
      const result = await objects.upload(path, bytes, { contentType: mime, upsert: false });
      if (result.error && !/already exists|duplicate/i.test(result.error.message)) checked(result);
    },
    async remove(paths) {
      checked(await objects.remove(paths));
    }
  };
}
function fileBackend(admin2) {
  const fileObjects = admin2.storage.from(projectFileBucket);
  const fileRows = () => admin2.from("plmr_v43_project_files");
  return {
    async fileProject(scope, project) {
      return checked(await admin2.rpc("plmr_v43_file_project", { p_scope: scope, p_project: project }));
    },
    async fileOwners(scope, projects) {
      return checked(await admin2.rpc("plmr_v43_file_owners", { p_scope: scope, p_projects: projects }));
    },
    async searchFiles(scope, projects) {
      let after = null;
      const files = [];
      for (; ; ) {
        const page = checked(await admin2.rpc("plmr_v43_file_search", { p_scope: scope, p_projects: projects, p_after: after }));
        files.push(...page.map((row) => row.metadata));
        if (page.length < 128) return files;
        after = page.at(-1).id;
      }
    },
    async legacyProjectFiles(scope, project, id) {
      return checked(await admin2.rpc("plmr_v43_legacy_project_files", { p_scope: scope, p_project: project, p_id: id ?? null }));
    },
    async projectFileList(scope, project) {
      const result = [];
      let after;
      for (; ; ) {
        let query = fileRows().select("id,metadata").eq("scope", scope).eq("project_id", project).in("metadata->>status", ["active", "deleted"]).order("id").limit(100);
        if (after) query = query.gt("id", after);
        const rows = checked(await query);
        result.push(...rows.map((row) => row.metadata));
        if (rows.length < 100) return result;
        after = rows.at(-1).id;
      }
    },
    async projectFileGet(scope, id) {
      return checked(await fileRows().select("metadata,version").eq("scope", scope).eq("id", id).maybeSingle());
    },
    async projectFileInsert(scope, metadata) {
      checked(await fileRows().upsert(
        { scope, id: metadata.attachmentId, project_id: metadata.projectId, metadata },
        { onConflict: "scope,id", ignoreDuplicates: true }
      ));
    },
    async projectFileUpdate(scope, before, metadata) {
      const row = checked(await fileRows().update({ metadata, version: before.version + 1 }).eq("scope", scope).eq("id", metadata.attachmentId).eq("version", before.version).select("id").maybeSingle());
      if (!row) throw Error("VERSION_CONFLICT");
    },
    ...storageBackend(fileObjects),
    async projectFileCopy(from, to) {
      checked(await fileObjects.copy(from, to));
    }
  };
}
async function allRows(table, fields, scope, excludeKey, excludeAlso) {
  const result = [];
  for (let from = 0; ; from += 1e3) {
    let query = admin.from(table).select(fields).range(from, from + 999);
    if (scope)
      query = query.eq("scope", scope);
    if (excludeKey) query = query.neq("key", excludeKey);
    if (excludeAlso) query = query.neq("key", excludeAlso);
    if (table === "plmr_v12_records") query = query.order("key");
    const rows = checked(await query);
    result.push(...rows);
    if (rows.length < 1e3)
      return result;
  }
}
async function projectPage(scope, kind, commercial, legacy, key, after, limit) {
  if (kind === "header" && /:(drawing\.projects|quote\.quotes)$/.test(scope)) {
    const rows2 = checked(await admin.rpc("plmr_v43_project_header_page", { p_scope: scope, p_key: key, p_after: after, p_limit: limit }));
    return rows2.map((row) => ({ ...row, version: Number(row.version) }));
  }
  const rows = checked(await admin.rpc("plmr_v40_project_rows", {
    p_scope: scope,
    p_kind: kind,
    p_commercial: commercial,
    p_legacy: legacy,
    p_key: key,
    p_after: after,
    p_limit: limit
  }));
  return rows.map((row) => ({ ...row, version: Number(row.version) }));
}
Deno.serve(async (request) => {
  const projectEpoch = request.headers.get("x-plmr-project-epoch") || "0";
  const admin2 = createClient(url, secret, {
    global: { headers: { "x-plmr-project-epoch": projectEpoch, "x-plmr-project-protocol": "44" } },
    auth: { persistSession: false, autoRefreshToken: false }
  });
  const token = (request.headers.get("Authorization") || "").replace(/^Bearer\s+/i, ""), userClient = createClient(url, anon, { global: { headers: { Authorization: "Bearer " + token } }, auth: { persistSession: false, autoRefreshToken: false } });
  const backend = {
    async companyDelete(cid, nativeActor) {
      return checked(await admin2.rpc("plmr_v50_company_delete", { p_company: cid, p_actor: nativeActor }));
    },
    async companyDeletionJobs() {
      return checked(await admin2.from("plmr_v50_company_deletions").select("*").is("cleaned_at", null).order("deleted_at", { ascending: true }).limit(100));
    },
    async companyCleanup(cid) {
      const page = checked(await admin2.rpc("plmr_v50_company_storage_page", { p_company: cid }));
      const groups = /* @__PURE__ */ new Map();
      for (const { bucket, path } of page) {
        const paths = groups.get(bucket) || [];
        paths.push(path);
        groups.set(bucket, paths);
      }
      const results = await Promise.allSettled([...groups].map(async ([bucket, paths]) => {
        checked(await admin2.storage.from(bucket).remove(paths));
      }));
      return checked(await admin2.rpc("plmr_v50_company_cleanup_result", {
        p_company: cid,
        p_failed: results.some((result) => result.status === "rejected")
      }));
    },
    projectFiles: fileBackend(admin2),
    libraryObjects: libraryBackend(admin2),
    async projectEpochs(scopes2) {
      if (!scopes2.length) return {};
      const rows = checked(await admin2.from("plmr_v43_project_epoch").select("scope,epoch").in("scope", scopes2));
      return Object.fromEntries(rows.map((row) => [row.scope, row.epoch]));
    },
    async authenticate() {
      if (!token)
        throw Error("Oturum gerekli.");
      const [auth, session2] = await Promise.all([admin2.auth.getUser(token), userClient.rpc("plmr_v49_current_session_profile")]);
      const result = checked(auth);
      if (!result.user)
        throw Error("Oturum ge\xE7ersiz.");
      const profile = checked(session2);
      if (profile?.id !== result.user.id || profile.is_active !== true) throw Error("SESSION_INVALID");
      return { id: result.user.id, profile };
    },
    async uploadCatalogMedia(cid, input) {
      const data = String(input.data || "");
      if (!data.startsWith("data:image/webp;base64,") || data.length > 3 * 1024 * 1024) throw Error("INVALID_WEBP");
      const bytes = Uint8Array.from(atob(data.split(",")[1]), (c) => c.charCodeAt(0));
      const metadata = inspectCatalogWebp(bytes);
      if (input.encoding === "lossless" && !metadata.lossless) throw Error("LOSSLESS_WEBP_REQUIRED");
      const id = crypto.randomUUID(), path = cid + "/" + id + ".webp", sha = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)), (b) => b.toString(16).padStart(2, "0")).join("");
      checked(await admin2.storage.from("plmr-catalog-media").upload(path, bytes, { contentType: "image/webp", upsert: false }));
      return { fileName: String(input.fileName || "image.webp").slice(0, 200), mimeType: "image/webp", sizeBytes: bytes.length, storage: { bucket: "plmr-catalog-media", path, id, companyId: cid, sha256: sha, width: 512, height: 512, encoding: metadata.lossless ? "lossless" : "photo" } };
    },
    async catalogMediaUrl(path) {
      const result = await admin2.storage.from("plmr-catalog-media").createSignedUrl(path, 300);
      if (!result.error) return result.data.signedUrl;
      const error = result.error;
      if (Number(error.statusCode) === 404 || /^object not found$/i.test(error.message)) return null;
      throw Error("CATALOG_STORAGE_UNAVAILABLE");
    },
    async catalogMediaUrls(paths) {
      if (!paths.length) return [];
      const rows = checked(await admin2.storage.from("plmr-catalog-media").createSignedUrls(paths, 300));
      return paths.map((path) => {
        const row = rows.find((item) => item.path === path);
        if (row?.signedUrl) return row.signedUrl;
        if (row?.error && /not found|404/i.test(row.error)) return null;
        throw Error("CATALOG_STORAGE_UNAVAILABLE");
      });
    },
    quoteBranding: {
      async store(cid, bytes, mime) {
        const hash2 = createHash("sha256").update(bytes).digest("hex");
        const bucket = admin2.storage.from(quoteBrandBucket);
        const path = cid + "/" + hash2;
        const existing = await bucket.exists(path);
        if (existing.data === true) return hash2;
        const result = await bucket.upload(path, bytes, { contentType: mime, upsert: false, cacheControl: "60" });
        if (result.error && !/already exists|duplicate/i.test(result.error.message)) checked(result);
        return hash2;
      },
      async url(cid, hash2) {
        return checked(await admin2.storage.from(quoteBrandBucket).createSignedUrl(cid + "/" + hash2, 60)).signedUrl;
      }
    },
    async directory() {
      const [profiles, organizations] = await Promise.all([
        allRows("profiles", "id,organization_id,full_name,username,email,role,is_active,user_code,created_at,updated_at"),
        allRows("organizations", "id,name,company_code,is_active,license_start,license_end,max_users,created_at,updated_at")
      ]);
      const users = profiles.map((p, index) => {
        const names = String(p.full_name || p.username || "").split(" "), firstName = names.shift() || "", lastName = names.join(" ");
        return { userId: p.id, firstName, lastName, fullName: p.full_name || p.username || "", username: p.username || "", email: p.email || "", roleId: p.role === "system_admin" ? "SYSTEM_ADMIN" : "VIEWER", status: p.is_active ? "ACTIVE" : "INACTIVE", projectCodeUserNo: Number(p.user_code) || index + 1, memberships: p.organization_id && p.role !== "system_admin" ? [{ companyId: p.organization_id, roleId: p.role === "company_admin" ? "COMPANY_ADMIN" : "DESIGNER", status: p.is_active ? "ACTIVE" : "INACTIVE", permissionOverrides: {}, dataScopeOverrides: {} }] : [], permissionOverrides: {}, dataScopeOverrides: {}, createdAt: p.created_at, updatedAt: p.updated_at, createdBy: "CLOUD_IMPORT", updatedBy: "CLOUD_IMPORT" };
      });
      const companies = organizations.map((o) => ({ companyId: o.id, code: o.company_code || "PLMR", status: o.is_active ? "ACTIVE" : "INACTIVE", licenseStart: o.license_start || "2000-01-01", licenseEnd: o.license_end || "2099-12-31", userLimit: o.max_users, settings: { companyName: o.name, documentBrandName: o.name, address: "", phone: "", email: "", website: "", defaultLanguage: "TR", defaultCurrency: "TRY" }, createdAt: o.created_at, updatedAt: o.updated_at }));
      return { users, companies };
    },
    async get(scope, key) {
      if (scope.endsWith(":drawing.projects"))
        return checked(await admin2.rpc("plmr_v44_drawing_get", { p_scope: scope, p_key: key })) || { key, value: null, version: 0 };
      if (key === "plmr.project.index.v11") {
        const split = await this.splitIndex(scope);
        if (split) return { key, version: split.version, value: JSON.stringify(split.projects.map((row) => row.value)) };
      }
      return checked(await admin2.from("plmr_v12_records").select("key,value,version").eq("scope", scope).eq("key", key).maybeSingle()) || { key, value: null, version: 0 };
    },
    async getMany(scope, keys) {
      return checked(await admin2.from("plmr_v12_records").select("key,value,version").eq("scope", scope).in("key", keys));
    },
    async header(scope, key) {
      return (await projectPage(scope, "header", false, false, key, null, 1))[0] ?? { key, value: null, version: 0 };
    },
    async overview(scope, key) {
      return (await projectPage(scope, "overview", false, false, key, null, 1))[0] ?? { key, value: null, version: 0 };
    },
    async projectRowsForKeys(scope, kind, commercial, legacy, keys) {
      const rows = checked(await admin2.rpc("plmr_v45_project_rows_for_keys", {
        p_scope: scope,
        p_kind: kind,
        p_commercial: commercial,
        p_legacy: legacy,
        p_keys: keys
      }));
      return rows.map((row) => ({ ...row, version: Number(row.version) }));
    },
    async unlinkedProjectHeaders(companyId2) {
      const result = [];
      let after = null;
      for (; ; ) {
        const rows = checked(await admin2.rpc("plmr_v45_unlinked_headers", { p_company: companyId2, p_after: after }));
        result.push(...rows.map((row) => ({ ...row, version: Number(row.version) })));
        if (rows.length < 128) return result;
        after = rows.at(-1).key;
      }
    },
    async projectRows(scope, kind, commercial = false, legacy = false) {
      const pageSize = 128, result = [];
      let cursor = null;
      for (; ; ) {
        const rows = await projectPage(scope, kind, commercial, legacy, null, cursor, pageSize);
        result.push(...rows);
        if (rows.length < pageSize) return result;
        cursor = rows.at(-1).key;
      }
    },
    async projectPackage(scope, code, revision) {
      return checked(await admin2.rpc("plmr_v41_index_package", { p_scope: scope, p_code: code, p_revision: revision }));
    },
    async projectIndexState(scope, ids) {
      return checked(await admin2.rpc("plmr_v41_legacy_index_state", { p_scope: scope, p_ids: ids }));
    },
    async patchProjectIndex(scope, expected, upserts, remove) {
      return Number(checked(await admin2.rpc("plmr_v40_project_index_patch", {
        p_scope: scope,
        p_expected: expected,
        p_upserts: upserts,
        p_remove: remove
      })));
    },
    async splitIndex(scope, compact = false) {
      return checked(await admin2.rpc(compact ? "plmr_v46_compact_index" : "plmr_v44_index_snapshot", { p_scope: scope }));
    },
    async productionPage(company2, actor2, projects, operations2, technical, query, offset, limit, includeItems, id, facets) {
      return checked(await admin2.rpc("plmr_v46_production_page", {
        p_company: company2,
        p_actor: actor2,
        p_projects: projects,
        p_operations: operations2,
        p_technical: technical,
        p_query: query,
        p_offset: offset,
        p_limit: limit,
        p_include_items: includeItems,
        p_id: id,
        p_facets: facets
      }));
    },
    async masterProject(scope, id) {
      return checked(await admin2.rpc("plmr_v44_index_project", { p_scope: scope, p_code: "", p_id: id }));
    },
    async masterOwner(scope, reference) {
      return checked(await admin2.rpc("plmr_v44_index_owner", { p_scope: scope, p_reference: reference }));
    },
    async masterState(scope, ids, actor2, operation, details) {
      return checked(await admin2.rpc("plmr_v44_index_state", { p_scope: scope, p_ids: ids, p_actor: actor2, p_operation: operation, p_details: details }));
    },
    async masterCommit(scope, actor2, operation, entries) {
      return checked(await admin2.rpc("plmr_v44_index_commit", { p_scope: scope, p_actor: actor2, p_operation: operation, p_entries: entries }));
    },
    async splitIndexState(scope, ids, actor2, operation) {
      return checked(await admin2.rpc("plmr_v41_index_state", { p_scope: scope, p_ids: ids, p_actor: actor2, p_operation: operation }));
    },
    async splitIndexCommit(scope, actor2, operation, entries) {
      return checked(await admin2.rpc("plmr_v41_index_commit", { p_scope: scope, p_actor: actor2, p_operation: operation, p_entries: entries }));
    },
    async drawingWriteState(scope, key, actor2, operation, inserting, retain = []) {
      return checked(await admin2.rpc("plmr_v44_drawing_state", {
        p_scope: scope,
        p_key: key,
        p_actor: actor2,
        p_operation: operation,
        p_insert: inserting,
        p_ignore: retain
      }));
    },
    async drawingCommit(scope, key, actor2, operation, expected, value) {
      return checked(await admin2.rpc("plmr_v41_drawing_commit", {
        p_scope: scope,
        p_key: key,
        p_actor: actor2,
        p_operation: operation,
        p_expected: expected,
        p_value: value
      }));
    },
    async compactDrawingCommit(scope, key, actor2, operation, expected, value, retain) {
      return checked(await admin2.rpc("plmr_v44_drawing_commit", {
        p_scope: scope,
        p_key: key,
        p_actor: actor2,
        p_operation: operation,
        p_expected: expected,
        p_value: value,
        p_retained: retain
      }));
    },
    async list(scope, excludeKey, excludeAlso) {
      if (scope.endsWith(":drawing.projects")) {
        const rows = [];
        let after = null;
        for (; ; ) {
          const page = checked(await admin2.rpc("plmr_v44_drawing_page", { p_scope: scope, p_after: after }));
          rows.push(...page);
          if (page.length < 24) return rows;
          after = page.at(-1).key;
        }
      }
      return await allRows("plmr_v12_records", "key,value,version", scope, excludeKey, excludeAlso);
    },
    async cas(scope, key, value, expected, versionOnly = false) {
      const args = { p_scope: scope, p_key: key, p_value: value, p_expected: expected };
      if (!versionOnly) return checked(await admin2.rpc("plmr_v12_cas", args));
      const version = checked(await admin2.rpc(scope.endsWith(":drawing.projects") ? "plmr_v44_drawing_cas" : "plmr_v40_cas_version", args));
      return { key, value: null, version: Number(version) };
    },
    async deleteMany(scope, items) {
      checked(await admin2.rpc("plmr_v12_delete_many", { p_scope: scope, p_items: items }));
    },
    async appendAudit(scope, key, events) {
      return checked(await admin2.rpc("plmr_v12_append_audit", { p_scope: scope, p_key: key, p_events: events }));
    },
    async sequence(scope, key, minimum) {
      return checked(await admin2.rpc("plmr_v12_sequence", { p_scope: scope, p_key: key, p_minimum: minimum }));
    },
    async setPin(actor2, user2, pin) {
      const mapping = checked(await admin2.from("plmr_v12_records").select("key").eq("scope", "platform").eq("value", JSON.stringify(user2.userId)).like("key", "@auth:%").maybeSingle()), nativeId = mapping?.key.slice(6) || user2.userId;
      const existing = checked(await admin2.from("profiles").select("id,username").eq("id", nativeId).maybeSingle());
      let body;
      if (existing) {
        if (existing.username !== user2.username.toLowerCase())
          checked(await admin2.from("profiles").update({ username: user2.username.toLowerCase() }).eq("id", nativeId));
        body = { action: "set_pin", userId: nativeId, pin };
      } else {
        if (user2.roleId === "SYSTEM_ADMIN") {
          if (actor2.profile.role !== "system_admin")
            throw Error("System Admin gerekli.");
          const pepper = Deno.env.get("PLMR_PIN_PEPPER");
          if (!pepper)
            throw Error("PIN_PEPPER_MISSING");
          const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`${pepper}|${user2.username.toLowerCase()}|${pin}`));
          const password = "P!" + Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join(""), email = `plmr.${crypto.randomUUID().replaceAll("-", "")}@auth.pulumur.app`;
          const created = checked(await admin2.auth.admin.createUser({ email, password, email_confirm: true }));
          if (!created.user)
            throw Error("Bulut hesab\u0131 olu\u015Fturulamad\u0131.");
          try {
            checked(await admin2.from("profiles").upsert({ id: created.user.id, username: user2.username.toLowerCase(), email, full_name: user2.fullName, role: "system_admin", organization_id: null, is_active: user2.status === "ACTIVE", user_code: String(user2.projectCodeUserNo).padStart(4, "0") }));
            await this.cas("platform", "@auth:" + created.user.id, user2.userId, 0);
          } catch (error) {
            const cleanup = await admin2.auth.admin.deleteUser(created.user.id);
            if (cleanup.error)
              throw Error("Yeni hesap kurulumu tamamlanamad\u0131; y\xF6netimden kontrol edin.");
            throw error;
          }
          return;
        }
        const member = user2.memberships[0];
        if (!member)
          throw Error("Firma se\xE7in.");
        body = { action: "create", organizationId: member.companyId, fullName: user2.fullName, username: user2.username.toLowerCase(), pin, role: member.roleId === "COMPANY_ADMIN" ? "company_admin" : "designer", language: "tr" };
      }
      const response = await fetch(url + "/functions/v1/admin-users", { method: "POST", headers: { Authorization: "Bearer " + token, apikey: anon, "Content-Type": "application/json" }, body: JSON.stringify(body) }), result = await response.json();
      if (!response.ok)
        throw Error(result.error || "PIN belirlenemedi.");
      if (!existing) {
        const id = result.user?.id;
        if (!id)
          throw Error("Bulut hesab\u0131 yan\u0131t\u0131 ge\xE7ersiz.");
        await this.cas("platform", "@auth:" + id, user2.userId, 0);
      }
    },
    async shareGet(id) {
      const result = checked(await admin2.from("plmr_v12_presentations").select("presentation,expires_at").eq("id", id).gt("expires_at", (/* @__PURE__ */ new Date()).toISOString()).maybeSingle());
      return result ? { presentation: import_v22_animation_core.default.validate(result.presentation, import_v15_core.default), expiresAt: result.expires_at } : null;
    },
    async sharePut(owner, cid, presentation) {
      const count = await admin2.from("plmr_v12_presentations").select("id", { count: "exact", head: true }).eq("owner_id", owner.id).gte("created_at", new Date(Date.now() - 36e5).toISOString());
      if (count.error)
        throw Error(count.error.message);
      if ((count.count || 0) >= 100)
        throw Error("Payla\u015F\u0131m s\u0131n\u0131r\u0131na ula\u015F\u0131ld\u0131. Daha sonra tekrar deneyin.");
      const id = crypto.randomUUID().replace(/-/g, ""), expiresAt = new Date(Date.now() + 30 * 864e5).toISOString();
      checked(await admin2.from("plmr_v12_presentations").insert({ id, owner_id: owner.id, company_id: cid, presentation, expires_at: expiresAt }));
      return { id, expiresAt };
    }
  };
  return createCloudHandler(backend, (value) => import_v22_animation_core.default.validate(value, import_v15_core.default))(request);
});

