# Supabase salt okunur inceleme

Kaynak: kullanıcının bağlı Supabase projesi `PLMR-FinalProcess`. Canlı yazma, migration, kullanıcı/PIN değiştirme, yeni ürün kaydı ve deploy yapılmadı. Müşteri/proje içerikleri test fixture'ı olarak okunmadı.

Alınan gerçek fonksiyonlar: `plmr-platform` deploy sürümü 54, `admin-users` 18, `plmr-bootstrap` 7. `supabase-deployed/SOURCE_PROVENANCE.json` hash ve köken kaydıdır. Platform dosyası, yayımdaki bundle snapshot'ıdır; eksiksiz geliştirme kaynak ağacı veya yeniden derlenmiş yeni sunucu sürümü diye sunulmaz.

- 17 public tablonun RLS'si açık; public policy kaydı yok. Bu tek başına güvenlik hatası veya tam güvenlik onayı değildir. İş erişimi platform Edge/RPC katmanındadır.
- `plmr-platform`, token'ı Auth `getUser` ile ve oturumu `plmr_v49_current_session_profile` RPC'siyle doğrular. Firma üyeliği, rol yetkisi, kayıt sahipliği ve lisans yazma sınırı ayrıca kontrol edilir.
- Kaynakla çalışan, sentetik backend kullanan 5 senaryo: fiziksel değişim/görünürlük fingerprint ayrımı, eksik ticari kimliğin reddi, başka firma kaydına erişimin kayıt okunmadan reddi, Viewer yazmasının reddi ve pasif hesabın reddi. Gerçek oturumlu Supabase E2E testi değildir.
- Kayıt backend'i expected version ve operation ID'yi mevcut `plmr_v44_drawing_commit` / ilgili RPC'lere geçirir. Yeni bağımsız kayıt tablosu veya client-only yetki sistemi eklenmedi. Gerçek eşzamanlı yazma deneyi çalıştırılmadı.
- `admin-users` PIN'i 4 rakam olarak sınırlar; rate limit sunucu RPC'sindedir, parola pepper ile türetilir, kullanıcı/şirket etkinliği ve mevcut oturum kontrol edilir. PIN deneme, kullanıcı oluşturma/değiştirme ve şirketler arası gerçek kimlikli test çalıştırılmadı. Eşzamanlı kullanıcı oluşturma/koltuk sınırı ayrıca doğrulanmalı.
- `plmr-bootstrap` 410 BOOTSTRAP_DISABLED döndürüyor; yeniden etkinleştirilmedi.

Güncel Supabase advisor çıktısında 17 adet RLS/policy bilgilendirmesi, oturum doğrulama amaçlı iki SECURITY DEFINER fonksiyon için authenticated execute uyarısı ve sızmış parola koruması uyarısı görüldü. Bu kurallar kaynak incelemesi olmadan değiştirilmedi.

İlgili açıklamalar:

- [RLS açık, policy yok](https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy)
- [Authenticated SECURITY DEFINER execute](https://supabase.com/docs/guides/database/database-linter?lint=0029_authenticated_security_definer_function_executable)
- [Parola koruması](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection)

Yeni ticari Pergola anahtarları, yayımdaki statik `finalIdentity` çözümleyicisinde bulunmadığı için yerel sunucu mantığı testinde açık hata veriyor. Antero UUID'sine dönüştürülmedi. İstemci ve sunucu merkezi ürün/fiyat/üretim sözleşmesi tamamlanmadan production entegrasyonu tamamlanmış değildir.

## Ek kaynak arşivi araması

Storage şeması ve bucket/nesne toplamları salt okunur kontrol edildi: 5 özel bucket, toplam 28 nesne. ZIP/TAR/GZ/TSX/TS/JSX/JS/MAP uzantılarına göre kaynak adayı 0. Müşteri dosyalarının içeriği okunmadı. Bu kontrol, yayımdaki Edge Function kaynakları dışında tam V51 istemci geliştirme ağacı sağlamadı; bütün olası dosya içeriklerinde kaynak olmadığı iddia edilmez.
