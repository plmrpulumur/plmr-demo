/* Precise technical card from the application's actual assembly; no separate CAD math. */
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=__dirname,c=vm.createContext({console});c.window=c;c.parent=c;
const files=['core/pergolaDefinition.js','core/productPresentation.js','src/appLimits.js','ui/inputLimitPolicy.js','core/multiPositionRules.js','blocks/filteredBlocks.js','src/peri01ExcelBridge.js','src/peri01Geometry.js','core/projectModel.js','shared/ral-colors.js','shared/v34/v15-core.js','shared/technical2d-export.js','shared/final-project-date.js','shared/v53-titleblock.js','shared/v34/final-company-logo.js','shared/v34/default-drawing-logo.js','source/pergola-dimensions.js','source/pergola-document.js','modules/p3dv/products/pergo-rise/pergo-rise-derived-geometry.js','source/pergola-colors.js','source/pergola-parts.js','source/pergola-mounting.js','source/pergola-model.js','source/pergola-variant-geometry.js','source/pergola-variants.js','source/pergola-native-details.js','source/pergola-orthographic.js','source/pergola-layouts.js','source/pergola-product-picker.js'];
for(const name of files){const p=path.join(root,name.startsWith('source/')||name.startsWith('shared/')?name:'peri01/'+name);vm.runInContext(fs.readFileSync(p,'utf8'),c,{filename:name});}
const type=process.argv[2]||'Curve-Quad-Wing';
if(!['Lean-Quad','Curve-Quad-Wing'].includes(type))throw Error('Unsupported generated card');
c.cardType=type;
const iso=vm.runInContext('PLMRPergolaProductPicker.iso(PLMRPergolaLayouts.cards[0].values,PLMRPergolaDefinition.normalize({pergolaType:cardType,railType:cardType.startsWith("Curve")?"Curved":"Linear"}))',c);
const inner=iso.slice(iso.indexOf('>')+1,iso.lastIndexOf('</svg>'));
const svg='<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 1024 1024" role="img" aria-label="'+type+', orta çelik kiriş ve dikmeler"><rect width="1024" height="1024" fill="#fff"/><rect x="30" y="30" width="964" height="964" rx="52" fill="#fbfdfe" stroke="#d9e2e9" stroke-width="2"/><g transform="translate(64 140) scale(3.2)">'+inner+'</g><rect x="482" y="846" width="60" height="8" rx="4" fill="#12a7aa"/><text x="512" y="938" text-anchor="middle" font-family="Arial, sans-serif" font-size="'+(type.length>12?51:64)+'" font-weight="700" fill="#182a49">'+type+'</text></svg>\n';
fs.writeFileSync(path.join(root,'source/assets/pergola-types/'+type.toLowerCase()+'.svg'),svg);
console.log('Generated '+type+' card from native steel assembly');
