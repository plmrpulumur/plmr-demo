/* V34 zone identity/filter contract projected from native pergola openings. */
(function(root){
  'use strict';
  const clone=v=>JSON.parse(JSON.stringify(v));
  function project(zones,scene){
    const spec={pozNo:1,zoneRegistry:clone(scene.zoneRegistry||{}),nextZoneNumber:scene.nextZoneNumber||1,sceneEditor:{bioCodes:{}}};
    const owners=[{id:'roof-main',spec}];
    const list=zones.map(z=>root.PLMRV16Core.assignZone({...z,moduleIndex:z.systemIndex||0,group:z.isRoofZone?'roof':z.face},spec,'roof-main',owners));
    return {list:list.map(z=>({...z,key:root.PLMRV11Zones.key(z,'roof-main')})),registry:spec.zoneRegistry,next:spec.nextZoneNumber};
  }
  function list(){const d=root.PLMRPergolaNative.drawing();if(!d)return [];return root.PLMRJustPergola.fromDrawing(d,'white').zones;}
  const state=()=>root.PLMRPergolaScene.read();
  function update(fn){root.PLMRPergolaScene.change(n=>{n.zoneFilters??=root.PLMRV11Zones.defaults();fn(n);});}
  function generate(){
    const current=state(),named=project(list(),current);
    update(n=>{n.zonesGenerated=true;n.zonesVisible=true;n.zoneRegistry=named.registry;n.nextZoneNumber=named.next;});
  }
  function visible(){const s=state();return s.zonesGenerated===true&&s.zonesVisible!==false;}
  function filters(){return state().zoneFilters||root.PLMRV11Zones.defaults();}
  function allowed(z){return visible()&&root.PLMRV11Zones.allowed(filters(),z,z.owner);}
  const api={list,filters,visible,generate,allowed,
    setVisible:value=>update(n=>n.zonesVisible=!!value),
    setZone:(key,value)=>update(n=>{n.zoneFilters.ids[key]=!!value;n.zonesVisible=true;}),
    setBatch:(keys,value)=>update(n=>{for(const key of keys)n.zoneFilters.ids[key]=!!value;n.zonesVisible=true;}),
    setAll:value=>update(n=>{n.zoneFilters=root.PLMRV11Zones.defaults();for(const key of Object.keys(n.zoneFilters.groups))n.zoneFilters.groups[key]=!!value;n.zonesVisible=!!value;})};
  root.PLMRZones=Object.freeze(api);
  function node(tag,className,text){const el=document.createElement(tag);if(className)el.className=className;if(text!==undefined)el.textContent=text;return el;}
function buildZoneMenu(menu){const open=new Set([...menu.querySelectorAll('details[open]')].map(e=>e.dataset.refs)),api=window.PLMRZones,zones=api.list(),filters=api.filters(),enabled=z=>api.visible()&&window.PLMRV11Zones.allowed(filters,z,z.owner);menu.replaceChildren();const checkbox=(parent,title,list,key)=>{const row=node('label','rr-v11-filter-row'),input=node('input');input.type='checkbox';input.checked=list.length>0&&list.every(enabled);input.indeterminate=list.some(enabled)&&!list.every(enabled);input.disabled=!list.length;input.dataset.zoneScope=key;input.onchange=()=>{if(key==='all')api.setAll(input.checked);else window.PLMRZones.setBatch(list.map(z=>z.key),input.checked);buildZoneMenu(menu);};row.append(input,node('span',null,title));parent.append(row);};checkbox(menu,'Tüm Zone Alanları',zones,'all');checkbox(menu,'Tavan Alanları',zones.filter(z=>z.isRoofZone),'roof');checkbox(menu,'Cephe Alanları',zones.filter(z=>!z.isRoofZone),'facade');const search=node('input');search.type='search';search.placeholder='Zone kodu ara…';search.setAttribute('aria-label','Zone kodu filtrele');menu.append(search);const groups=new Map();for(const z of zones){const key=z.positionRefs?.join('*')||String(z.label).replace(/\s*-\s*\d+$/,'');if(!groups.has(key))groups.set(key,[]);groups.get(key).push(z);}for(const [refs,list]of groups){const details=node('details');details.dataset.refs=refs;details.open=open.has(refs);details.append(node('summary',null,'Poz '+refs.replace(/^Poz\s*/,'')));checkbox(details,'Bu Pozun Tüm Alanları',list,'position:'+refs);for(const z of list){const row=node('label','rr-v11-filter-row rr-v16-zone-row'),input=node('input');input.type='checkbox';input.checked=enabled(z);input.dataset.zoneKey=z.key;input.onchange=()=>api.setZone(z.key,input.checked);row.dataset.search=(z.label+(z.isRoofZone?' tavan':' cephe')).toLocaleLowerCase('tr');row.append(input,node('span',null,z.label+' · '+(z.isRoofZone?'Tavan':'Cephe')));details.append(row);}menu.append(details);}search.oninput=()=>{const text=search.value.toLocaleLowerCase('tr');for(const details of menu.querySelectorAll('details')){let found=false;for(const row of details.querySelectorAll('[data-search]')){row.hidden=!row.dataset.search.includes(text);found=found||!row.hidden;}details.hidden=!found;if(text&&found)details.open=true;}};}
  function identities(drawing){
    const scene=state();if(!scene.zonesGenerated)return null;
    const named=project(root.PLMRJustPergola.fromDrawing(drawing,'white').zones,scene);
    if(JSON.stringify(named.registry)===JSON.stringify(scene.zoneRegistry))return null;
    return {...scene,zoneRegistry:named.registry,nextZoneNumber:named.next};
  }
  root.PLMRPergolaZones=Object.freeze({project,buildZoneMenu,allowed,generate,identities});
})(window);
