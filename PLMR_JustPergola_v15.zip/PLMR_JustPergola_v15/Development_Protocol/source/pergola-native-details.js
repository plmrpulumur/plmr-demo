/* Native technical entities, never bounding-box fitted accessory drawings. */
(function(root){
  'use strict';
  const clone=value=>{
    const result=JSON.parse(JSON.stringify(value));
    // Native renderer attaches these as non-enumerable so export JSON stays
    // compact. Projection must preserve them across view-specific cloning.
    if(value?.type==='dimension')for(const key of ['dimensionId','hiddenDimension'])
      if(value[key]!=null)result[key]=value[key];
    return result;
  };
  function move(entity,dx,dy){
    const e=clone(entity),G=root.PulumurGeometry;G.moveEntityX(e,dx);G.moveEntityY(e,dy);
    if(e.arc){e.arc.x+=dx;e.arc.y+=dy;}return e;
  }
  function mirrorX(entity,axis){
    const e=root.PulumurGeometry.mirrorEntityX(clone(entity),axis);
    if(e.arc){const a=e.arc;e.arc={...a,x:2*axis-a.x,start:(180-a.end+360)%360,end:(180-a.start+360)%360};}
    return e;
  }
  function mirrorY(entity,axis){
    const e=clone(entity),my=y=>2*axis-y;
    if(e.points)e.points=e.points.map(([x,y])=>[x,my(y)]).reverse();
    if(Number.isFinite(e.y))e.y=my(e.y)-(e.type==='interaction'?(e.h||0):0);
    for(const k of ['y1','y2'])if(Number.isFinite(e[k]))e[k]=my(e[k]);
    if(e.type==='insert'){e.rotation=(180-(Number(e.rotation)||0)+360)%360;e.mirrorX=!e.mirrorX;}
    if(e.type==='text'||e.type==='mtext')e.rotation=0;
    if(e.type==='dimension'){
      for(const k of ['p1','p2','dimLine','text'])if(e[k])e[k].y=my(e[k].y);
      e.graphics=(e.graphics||[]).map(g=>mirrorY(g,axis));
    }
    if(e.arc){const a=e.arc;e.arc={...a,y:my(a.y),start:(360-a.end)%360,end:(360-a.start)%360};}
    return e;
  }
  function clipX(entity,left,right){
    const e=clone(entity);
    if(!e.points)return e;
    let points=e.points;
    for(const [boundary,sign]of [[left,1],[right,-1]]){
      const out=[];
      for(let i=0;i<points.length;i++){
        const a=points[i],b=points[(i+1)%points.length],da=sign*(a[0]-boundary),db=sign*(b[0]-boundary);
        if(da>=-1e-8)out.push(a);
        if(da*db<0){const t=(boundary-a[0])/(b[0]-a[0]);out.push([boundary,a[1]+t*(b[1]-a[1])]);}
      }points=out;
    }
    if(points.length<3)return null;e.points=points;return e;
  }
  function bounds(entities,blocks){
    return root.PulumurGeometry.bounds(entities.filter(e=>e.type!=='interaction'&&!e.layoutNeutral),blocks);
  }
  function stamp(entities,view,systemIndex){
    for(const e of entities){e.viewType=view;e.projectionView=view.toLowerCase()+(systemIndex==null?'':'-'+systemIndex);if(systemIndex!=null)e.systemIndex=systemIndex;e.nativeDetail=true;}
    return entities;
  }
  root.PLMRPergolaNativeDetails=Object.freeze({clone,move,mirrorX,mirrorY,clipX,bounds,stamp});
})(window);
