/* Two-stage product/placement draft in the existing layout popup. */
(function(root){
  'use strict';
  const D=root.PLMRPergolaDefinition,V=root.PLMRPergolaVariantGeometry;
  function iso(values,configuration){
    const raw={...root.PulumurGeometry.SAMPLE_INPUT,...values,rayCount:'',postCount:'',glassTrack:'HAYIR',triangleJoinery:'HAYIR',parapet:'HAYIR',__pergola:configuration};
    const drawing=root.PulumurGeometry.buildDrawing(raw),model=root.PLMRJustPergola.fromDrawing(drawing,'white',raw);
    const project=([x,y,z])=>[x-z*.65,-y+z*.32+x*.16],shapes=[];
    for(const c of model.components){
      const points=V.hull(V.vertices(c).map(project));if(points.length<3)continue;
      const wall=c.kind==='rear-wall',sheet=c.kind==='trapez-sheet';
      const steel=['rear-steel-beam','rear-steel-post'].includes(c.kind);
      shapes.push({points,order:wall?0:sheet?2:c.kind==='rail'||c.kind==='suspension-stay'?5:1,fill:wall?'#e1e8ee':sheet?'#c6d5df':steel?'#667685':'#dce5ec',stroke:wall?'#bccbd5':steel?'#465462':'#748f9e'});
    }
    for(const p of model.positions)for(const roof of p.roofs){
      const path=roof.trajectory||V.table([roof.start,V.add(roof.start,[0,Math.sin(roof.angle)*roof.length,Math.cos(roof.angle)*roof.length])]);
      const points=[...path.points.map(point=>project([point[0]-roof.width/2,point[1]-138,point[2]])),...path.points.slice().reverse().map(point=>project([point[0]+roof.width/2,point[1]-138,point[2]]))];
      shapes.push({points,order:3,fill:'#14989b',stroke:'#087e83'});
    }
    const all=shapes.flatMap(s=>s.points),min=[0,1].map(i=>Math.min(...all.map(p=>p[i]))),max=[0,1].map(i=>Math.max(...all.map(p=>p[i]))),scale=Math.min(250/(max[0]-min[0]),125/(max[1]-min[1]));
    const paths=shapes.sort((a,b)=>a.order-b.order).map(s=>'<polygon points="'+s.points.map(p=>[(p[0]-min[0])*scale+15+(250-(max[0]-min[0])*scale)/2,(p[1]-min[1])*scale+8].join(',')).join(' ')+'" fill="'+s.fill+'" stroke="'+s.stroke+'" stroke-width=".8"/>').join('');
    return '<svg viewBox="0 0 280 145" role="img" aria-label="'+configuration.derivedModelName+' izometrik yerleşimi">'+paths+'</svg>';
  }
  function open(current,choose){
    const initial=D.normalize(current),back=document.createElement('div');back.id='rrV14LayoutDialog';back.className='rr-settings-backdrop pergola-settings';
    back.innerHTML='<section class="rr-settings-dialog pergola-product-dialog" role="dialog" aria-modal="true" aria-label="Modül yerleşim planları"><header class="rr-settings-head"><strong>MODÜL · YERLEŞİM PLANI</strong><button aria-label="Kapat">×</button></header><div class="rr-settings-body"><div class="pergola-type-filters"><label>Seri<select id="pergolaSeries"></select></label><label>Ray Tipi<select id="pergolaRailType"><option>Linear</option><option>Curved</option></select></label></div><h3>1 · Ürün tipini seçin</h3><div id="pergolaTypeCards" class="pergola-type-grid"></div><section id="pergolaPlacementStage" hidden><h3 id="pergolaPlacementTitle"></h3><div class="rr-v14-layout-grid"></div></section></div></section>';
    const series=back.querySelector('#pergolaSeries'),rail=back.querySelector('#pergolaRailType'),types=back.querySelector('#pergolaTypeCards'),stage=back.querySelector('#pergolaPlacementStage');
    for(const name of D.SERIES)series.add(new Option(name,name));series.value=initial.series;rail.value=initial.railType;let selected=null;
    function close(){back.remove();}
    function configuration(){return D.normalize({...initial,series:series.value,railType:rail.value,pergolaType:selected});}
    function placements(){
      stage.hidden=!selected;if(!selected)return;
      const config=configuration(),grid=stage.querySelector('.rr-v14-layout-grid');grid.replaceChildren();
      back.querySelector('#pergolaPlacementTitle').textContent='2 · '+config.derivedModelName+' yerleşimini seçin';
      for(const card of root.PLMRPergolaLayouts.cards){
        const button=document.createElement('button');button.type='button';button.className='v33-tool light';button.dataset.layout=card.id;
        const thumb=document.createElement('div');thumb.className='rr-v14-layout-thumb';thumb.innerHTML=iso(card.values,config);
        const title=document.createElement('strong');title.textContent=card.title;const detail=document.createElement('small');detail.textContent=card.description+(config.pergolaType==='Curve-Quad-Wing'?' Orta çeliğin iki yüzüne bağlanan ayrı kavisli kanatlar; her kumaş kendi orta/arka ucunda toplanır.':config.pergolaType==='Curve-Quad'?' Açılım yarım kemer içindir; kumaş toplam kemeri geçerek arkada toplanır.':D.traits(config).double?' Açılım her kanat için uygulanır.':'');
        button.append(thumb,title,detail);button.onclick=()=>{close();choose(card.values,{...config,layoutPlanId:card.id});};grid.append(button);
      }
    }
    function renderTypes(){
      types.replaceChildren();for(const type of D.types(rail.value)){
        const button=document.createElement('button');button.type='button';button.dataset.pergolaType=type;button.className='pergola-type-card';button.setAttribute('aria-label',series.value+' '+type);button.setAttribute('aria-pressed',String(type===selected));
        const image=document.createElement('img');image.src='source/assets/pergola-types/'+type.toLowerCase()+(['Lean-Quad','Curve-Quad-Wing'].includes(type)?'.svg':'.webp');image.alt=type;image.width=512;image.height=512;image.decoding='async';button.append(image);
        button.onclick=()=>{selected=type;renderTypes();placements();};types.append(button);
      }
    }
    series.onchange=()=>{renderTypes();placements();};rail.onchange=()=>{selected=null;renderTypes();placements();};
    back.querySelector('header button').onclick=close;back.onmousedown=e=>{if(e.target===back)close();};back.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape')close();};
    (document.fullscreenElement||document.body).append(back);renderTypes();series.focus();
  }
  root.PLMRPergolaProductPicker=Object.freeze({open,iso});
})(window);
