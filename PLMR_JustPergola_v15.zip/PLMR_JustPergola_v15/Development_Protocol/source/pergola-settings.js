/* Form drafts use native option lists and native automatic ray/post calculations. */
(function(root){
  'use strict';
  const clone=v=>JSON.parse(JSON.stringify(v));
  function mount(back,legacy,apply,close){
    const native=root.PLMRPergolaNative,form=back.querySelector('form'),controls=new Map();
    const nativeOptions=native.options();
    const labels={systemCount:'Sistem Adedi',width:'Genişlik',opening:'Açılım',rearHeight:'Arka H',frontHeight:'Ön H · Oluk Altı',rayCount:'Ray Sayısı · Bir Sistem',postCount:'Dikme Sayısı · Tüm Sistem',parapet:'Parapet',parapetHeight:'Parapet H',glassTrack:'Yan Kayıt',glassRayBoundaryMode:'Ray Sınırlarını Daralt',triangleJoinery:'Üçgen Doğrama',waterStandard:'Standart Su Çıkışı',waterOutletPlacement:'Fi70 Boru Konumu',structureColor:'Sistem Rengi',fabric:'Kumaş',fabricProfiles:'Kumaş Profilleri',motor:'Motor',remote:'Kumanda',led:'LED',dimmer:'Dimmer',extras:'Ek Bilgiler / Notlar'};
    const sections=[['Sistem Ölçüleri (mm)',['systemCount','width','opening','rearHeight','frontHeight','rayCount','postCount']],['Opsiyonlar',['parapet','parapetHeight','glassTrack','glassRayBoundaryMode','triangleJoinery','waterStandard','waterOutletPlacement']],['Renk ve Donanım',['structureColor','fabric','fabricProfiles','motor','remote','led','dimmer']],['Ek Bilgiler',['extras']]];
    function row(group,id,label,input){
      const r=document.createElement('label');r.className='rr-v13-form-row';
      const caption=document.createElement('span');caption.textContent=label;
      input.id='pergolaSetting-'+id;input.name=id;r.append(caption,input);group.append(r);controls.set(id,input);return r;
    }
    function select(values,current){
      const el=document.createElement('select');
      for(const value of values){const pair=Array.isArray(value)?value:[value,value];el.add(new Option(pair[1],pair[0]));}
      if(current!=null&&![...el.options].some(o=>o.value===current))el.add(new Option(current,current));
      el.value=current??values[0];return el;
    }
    const groups=[];
    for(const [title,ids]of sections){
      const group=document.createElement('fieldset'),legend=document.createElement('legend');legend.textContent=title;group.append(legend);groups.push(group);
      for(const id of ids){
        const original=document.getElementById(id),value=legacy.formData[id]??original?.value??'-';let input;
        if(id==='motor'||id==='fabric')input=select(nativeOptions.combos[id],value);
        else if(id==='remote')input=select(nativeOptions.remotes[legacy.formData.motor]||['-'],value);
        else if(id==='led'||id==='dimmer')input=select(['-','YES','NO'],value);
        else if(id==='glassRayBoundaryMode')input=select([['DARALT','EVET'],['DEGISTIRME','HAYIR']],value);
        else{input=original.cloneNode(true);input.value=value;input.hidden=false;for(const a of ['readonly','required','pattern'])input.removeAttribute(a);}
        row(group,id,labels[id],input);
      }
      form.append(group);
    }
    const definition=root.PLMRPergolaDefinition.traits(legacy.drawingState.pergolaConfiguration);
    const geometryGroup=document.createElement('fieldset'),geometryLegend=document.createElement('legend');geometryLegend.textContent='Ürün Geometrisi · '+definition.derivedModelName;geometryGroup.append(geometryLegend);groups[0].append(geometryGroup);
    back.querySelector('.rr-settings-head strong').textContent='PLMR | '+definition.derivedModelName;
    geometryGroup.className='pergola-geometry-group';
    for(const [id,label,visible]of [['curveRise','Kavis yüksekliği',definition.curved&&!definition.quad],['anchorRise','Askı üst kot farkı',definition.suspended||definition.wing],['stayDiameter','Askı borusu dış çapı',definition.suspended||definition.wing]]){
      if(!visible)continue;const input=document.createElement('input');input.type='number';input.min='1';input.step='1';input.value=String(definition.geometry[id]);row(geometryGroup,id,label+' (mm)',input);
    }
    const note=document.createElement('small');note.className='pergola-geometry-note';note.textContent=definition.quad&&definition.curved?'Sürekli kemer: orta teğet yataydır; kavis orta/uç kotlarından hesaplanır.':'Kavis ve askı değerleri düzenlenebilir çizim girdileridir.';geometryGroup.append(note);
    if(definition.suspended||definition.wing)controls.get('postCount').closest('label').hidden=true;
    if(definition.double){controls.get('opening').previousElementSibling.textContent='Bir kanat açılımı';controls.get('rearHeight').previousElementSibling.textContent='Orta / mahya kotu';}
    const sideGroup=document.createElement('fieldset'),sideLegend=document.createElement('legend');sideLegend.textContent='Yan Kayıt Yerleşimi';sideGroup.append(sideLegend);form.insertBefore(sideGroup,groups[2]);
    groups[3].className='pergola-extra-group';
    const side=legacy.drawingState.sideFeatureState,offsets=legacy.drawingState.glassTrackLengthOffsets;
    for(const [key,title]of [['left','Sol'],['right','Sağ']]){
      row(sideGroup,'track-'+key,title+' Yan Kayıt',select([['EVET','EVET'],['HAYIR','HAYIR']],side.glassTrack[key]?'EVET':'HAYIR'));
      const input=document.createElement('input');input.inputMode='decimal';input.value=String(offsets[key]||0);
      row(sideGroup,'track-length-'+key,title+' Kayıt Uzat / Kısalt (mm)',input);
    }
    row(groups[1],'sheet-enabled','Üst Trapez Sac',select([['EVET','EVET'],['HAYIR','HAYIR']],legacy.drawingState.trapezSheetEnabled===false?'HAYIR':'EVET'));
    row(groups[1],'rear-support','Arka Taşıyıcı',select([['wall','Duvar'],['steel','Çelik Taşıyıcı']],legacy.drawingState.rearSupport?.type||'wall'));
    if(definition.centralSteel){
      const support=controls.get('rear-support');support.value='steel';support.disabled=true;support.previousElementSibling.textContent='Orta Çelik Taşıyıcı';
    }
    if(definition.pergolaType==='Curve-Quad'){
      controls.get('opening').previousElementSibling.textContent='Yarım kemer açılımı';
      note.textContent='Kesintisiz kemer ve tek kumaş hattı. Kumaş orta noktadan geçerek arka uçta toplanır.';
    }
    if(definition.quad)controls.get('postCount').previousElementSibling.textContent='Bir dış cephede dikme sayısı';
    let rayManual=!!legacy.drawingState.manualInputFlags?.rayCount,postManual=!!legacy.drawingState.manualInputFlags?.postCount;
    function options(){
      const motor=controls.get('motor').value,remote=controls.get('remote'),previous=remote.value;
      remote.replaceChildren(...(nativeOptions.remotes[motor]||['-']).map(value=>new Option(value,value)));
      remote.value=[...remote.options].some(o=>o.value===previous)?previous:'-';
      controls.get('waterOutletPlacement').disabled=controls.get('waterStandard').value!=='HAYIR';
      controls.get('glassRayBoundaryMode').disabled=controls.get('glassTrack').value!=='EVET';
    }
    function auto(){
      const get=id=>controls.get(id).value;
      const independent=root.PulumurMultiPositionRules.parseIndependentWidthGroups(get('width'));
      if(independent.ok&&independent.independent)controls.get('systemCount').value=String(independent.totalPositionCount);
      const sideState=clone(side);sideState.glassTrack.left=get('track-left')==='EVET';sideState.glassTrack.right=get('track-right')==='EVET';
      let calculated;
      try{calculated=root.PulumurExcelBridge.autoRayPostCount(get('systemCount'),get('width'),get('frontHeight'),get('glassTrack'),get('glassRayBoundaryMode'),sideState);}
      catch{return;} // Partial text entry is validated by native commit, without mutating the model.
      if(!rayManual)controls.get('rayCount').value=calculated.rayText||'';
      if(!postManual)controls.get('postCount').value=String(root.PulumurExcelBridge.postCountFromRayText(get('rayCount'),get('systemCount'),get('width'),get('frontHeight'))??'');
    }
    controls.get('rayCount').oninput=()=>{rayManual=!!controls.get('rayCount').value.trim();auto();};
    controls.get('postCount').oninput=()=>{postManual=!!controls.get('postCount').value.trim();if(!postManual)auto();};
    controls.get('glassTrack').onchange=()=>{for(const key of ['left','right'])controls.get('track-'+key).value=controls.get('glassTrack').value;options();auto();};
    for(const key of ['left','right'])controls.get('track-'+key).onchange=()=>{controls.get('glassTrack').value=['left','right'].some(k=>controls.get('track-'+k).value==='EVET')?'EVET':'HAYIR';options();auto();};
    for(const key of ['systemCount','width','frontHeight','glassRayBoundaryMode'])controls.get(key).addEventListener('input',auto);
    controls.get('motor').addEventListener('change',options);controls.get('waterStandard').addEventListener('change',options);
    const error=document.createElement('p');error.className='pergola-settings-error';error.id='pergolaSettingsError';error.setAttribute('role','alert');form.append(error);
    const foot=document.createElement('footer');foot.className='rr-v13-footer';foot.innerHTML='<button type="button" id="pergolaCalculatorBtn">PLMR Calculator</button><span style="flex:1"></span><button type="button" id="pergolaSettingsCancel">Vazgeç</button><button type="submit" id="pergolaSettingsApply" class="primary">Uygula</button>';form.append(foot);
    foot.querySelector('#pergolaCalculatorBtn').onclick=native.openCalculator;foot.querySelector('#pergolaSettingsCancel').onclick=close;
    form.onsubmit=event=>{
      event.preventDefault();
      try{
        auto();const next=clone(legacy);
        for(const[id,input]of controls)if(!id.startsWith('track-')&&!['sheet-enabled','rear-support','curveRise','anchorRise','stayDiameter','modelName'].includes(id))next.formData[id]=input.value;
        next.drawingState.pergolaConfiguration=root.PLMRPergolaDefinition.normalize({...definition,geometry:{...definition.geometry,...Object.fromEntries(['curveRise','anchorRise','stayDiameter'].filter(k=>controls.has(k)).map(k=>[k,Number(controls.get(k).value)]))}});
        next.drawingState.trapezSheetEnabled=controls.get('sheet-enabled').value==='EVET';
        next.drawingState.rearSupport=root.PulumurGeometry.normalizeRearSupport({...next.drawingState.rearSupport,type:controls.get('rear-support').value});
        for(const key of ['left','right']){
          next.drawingState.sideFeatureState.glassTrack[key]=controls.get('track-'+key).value==='EVET';
          const value=Number(controls.get('track-length-'+key).value.replace(',','.'));
          if(!Number.isFinite(value))throw Error('Yan kayıt ofseti geçerli bir sayı olmalı.');
          next.drawingState.glassTrackLengthOffsets[key]=value;

        }
        next.drawingState.manualInputFlags={rayCount:rayManual,postCount:postManual};apply(next);
      }catch(e){error.textContent=e.message;}
    };
    options();auto();
  }
  root.PLMRPergolaSettings=Object.freeze({mount});
})(window);
