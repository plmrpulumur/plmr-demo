/* Pergola command adapter. Shared V34 tools own pointer behavior; native ProjectModel owns state/history. */
(function(root){
  'use strict';
  const clone=value=>JSON.parse(JSON.stringify(value));
  const defaults=()=>({schema:'plmr-pergola-scene-v1',pose:{x:0,y:0,z:0,angle:0},copies:[],wallEdits:{},
    templates:[],dimensionUnits:{mm:true,inch:false},dimensions:{main:true,intermediate:true,positions:true,total:true},presentation:{environment:'empty',floor:'none'},nextCopy:1});
  function read(){
    const saved=root.PulumurProjectState.getModel().workspaces.standalone.project;
    if(!saved)return defaults();
    if(saved.schema!=='plmr-pergola-scene-v1')throw Error('Bu çizimin sahne biçimi desteklenmiyor.');
    const out={...defaults(),...clone(saved)};
    root.PLMRRollingRoofSceneCore.pose(out.pose);
    if(!Array.isArray(out.copies)||out.copies.length>30)throw Error('Pergola kopya listesi geçersiz.');
    for(const c of out.copies){root.PLMRRollingRoofSceneCore.pose(c.pose);if(!c.input||!c.id)throw Error('Pergola kopyası eksik.');}
    return out;
  }
  function commit(next){read();root.PLMRPergolaNative.commitScene(next);}
  function change(mutator){const next=read();mutator(next);commit(next);}
  function snapshotInput(){return root.PulumurProjectModel.geometryInputFromModel(root.PulumurProjectState.getModel());}
  function project(input){return root.PLMRJustPergola.fromDrawing(root.PulumurGeometry.buildDrawing(input),'white',input);}
  function command(cmd){
    const next=read();
    if(cmd.type==='units'){
      next.dimensionUnits={...next.dimensionUnits,...cmd.units};
      if(!next.dimensionUnits.mm&&!next.dimensionUnits.inch)throw Error('En az bir ölçü birimi açık olmalı.');
    }else throw Error('Desteklenmeyen pergola komutu: '+cmd.type);
    commit(next);
  }
  function canonicalWalls(model,owner,pose){
    const out=[];
    for(const c of model.components.filter(c=>c.polygonXZ)){
      const points=c.polygonXZ,xs=points.map(p=>p[0]),zs=points.map(p=>p[1]);
      const x0=Math.min(...xs),x1=Math.max(...xs),z0=Math.min(...zs),z1=Math.max(...zs);
      // Native sloping solids retain their original renderer; the shared box editor handles rectangular solids.
      if(c.startHeight!=null&&Math.abs(c.startHeight-c.endHeight)>.01)continue;
      const side=c.parapetView==='side',width=side?z1-z0:x1-x0,depth=side?x1-x0:z1-z0;
      const height=c.topY-c.bottomY;if(!(width>0&&depth>0&&height>0))continue;
      const base=side?{origin:[x0,c.bottomY,z0],u:[0,0,1],v:[0,1,0],t:[1,0,0]}:
        {origin:[x0,c.bottomY,z0],u:[1,0,0],v:[0,1,0],t:[0,0,1]};
      const minZ=Math.min(...model.assembly.systems.map(s=>s.rearDatumZ)),maxZ=Math.max(...model.assembly.systems.map(s=>s.frontDatumZ));
      const sourceCenterZ=(minZ+maxZ)/2;
      base.origin[2]-=sourceCenterZ;
      const local=root.PLMRRollingRoofSceneCore.vector(base.origin,pose.angle);
      const frame={origin:[local[0]+pose.x,local[1]+pose.y,local[2]+pose.z],
        u:root.PLMRRollingRoofSceneCore.vector(base.u,pose.angle),v:base.v,t:root.PLMRRollingRoofSceneCore.vector(base.t,pose.angle)};
      const wall=root.PLMRRollingRoofSketchCore.createWall({width,height},owner+'|'+c.id,depth);
      out.push({...wall,frame,label:c.kind==='parapet'?'Parapet':'Arka duvar',sourceComponent:c.id,sourceOwner:owner,sourceCenterZ,sourcePose:clone(pose),appearance:model.wallAppearance||'white',nativeComponent:clone(c)});
    }
    return out;
  }
  root.PLMRPergolaScene=Object.freeze({read,change,command,snapshotInput,project,canonicalWalls});
})(window);
