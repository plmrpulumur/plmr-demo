/* Shared physical contact constraints. Millimetres, derived data only; no editor state. */
(function(root){
  'use strict';
  const clone=x=>JSON.parse(JSON.stringify(x));
  function resolve(model){
    const G=root.PLMRPergolaVariantGeometry,{add,sub,mul,norm}=G,K=root.PulumurGeometry.K;
    const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
    const parts=model.components.map(clone),systems=model.assembly.systems;
    const pathOf=c=>c.trajectory||G.table([c.start,c.end]);
    function meshFromFaces(faces){
      const positions=[],indices=[];
      for(const face of faces){const offset=positions.length/3;positions.push(...face.flat());for(let i=1;i<face.length-1;i++)indices.push(offset,offset+i,offset+i+1);}
      // Normalize winding once. Closed solids are also checked independently in the release tests.
      let volume=0;for(let i=0;i<indices.length;i+=3){const p=indices.slice(i,i+3).map(j=>positions.slice(j*3,j*3+3));volume+=dot(p[0],[p[1][1]*p[2][2]-p[1][2]*p[2][1],p[1][2]*p[2][0]-p[1][0]*p[2][2],p[1][0]*p[2][1]-p[1][1]*p[2][0]])/6;}
      if(volume<0)for(let i=0;i<indices.length;i+=3)[indices[i+1],indices[i+2]]=[indices[i+2],indices[i+1]];
      return {positions,indices};
    }
    function mechanismChannel(c,rail,pose){
      const original=c.prismVertices,axis=pose.tangent,n=pose.normal,point=pose.point;
      const zs=original.map(v=>v[2]),rear=axis[2]>0?Math.min(...zs):Math.max(...zs),front=axis[2]>0?Math.max(...zs):Math.min(...zs),x0=Math.min(...original.map(v=>v[0])),x1=Math.max(...original.map(v=>v[0]));
      const height=Math.abs(dot(sub(original[0],original[4]),n)),w=rail.section[0],h=rail.section[1];
      const xs=[x0,rail.axisX-w/2,rail.axisX+w/2,x1],vs=[-height,-h,0];
      let floorDrop=0;
      if(rail.trajectory){let pose=G.atZ(rail.trajectory,front);for(let i=0;i<4;i++)pose=G.atZ(rail.trajectory,front+pose.normal[2]*h);const floor=add(pose.point,mul(pose.normal,-h));floor[2]=front;floorDrop=Math.max(0,-h-dot(sub(floor,point),n));}
      // A curved rail needs a matching open channel floor; the chord stays below its arc.
      const grid=(i,j,k)=>{const v=vs[j]-(j===1&&k===2?floorDrop:0),z=k===0?rear:front,u=k===1?0:(z-point[2]-n[2]*v)/axis[2];return add(add(point,[xs[i]-point[0],0,0]),add(mul(axis,u),mul(n,v)));};
      const occupied=(i,j,k)=>i>=0&&i<3&&j>=0&&j<2&&k>=0&&k<2&&!(i===1&&j===1&&k===1);
      const faces=[];
      const faceSpecs=[[-1,0,0,[[0,0,0],[0,0,1],[0,1,1],[0,1,0]]],[1,0,0,[[1,0,0],[1,1,0],[1,1,1],[1,0,1]]],[0,-1,0,[[0,0,0],[1,0,0],[1,0,1],[0,0,1]]],[0,1,0,[[0,1,0],[0,1,1],[1,1,1],[1,1,0]]],[0,0,-1,[[0,0,0],[0,1,0],[1,1,0],[1,0,0]]],[0,0,1,[[0,0,1],[1,0,1],[1,1,1],[0,1,1]]]];
      for(let i=0;i<3;i++)for(let j=0;j<2;j++)for(let k=0;k<2;k++)if(occupied(i,j,k))for(const [dx,dy,dz,f]of faceSpecs)if(!occupied(i+dx,j+dy,k+dz))faces.push(f.map(([a,b,c])=>grid(i+a,j+b,k+c)));
      c.meshData=meshFromFaces(faces);c.contactPlane={point,n:axis};c.railCavity={width:w,height:h,normal:n};c.envelopePreserved=true;delete c.prismVertices;
    }
    function cutCylinder(c,startPlane,endPlane){
      const axis=norm(sub(c.end,c.start)),u=[1,0,0],v=[0,axis[2],-axis[1]],r=c.diameter/2;
      const ring=(center,plane)=>Array.from({length:24},(_,i)=>{const angle=i*Math.PI/12,p=add(center,add(mul(u,r*Math.cos(angle)),mul(v,r*Math.sin(angle))));return add(p,mul(axis,dot(sub(plane.point,p),plane.n)/dot(axis,plane.n)));});
      const a=ring(c.start,startPlane),b=ring(c.end,endPlane),faces=[a.slice().reverse(),b];
      for(let i=0;i<a.length;i++){const j=(i+1)%a.length;faces.push([a[i],a[j],b[j],b[i]]);}
      c.meshData=meshFromFaces(faces);c.cutPlanes={start:startPlane,end:endPlane};c.nominalAttachment=clone(c.end);
    }
    for(const c of parts){
      if(c.kind==='rear-steel-beam'||c.kind==='rear-steel-post'||c.kind==='central-mast')c.editor='[data-interaction-type="topBackWallEditor"][data-system-index="'+c.systemIndex+'"]';
      if(c.kind==='rail-rear-mechanism'&&c.prismVertices){
        const rail=parts.find(r=>r.id===c.railId),pose=G.sample(pathOf(rail),0);
        mechanismChannel(c,rail,pose);
      }
      if(c.kind==='roof-register-profile'){
        const rail=parts.find(r=>r.kind==='rail'&&r.systemIndex===c.systemIndex&&(r.wing||'main')===(c.wing||'main'));if(!rail)continue;
        const path=pathOf(rail),half=(c.section?.[1]||30)/2,z=c.start[2];
        // Horizontal register has a flat upper face; use the lower rail edge across its depth.
        const top=Math.min(G.atZ(path,z-half).point[1],G.atZ(path,z+half).point[1]);
        c.start[1]=c.end[1]=top-(c.section?.[0]||130)/2;c.topFlushRail=true;
      }
      if(c.kind==='gutter-ray-connection'){
        const rail=parts.find(r=>r.kind==='rail'&&r.systemIndex===c.systemIndex&&r.railIndex===Number(c.id.split('-').at(-1))&&((r.wing||'main')===(c.wing||'main')||r.continuousArch));
        if(!rail)continue;const path=pathOf(rail),pose=G.sample(path,rail.continuousArch&&c.wing==='opposite'?17.75:path.length-17.75),t=4,w=rail.section[0],h=rail.section[1],length=35.5;
        // L sits on the gutter and against the OUTSIDE rail face. There is no room
        // for a plate between the reference rail underside and the gutter top.
        const side=rail.railIndex===0?-1:1,base=systems[c.systemIndex].frontHeight+K.frontGutterH,station=rail.continuousArch&&c.wing==='opposite'?17.75:path.length-17.75;
        const outline=[[w/2,0],[w/2+35.5,0],[w/2+35.5,t],[w/2+t,t],[w/2+t,h],[w/2,h]];
        const rings=[-length/2,length/2].map(d=>{const p=G.sample(path,station+d).point;return outline.map(([x,y],i)=>[rail.axisX+side*x,i>=4?Math.min(p[1],base+(c.size?.[1]||127)):base+y,p[2]]);});
        const [a,b]=rings,faces=[];
        for(const ring of [a,b])faces.push([ring[0],ring[1],ring[2],ring[3]],[ring[0],ring[3],ring[4],ring[5]]);
        for(let i=0;i<a.length;i++){const j=(i+1)%a.length;faces.push([a[i],a[j],b[j],b[i]]);}
        faces[0].reverse();faces[1].reverse();
        c.meshData=meshFromFaces(faces);c.plateThickness=t;c.railId=rail.id;c.sectionOutline=outline;c.contactNormal=pose.normal;
        delete c.size;delete c.position;
      }
      if(c.kind==='suspension-stay'){
        const rail=parts.find(r=>r.id===c.attachmentRailId),path=pathOf(rail),pose=G.sample(path,c.attachmentDistance),sign=Math.sign(c.end[2]-c.start[2])||1;
        const support=parts.find(p=>p.kind==='central-mast'&&Math.abs(p.start[0]-c.start[0])<p.section[0]/2+1&&Math.abs(p.start[2]-c.start[2])<=p.section[1]+1);
        const faceZ=support?support.start[2]+sign*support.section[1]/2:systems[c.systemIndex].rearDatumZ;
        const anchorTop=systems[c.systemIndex].rearHeight+model.configuration.geometry.anchorRise;
        for(let i=0;i<5;i++){const delta=sub(c.end,c.start),axis=norm(delta);c.start[1]=anchorTop-c.diameter/2/Math.max(.05,Math.abs(axis[2]));}
        const startPlane={point:[c.start[0],c.start[1],faceZ],n:[0,0,sign]},endPlane={point:pose.point,n:pose.normal};
        cutCylinder(c,startPlane,endPlane);
        const cap=c.meshData.positions.slice(0,72),capTop=Math.max(...cap.filter((_,i)=>i%3===1));
        if(support)support.end[1]=Math.max(support.end[1],capTop);
        else for(const wall of parts.filter(p=>p.kind==='rear-wall'&&p.systemIndex===c.systemIndex))wall.topY=Math.max(wall.topY,capTop);
      }
    }
    // Tall suspension columns pass beside the beam ends, never through a full-width beam.
    // Split transverse stock at the actual column faces (same editable section, no extra state).
    const beams=parts.filter(c=>['rear-steel-beam','ridge-beam'].includes(c.kind));
    for(const beam of beams){
      const masts=parts.filter(c=>c.kind==='central-mast'&&Math.abs(c.start[2]-beam.start[2])<(c.section[1]+beam.section[1])/2&&c.end[1]>beam.start[1]-beam.section[0]/2&&c.start[0]+c.section[0]/2>beam.start[0]&&c.start[0]-c.section[0]/2<beam.end[0]);
      if(!masts.length)continue;
      let intervals=[[beam.start[0],beam.end[0]]];
      for(const mast of masts){const lo=mast.start[0]-mast.section[0]/2,hi=mast.start[0]+mast.section[0]/2;intervals=intervals.flatMap(([a,b])=>b<=lo||a>=hi?[[a,b]]:[[a,Math.min(b,lo)],[Math.max(a,hi),b]].filter(([a,b])=>b-a>.001));}
      parts.splice(parts.indexOf(beam),1,...intervals.map(([a,b],i)=>({...clone(beam),id:beam.id+'|stock-'+i,start:[a,beam.start[1],beam.start[2]],end:[b,beam.end[1],beam.end[2]],stockSourceId:beam.id,cutAtColumnFaces:true})));
    }
    // The original wall bracket remains an original block in technical projections.
    for(const rail of parts.filter(c=>c.kind==='rail'&&!c.continuousArch)){
      const rear=parts.find(c=>c.kind==='rail-rear-mechanism'&&c.railId===rail.id);if(!rear)continue;
      const s=systems[rail.systemIndex];parts.push({id:rail.id+'|wall-bracket',kind:'rail-wall-bracket',label:'Ray Duvar Bağlantı Seti',systemIndex:rail.systemIndex,wing:rail.wing,technicalOnly:true,position:[rail.axisX,s.rearHeight,rear.mountFaceZ??s.rearDatumZ],size:[92,142.324176,97.298355],editor:'[data-interaction-type="topBackWallEditor"][data-system-index="'+rail.systemIndex+'"]'});
    }
    // Retraction uses the same native Antero pitch/count, with the leading carrier stopped at the sheet boundary.
    for(const position of model.positions)for(const roof of position.roofs){
      const systemIndex=model.positions.indexOf(position),rail=parts.find(c=>c.kind==='rail'&&c.systemIndex===systemIndex&&(c.wing||'main')===(roof.wing||'main'));
      if(!rail)continue;
      if(!roof.trajectory){roof.trajectory=G.table([[...roof.start],[roof.start[0],roof.start[1]+Math.sin(roof.angle)*roof.length,roof.start[2]+Math.cos(roof.angle)*roof.length]]);}
      const sheet=parts.find(c=>c.kind==='trapez-sheet'&&c.systemIndex===systemIndex&&(c.wing||'main')===(roof.wing||'main'));
      const sign=Math.sign(roof.trajectory.points.at(-1)[2]-roof.trajectory.points[0][2])||1;
      const registers=parts.filter(c=>c.kind==='roof-register-profile'&&c.systemIndex===systemIndex&&(c.wing||'main')===(roof.wing||'main'));
      const targetZ=sheet?sheet.frontZ:registers.length?registers.sort((a,b)=>sign*(b.start[2]-a.start[2]))[0].start[2]:roof.start[2]+sign*700;
      let lo=0,hi=roof.trajectory.length;
      for(let n=0;n<48;n++){const mid=(lo+hi)/2,pose=G.sample(roof.trajectory,mid),front=pose.point[2]-pose.normal[2]*(K.sideRayH+7)+pose.tangent[2]*17.5;if(sign*(front-targetZ)<0)lo=mid;else hi=mid;}
      roof.retractedLeadingDistance=(lo+hi)/2;
      roof.retractedLeadingZ=targetZ;roof.frontOverhang=30;
    }
    // V12: The load-bearing axis and all native hardware remain in their original
    // positions. Only the physical rail stock projects over the front gutter.
    // Continuous Curve-Quad has an exposed gutter at both outside ends.
    for(const rail of parts.filter(c=>c.kind==='rail')){
      const rearExtra=rail.continuousArch?30:0,frontExtra=30;
      const path=pathOf(rail),a=path.points[0],b=path.points.at(-1);
      rail.standardStart=[...a];rail.standardEnd=[...b];
      rail.extensionMm={rear:rearExtra,front:frontExtra};
      let extended;
      if(rail.curveRadius>0&&rail.curveCenter){
        const [cz,cy]=rail.curveCenter,r=rail.curveRadius;
        const a0=Math.atan2(a[1]-cy,a[2]-cz),a1=Math.atan2(b[1]-cy,b[2]-cz);
        const sweep=Math.atan2(Math.sin(a1-a0),Math.cos(a1-a0));
        const direction=Math.sign(sweep)||-1;
        const from=a0-direction*rearExtra/r,to=a1+direction*frontExtra/r;
        const count=Math.max(128,path.points.length-1);
        extended=G.table(Array.from({length:count+1},(_,i)=>{
          const theta=from+(to-from)*i/count;
          return [rail.axisX,cy+r*Math.sin(theta),cz+r*Math.cos(theta)];
        }));
      }else{
        const tangent=G.norm(G.sub(b,a));
        extended=G.table([G.sub(a,G.mul(tangent,rearExtra)),...path.points.map(point=>[...point]),G.add(b,G.mul(tangent,frontExtra))]
          .filter((point,i,all)=>i===0||Math.hypot(...G.sub(point,all[i-1]))>.000001));
      }
      rail.start=extended.points[0];rail.end=extended.points.at(-1);
      rail.trajectory=extended;rail.meshData=G.sweep(extended,rail.section[0],rail.section[1]);
      rail.actualPathLength=extended.length;
    }
    return {...model,components:parts,physicalBounds:G.bounds(parts.filter(c=>!c.technicalOnly))};
  }
  root.PLMRPergolaMounting=Object.freeze({resolve});
})(window);
