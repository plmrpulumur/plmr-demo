/* Placement thumbnails are read-only projections of the native layout parser. */
(function(root){
  'use strict';
  const cards=[
    ['single','Tek sistem','Bir genişlik ve bir açılım ile tek pergola.',{systemCount:'1',width:'4000',opening:'4500',rearHeight:'3200',frontHeight:'2600'}],
    ['equal','Yan yana · eşit genişlik','Toplam 8000 mm genişlik iki sisteme eşit bölünür. Ön oluk aynı hizada kalır.',{systemCount:'2',width:'8000',opening:'4500',rearHeight:'3200',frontHeight:'2600'}],
    ['variable','Yan yana · farklı ölçüler','4000 ve 4500 mm genişlik; 4500 ve 5200 mm açılım. Ön oluk hizası ortak, arka uçlar farklıdır.',{systemCount:'2',width:'4000;4500',opening:'4500;5200',rearHeight:'3200;3400',frontHeight:'2600'}],
    ['independent','Aralıklı sistemler','İki 4000 mm sistem arasında 500 mm boşluk. Genişlik yazımı: 4000;500;4000;NO.',{systemCount:'2',width:'4000;500;4000;NO',opening:'4500;4500',rearHeight:'3200;3200',frontHeight:'2600'}],
    ['rear-aligned','Bağımsız · arka uçlar hizalı','Aralarında 500 mm boşluk olan iki grup. Arka uçlar hizalı; 4500 ve 5200 mm açılım nedeniyle ön oluklar kademelidir.',{systemCount:'2',width:'4000:500:4500',opening:'4500;5200;NO',rearHeight:'3200;3400',frontHeight:'2600'}],
    ['colon','Birbirinden bağımsız gruplar','4000 ve 5000 mm iki bağımsız grup; aralarında 500 mm boşluk. Her grubun açılımı ve yüksekliği ayrıdır.',{systemCount:'2',width:'4000:500:5000',opening:'4500;5200',rearHeight:'3200;3500',frontHeight:'2600;2800'}],
    ['colon-mixed','Aralıklı pozlar ve bağımsız grup','İlk grupta 3000 ve 3200 mm sistem arasında 250 mm boşluk; 600 mm sonra bağımsız 4000 mm sistem.',{systemCount:'3',width:'3000;250;3200:600:4000',opening:'4500;4800;5200',rearHeight:'3200;3300;3500',frontHeight:'2600;2700;2800'}]
  ].map(([id,title,description,values])=>Object.freeze({id,title,description,values}));
  function preview(values){
    const raw={...root.PulumurGeometry.SAMPLE_INPUT,...values,rayCount:'2',postCount:''};
    const d=root.PulumurGeometry.normalizeInput(raw),K=root.PulumurGeometry.K;
    return d.systems.map(s=>{
      const p=d.positions[s.index],r=root.PulumurGeometry.physicalRay(d,s,p),front=-r.endPlan-K.topRayEndExtra;
      return {index:s.index,group:s.independentGroupId||'main',x:s.outerStartX,z:front-p.opening,width:s.outerEndX-s.outerStartX,depth:p.opening};
    });
  }
  function thumbnail(values){
    const items=preview(values),minX=Math.min(...items.map(p=>p.x)),minZ=Math.min(...items.map(p=>p.z));
    const w=Math.max(...items.map(p=>p.x+p.width))-minX,h=Math.max(...items.map(p=>p.z+p.depth))-minZ,scale=Math.min(246/w,106/h);
    const left=(280-w*scale)/2,top=(136-h*scale)/2;
    const rects=items.map(p=>{const x=left+(p.x-minX)*scale,y=top+(p.z-minZ)*scale,W=p.width*scale,H=p.depth*scale;
      return '<rect x="'+x+'" y="'+y+'" width="'+W+'" height="'+H+'" fill="#eaf5fc" stroke="#1479b8" stroke-width="1.5"/><path d="M'+x+' '+(y+H)+'h'+W+'" stroke="#f59e0b" stroke-width="3"/><text x="'+(x+W/2)+'" y="'+(y+H/2)+'" text-anchor="middle" font-size="10" fill="#334155">P'+(p.index+1)+'</text>';}).join('');
    return '<svg viewBox="0 0 280 145" aria-label="Üst görünüş yerleşim şeması">'+rects+'<text x="140" y="142" text-anchor="middle" font-size="8" fill="#64748b">Üst görünüş · turuncu kenar ön oluk</text></svg>';
  }
  root.PLMRPergolaLayouts=Object.freeze({cards,preview,thumbnail});
})(window);
