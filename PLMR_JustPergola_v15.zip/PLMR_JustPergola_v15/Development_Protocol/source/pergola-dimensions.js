/* Native dimension identity -> current V34 display categories. No physical state here. */
(function(root){
  'use strict';
  function describe(drawing,entity,owner='roof-main'){
    const edit=entity.edit||{},id=edit.dimId||entity.dimensionId;
    const index=root.PulumurGeometry.dimensionPositionIndex(drawing,entity,edit)||0;
    const detail=(edit.dimensionType||entity.dimensionFilterType)==='detail';
    const total=/total/.test(id||'');
    const field=edit.field||'';
    const axis=entity.dimensionAxis||'horizontal';
    const key=detail?'intermediate':total?(axis==='vertical'?'total-depth':'total-width'):
      /height/i.test(field)?'height':field==='opening'?'depth':field==='width'?'width':
      /height/i.test(id||'')?'height':/opening|depth/i.test(id||'')?'depth':'width';
    return {id:owner+'|'+(id||index+'|'+key),owner,moduleIndex:index,key,total,title:edit.label||entity.previewText||'Ölçü',value:entity.measuredValue};
  }
  function visible(drawing,entity,state){
    const m=describe(drawing,entity);
    return root.PLMRV15Core.allowed(state,m.total?null:m.owner,m.moduleIndex,m.key)&&!state.hiddenIds?.[m.id];
  }
  function measurements(drawing,actual=[]){
    if(!drawing)return [];
    // Keep hidden measurements in the menu so the same control can show them
    // again. Mirrored views may describe the same persistent measurement ID.
    const entries=[],seen=new Set();
    for(const entity of drawing.entities.filter(e=>e.type==='dimension')){
      const measurement=describe(drawing,entity);
      if(measurement.key!=='intermediate'||seen.has(measurement.id))continue;
      entries.push(measurement);seen.add(measurement.id);
    }
    for(const m of actual)if(m.owner&&m.key==='intermediate'&&!seen.has(m.id)){entries.push(m);seen.add(m.id);}
    return entries;
  }
  root.PLMRPergolaDimensions=Object.freeze({describe,visible,measurements});
})(window);
