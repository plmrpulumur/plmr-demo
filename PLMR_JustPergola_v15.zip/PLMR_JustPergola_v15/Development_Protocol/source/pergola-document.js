/* V34's canonical title block and unit policy applied to the native pergola drawing. */
(function(root){
  'use strict';
  const E=root.PulumurTechnical2DExport,T=root.PLMRV53TitleBlock;
  function projectInfo(raw){
    const host=root.PLMRPergolaEmbedded&&root.PLMRFinalMetadata?.projectInfo;
    if(host)return {projectCode:host.projectCode||'',customerName:host.customerName||'',country:host.country||'',
      projectName:host.projectName||'',revision:host.revision||'',date:host.date||host.createdAt||'',
      description:host.description||'',customerRepresentative:host.customerRepresentative||'',designer:host.designer||host.projectRepresentative||''};
    return {projectCode:raw.projectCode||'',customerName:raw.customer||'',country:raw.country||'',
      projectName:raw.project||'',revision:raw.version||'',date:raw.date||'',
      description:raw.description||raw.extras||'',customerRepresentative:raw.customerRepresentative||'',designer:raw.drawnBy||''};
  }
  function translate(e,dx,dy){
    const out={...e};
    if(e.points)out.points=e.points.map(([x,y])=>[x+dx,y+dy]);
    if(Number.isFinite(e.x))out.x=e.x+dx;if(Number.isFinite(e.y))out.y=e.y+dy;
    for(const k of ['x1','x2','dxfCellX'])if(Number.isFinite(e[k]))out[k]=e[k]+dx;
    for(const k of ['y1','y2','dxfCellY'])if(Number.isFinite(e[k]))out[k]=e[k]+dy;
    return out;
  }
  function styleKey(layer){
    if(/Dikme|^POST$/.test(layer))return 'vertical';
    if(/Oluk|^PROFILE$/.test(layer))return 'gutter';
    if(/Ray|^RAY$/.test(layer))return 'frame';
    if(/Yan Kayıt|^GLASS$|^TRIANGLE$/.test(layer))return 'product';
    if(/FABRIC/.test(layer))return 'fabric';
    if(/WALL|Duvar/.test(layer))return 'wall';
    return 'text';
  }
  function decorate(drawing,raw){
    const units={mm:raw.__dimensionUnits?.mm!==false,inch:!!raw.__dimensionUnits?.inch};
    const mode=units.mm&&units.inch?'dual':units.inch?'inch':'mm';
    const layers=Object.fromEntries(Object.entries(drawing.layerStyle).filter(([name])=>!/^Ölçüler|^DIM$/.test(name)));
    for(const name of Object.values(E.DIM_LAYERS))layers[name]={...E.PALETTE.dimension};
    for(const [name,key]of [['Antetler','title'],['PLMR','logo'],['Dış Çerçeve','outer']])layers[name]={...E.PALETTE[key]};
    for(const entity of [...drawing.entities,...(drawing.input.pergola?.pergolaType==='Lean'?(drawing.nativeEntities||[]):[])]){
      if(entity.type==='dimension'){
        const visibility=raw.__dimensionVisibility||{};
        entity.hiddenDimension=entity.hiddenDimension||!root.PLMRPergolaDimensions.visible(drawing,entity,visibility);
        entity.layer=E.DIM_LAYERS[mode];entity.style=E.DIM_STYLES[mode];entity.color=1;
        const value=entity.textOverride&&entity.textOverride!=='<>'?Number(entity.textOverride):entity.measuredValue;
        const n=Number.isFinite(value)?value:entity.measuredValue;
        const label=[units.mm?Math.round(n)+' mm':null,units.inch?(n/25.4).toFixed(2)+'"':null].filter(Boolean).join(' - ');
        // The on-screen/PDF preview keeps the formatted snapshot, while the
        // exported CAD dimension must use the measurement placeholder. A
        // literal "4000 mm" DXF override freezes its value after STRETCH.
        // AutoCAD recomputes <> from the dimension definition points.
        entity.textOverride=units.inch&&!units.mm?'<>"':'<> mm';
        entity.previewText=label;
        for(const g of entity.graphics||[]){g.layer=entity.layer;g.color=1;g.trueColor=0xff0000;if(g.type==='text'||g.type==='mtext')g.value=label;}
      }
    }
    const body=root.PulumurGeometry.bounds(drawing.entities,drawing.blocks),info=projectInfo(raw),project={projectInfo:info};
    const layout=T.layout(project),height=Math.max(body.height+800,layout.requiredInnerHeight+120),block=T.build(project,height,layout);
    const dx=body.minX-T.TITLE_WIDTH-650,dy=body.minY-400;
    const titleEntities=block.entities.map(e=>translate(e,dx,dy));
    const x0=dx+60,x1=body.maxX+400,y0=dy+60,y1=dy+height-60;
    drawing.entities.push(...titleEntities,{type:'polyline',layer:'Dış Çerçeve',color:7,closed:true,points:[[x0,y0],[x1,y0],[x1,y1],[x0,y1]]});
    drawing.blocks['PLMR - LOGO']=T.logo();
    drawing.titleBlock={...block,bounds:{...block.bounds,minX:block.bounds.minX+dx,maxX:block.bounds.maxX+dx,minY:block.bounds.minY+dy,maxY:block.bounds.maxY+dy},entities:titleEntities,projectInfo:info};drawing.dimensionUnits=units;
    const logo=root.PLMRFinalMetadata?.projectInfo?.drawingLogo||root.PLMRDefaultDrawingLogo;
    root.PLMRCompanyDrawingLogo.applyCompanyDrawingLogo(drawing,logo);
    for(const entity of [...drawing.entities,...(drawing.input.pergola?.pergolaType==='Lean'?(drawing.nativeEntities||[]):[])])if(['product-name','view-title'].includes(entity.presentationRole))entity.hiddenInformation=raw.__dimensionVisibility?.information===false;
    drawing.layerStyle=layers;drawing.layers=Object.keys(layers);
    return drawing;
  }
  root.PLMRPergolaDocument=Object.freeze({decorate,projectInfo});
})(window);
