/* The V49 drawing is authoritative. The 3D view only projects its physical geometry. */
(function(root){
  'use strict';
  const K=root.PulumurGeometry.K;
  const colors=new Map(root.PLMRRal.RAL_COLOR_CATALOG.map(c=>[c.code,c.hex]));
  const midpoint=(a,b)=>a.map((v,i)=>(v+b[i])/2);

  function paintValue(text,fallback){
    const value=String(text||'');
    const ral=value.toUpperCase().match(/\bRAL\s*(\d{4})\b/);
    const hex=value.match(/#[0-9a-f]{6}\b/i);
    return hex?.[0]||colors.get(ral?'RAL '+ral[1]:value.trim())||fallback;
  }

  function hasPaint(text){
    const value=String(text||'').trim(),hex=/^#[0-9a-f]{6}$/i.test(value);
    const ral=value.toUpperCase().match(/\bRAL\s*(\d{4})\b/);
    return hex||colors.has(ral?'RAL '+ral[1]:value);
  }
  function rearSteel(drawing,assembly){
    const d=drawing.input;
    if(d.rearSupport?.type!=='steel')return [];
    const {beamProfile:beam,postProfile:post}=d.rearSupport;
    return drawing.entities.filter(e=>e.view==='top'&&e.profileBoundary==='outer'&&
      ['rearSteelBeam','rearSteelPost'].includes(e.semantic)).map(e=>{
      const i=e.systemIndex||0;
      const height=assembly.systems[i].rearHeight;
      const [x0,x1]=[Math.min(...e.points.map(p=>p[0])),Math.max(...e.points.map(p=>p[0]))].map(x=>x-assembly.origin.sourceX);
      const z=-e.centerY;
      if(e.semantic==='rearSteelBeam'){
        const y=height-beam.elevationHeight/2;
        return {id:'rear-steel-beam-'+i+(e.segmentIndex?'|segment-'+e.segmentIndex:''),kind:'rear-steel-beam',systemIndex:i,start:[x0,y,z],end:[x1,y,z],section:[beam.elevationHeight,beam.planDepth],thickness:beam.thickness};
      }
      return {id:'rear-steel-post-'+e.postIndex,kind:'rear-steel-post',systemIndex:i,start:[(x0+x1)/2,0,z],end:[(x0+x1)/2,Math.max(1,height-beam.elevationHeight),z],section:[post.width,post.depth],thickness:post.thickness};
    });
  }

  function horizontalProfiles(drawing,assembly){
    const d=drawing.input;
    return drawing.entities.filter(e=>e.type==='interaction'&&e.kind==='horizontalProfileEditor').flatMap(e=>{
      const m=e.data,key=m.sideViewKey;
      const front=m.profileView==='front';
      const center=e.x+e.w/2;
      const i=front?Math.max(0,d.systems.findIndex(s=>center>=s.outerStartX&&center<=s.outerEndX)):m.sideIndex;
      const side=key==='right'?d.rightSideSupportGeometry:d.sideSupportGeometry[key];
      const profile=(front?d.horizontalFacadeProfiles.front:d.horizontalFacadeProfiles.side[key])
        ?.find(p=>p.id===m.horizontalProfileId);
      if(!profile)return [];
      const system=assembly.systems[i],originX=assembly.origin.sourceX;
      const ratio=Math.max(.01,Math.min(.99,profile.positionYRatio||.5));
      let start,end;
      if(front){
        const localX=center-K.systemStartX;
        const parapet=d.parapetSegments.front.find(s=>localX>=s.start&&localX<=s.end);
        const height=parapet?parapet.startHeight+(parapet.endHeight-parapet.startHeight)*
          (localX-parapet.start)/(parapet.end-parapet.start):d.parapetHeight;
        const y=height-K.onPostTopDrop+ratio*m.clearHeight;
        const z=system.frontDatumZ-m.boy/2;
        start=[e.x-originX,y,z];
        end=[e.x+e.w-originX,y,z];
      }else{
        const gap=side?.gaps[m.sideGapIndex];
        if(!gap)return [];
        const x=key==='right'?system.outerEndX-m.boy/2:system.outerStartX+m.boy/2;
        const y=ratio*m.clearHeight;
        const base=system.rearDatumZ-side.wallX;
        start=[x,y,base+gap.left];
        end=[x,y,base+gap.right];
      }
      return [{id:m.horizontalProfileId,kind:'horizontal-profile',systemIndex:i,start,end,
        section:front?[m.en,m.boy]:[m.boy,m.en]}];
    });
  }

  function fromDrawing(drawing,wallAppearance,inputOverride){
    const cached=root.PLMRPergolaVariants?.cached(drawing);if(cached)return {...cached,wallAppearance};
    const d=drawing.input;
    const input=inputOverride||root.PulumurProjectModel.geometryInputFromModel(root.PulumurProjectState.getModel());
    const assembly=root.P3DVPergoRiseDerivedGeometry.build({input,normalized:{...d},drawing,source:{mode:'PERI01'}});
    let components=[...assembly.components,...rearSteel(drawing,assembly),...horizontalProfiles(drawing,assembly)].filter(c=>c.renderVisible!==false&&!(c.kind==='parapet'&&Number(c.startHeight??c.topY)<=Number(c.bottomY||0)&&Number(c.endHeight??c.topY)<=Number(c.bottomY||0))&&c.kind!=='fabric-stack'&&c.kind!=='triangle-joinery');
    for (const system of assembly.systems) {
      const index=system.systemIndex ?? system.index;
      const members=assembly.components.filter(c=>c.kind==='triangle-joinery'&&c.systemIndex===index);
      for (const key of new Set(members.map(c=>c.sideViewKey))) {
        const member=members.find(c=>c.sideViewKey===key), p=d.positions[index];
        const geometry=root.PulumurGeometry.triangleProfileGeometry(d,p,key);
        components.push({id:'triangle-'+index+'-'+key,kind:'triangle-frame',systemIndex:index,sideViewKey:key,
          x:member.start[0],y:p.frontHeight-3,z:system.rearDatumZ,geometry});
      }
    }
    components=root.PLMRPergolaParts.project(drawing,assembly,components);
    let zones=root.PulumurGeometry.facadeRegions(drawing).map(region=>{
      const s=assembly.systems[region.systemIndex],x0=region.from-assembly.origin.sourceX,x1=region.to-assembly.origin.sourceX;
      const a=['front','back'].includes(region.face)?[x0,region.bottom,region.face==='back'?s.rearDatumZ:s.frontDatumZ-50]:[region.face==='right'?s.outerEndX:s.outerStartX,region.bottom,s.rearDatumZ+region.from];
      const b=['front','back'].includes(region.face)?[x1,region.top,region.face==='back'?s.rearDatumZ:s.frontDatumZ-50]:[a[0],region.top,s.rearDatumZ+region.to];
      return {...region,width:region.to-region.from,height:region.top-region.bottom,a,b};
    });
    const positions=assembly.systems.map((s,i)=>{
      const rails=components.filter(c=>c.kind==='rail'&&c.systemIndex===i);
      return {
        id:s.positionId,number:'P'+String(i+1).padStart(2,'0'),
        roofs:rails.length<2?[]:(()=>{
          const first=rails[0],last=rails.at(-1),start=midpoint(first.start,last.start),front=midpoint(first.end,last.end);
          const width=last.axisX-first.axisX-K.rayW;
          const gutter=components.find(c=>c.kind==='gutter'&&(c.systemIndex===i||c.systemIndices?.includes(i)));
          const travelZ=(gutter?gutter.rearDatumZ:front[2])-start[2];
          return [{width,start,angle:first.angleRad,length:Math.max(1,travelZ/Math.cos(first.angleRad))}];
        })()
      };
    });
    for(const system of assembly.systems){
      const rails=components.filter(c=>c.kind==='rail'&&c.systemIndex===system.index),first=rails[0],last=rails.at(-1);
      if(!first||!last)continue;
      zones.push({id:system.positionId+'|roof',face:'roof',isRoofZone:true,systemIndex:system.index,moduleIndex:system.index,
        width:system.width,height:system.opening,a:first.start,b:last.end,
        points:[first.start,last.start,last.end,first.end]});
    }
    const options=d.formRawOriginal||d.formRaw||input;
    const finish=/TEXTURE|DOKULU/i.test(options.structureColor)?'TEXTURE':/PARLAK|GLOSS/i.test(options.structureColor)?'GLOSS':'MATTE';
    let result={
      positions,components,zones,assembly,drawing,
      paint:paintValue(options.structureColor,'#383e42'),
      fabricProfile:paintValue(options.fabricProfiles,paintValue(options.structureColor,'#383e42')),
      fabric:paintValue(options.fabric,'#e1d9c4'),
      schematic:!hasPaint(options.structureColor),
      finish,wallAppearance
    };
    if(root.PLMRPergolaVariants)result=root.PLMRPergolaVariants.project(result,input);
    if(root.PLMRPergolaMounting)result=root.PLMRPergolaMounting.resolve(result);
    if(root.PLMRPergolaZones){const scene=root.PulumurProjectState?.getModel().workspaces.standalone.project||{};result.zones=root.PLMRPergolaZones.project(result.zones,scene).list;}
    const rotations=root.PulumurProjectState?.getModel().workspaces.standalone.project?.zoneRotations||{};
    result.zones=result.zones.map(z=>({...z,mountRotation:rotations[z.id]||0}));
    return result;
  }

  function migrateV1(text){
    let data;
    try{data=JSON.parse(text);}catch(_){return null;}
    if(data?.schema!=='plmr-justpergola-v1')return null;
    const c=data.config;
    if(!c||typeof c!=='object')throw Error('JustPergola ayarları eksik.');
    const formData={
      ...root.PulumurGeometry.SAMPLE_INPUT,
      product:'Pergo Rise',moduleName:'Module 1',engine:'2d',
      systemCount:c.systemCount,width:c.width,opening:c.opening,rearHeight:c.rearHeight,
      frontHeight:c.frontHeight,rayCount:c.rayCount,postCount:c.postCount,glassTrack:c.glassTrack,
      parapet:c.parapet,parapetHeight:c.parapetHeight,led:c.led,
      structureColor:String(c.systemColor||'')+' '+String(c.finish||''),fabric:c.fabricColor,
      fabricProfiles:c.systemColor,customer:'',project:'',drawnBy:''
    };
    const wall={enabled:c.wallEnabled!==false,xOffset:0,depth:Number(c.wallDepth)||600,height:Number(c.wallHeight)||0};
    const normalized=root.PulumurGeometry.normalizeInput(formData);
    const middle=Object.fromEntries(normalized.positions.map((_,i)=>[String(i),wall]));
    const glass=c.glassTrack==='EVET';
    const topBackWallGridState=Object.fromEntries(normalized.systems.map(s=>{
      const far=K.topWallH+normalized.maxOpening-normalized.positions[s.index].opening;
      const near=Math.max(0,far-wall.depth);
      return [String(s.index),{cells:[{id:'legacy-wall-'+s.index,enabled:wall.enabled,minX:0,maxX:s.outerWidth,
        startNearDepth:near,endNearDepth:near,startFarDepth:far,endFarDepth:far}]}];
    }));
    const drawingState={backWallState:{left:wall,right:wall,middle},topBackWallGridState,
      sideFeatureState:{glassTrack:{left:glass,right:glass,middle:{}},triangle:{left:false,right:false,middle:{}},middleEnabled:{}}};
    return root.PulumurProjectSchema.createEnvelope(root.PulumurProjectModel.fromLegacy({formData,drawingState},null,normalized),
      {appVersion:root.PulumurProjectState.appVersion});
  }

  root.PLMRJustPergola=Object.freeze({fromDrawing,migrateV1});
})(window);
