/* Native Lean assembly -> explicit product variation. No second persistent model. */
(function(root){
  'use strict';
  const D=root.PLMRPergolaDefinition,G=root.PLMRPergolaVariantGeometry,cache=new WeakMap(),clone=x=>JSON.parse(JSON.stringify(x));
  function railFunction(rail,cfg,system){
    const a=rail.start,b=rail.end,dz=b[2]-a[2],slope=(b[1]-a[1])/dz;
    const rise=cfg.curved?cfg.geometry.curveRise:0;
    let centerZ=0,centerY=0,radius=0;
    if(cfg.curved){
      if(cfg.continuous){
        centerZ=system.mirrorDatumZ;
        const apex=system.rearHeight;
        radius=((b[2]-centerZ)**2+(apex-b[1])**2)/(2*(apex-b[1]));centerY=apex-radius;
      }else{
        const dy=b[1]-a[1],midY=dy/2+rise,midZ=dz/2,B=(dz*dz+dy*dy)/2,M=(midZ*midZ+midY*midY)/2,det=dz*midY-dy*midZ;
        centerZ=a[2]+(B*midY-M*dy)/det;centerY=a[1]+(dz*M-midZ*B)/det;
      }
      radius=Math.hypot(a[2]-centerZ,a[1]-centerY);
      if(!Number.isFinite(radius)||centerY>=Math.min(a[1],b[1]))throw Error('Kavis uç teğetleri geriye dönüyor; kavis yüksekliğini azaltın.');
    }
    const baseY=z=>a[1]+slope*(z-a[2]);
    const y=z=>cfg.curved?centerY+Math.sqrt(Math.max(0,radius*radius-(z-centerZ)**2)):baseY(z);
    const count=cfg.curved?128:1;
    const path=G.table(Array.from({length:count+1},(_,i)=>{const z=a[2]+dz*i/count;return [a[0],y(z),z];}));
    const tangent=z=>G.atZ(path,z).tangent;
    return {y,tangent,path,rise,radius,centerZ,centerY,baseY};
  }

  function reflectPoint(p,z){return [p[0],p[1],2*z-p[2]];}
  function reflected(component,z){
    const c=clone(component);c.id='opposite|'+c.id;c.wing='opposite';c.zSign=-(c.zSign||1);
    for(const key of ['start','end','position','joint','insertionAnchor','alignmentAnchor','rearMechanismPivot'])if(c[key])c[key]=reflectPoint(c[key],z);
    if(c.prismVertices)c.prismVertices=c.prismVertices.map(p=>reflectPoint(p,z));
    if(c.polygonXZ)c.polygonXZ=c.polygonXZ.map(([x,Z])=>[x,2*z-Z]);
    if(c.corners)c.corners=c.corners.map(p=>reflectPoint(p,z));
    if(c.meshData){const p=c.meshData.positions;for(let i=2;i<p.length;i+=3)p[i]=2*z-p[i];for(let i=0;i<c.meshData.indices.length;i+=3)[c.meshData.indices[i+1],c.meshData.indices[i+2]]=[c.meshData.indices[i+2],c.meshData.indices[i+1]];}
    if(c.trajectory)c.trajectory=G.table(c.trajectory.points.map(p=>reflectPoint(p,z)));
    if(c.curveCenter)c.curveCenter=[2*z-c.curveCenter[0],c.curveCenter[1]];
    if(c.z!=null)c.z=2*z-c.z;
    if(c.centerZ!=null)c.centerZ=2*z-c.centerZ;
    for(const key of ['frontZ','rearZ','frontDatumZ','rearDatumZ','mountFaceZ'])if(c[key]!=null)c[key]=2*z-c[key];
    if(c.rotationX!=null)c.rotationX=-c.rotationX;
    if(c.railId)c.railId='opposite|'+c.railId;
    if(c.attachmentRailId)c.attachmentRailId='opposite|'+c.attachmentRailId;
    return c;
  }
  function curvedTriangle(c,fn){
    const out=clone(c),outer=c.geometry.polygons[0],maxU=Math.max(...outer.map(p=>p[0]));
    const left=Math.max(...outer.filter(p=>p[0]<.01).map(p=>p[1])),right=Math.max(...outer.filter(p=>Math.abs(p[0]-maxU)<.01).map(p=>p[1]));
    const top=u=>left+(right-left)*u/maxU,displace=([u,v])=>[u,v+(Math.abs(v-top(u))<90?fn.y(c.z+u)-fn.baseY(c.z+u):0)];
    out.geometry.polygons=c.geometry.polygons.map(poly=>{
      const points=[];
      for(let i=0;i<poly.length;i++){
        const a=poly[i],b=poly[(i+1)%poly.length],isTop=Math.abs(a[1]-top(a[0]))<90&&Math.abs(b[1]-top(b[0]))<90;
        const steps=isTop?Math.max(1,Math.ceil(Math.abs(b[0]-a[0])/150)):1;
        for(let n=0;n<steps;n++)points.push(displace([a[0]+(b[0]-a[0])*n/steps,a[1]+(b[1]-a[1])*n/steps]));
      }return points;
    });return out;
  }
  function project(base,input){
    const cfg=D.traits(input.__pergola||base.drawing.input.pergola),model={...base,configuration:cfg};
    if(cfg.pergolaType==='Lean')return model;
    const systems=base.assembly.systems.map(s=>({...s}));
    for(const s of systems){
      const steel=base.components.find(c=>c.kind==='rear-steel-beam'&&c.systemIndex===s.index);
      s.mirrorDatumZ=cfg.centralSteel&&steel?steel.start[2]:cfg.continuous?s.rearDatumZ-root.PulumurGeometry.K.postSize/2:s.rearDatumZ;
    }
    for(const s of systems){
      if(cfg.double&&!(s.rearHeight>s.frontHeight))throw Error('İki kanatlı üründe orta/mahya kotu dış oluk kotundan yüksek olmalı.');
      if(cfg.curved&&!cfg.continuous&&cfg.geometry.curveRise>=s.opening/2)throw Error('Kavis yüksekliği bir kanat açılımının yarısından küçük olmalı.');
    }
    const functions=new Map();
    for(const c of base.components.filter(c=>c.kind==='rail'))functions.set(c.id,railFunction(c,cfg,systems[c.systemIndex]));
    let primary=clone(base.components);
    if(cfg.suspended||cfg.wing)primary=primary.filter(c=>!['post','post-upper-connection','post-lower-connection','side-support-post'].includes(c.kind));
    if((cfg.suspended&&base.drawing.input.rearSupport?.type==='steel')||cfg.wing)primary=primary.filter(c=>c.kind!=='rear-steel-post');
    if(cfg.double)primary=primary.filter(c=>c.kind!=='rear-wall'&&(cfg.centralSteel||!['rear-steel-beam','rear-steel-post'].includes(c.kind)));
    for(const c of primary.filter(c=>c.kind==='rail')){const f=functions.get(c.id);c.trajectory=f.path;c.meshData=G.sweep(f.path,c.section[0],c.section[1]);c.actualPathLength=f.path.length;c.curveRadius=f.radius;c.curveCenter=[f.centerZ,f.centerY];}
    if(cfg.curved){
      primary=primary.map(c=>{
        const rail=base.components.find(r=>r.kind==='rail'&&r.systemIndex===c.systemIndex&&(c.railId?r.id===c.railId:true));
        const fn=rail&&functions.get(rail.id);if(!fn)return c;
        if(c.kind==='rail'){
          const f=functions.get(c.id);c.trajectory=f.path;c.meshData=G.sweep(f.path,c.section[0],c.section[1]);c.actualPathLength=f.path.length;c.curveRadius=f.radius;c.curveCenter=[f.centerZ,f.centerY];
        }else if(c.kind==='roof-register-profile'){
          const delta=fn.y(c.start[2])-fn.baseY(c.start[2]);c.start[1]+=delta;c.end[1]+=delta;
        }else if(c.kind==='triangle-frame')return curvedTriangle(c,fn);
        else if(c.kind==='rail-rear-mechanism'||c.kind==='rail-front-head'){
          const own=functions.get(c.railId),joint=c.joint,tangent=own.tangent(joint[2]),normal=[0,tangent[2],-tangent[1]];
          const previousAngle=-(c.rotationX||0),nextAngle=Math.atan2(tangent[1],tangent[2]);
          if(c.insertionAnchor){const dy=c.insertionAnchor[1]-joint[1],dz=c.insertionAnchor[2]-joint[2],delta=nextAngle-previousAngle;c.insertionAnchor=[c.insertionAnchor[0],joint[1]+dy*Math.cos(delta)+dz*Math.sin(delta),joint[2]-dy*Math.sin(delta)+dz*Math.cos(delta)];}
          c.rotationX=-nextAngle;
          if(c.prismVertices){
            const original=clone(c.prismVertices);
            for(let i=0;i<4;i++){
              const upper=original[i+4],top=own.y(joint[2])+tangent[1]/tangent[2]*(upper[2]-joint[2]);
              c.prismVertices[i+4][1]=top;c.prismVertices[i][1]=top-(upper[1]-original[i][1]);
            }
          }else c.position=G.sub(G.add(joint,G.mul(tangent,c.size[2]/2)),G.mul(normal,c.size[1]/2));
        }
        return c;
      });
      for(const c of primary.filter(c=>c.kind==='trapez-sheet')){
        const rail=base.components.find(r=>r.kind==='rail'&&r.systemIndex===c.systemIndex),fn=functions.get(rail.id);
        const registers=primary.filter(r=>r.kind==='roof-register-profile'&&r.systemIndex===c.systemIndex);
        const offset=Math.max(0,...registers.flatMap(r=>[-15,15].map(z=>r.start[1]+65-fn.y(r.start[2]+z))));
        const x0=Math.min(...c.corners.map(p=>p[0])),x1=Math.max(...c.corners.map(p=>p[0]));
        const points=Array.from({length:25},(_,i)=>{const z=c.rearZ+(c.frontZ-c.rearZ)*i/24;return [0,fn.y(z),z];});
        c.meshData=G.ribbon(G.table(points),x0,x1,offset);c.supportTopOffsetY=offset;delete c.corners;
      }
    }
    const components=[...primary];
    if(cfg.double){
      for(const c of primary){
        if(['rear-steel-beam','rear-steel-post'].includes(c.kind)){
          c.label=c.kind==='rear-steel-beam'?'Orta çelik kiriş':'Orta çelik dikme';
          c.editor='[data-interaction-type="topBackWallEditor"][data-system-index="'+c.systemIndex+'"]';continue;
        }
        const indices=c.systemIndices?.length>1?c.systemIndices:[c.systemIndex||0];
        const planes=new Map();for(const i of indices){const z=systems[i].mirrorDatumZ;if(!planes.has(z))planes.set(z,[]);planes.get(z).push(i);}
        if(planes.size===1){components.push(reflected(c,planes.keys().next().value));continue;}
        // Stepped rear datums must not be joined by one invented opposite gutter.
        for(const [z,indicesAtPlane]of planes)for(const i of indicesAtPlane){
          const piece=clone(c);piece.id+='|module-'+i;piece.systemIndex=i;piece.systemIndices=[i];
          if(piece.start&&piece.end&&Math.abs(piece.end[0]-piece.start[0])>1){piece.start[0]=Math.max(piece.start[0],systems[i].outerStartX);piece.end[0]=Math.min(piece.end[0],systems[i].outerEndX);piece.length=Math.abs(piece.end[0]-piece.start[0]);if(piece.length<.1)continue;}
          components.push(reflected(piece,z));
        }
      }
    }
    const mastKeys=new Set(),beamKeys=new Set(),K=root.PulumurGeometry.K;
    if(cfg.double||cfg.suspended){
      for(const s of systems){
        const rails=primary.filter(c=>c.kind==='rail'&&c.systemIndex===s.index),first=rails[0];if(!first)continue;
        const fn=functions.get(first.id),ridgeY=fn.y(s.rearDatumZ),anchorY=s.rearHeight+cfg.geometry.anchorRise;
        if(cfg.double&&!cfg.quad&&!primary.some(c=>c.kind==='rear-steel-beam'&&c.systemIndex===s.index)){
          const key=[s.outerStartX,s.outerEndX,s.rearDatumZ,ridgeY].join('|');
          if(!beamKeys.has(key)){beamKeys.add(key);components.push({id:s.positionId+'|ridge',kind:'ridge-beam',label:'Orta taşıyıcı kiriş',systemIndex:s.index,start:[s.outerStartX,ridgeY-50,s.rearDatumZ],end:[s.outerEndX,ridgeY-50,s.rearDatumZ],section:[100,100],thickness:3,variantEditable:true});}
        }
        if(cfg.suspended&&base.drawing.input.rearSupport?.type!=='steel'){
          for(const wall of components.filter(c=>c.kind==='rear-wall'&&c.systemIndex===s.index))wall.topY=Math.max(wall.topY,anchorY+cfg.geometry.stayDiameter/2);
        }
        if(cfg.wing||cfg.suspended&&base.drawing.input.rearSupport?.type==='steel'){
          for(const rail of rails){
            const key=[rail.axisX,s.rearDatumZ,anchorY].map(n=>n.toFixed(3)).join('|');if(mastKeys.has(key))continue;mastKeys.add(key);
            const profile=base.drawing.input.rearSupport?.postProfile||{width:100,depth:100,thickness:3};
            const steel=primary.find(c=>c.kind==='rear-steel-beam'&&c.systemIndex===s.index),mastZ=steel?steel.start[2]:s.rearDatumZ;
            components.push({id:rail.id+'|mast',kind:'central-mast',label:'Askı taşıyıcı orta dikme',systemIndex:s.index,start:[rail.axisX,0,mastZ],end:[rail.axisX,anchorY,mastZ],section:[profile.width,profile.depth],thickness:profile.thickness,variantEditable:true});
          }
        }
        if(cfg.wing||cfg.suspended){
          for(const rail of rails){const path=functions.get(rail.id).path,target=G.sample(path,path.length/2).point,anchor=[rail.axisX,anchorY,s.rearDatumZ];
            const stay={id:rail.id+'|stay',kind:'suspension-stay',label:'Ray orta nokta askısı',systemIndex:s.index,start:anchor,end:target,section:[cfg.geometry.stayDiameter,cfg.geometry.stayDiameter],diameter:cfg.geometry.stayDiameter,variantEditable:true,attachmentRailId:rail.id,attachmentDistance:path.length/2};components.push(stay);
            if(cfg.wing)components.push(reflected(stay,s.mirrorDatumZ));
          }
        }
      }
    }
    const mastClusters=[];
    for(const mast of components.filter(c=>c.kind==='central-mast').sort((a,b)=>a.start[0]-b.start[0])){
      const other=mastClusters.find(c=>Math.abs(c.start[2]-mast.start[2])<.001&&Math.abs(c.end[1]-mast.end[1])<.001&&Math.abs(c.start[0]-mast.start[0])<=(c.section[0]+mast.section[0])/2+.001);
      if(!other){mast.supportMinX=mast.supportMaxX=mast.start[0];mastClusters.push(mast);continue;}
      other.supportMinX=Math.min(other.supportMinX,mast.start[0]);other.supportMaxX=Math.max(other.supportMaxX,mast.start[0]);other.start[0]=other.end[0]=(other.supportMinX+other.supportMaxX)/2;
      other.systemIndices=[...new Set([...(other.systemIndices||[other.systemIndex]),mast.systemIndex])];mast.mergedInto=other.id;
    }
    let physicalComponents=components.filter(c=>!c.mergedInto);
    // The Quad has outside columns; Wing has only the central masts. Exactly as the new cards.
    let zones=base.zones.filter(z=>!(cfg.double&&z.face==='back'&&!cfg.centralSteel));
    if(cfg.suspended||cfg.wing)zones=zones.filter(z=>z.isRoofZone);
    if(cfg.double)zones=[...zones,...zones.filter(z=>!cfg.centralSteel||z.face!=='back').map(z=>({...clone(z),id:'opposite|'+z.id,face:z.face==='front'?'back':z.face,wing:'opposite',a:reflectPoint(z.a,systems[z.systemIndex].mirrorDatumZ),b:reflectPoint(z.b,systems[z.systemIndex].mirrorDatumZ),points:z.points?.map(p=>reflectPoint(p,systems[z.systemIndex].mirrorDatumZ))}))];
    if(cfg.wing){
      // Only real bounded mast openings become facade zones; gaps between groups do not.
      const masts=physicalComponents.filter(c=>c.kind==='central-mast');
      for(const s of systems){
        const row=masts.filter(c=>Math.abs(c.start[2]-s.mirrorDatumZ)<.001&&c.start[0]>=s.outerStartX-100&&c.start[0]<=s.outerEndX+100).sort((a,b)=>a.start[0]-b.start[0]);
        const beam=physicalComponents.find(c=>['ridge-beam','rear-steel-beam'].includes(c.kind)&&c.systemIndex===s.index);if(!beam)continue;
        for(let i=1;i<row.length;i++){
          const x0=Math.max(s.outerStartX,row[i-1].start[0]+row[i-1].section[0]/2),x1=Math.min(s.outerEndX,row[i].start[0]-row[i].section[0]/2),top=beam.start[1]-beam.section[0]/2;
          if(x1>x0&&top>0)zones.push({id:s.positionId+'|central-opening-'+i,face:'back',systemIndex:s.index,moduleIndex:s.index,isRoofZone:false,width:x1-x0,height:top,bottom:0,top,a:[x0,0,s.rearDatumZ],b:[x1,top,s.rearDatumZ]});
        }
      }
    }
    if(cfg.quad){
      zones=zones.filter(z=>z.isRoofZone||!['left','right'].includes(z.face));
      for(const s of systems)for(const face of ['left','right']){
        const x=face==='left'?s.outerStartX:s.outerEndX,posts=physicalComponents.filter(c=>c.kind==='post'&&(c.systemIndex===s.index||c.systemIndices?.includes(s.index))&&Math.abs(c.start[0]-x)<(c.section?.[0]||100)+1).sort((a,b)=>a.start[2]-b.start[2]);
        if(posts.length<2)continue;const first=posts[0],last=posts.at(-1),z0=G.bounds([first]).max[2],z1=G.bounds([last]).min[2],top=Math.min(first.end[1],last.end[1])-K.onPostTopDrop;
        if(z1>z0&&top>0)zones.push({id:s.positionId+'|'+face+'-total',face,systemIndex:s.index,moduleIndex:s.index,isRoofZone:false,width:z1-z0,height:top,bottom:0,top,a:[x,0,z0],b:[x,top,z1]});
      }
    }
    let positions=base.positions.map((position,i)=>{
      const roofs=position.roofs.map(roof=>{
        const rail=primary.find(c=>c.kind==='rail'&&c.systemIndex===i),f=functions.get(rail.id),centerX=roof.start[0];
        const path=G.range(f.path,roof.start[2]+Math.cos(roof.angle)*roof.length);
        path.points=path.points.map(p=>[centerX,p[1],p[2]]);
        return {...roof,trajectory:path,length:path.length,wing:'main'};
      });
      if(cfg.double)for(const roof of [...roofs])roofs.push({...clone(roof),start:reflectPoint(roof.start,systems[i].mirrorDatumZ),trajectory:G.table(roof.trajectory.points.map(p=>reflectPoint(p,systems[i].mirrorDatumZ))),wing:'opposite'});
      return {...position,roofs};
    });
    for(const s of systems){
      s.backExtentZ=cfg.double?2*s.mirrorDatumZ-s.frontDatumZ:s.rearDatumZ;s.totalDepth=s.frontDatumZ-s.backExtentZ;
    }
    if(cfg.pergolaType==='Curve-Quad'){
      // One continuous arch and fabric run, from the rear outside end to the front.
      // The crest is a passage point, never a fabric collection station.
      const result=continuousQuad(physicalComponents,positions,systems,functions,base);
      physicalComponents=result.components;positions=result.positions;
      zones=zones.filter(z=>!z.isRoofZone||z.wing!=='opposite');
    }
    for(const z of zones.filter(z=>z.isRoofZone)){
      const roof=positions[z.systemIndex].roofs.find(r=>r.wing===(z.wing||'main'));if(!roof)continue;
      z.points=roof.trajectory.points.flatMap(p=>[[p[0]-roof.width/2,p[1],p[2]],[p[0]+roof.width/2,p[1],p[2]]]);z.triangles=[];
      for(let i=0;i<roof.trajectory.points.length-1;i++){const a=i*2;z.triangles.push(a,a+2,a+1,a+1,a+2,a+3);}
      z.width=roof.width;z.height=roof.trajectory.length;
    }
    return {...model,components:physicalComponents,positions,zones,assembly:{...base.assembly,systems},physicalBounds:G.bounds(physicalComponents)};
  }
  function continuousQuad(parts,positions,systems,functions,base){
    const out=parts.filter(c=>c.kind!=='rail'&&c.kind!=='rail-rear-mechanism'&&
      !(c.kind==='rail-front-head'&&c.wing==='opposite')&&
      !['roof-register-profile','trapez-sheet'].includes(c.kind));
    const newPositions=[];
    for(const s of systems){
      const rails=parts.filter(c=>c.kind==='rail'&&c.systemIndex===s.index&&c.wing!=='opposite');
      for(const rail of rails){
        const fn=functions.get(rail.id),z0=2*s.mirrorDatumZ-rail.end[2],z1=rail.end[2];
        const path=G.table(Array.from({length:257},(_,i)=>{const z=z0+(z1-z0)*i/256;return [rail.axisX,fn.y(z),z];}));
        const full={...rail,start:path.points[0],end:path.points.at(-1),trajectory:path,meshData:G.sweep(path,...rail.section),actualPathLength:path.length,continuousArch:true};out.push(full);
        const front=parts.find(c=>c.kind==='rail-front-head'&&c.railId===rail.id&&c.wing!=='opposite');
        const rear=reflected(front,s.mirrorDatumZ);rear.id=rail.id+'|rear-front-head';rear.railId=rail.id;rear.label='Arka uç · Ön Ray Mekanizması';out.push(rear);
      }
      const rail=rails[0],fn=functions.get(rail.id),back=2*s.mirrorDatumZ-rail.end[2],delta=back-rail.start[2];
      const registers=parts.filter(c=>c.kind==='roof-register-profile'&&c.systemIndex===s.index&&c.wing!=='opposite').map(c=>{
        const moved=clone(c),sheet=parts.find(p=>p.kind==='trapez-sheet'&&p.systemIndex===s.index&&p.wing!=='opposite');
        const fixed=String(c.id).includes('fixed'),tail=Math.abs(Math.sin(rail.angleRad))*root.PulumurGeometry.K.sideRayH;
        const z=fixed?back+(c.start[2]-rail.start[2])+tail:back+(sheet.frontZ-sheet.rearZ)-15;
        moved.start[2]=moved.end[2]=z;moved.start[1]=moved.end[1]=fn.y(z)-65;return moved;
      });out.push(...registers);
      for(const sheet of parts.filter(c=>c.kind==='trapez-sheet'&&c.systemIndex===s.index&&c.wing!=='opposite')){
        const moved=clone(sheet),p=sheet.meshData.positions,x0=Math.min(...p.filter((_,i)=>i%3===0)),x1=Math.max(...p.filter((_,i)=>i%3===0));
        moved.rearZ=back;moved.frontZ=back+(sheet.frontZ-sheet.rearZ);
        const offset=Math.max(0,...registers.flatMap(r=>[-15,15].map(dz=>r.start[1]+65-fn.y(r.start[2]+dz))));
        const path=G.table(Array.from({length:25},(_,i)=>{const z=moved.rearZ+(moved.frontZ-moved.rearZ)*i/24;return [0,fn.y(z),z];}));
        moved.meshData=G.ribbon(path,x0,x1,offset);moved.supportTopOffsetY=offset;out.push(moved);
      }
      const templates=[...new Map(registers.map(r=>[r.start[0]+'|'+r.end[0],r])).values()];
      for(const template of templates)for(const [suffix,z]of [['mid',s.mirrorDatumZ],['front',s.frontDatumZ-root.PulumurGeometry.K.topGutterH-22]]){
        const c=clone(template);c.id=template.id+'|'+suffix;c.start[2]=c.end[2]=z;c.start[1]=c.end[1]=fn.y(z)-c.section[0]/2;out.push(c);
      }
      const old=positions[s.index].roofs[0],z1=old.trajectory.points.at(-1)[2],z0=2*s.mirrorDatumZ-z1;
      const path=G.table(Array.from({length:257},(_,i)=>{const z=z0+(z1-z0)*i/256;return [old.start[0],fn.y(z),z];}));
      newPositions.push({...positions[s.index],roofs:[{...old,start:path.points[0],trajectory:path,length:path.length,wing:'main',collectionEnd:'rear',continuousArch:true}]});
    }
    return {components:out,positions:newPositions};
  }
  function decorateDrawing(drawing,raw){
    const configuration=D.normalize(raw.__pergola);drawing.input.pergola=configuration;
    const model=root.PLMRJustPergola.fromDrawing(drawing,'white',raw);cache.set(drawing,model);
    Object.defineProperty(drawing,'nativeEntities',{value:[...drawing.entities],enumerable:false});
    root.PLMRPergolaOrthographic.project(drawing,model);
    for(const e of drawing.entities){
      if(e.presentationRole!=='product-name')continue;
      // Independent groups have local position numbers; printed POZ is global.
      let index=drawing.input.positions.findIndex(p=>e.positionId&&String(p.positionId||p.id)===String(e.positionId));
      if(index<0)index=drawing.input.systems.findIndex(s=>e.x>=s.outerStartX&&e.x<=s.outerEndX);
      if(index<0)index=Number(e.systemIndex)||0;
      e.value=configuration.derivedModelName+(drawing.input.systemCount>1?' · POZ '+(index+1):'');
      const system=drawing.input.systems[index];
      if(system){const width=system.outerEndX-system.outerStartX;e.height=Math.min(e.height,width*.82/Math.max(1,[...e.value].length*.58));}
    }
  }
  root.PLMRPergolaVariants=Object.freeze({project,decorateDrawing,cached:d=>cache.get(d)});
})(window);
