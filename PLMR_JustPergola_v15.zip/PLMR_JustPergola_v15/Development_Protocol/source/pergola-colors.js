/* Profile colours are derived from the native drawing layer owner. */
(function(root){
  const styles=root.PulumurGeometry.LAYER_STYLE;
  const layers={rail:'RAY',gutter:'PROFILE','gutter-cap':'PROFILE',post:'POST',
    'central-mast':'MAST','ridge-beam':'RIDGE','suspension-stay':'ASKI','side-support-post':'POST','roof-register-profile':'FABRIC','horizontal-profile':'GLASS',
    'glass-track':'Profil - Yan Kayıt - Üst Görünüş','triangle-frame':'TRIANGLE',
    'rail-rear-mechanism':'RAY','rail-front-head':'RAY','gutter-ray-connection':'PROFILE',
    'post-upper-connection':'POST','post-lower-connection':'POST','water-outlet':'WATER'};
  root.PLMRPergolaColors=Object.freeze({profile:kind=>(styles[layers[kind]||'OUTLINE']).stroke,
    fabric:'#e1d9c4',sheet:'#8296a8'});
})(window);
