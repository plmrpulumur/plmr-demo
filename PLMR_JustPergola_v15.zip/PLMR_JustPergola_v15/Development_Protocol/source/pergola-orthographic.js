/* PERI01 owns the plan/elevation templates and editing math. Product assembly
   changes only the required views; SVG, PDF and DXF consume these same entities. */
(function(root){
  'use strict';
  const N=root.PLMRPergolaNativeDetails,V=root.PLMRPergolaVariantGeometry;
  const isPost=e=>/^POST$|^Dikme -/.test(e.layer||'')||/^PergoRise Dikme/.test(e.name||'');
  const isSupport=e=>/WALL|Duvar/.test(e.layer||'')||/^rearSteel/.test(e.semantic||'')||e.kind==='topBackWallEditor';
  const norm=angle=>(angle%360+360)%360;
  function sourceMetadata(part,native){
    if(!part.editor)return null;
    const attrs=[...part.editor.matchAll(/\[data-([a-z-]+)="([^"]*)"\]/g)],kind=attrs.find(a=>a[1]==='interaction-type')?.[2];
    const alias={'profile-part':'part','profile-view':'profileView'};
    return native.find(e=>e.type==='interaction'&&e.kind===kind&&attrs.every(([,k,v])=>k==='interaction-type'||String(e.data?.[alias[k]||k.replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]??'')===v));
  }
  function project(drawing,model){
    const G=root.PulumurGeometry,K=G.K,g=G.makeEntitySink(),d=drawing.input,cfg=model.configuration;
    const native=drawing.nativeEntities,ranges=drawing.nativeViewRanges;
    if(!ranges)throw Error('PERGOLA_NATIVE_VIEW_RANGES_MISSING');
    const systems=model.assembly.systems,origin=model.assembly.origin.sourceX;
    const frontPosts=!cfg.suspended&&!cfg.wing;
    const keep=e=>frontPosts||(!isPost(e)&&!['postEditor','frontPostProfileEditor'].includes(e.kind)&&!(e.edit?.field==='__zone__'&&e.edit.view==='Front'));
    const top=native.slice(...ranges.top).filter(keep).map(N.clone);
    const front=native.slice(...ranges.front).filter(keep).map(N.clone);
    // Extend the native 2D rail outlines using the physical stock endpoint.
    // The front head, rear mechanism and wall-plate blocks do not move.
    for(const s of systems){
      for(const rail of model.components.filter(c=>c.kind==='rail'&&c.systemIndex===s.index&&c.wing!=='opposite')){
        const delta=rail.end[2]-(rail.standardEnd?.[2]??rail.end[2]);
        if(Math.abs(delta)<.000001)continue;
        const axis=rail.axisX+origin;
        for(const e of top.filter(e=>e.layer==='Ray - Üst Görünüş'&&e.points?.length===4)){
          const xs=e.points.map(p=>p[0]);
          if(Math.abs((Math.min(...xs)+Math.max(...xs))/2-axis)>K.rayW/2+1)continue;
          const frontY=Math.min(...e.points.map(p=>p[1]));
          e.points=e.points.map(([x,y])=>[x,Math.abs(y-frontY)<.00001?y-delta:y]);
        }
      }
    }
    N.stamp(top,'TOP');N.stamp(front,'FRONT');
    if(!cfg.continuous)g.entities.push(...top);
    else{
      // One continuous ray; original native plan accessories remain unchanged.
      const fixed=top.filter(e=>!/^Ray - Üst/.test(e.layer||'')&&!/^FABRIC$|^HATCH_FABRIC$/.test(e.layer||'')&&!/^PULUMUR TRAPEZ/.test(e.name||'')&&!/Ray Arka Mekanizma/.test(e.name||'')&&!isSupport(e)&&e.kind!=='trapezSheetEditor');
      g.entities.push(...fixed);
      // The new user DXF reference places Curve-Quad's single product title
      // on the full continuous-arch plan centre, not the original first-wing
      // centre. Other double-wing titles retain their native per-wing labels.
      for(const s of systems){
        const minX=s.outerStartX+origin-1,maxX=s.outerEndX+origin+1;
        const centerY=-(s.backExtentZ+s.frontDatumZ)/2;
        for(const title of g.entities.filter(e=>e.presentationRole==='product-name'&&e.viewType==='TOP'&&Number.isFinite(e.x)&&e.x>=minX&&e.x<=maxX))title.y=centerY;
      }
      for(const s of systems){
        const rail=model.components.find(c=>c.kind==='rail'&&c.systemIndex===s.index);
        const a=-rail.start[2],b=-rail.end[2];
        for(const r of model.components.filter(c=>c.kind==='rail'&&c.systemIndex===s.index)){
          G.drawTopRayProfile(g,r.axisX+origin-K.rayW/2,a,b);
        }
        for(const c of model.components.filter(c=>c.kind==='roof-register-profile'&&c.systemIndex===s.index)){
          const x=Math.min(c.start[0],c.end[0])+origin,w=Math.abs(c.end[0]-c.start[0]);
          const e=g.rect(x,-c.start[2]-15,w,30,'FABRIC');e.componentKind=c.kind;e.physicalPartId=c.id;
        }
        for(const c of model.components.filter(c=>c.kind==='trapez-sheet'&&c.systemIndex===s.index)){
          const xs=V.vertices(c).map(p=>p[0]+origin),points=[[Math.min(...xs),-c.rearZ],[Math.max(...xs),-c.rearZ],[Math.max(...xs),-c.frontZ],[Math.min(...xs),-c.frontZ]];
          g.poly(points,true,'HATCH_FABRIC');g.entities.push({type:'hatch',layer:'HATCH_FABRIC',points,patternKind:'fabric',systemIndex:s.index});
        }
      }
    }
    if(cfg.double){
      // Split only shared transverse plan shapes when rear datums differ.
      // No member is reflected using another module's rear plane.
      const originals=cfg.continuous?g.entities.filter(e=>e.viewType==='TOP'&&!/^Ray - Üst/.test(e.layer||'')):top;
      const planes=new Set(systems.map(s=>s.mirrorDatumZ.toFixed(6)));
      const mirrorable=e=>!isSupport(e)&&e.type!=='dimension'&&e.type!=='interaction'&&(!cfg.continuous||(!/^FABRIC$|^HATCH_FABRIC$/.test(e.layer||'')&&!/TRAPEZ/.test(e.name||'')&&!/Ray Arka/.test(e.name||'')&&e.presentationRole!=='product-name'));
      for(const e of originals.filter(mirrorable)){
        if(planes.size===1){g.entities.push(N.mirrorY(e,-systems[0].mirrorDatumZ));continue;}
        const b=G.bounds([e],drawing.blocks),center=(b.minX+b.maxX)/2;
        for(const s of systems){
          const lo=s.outerStartX+origin,hi=s.outerEndX+origin;
          if(e.points&&b.minX<hi&&b.maxX>lo){const clipped=N.clipX(e,lo-(s.index===0?100:0),hi+(s.index===systems.length-1?100:0));if(clipped)g.entities.push(N.mirrorY(clipped,-s.mirrorDatumZ));}
          else if(center>=lo-.001&&center<hi+.001)g.entities.push(N.mirrorY(e,-s.mirrorDatumZ));
        }
      }
      // Mirrored native dimensions must never claim a neighboring module's depth.
      for(const s of systems){
        const x=s.outerEndX+origin,back=s.backExtentZ,forward=s.frontDatumZ;
        G.addDimV(g,-forward,-back,x,x+650,'',{edit:{dimId:'pergola_total_depth_'+s.index,field:'__info__',index:s.index,label:'Toplam açılım',editable:false,dimensionType:'main'},positionIndex:s.index});
      }
    }
    g.entities.push(...front);
    const topBounds=N.bounds(g.entities.filter(e=>e.viewType==='TOP'),drawing.blocks);
    const sideRanges=d.independentMode?d.independentSideViewRanges:d.sideViewRanges;
    // Right side is a normal view for every position, not a glazing-dependent
    // optional mirror. Existing user-hidden left views stay hidden.
    const declarations=[...(sideRanges||[])];
    if(!declarations.length)declarations.push({index:0,side:'left'});
    for(const s of systems)if(!declarations.some(v=>Number(v.index)===s.index&&v.side==='right'))
      declarations.push({index:s.index,side:'right'});
    const seenViews=new Set(),views=[];
    const frontBounds=N.bounds(front,drawing.blocks);
    const gutters=front.filter(e=>e.type==='polyline'&&e.layer==='PROFILE'&&e.points?.length===4);
    let bottomLeft=null,bottomRight=null;
    for(const declaration of declarations){
      const index=Number(declaration.index)||0,s=systems[index],right=declaration.side==='right';
      if(!s)continue;const key=index+'|'+(right?'right':'left');if(seenViews.has(key))continue;seenViews.add(key);
      const original=native.slice(declaration.start||0,declaration.end||0),sideKey=original.map(e=>e.data?.sideViewKey??e.edit?.sideViewKey).find(k=>k!=null);
      const p={...d.positions[index],index,sideViewKey:sideKey??(right?'right':String(index)),semanticMirror:right||sideKey==='right'};
      const sink=G.makeEntitySink();G.drawOneSideView(sink,d,p,0);
      const rear=sink.entities.find(e=>e.name==='PergoRise Ray Arka Mekanizma Yan Görünüş');
      if(!rear)throw Error('PERGOLA_NATIVE_REAR_PIVOT_MISSING');
      const sourceX=rear.x-K.sideArkaMekOffsetX,sourceY=rear.y-K.sideArkaMekOffsetY-s.rearHeight;
      const point=([x,y,z])=>[sourceX+z-s.rearDatumZ,sourceY+y];
      const rail=model.components.find(c=>c.kind==='rail'&&c.systemIndex===index&&c.wing!=='opposite');
      const rearPart=model.components.find(c=>c.kind==='rail-rear-mechanism'&&c.systemIndex===index&&c.wing!=='opposite');
      const own=[];
      const railFloor=Math.min(...sink.entities.filter(e=>e.layer==='Ray - Yan Görünüş').flatMap(e=>(e.points||[]).map(p=>p[1])));
      for(const seed of sink.entities){
        if(!keep(seed))continue;
        if(cfg.double&&isSupport(seed)&&!cfg.centralSteel)continue;
        if(cfg.curved&&seed.layer==='Ray - Yan Görünüş')continue;
        if(seed.profileRole==='trapez-side-surface')continue;
        if(cfg.continuous&&/Ray Arka Mekanizma|Ray Duvar Bağlantı/.test(seed.name||''))continue;
        if(cfg.continuous&&seed.edit?.field==='rearHeight')continue;
        if(cfg.curved&&seed.type==='text'&&/°/.test(seed.value||''))continue;
        const e=N.clone(seed);
        if((cfg.suspended||cfg.wing)&&e.type==='text'&&/°/.test(e.value||''))e.y=railFloor-250;
        if(e.name==='PergoRise Ray Arka Mekanizma Yan Görünüş'&&rearPart&&cfg.curved){
          [e.x,e.y]=point(rearPart.insertionAnchor);e.rotation=norm(-rearPart.rotationX*180/Math.PI);
        }
        if(!cfg.curved&&e.layer==='Ray - Yan Görünüş'&&e.points?.length===4){
          const endX=Math.max(...e.points.map(p=>p[0]));
          const deltaY=rail.end[1]-(rail.standardEnd?.[1]??rail.end[1]);
          const deltaZ=rail.end[2]-(rail.standardEnd?.[2]??rail.end[2]);
          e.points=e.points.map(([x,y])=>Math.abs(x-endX)<.001?[x+deltaZ,y+deltaY]:[x,y]);
        }
        if(e.name==='PergoRise Ray Kafası Yan Görünüş'){
          [e.x,e.y]=point(rail.standardEnd||rail.end);const tangent=rail.trajectory?V.sample(rail.trajectory,rail.trajectory.length).tangent:V.norm(V.sub(rail.end,rail.start));
          e.rotation=norm(Math.atan2(tangent[1],tangent[2])*180/Math.PI);
        }
        // Extend the existing native support outline, not a replacement wall sketch.
        if(cfg.suspended||cfg.wing){
          const height=s.rearHeight+cfg.geometry.anchorRise;
          if(e.layer==='Duvar - Yan Görünüş'||e.semantic==='rearSteelPost'){
            if(e.points){const ys=e.points.map(p=>p[1]),max=Math.max(...ys);e.points=e.points.map(([x,y])=>[x,Math.abs(y-max)<.001?sourceY+height:y]);}
          }
          if(e.type==='hatch'&&e.layer==='HATCH_WALL'){
            const max=Math.max(...e.points.map(p=>p[1]));e.points=e.points.map(([x,y])=>[x,Math.abs(y-max)<.001?sourceY+height:y]);
          }
        }
        own.push(e);
      }
      if(cfg.curved){
        const [cz,cy]=rail.curveCenter,center=[sourceX+cz-s.rearDatumZ,sourceY+cy],a=rail.start,b=rail.end;
        const start=norm(Math.atan2(b[1]-cy,b[2]-cz)*180/Math.PI),end=norm(Math.atan2(a[1]-cy,a[2]-cz)*180/Math.PI);
        for(const offset of [0,K.sideInnerRayOffsetY,K.sideInnerRayOffsetY+K.sideInnerRayH,K.sideRayH]){
          const radius=rail.curveRadius-offset,points=[];
          for(let j=0;j<=256;j++){const angle=(start+((end-start+360)%360)*j/256)*Math.PI/180;points.push([center[0]+radius*Math.cos(angle),center[1]+radius*Math.sin(angle)]);}
          own.push({type:'polyline',layer:'Ray - Yan Görünüş',closed:false,points,arc:{x:center[0],y:center[1],radius,start,end},componentKind:'rail',physicalPartId:rail.id});
        }
      }
      if(cfg.double){
        const reflection=sourceX+s.mirrorDatumZ-s.rearDatumZ;
        const mirror=own.filter(e=>!isSupport(e)&&(!cfg.continuous||e.componentKind!=='rail')).map(e=>{
          const m=N.mirrorX(e,reflection);m.wing='opposite';
          if(m.edit){m.edit={...m.edit};if(m.edit.field==='opening')m.edit.dimensionType='detail';}
          return m;
        });own.push(...mirror);
      }
      for(const c of model.components.filter(c=>c.kind==='suspension-stay'&&c.systemIndex===index)){
        const hull=V.hull(V.vertices(c).map(point));own.push({type:'polyline',points:hull,closed:true,layer:'ASKI',componentKind:c.kind,physicalPartId:c.id});
      }
      if(cfg.suspended||cfg.wing){
        const extra=G.makeEntitySink();G.addDimV(extra,sourceY,sourceY+s.rearHeight+cfg.geometry.anchorRise,sourceX,sourceX-1500,'',{edit:{dimId:'anchor_height_'+index,field:'__info__',index,label:'Askı üst kotu',editable:false,dimensionType:'main'}});own.push(...extra.entities);
      }
      if(cfg.continuous){
        const extra=G.makeEntitySink(),centerX=point([0,0,s.mirrorDatumZ])[0];
        G.addDimV(extra,sourceY,sourceY+s.rearHeight,centerX,centerX+180,'',{edit:{dimId:'quad_apex_'+index,field:'rearHeight',index,label:'Orta üst kot',dimensionType:'main'}});
        G.addDimH(extra,point([0,0,s.backExtentZ])[0],point([0,0,s.frontDatumZ])[0],sourceY,sourceY-850,'',{edit:{dimId:'quad_depth_'+index,field:'__info__',index,label:'Toplam açılım',editable:false,dimensionType:'main'}});own.push(...extra.entities);
      }
      // The rear wall bracket and rear mechanism must align by their actual
      // lower mounting-hole centres in side elevation. The preserved native
      // CAD blocks contain many circles; using the lowest circle picks the
      // perforated base row instead of the intended mounting hole.
      if(!cfg.continuous){
        const alignmentHole=name=>{
          const circles=(drawing.blocks[name]?.entities||[]).filter(e=>e.type==='circle');
          if(!circles.length)return null;
          if(name==='PergoRise Ray Duvar Bağlantı Set')return circles[0];
          if(name==='PergoRise Ray Arka Mekanizma Yan Görünüş'){
            const mounts=circles.filter(e=>Math.abs((e.r||0)-7.75)<.05&&e.x>80&&e.x<145);
            return mounts.sort((a,b)=>a.y-b.y)[0]||null;
          }
          return circles[0]||null;
        };
        const wallHole=alignmentHole('PergoRise Ray Duvar Bağlantı Set');
        const mechHole=alignmentHole('PergoRise Ray Arka Mekanizma Yan Görünüş');
        const transformed=(h,insert)=>{
          const a=(insert.rotation||0)*Math.PI/180,sx=Math.abs(Number(insert.scaleX)||1),sy=Number(insert.scaleY)||1;
          const x=(insert.mirrorX?-h.x:h.x)*sx,y=h.y*sy;
          return [insert.x+x*Math.cos(a)-y*Math.sin(a),insert.y+x*Math.sin(a)+y*Math.cos(a)];
        };
        for(const wing of ['main','opposite']){
          const belongs=e=>(e.wing||'main')===wing;
          const wall=own.find(e=>belongs(e)&&e.name==='PergoRise Ray Duvar Bağlantı Set');
          const mechanism=own.find(e=>belongs(e)&&e.name==='PergoRise Ray Arka Mekanizma Yan Görünüş');
          if(!wall||!mechanism||!wallHole||!mechHole)continue;
          const [wx,wy]=transformed(wallHole,wall),[mx,my]=transformed(mechHole,mechanism);
          mechanism.x+=wx-mx;mechanism.y+=wy-my;
          mechanism.lowerMountHoleAligned=true;
        }
      }
      // Native custom profile/triangle/parapet edits remain on their original entities.
      const gutter=gutters.find(e=>{const b=G.bounds([e],drawing.blocks);return (b.minX+b.maxX)/2>=s.outerStartX+origin-100&&(b.minX+b.maxX)/2<=s.outerEndX+origin+100;})||gutters[0];
      const frontFloor=gutter?G.bounds([gutter],drawing.blocks).minY-s.frontHeight:frontBounds.minY-46;
      let entities=own.map(e=>N.move(e,0,frontFloor-sourceY));
      if(right){const b=N.bounds(entities,drawing.blocks);entities=entities.map(e=>N.mirrorX(e,(b.minX+b.maxX)/2));const mb=N.bounds(entities,drawing.blocks);entities=entities.map(e=>N.move(e,frontBounds.maxX+1000-mb.minX,0));}
      const bound=N.bounds(entities,drawing.blocks),previous=right?bottomRight:bottomLeft;
      if(previous!=null&&bound.maxY>previous-1000)entities=entities.map(e=>N.move(e,0,previous-1000-bound.maxY));
      const placed=N.bounds(entities,drawing.blocks);if(right)bottomRight=placed.minY;else bottomLeft=placed.minY;
      N.stamp(entities,'SIDE',index);
      for(const entity of entities)entity.projectionView='side-'+index+'-'+(right?'right':'left');
      g.entities.push(...entities);
      const title=g.text((placed.minX+placed.maxX)/2,placed.maxY+230,'POZ '+(index+1)+' · '+(right?'SAĞ':'SOL')+' YAN GÖRÜNÜŞ',105,'TITLE','center');title.presentationRole='view-title';title.systemIndex=index;
      views.push({id:key,kind:'SIDE',systemIndex:index,side:right?'right':'left',bounds:placed});
    }
    // Physical rear elevations (not copies of the front projection).
    // Each system has its own rear steel/wall/rail cross sections.
    // Place the whole rear-elevation group above the top view, centered on the
    // same vertical axis, with a visible gap and no overlap.
    const rearViews=[];
    const rearGroups=[];
    const mirrorX=x=>frontBounds.minX+frontBounds.maxX-(x+origin);
    for(const s of systems){
      const rearSink=G.makeEntitySink();
      const rear=[];
      const put=(points,layer,part)=>{
        const e=rearSink.poly(points.map(([x,y])=>[mirrorX(x),y]),true,layer);
        e.componentKind=part.kind;e.physicalPartId=part.id;rear.push(e);
      };
      for(const c of model.components.filter(c=>(c.systemIndex===s.index||c.systemIndices?.includes(s.index))&&
        ['rear-wall','rear-steel-beam','rear-steel-post','central-mast','ridge-beam'].includes(c.kind)&&!c.technicalOnly)){
        const pts=V.vertices(c),xs=pts.map(v=>v[0]),ys=pts.map(v=>v[1]);
        const x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys);
        if(x1-x0>.001&&y1-y0>.001)put([[x0,y0],[x1,y0],[x1,y1],[x0,y1]],'PROFILE',c);
      }
      const rails=model.components.filter(c=>c.kind==='rail'&&c.systemIndex===s.index);
      for(const r of rails){
        const end=r.standardStart||r.start,section=r.section||[K.rayW,K.sideRayH];
        const x0=r.axisX-section[0]/2,x1=r.axisX+section[0]/2;
        put([[x0,end[1]-section[1]],[x1,end[1]-section[1]],[x1,end[1]],[x0,end[1]]],'Ray - Ön Görünüş',r);
      }
      N.stamp(rear,'REAR',s.index);
      const b=N.bounds(rear,drawing.blocks);
      const title=rearSink.text((b.minX+b.maxX)/2,b.maxY+230,'POZ '+(s.index+1)+' · ARKA GÖRÜNÜŞ',105,'TITLE','center');
      title.presentationRole='view-title';title.viewType='REAR';title.systemIndex=s.index;
      rearGroups.push({id:'rear-'+s.index,systemIndex:s.index,bounds:b,entities:rearSink.entities});
    }
    if(rearGroups.length){
      const union=rearGroups.reduce((acc,group)=>({
        minX:Math.min(acc.minX,group.bounds.minX),
        maxX:Math.max(acc.maxX,group.bounds.maxX),
        minY:Math.min(acc.minY,group.bounds.minY),
        maxY:Math.max(acc.maxY,group.bounds.maxY)
      }),{minX:Infinity,maxX:-Infinity,minY:Infinity,maxY:-Infinity});
      const dx=((topBounds.minX+topBounds.maxX)/2)-((union.minX+union.maxX)/2);
      const dy=(topBounds.maxY+1200)-union.minY;
      for(const group of rearGroups){
        const moved=group.entities.map(e=>N.move(e,dx,dy));
        g.entities.push(...moved);
        rearViews.push({id:group.id,kind:'REAR',systemIndex:group.systemIndex,bounds:{
          minX:group.bounds.minX+dx,maxX:group.bounds.maxX+dx,
          minY:group.bounds.minY+dy,maxY:group.bounds.maxY+dy
        }});
      }
    }
    // Native hidden-dimension identifiers survive regenerated side views.
    const hidden=new Set(d.hiddenDimensionIds||[]);
    for(const e of g.entities.filter(e=>e.type==='dimension')){
      const id=e.edit?.dimId||e.dimensionId;
      if(id&&hidden.has(String(id)))e.hiddenDimension=true;
    }
    drawing.entities=g.entities;
    const smart=G.buildSmartMetadata(drawing.entities,d);drawing.smartDimensions=smart.dimensions;drawing.zones=smart.zones;drawing.profileInstances=smart.profileInstances;
    drawing.orthographicViews=[{id:'top',kind:'TOP'},{id:'front',kind:'FRONT'},...views,...rearViews];
  }
  root.PLMRPergolaOrthographic=Object.freeze({project});
})(window);
