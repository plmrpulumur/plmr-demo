/* Read-only native drawing -> physical part metadata. No persistent editor state here. */
(function(root){
  'use strict';
  const clone=x=>JSON.parse(JSON.stringify(x));
  function project(drawing,assembly,components){
    const d=drawing.input,K=root.PulumurGeometry.K,blocks=drawing.blocks;
    const bounds=name=>blocks[name].bounds;
    const labels={'rear-steel-beam':'Arka Çelik Kiriş','rear-steel-post':'Arka Çelik Dikme',rail:'Ray',gutter:'Oluk',post:'Dikme','side-support-post':'Yan Dikme','glass-track':'Yan Kayıt',
      'roof-register-profile':'Travers · Çatı Kayıt Profili','horizontal-profile':'Yatay Profil','trapez-sheet':'Trapez Sac',
      'rail-rear-mechanism':'Arka Ray Mekanizması','rail-front-head':'Ön Ray Mekanizması','post-upper-connection':'Dikme Oluk Bağlantısı','post-lower-connection':'Dikme Alt Bağlantısı','triangle-frame':'Aldoks Doğrama','rear-wall':'Arka Duvar',parapet:'Parapet','water-outlet':'Su Çıkışı'};
    const out=[];
    for(const source of components){
      if(['rear-profile','front-profile','fabric-stack','area-product'].includes(source.kind))continue;
      const c=clone(source),s=assembly.systems[c.systemIndex||0];
      c.label=labels[c.kind]||c.kind;
      if(c.kind==='rail'){
        c.section=[K.rayW,K.sideRayH];
        c.dimensionId='top_ray_spacing_'+c.systemIndex+'_'+Math.max(0,c.railIndex===0?0:c.railIndex-1);
      }else if(c.kind==='roof-register-profile'){
        c.editor='[data-interaction-type="trapezSheetEditor"][data-system-index="'+c.systemIndex+'"]';
      }else if(c.kind==='gutter'){
        const parts=root.PulumurGeometry.gutterParts(d,{start:c.sourceStartX,end:c.sourceEndX});
        for(const part of parts){
          const min=part.start-assembly.origin.sourceX,max=part.end-assembly.origin.sourceX;
          out.push({...c,id:c.id+'-part-'+(part.index+1),start:[min,c.start[1],c.start[2]],end:[max,c.end[1],c.end[2]],length:part.length,jointAfter:part.jointAfter,
            sourceStartX:part.start,sourceEndX:part.end,editor:'[data-interaction-type="gutterEditor"]',sectionKind:'open-gutter'});
        }
        continue;
      }else if(c.kind==='rail-rear-mechanism'||c.kind==='rail-front-head'){
        const rear=c.kind==='rail-rear-mechanism',plan=bounds(rear?'PergoRise Ray Arka Mekanizma Üst Görünüş':'PergoRise Ray Kafası Üst Görünüş');
        const elevation=bounds(rear?'PergoRise Ray Arka Mekanizma Yan Görünüş':'PergoRise Ray Kafası Ön Görünüş');
        const rail=components.find(x=>x.kind==='rail'&&x.systemIndex===c.systemIndex&&x.railIndex===c.railIndex);
        const anchor=rear?rail.start:rail.end;
        const direction=rail.end.map((v,i)=>v-rail.start[i]),length=Math.hypot(...direction);
        const tangent=direction.map(v=>v/length),normal=[0,tangent[2],-tangent[1]];
        c.size=[plan.width,elevation.height,plan.height];
        c.position=anchor.map((v,i)=>v+tangent[i]*(rear?-1:1)*c.size[2]/2-normal[i]*c.size[1]/2);
        c.rotationX=-rail.angleRad;c.joint=anchor;c.railId=rail.id;
        if(rear){
          const envelope=root.PulumurGeometry.rearMechanismEnvelope(d,d.systems[c.systemIndex],d.positions[c.systemIndex],rail.axisX+assembly.origin.sourceX);
          c.prismVertices=envelope.vertices.map(v=>[v[0]-assembly.origin.sourceX,v[1],v[2]]);
          c.mountFaceZ=envelope.rearZ;c.mountSource='native-rear-mechanism-envelope';
        }

        delete c.start;delete c.end;
      }else if(c.kind==='post-upper-connection'||c.kind==='post-lower-connection'){
        const post=components.find(p=>p.kind==='post'&&p.postIndex===c.postIndex),upper=c.kind==='post-upper-connection';
        const front=bounds(upper?'PergoRise Dikme Oluk Bağlantı Karşı Görünüş':'PergoRise Dikme Alt Bağlantı Karşı Görünüş');
        const plan=upper?bounds('PergoRise Dikme Oluk Bağlantı Üst Görünüş'):bounds('PergoRise Dikme Alt Bağlantı Yan Görünüş');
        const anchor=upper?post.topY:post.bottomY;
        c.position=[post.renderCenterX,anchor+(front.minY+front.maxY)/2,upper?s.frontDatumZ-plan.height/2:post.start[2]];
        c.size=[front.width,front.height,upper?plan.height:plan.width];
      }else if(c.kind==='post')c.editor='[data-interaction-type="postEditor"][data-post-index="'+c.postIndex+'"]';
      else if(c.kind==='side-support-post'){
        const plan=drawing.entities.find(e=>e.profileRole==='side-support-plan'&&e.sidePostId===c.profileId&&e.sideViewKey===c.sideViewKey);
        if(plan){const xs=plan.points.map(p=>p[0]),zs=plan.points.map(p=>-p[1]);
          const x=(Math.min(...xs)+Math.max(...xs))/2-assembly.origin.sourceX,z=(Math.min(...zs)+Math.max(...zs))/2;
          c.start[0]=c.end[0]=x;c.start[2]=c.end[2]=z;
          c.section=[Math.max(...xs)-Math.min(...xs),Math.max(...zs)-Math.min(...zs)];}
        c.editor='[data-interaction-type="glassTrackEditor"][data-side-post-id="'+c.profileId+'"]';
      }else if(c.kind==='glass-track'){
        const plan=drawing.entities.find(e=>e.profileRole==='side-track'&&e.sideViewKey===c.sideViewKey);
        if(plan){const xs=plan.points.map(p=>p[0]),zs=plan.points.map(p=>-p[1]);
          const x=(Math.min(...xs)+Math.max(...xs))/2-assembly.origin.sourceX;
          c.start=[x,c.start[1],Math.min(...zs)];c.end=[x,c.end[1],Math.max(...zs)];}
        c.editor='[data-interaction-type="glassTrackEditor"][data-profile-part="track"][data-side-view-key="'+c.sideViewKey+'"]';
      }else if(c.kind==='horizontal-profile')c.editor='[data-interaction-type="horizontalProfileEditor"][data-horizontal-profile-id="'+c.id+'"]';
      else if(c.kind==='triangle-frame'){
        const mount=root.PulumurGeometry.triangleMount(d.systems[c.systemIndex],c.sideViewKey);
        c.depth=mount.depth;c.railEdge=mount.edge-assembly.origin.sourceX;c.clearance=mount.clearance;c.x=mount.centerX-assembly.origin.sourceX;
        c.editor='[data-interaction-type="triangleEditor"][data-side-view-key="'+c.sideViewKey+'"]';
      }
      out.push(c);
    }
    // Real end caps and the ray/gutter bracket envelopes share the native orthographic bounds.
    for(const g of out.filter(c=>c.kind==='gutter')){
      const cap=blocks['PergoRise Oluk Yan Kapak'].entities.find(e=>e.type==='polyline'&&e.closed);
      for(const [end,x]of [['left',g.start[0]],['right',g.end[0]]]){
        const isJoint=end==='right'?g.jointAfter:out.some(o=>o.kind==='gutter'&&o!==g&&Math.abs(o.end[0]-x)<.001);
        if(isJoint)continue;
        out.push({id:g.id+'-cap-'+end,kind:'gutter-cap',label:'Oluk Yan Kapağı',systemIndex:g.systemIndex,x,
          z:g.start[2],y:g.bottomDatumY,points:cap.points,thickness:1.6});
      }
    }
    for(const rail of out.filter(c=>c.kind==='rail')){
      const system=assembly.systems[rail.systemIndex],section=bounds('PergoRise Oluk-Ray Bağlantı Aparat Set');
      out.push({id:'gutter-ray-connection-'+rail.systemIndex+'-'+rail.railIndex,kind:'gutter-ray-connection',label:'Oluk Ray Bağlantısı',systemIndex:rail.systemIndex,
        position:[rail.axisX,system.frontHeight+K.frontGutterH+section.height/2,system.frontDatumZ-section.width/2],
        size:[K.rayW,section.height,section.width],envelopeSource:['PergoRise Oluk-Ray Bağlantı Aparat Set','K.rayW']});
    }
    return out;
  }
  root.PLMRPergolaParts=Object.freeze({project});
})(window);
