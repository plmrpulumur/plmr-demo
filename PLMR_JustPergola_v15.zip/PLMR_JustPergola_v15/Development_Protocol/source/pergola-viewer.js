(function(root){
  'use strict';
  const T=root.THREE;
  function mount(stage,callbacks={}){
    const scene=new T.Scene();
    const camera=new T.PerspectiveCamera(38,1,80,250000);
    camera.position.set(7000,5800,9000);
    const renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true,stencil:true});
    renderer.outputEncoding=T.sRGBEncoding;
    const background=(value)=>{const bg=root.PLMRV27Scene.background(value);if(value==='empty')bg.encoding=T.sRGBEncoding;return bg;};
    scene.background=background('empty');
    renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));
    stage.append(renderer.domElement);
    const controls=new T.OrbitControls(camera,renderer.domElement);
    root.PLMRSceneInteraction.configure(controls);
    scene.add(new T.HemisphereLight(0xffffff,0xd1d4d7,.76),new T.AmbientLight(0xffffff,.17));
    function light(intensity,position){
      const lamp=new T.DirectionalLight(0xffffff,intensity);
      lamp.position.fromArray(position);
      scene.add(lamp);
    }
    light(.53,[4000,8000,6000]);
    light(.25,[-5000,5000,-3000]);
    let assembly=new T.Group(),motions=[],progress=0,disposed=false,motionTarget=0,motionLast=0;
    let draws=0,view='3D',owners=[],zoneMeshes=[],sceneTools=null,currentTool='select',latestModel=null;
    let partSelection=null,partOutline=null;
    let sketch=null,wallModels=[],interactive=[];
    const wallHost=new T.Group();scene.add(wallHost);
    let zoneInteraction=null,referenceGeometry=null;
    let cube=null,presentation={environment:'empty',floor:'none'},presentationRevision=0;
    root.PLMRV27Host=Object.freeze({floor:()=>presentation.floor,frame:()=>({key:JSON.stringify(presentation)+presentationRevision,presentation})});
    const canvas=renderer.domElement;canvas.tabIndex=0;
    scene.add(assembly);
    const stencilReady=new WeakSet();
    function prepareCoverStencil(){
      scene.traverse(mesh=>{if(!mesh.isMesh)return;
        for(const material of Array.isArray(mesh.material)?mesh.material:[mesh.material]){
          if(!material||material.transparent||material.userData.plmrCoverOverlay||stencilReady.has(material))continue;
          material.stencilWrite=true;material.stencilFunc=T.AlwaysStencilFunc;
          material.stencilRef=material.userData.plmrSheetSupport?1:0;
          material.stencilZPass=T.ReplaceStencilOp;stencilReady.add(material);
        }
      });
    }
    function render(){
      if(!disposed&&view==='3D'){
        prepareCoverStencil();renderer.render(scene,camera);
        draws++;
        cube?.update();
      }
    }
    function resize(){
      if(view!=='3D'||!stage.clientWidth||!stage.clientHeight)return;
      renderer.setSize(stage.clientWidth,stage.clientHeight,false);
      camera.aspect=stage.clientWidth/stage.clientHeight;
      camera.updateProjectionMatrix();
      render();
    }
    const observer=new ResizeObserver(resize);
    observer.observe(stage);
    controls.addEventListener('change',()=>zoneInteraction?.changed());
    function clear(node){
      const materials=new Set();
      node.traverse(o=>{
        o.geometry?.dispose();
        for(const m of Array.isArray(o.material)?o.material:o.material?[o.material]:[])materials.add(m);
      });
      for(const m of materials)m.dispose();
      node.parent?.remove(node);
    }
    function fit(){
      const bounds=new T.Box3().setFromObject(assembly);
      if(bounds.isEmpty())return;
      const target=bounds.getCenter(new T.Vector3()),size=bounds.getSize(new T.Vector3());
      const half=T.MathUtils.degToRad(camera.fov/2);
      const distance=size.length()/2/Math.sin(Math.min(half,Math.atan(Math.tan(half)*camera.aspect)))*1.1;
      const axis=camera.position.clone().sub(controls.target).normalize();
      controls.target.copy(target);
      camera.position.copy(target).addScaledVector(axis,distance);
      controls.maxDistance=Math.max(distance*5,10000);
      controls.update();render();
    }
    function buildAssembly(model){
      const next=new T.Group(),updated=[],resources=new Set();
      const K=root.PulumurGeometry.K;
      const paint=root.PLMRPowderCoat.create(model.paint,model.finish);
      const schematic=new Map();
      const palette=root.PLMRPergolaColors;
      function materialFor(c){
        if(c?.kind==='fabric')return membrane;
        const rank=c?.kind==='triangle-frame'?2:c?.kind==='gutter'||c?.kind==='gutter-cap'?3:c?.kind==='roof-register-profile'?-8:1;
        const color=model.schematic?palette.profile(c?.kind):model.paint,key=color+'|'+rank;
        if(!schematic.has(key)){const material=root.PLMRSolidMesh.surface(root.PLMRPowderCoat.create(color,model.schematic?'MATTE':model.finish),rank);material.userData.plmrSheetSupport=c?.kind==='roof-register-profile';schematic.set(key,material);}
        return schematic.get(key);
      }
      let currentComponent=null;
      const profile=root.PLMRSolidMesh.surface(root.PLMRPowderCoat.create(model.fabricProfile,model.finish),1);
      const membrane=new T.MeshStandardMaterial({polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1,color:new T.Color(model.schematic?palette.fabric:model.fabric).convertSRGBToLinear(),side:T.DoubleSide,roughness:.87});
      const panel=root.PLMRPowderCoat.create(model.schematic?palette.sheet:model.paint,model.finish);
      root.PLMRSolidMesh.surface(membrane,2);panel.side=T.DoubleSide;root.PLMRSolidMesh.surface(panel,4);
      const glass=new T.MeshStandardMaterial({color:0xa5c4d3,roughness:.23,transparent:true,opacity:.33,depthWrite:false});
      const [wall,...unusedWallMaterials]=root.PLMRV27Scene.wallMaterials([1,1,1],model.wallAppearance);
      unusedWallMaterials.forEach(m=>m.dispose());
      wall.side=T.DoubleSide;
      const materials=[paint,profile,membrane,panel,glass,wall];
      function part(group,id,geometry,material,at=[0,0,0]){
        const mesh=new T.Mesh(geometry,material);
        mesh.name=id;mesh.position.fromArray(at);mesh.userData.isProduct=true;mesh.userData.component=currentComponent;
        group.add(mesh);for(const m of Array.isArray(material)?material:[material])resources.add(m);
        return mesh;
      }
      const names={
        rail:'Ray','rail-rear-mechanism':'Arka mekanizma','rail-front-head':'Ray kafası',
        'roof-register-profile':'Tavan kaydı',
        'trapez-sheet':'Trapez sac','rear-wall':'Arka duvar',parapet:'Parapet',gutter:'Oluk',post:'Ön dikme',
        'post-upper-connection':'Dikme üst bağlantı','post-lower-connection':'Dikme alt bağlantı',
        'glass-track':'Cam kaydı','triangle-joinery':'Üçgen doğrama','water-outlet':'Su çıkışı',
        'side-support-post':'Yan dikme','rear-steel-beam':'Arka çelik kiriş','rear-steel-post':'Arka çelik dikme',
        'horizontal-profile':'Yatay profil'
      };
      const VG=root.PLMRPergolaVariantGeometry;
      const sections={
        rail:[K.rayW,K.sideRayH],'rail-rear-mechanism':[95,90],'rail-front-head':[100,90],
        'roof-register-profile':[59,K.catiProfilH]
      };
      function beam(c,group,label){
        const start=new T.Vector3(...c.start),end=new T.Vector3(...c.end);
        const direction=end.clone().sub(start),length=direction.length();
        if(length<.001)return;
        const vertical=Math.abs(direction.y)/length>.999;
        const transverse=Math.abs(direction.x)/length>.999;
        const section=c.section||sections[c.kind]||(c.profileSection?
          [c.profileSection.heightY,c.profileSection.depthZ]:
          [c.profileWidthX||c.profileEn||K.postSize,c.profileDepthZ||c.profileBoy||K.postSize]);
        const [u,v]=section;
        const t=Math.max(0,Math.min(c.thickness||c.profileThickness||c.profileWallThickness||0,Math.min(u,v)/2-.01));
        const physicalFrame=VG.frame(c,section),center=new T.Vector3(...physicalFrame.center);
        const shape=new T.Group();
        const material=materialFor(c);
        group.add(shape);shape.position.copy(center);
        shape.quaternion.setFromRotationMatrix(new T.Matrix4().makeBasis(...physicalFrame.axes.map(a=>new T.Vector3(...a))));
        // Local section axes are width/height for longitudinal members,
        // height/depth for transverse members, width/depth for vertical ones.
        const box=(a,b,x=0,y=0)=>{
          if(transverse)part(shape,label,new T.BoxGeometry(b,a,length),material,[y,x,0]);
          else part(shape,label,new T.BoxGeometry(a,b,length),material,[x,y,0]);
        };
        if(c.kind==='water-outlet'||c.kind==='suspension-stay'){
          const cylinder=new T.CylinderGeometry(u/2,u/2,length,24);
          cylinder.rotateX(Math.PI/2);
          part(shape,label,cylinder,material);
        }else if(t){
          box(t,v,-(u-t)/2);box(t,v,(u-t)/2);
          box(u-2*t,t,0,-(v-t)/2);box(u-2*t,t,0,(v-t)/2);
        }else{
          if(c.kind==='rail')shape.position.addScaledVector(new T.Vector3(0,1,0).applyQuaternion(shape.quaternion),-v/2);
          box(u,v);
        }
      }
      function sheetPart(group,label,geometry,c){
        const sheet=part(group,label,geometry,panel);sheet.renderOrder=1;
        const material=panel.clone();material.userData.plmrCoverOverlay=true;
        Object.assign(material,{depthTest:false,depthWrite:false,polygonOffset:false,stencilWrite:true,stencilRef:1,stencilFunc:T.EqualStencilFunc,stencilZPass:T.ZeroStencilOp});
        const cover=new T.Mesh(geometry.clone(),material);cover.renderOrder=2;cover.userData.presentationAnnotation=true;group.add(cover);resources.add(material);
        const vertices=VG.vertices(c),a=vertices[0],b=vertices.at(-1),point=new T.Vector3(...a),normal=new T.Vector3(0,Math.abs(b[2]-a[2]),-(b[1]-a[1])*(c.zSign||1)).normalize(),eye=new T.Vector3();
        cover.onBeforeRender=(_renderer,_scene,viewCamera)=>{group.worldToLocal(viewCamera.getWorldPosition(eye));material.colorWrite=normal.dot(eye.sub(point))>=0;};
      }
      function wallGeometry(c){
        const points=c.polygonXZ;
        const y=c.bottomY;
        const h=(i)=>{
          if(c.startHeight==null||c.endHeight==null)return c.topY;
          const last=c.parapetView==='side'?i>=2:i===1||i===2;
          return last?c.endHeight:c.startHeight;
        };
        const vertices=[...points.map(([x,z])=>[x,y,z]),...points.map(([x,z],i)=>[x,h(i),z])];
        const faces=[];
        for(let i=1;i<points.length-1;i++){
          faces.push([0,i+1,i],[points.length,points.length+i,points.length+i+1]);
        }
        for(let i=0;i<points.length;i++){
          const j=(i+1)%points.length,n=points.length;
          faces.push([i,j,n+j],[i,n+j,n+i]);
        }
        const geometry=new T.BufferGeometry(),positions=[],uv=[];
        for(const f of faces){
          const vs=f.map(i=>vertices[i]);
          const normal=new T.Vector3(...vs[1]).sub(new T.Vector3(...vs[0])).cross(new T.Vector3(...vs[2]).sub(new T.Vector3(...vs[0])));
          for(const point of vs){
            positions.push(...point);
            uv.push((Math.abs(normal.x)>Math.abs(normal.z)?point[2]:point[0])/1536,
              (Math.abs(normal.y)>Math.max(Math.abs(normal.x),Math.abs(normal.z))?point[2]:point[1])/1536);
          }
        }
        geometry.setAttribute('position',new T.Float32BufferAttribute(positions,3));
        geometry.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
        geometry.computeVertexNormals();
        return geometry;
      }
      try{
        const groups=model.positions.map(p=>{
          const group=new T.Group();group.name='Pergola '+p.number;
          group.userData.plmrDaeGroup={key:p.id,name:group.name};
          next.add(group);
          return group;
        });
        const shared=new T.Group();
        shared.name='Pergola ortak taşıyıcı';
        shared.userData.plmrDaeGroup={key:'shared',name:shared.name};
        next.add(shared);
        for(const c of model.components){
          if(c.technicalOnly)continue;
          currentComponent=c;
          const group=c.systemIndices?.length>1?shared:groups[c.systemIndex]||shared;
          const label=(names[c.kind]||c.kind)+' '+c.id;
          if(c.meshData){
            const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(c.meshData.positions,3));geometry.setIndex(c.meshData.indices);geometry.computeVertexNormals();
            if(c.kind==='trapez-sheet')sheetPart(group,label,geometry,c);else part(group,label,geometry,materialFor(c));
          }else if(c.kind==='gutter'){
            const depth=c.profileSection.depthZ,height=c.profileSection.heightY,short=66,t=1.6;
            const points=VG.gutterContour(depth,height);
            const geometry=new T.ExtrudeGeometry(new T.Shape(points.map(p=>new T.Vector2(...p))),{depth:c.length,bevelEnabled:false,steps:1});
            const a=geometry.attributes.position;
            for(let i=0;i<a.count;i++){const z=a.getX(i),y=a.getY(i),x=a.getZ(i);a.setXYZ(i,c.start[0]+x,c.bottomDatumY+y,c.start[2]+(c.zSign||1)*z);}
            if(c.zSign!==-1)root.PLMRSolidMesh.reverseFaces(geometry);else geometry.computeVertexNormals();part(group,label,geometry,materialFor(c));
            if(c.jointAfter){
              const edge=points.map(([z,y])=>new T.Vector3(c.end[0],c.bottomDatumY+y,c.start[2]+(c.zSign||1)*z));
              const seam=new T.LineLoop(new T.BufferGeometry().setFromPoints(edge),new T.LineBasicMaterial({color:0x8f4b00}));
              seam.userData.component=c;group.add(seam);
            }
          }else if(c.kind==='gutter-cap'){
            const shape=new T.Shape(c.points.map(([u,v])=>new T.Vector2(u,v)));
            const geometry=new T.ExtrudeGeometry(shape,{depth:c.thickness,bevelEnabled:false,steps:1});const a=geometry.attributes.position;
            for(let i=0;i<a.count;i++){const z=a.getX(i),y=a.getY(i),x=a.getZ(i);a.setXYZ(i,c.x+x-c.thickness/2,c.y+y,c.z+(c.zSign||1)*z);}
            if(c.zSign!==-1)root.PLMRSolidMesh.reverseFaces(geometry);else geometry.computeVertexNormals();part(group,label,geometry,materialFor(c));
          }else if(c.kind==='triangle-frame'){
            const polys=c.geometry.polygons;
            const shape=new T.Shape(polys[0].map(p=>new T.Vector2(...p)));
            if(polys[1])shape.holes.push(new T.Path(polys[1].map(p=>new T.Vector2(...p)).reverse()));
            function extrude(shape,depth,material,label){
              const geometry=new T.ExtrudeGeometry(shape,{depth,bevelEnabled:false,steps:1});
              const a=geometry.attributes.position;
              for(let i=0;i<a.count;i++){const u=a.getX(i),y=a.getY(i),t=a.getZ(i);a.setXYZ(i,c.x+t-depth/2,c.y+y,c.z+(c.zSign||1)*u);}
              if(c.zSign!==-1)root.PLMRSolidMesh.reverseFaces(geometry);else geometry.computeVertexNormals();part(group,label,geometry,material);
            }
            extrude(shape,c.depth,materialFor(c),label);
            for(const poly of polys.slice(2))extrude(new T.Shape(poly.map(p=>new T.Vector2(...p))),c.depth,materialFor(c),label+' ara kayıt');
            if(polys[1])extrude(new T.Shape(polys[1].map(p=>new T.Vector2(...p))),6,glass,label+' cam');
          }else if(c.polygonXZ){
            if(c.startHeight==null||Math.abs(c.startHeight-c.endHeight)<.01)continue;
            const mesh=part(group,label,wallGeometry(c),wall);
            Object.assign(mesh.userData,{isSketchWallFace:true,isParapet:c.kind==='parapet',wallId:c.id,component:c});
          }else if(c.prismVertices){
            const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(c.prismVertices.flat(),3));
            g.setIndex([0,2,1,0,3,2,4,5,6,4,6,7,0,1,5,0,5,4,1,2,6,1,6,5,2,3,7,2,7,6,3,0,4,3,4,7]);
            if(c.wing==='opposite')root.PLMRSolidMesh.reverseFaces(g);else g.computeVertexNormals();part(group,label,g,materialFor(c));
          }else if(c.corners){
            const g=new T.BufferGeometry();
            g.setAttribute('position',new T.Float32BufferAttribute(c.corners.flat(),3));
            g.setIndex([0,2,1,0,3,2]);g.computeVertexNormals();
            sheetPart(group,label,g,c);
          }else if(c.start&&c.end){
            beam(c,group,label);
          }else if(c.size){
            const mesh=part(group,label,new T.BoxGeometry(...c.size),materialFor(c),c.position);
            if(c.rotationX!=null)mesh.rotation.x=c.rotationX;
          }
        }
        for(const [i,p] of model.positions.entries()){
          for(const [j,roof] of p.roofs.entries()){
            const [x,y,z]=roof.start;
            const slope=new T.Group();
            if(!roof.trajectory){slope.position.set(x,y-K.sideRayH-7,z);slope.rotation.x=-roof.angle;}
            groups[i].add(slope);
            const C=root.PLMRBioclimaticRoof;
            // The Antero contract supplies the bar count, pitch and retraction centers.
            const module={gutterWidth:roof.width+340,depth:roof.length+340,centerX:0,centerZ:roof.length/2,rearToFrontSign:1};
            const layout=C.layout(module,'antero',0),bars=[];
            currentComponent={id:'fabric-'+i+'-'+j,kind:'fabric',label:'Kumaş · P'+(i+1),systemIndex:i};
            const carrierMaterial=(model.schematic?materialFor({kind:'roof-register-profile'}):profile).clone();
            carrierMaterial.userData.plmrSheetSupport=false;carrierMaterial.polygonOffset=false;const carrierEye=new T.Vector3();
            for(let n=0;n<layout.count;n++){
              const bar=part(slope,'Kumaş taşıyıcı '+(n+1),new T.BoxGeometry(roof.width,30,35),carrierMaterial,[0,-15,0]);
              // Paint the covered carrier before its opaque textile. From outside,
              // it must not write a competing coplanar depth. From below it remains
              // an ordinary opaque closed solid. Neither geometry nor exports change.
              bar.renderOrder=-1;
              bar.onBeforeRender=(_renderer,_scene,viewCamera)=>{slope.worldToLocal(viewCamera.getWorldPosition(carrierEye));const normal=bar.userData.fabricNormal||new T.Vector3(0,1,0),top=bar.position.clone().addScaledVector(normal,15);carrierMaterial.depthWrite=carrierEye.sub(top).dot(normal)<0;};
              bars.push(bar);
            }
            // One continuous indexed membrane per system: shared seam vertices prevent
            // sub-pixel raster cracks exposing the carrier under adjacent fabric panels.
            const steps=14,segments=(layout.count-1)*steps+1;
            const geometry=new T.PlaneGeometry(roof.width,1,1,segments);geometry.rotateX(-Math.PI/2);
            if(roof.wing==='opposite')root.PLMRSolidMesh.reverseFaces(geometry);
            const fabricMesh=part(slope,'PVC Kumaş',geometry,membrane);
            updated.push(value=>{
              const lay=C.layout(module,'antero',value);
              const shift=(roof.retractedLeadingDistance-(lay.count-1)*lay.stack)*lay.retract;
              lay.centers=lay.centers.map(v=>v+shift);
              bars.forEach((bar,n)=>{
                if(!roof.trajectory){bar.position.z=lay.centers[n];return;}
                const pose=VG.sample(roof.trajectory,lay.centers[n]),normal=new T.Vector3(...pose.normal);
                bar.position.fromArray(pose.point).addScaledVector(normal,-K.sideRayH-7-15);bar.rotation.x=Math.atan2(normal.z,normal.y);bar.userData.fabricNormal=normal;
              });
              const a=geometry.attributes.position,spans=[];
              for(let n=0;n<lay.count-1;n++){
                const z0=lay.centers[n],z1=lay.centers[n+1],gap=Math.abs(z1-z0);
                const drop=Math.sqrt(Math.max(0,(lay.pitch/2)**2-(gap/2)**2));
                spans.push({z0,z1,gap,drop});
              }
              for(let v=0;v<a.count;v++){
                const row=Math.floor(v/2);
                if(row===(lay.count-1)*steps+1){
                  const distance=lay.centers.at(-1)+17.5+(roof.frontOverhang||30),path=roof.trajectory;
                  let pose=VG.sample(path,distance);if(distance>path.length)pose={...pose,point:VG.add(pose.point,VG.mul(pose.tangent,distance-path.length))};
                  const p=VG.add(pose.point,VG.mul(pose.normal,-K.sideRayH-7));a.setXYZ(v,p[0]+(v%2?1:-1)*roof.width/2,p[1],p[2]);continue;
                }
                const n=Math.min(spans.length-1,Math.floor(row/steps)),k=row-n*steps;
                const {z0,z1,gap,drop}=spans[n],covered=Math.min(17.5,gap/2);
                const fold=Math.max(0,Math.min(1,(k-1)/12));
                const t=k===0?0:k===steps?1:(covered+Math.max(0,gap-2*covered)*fold)/Math.max(.001,gap);
                if(roof.trajectory){
                  const pose=VG.sample(roof.trajectory,z0+(z1-z0)*t),p=VG.add(pose.point,VG.mul(pose.normal,-K.sideRayH-7-Math.sin(Math.PI*fold)*drop));
                  a.setXYZ(v,p[0]+(v%2?1:-1)*roof.width/2,p[1],p[2]);
                }else{a.setY(v,-Math.sin(Math.PI*fold)*drop);a.setZ(v,z0+(z1-z0)*t);}
              }
              a.needsUpdate=true;geometry.computeVertexNormals();geometry.computeBoundingSphere();
              const collection=roof.trajectory?VG.sample(roof.trajectory,0).point:null;
              fabricMesh.userData.fabricState={drop:Math.max(...spans.map(s=>s.drop)),pitch:lay.pitch,progress:value,systemIndex:i,width:roof.width,attachmentY:0,barTopY:0,carrierHalfDepth:17.5,coveredAttachment:true,continuous:true,trajectory:!!roof.trajectory,wing:roof.wing||'main',collectionEnd:roof.collectionEnd||'inner',collectionPoint:collection,travelLength:roof.length,retractedLeadingZ:roof.retractedLeadingZ,retractedLeadingDistance:roof.retractedLeadingDistance,frontOverhang:roof.frontOverhang,leadingCarrierCenter:bars.at(-1).position.toArray(),
                spans};
            });
          }
        }
      }catch(error){clear(next);throw error;}
      finally{materials.push(...schematic.values());for(const m of materials)if(!resources.has(m))m.dispose();}
      return {group:next,motions:updated};
    }
    function rebuild(model){
      zoneInteraction?.clear();referenceGeometry=null;latestModel=model;clearPart();callbacks.part?.(null);
      sketch?.cancel();sceneTools?.cancel();sceneTools?.clearSelection();
      motionTarget=progress;
      const next=new T.Group(),nextOwners=[],nextZones=[],nextMotions=[],nextWalls=[];
      const state=root.PLMRPergolaScene.read();
      const entries=[{id:'roof-main',pose:state.pose,model},...state.copies.map(c=>({...c,model:root.PLMRPergolaScene.project(c.input)}))];
      try{
        for(const [index,entry] of entries.entries()){
          const m=entry.model,systems=m.assembly.systems;
          const height=Math.max(...systems.map(s=>s.rearHeight));
          const minZ=Math.min(...systems.map(s=>s.backExtentZ??s.rearDatumZ)),maxZ=Math.max(...systems.map(s=>s.frontDatumZ));
          const centerZ=(minZ+maxZ)/2,width=m.drawing.input.width,depth=maxZ-minZ;
          const built=buildAssembly(m),holder=new T.Group();
          built.group.position.set(0,-height/2,-centerZ);holder.add(built.group);
          const pose=entry.pose;holder.position.set(pose.x,height/2+pose.y,pose.z);holder.rotation.y=-pose.angle*Math.PI/180;
          next.add(holder);
          const modules=systems.map(s=>({moduleIndex:s.index,centerX:(s.outerStartX+s.outerEndX)/2,centerZ:(s.rearDatumZ+s.frontDatumZ)/2-centerZ,
            outerMinX:s.outerStartX,outerMaxX:s.outerEndX,outerWidth:s.outerEndX-s.outerStartX,width:s.outerEndX-s.outerStartX,height:s.rearHeight,depth:s.totalDepth??s.opening,rearOuterZ:(s.backExtentZ??s.rearDatumZ)-centerZ,frontOuterZ:s.frontDatumZ-centerZ}));
          nextOwners.push({id:entry.id,pose,group:holder,sourceCenterZ:centerZ,sourceModel:m,width,depth,height,spec:{width,depth,height,pozNo:index+1,freedomLayout:{modules},sceneEditor:{bioCodes:{}}}});
          nextMotions.push(...built.motions);
          nextWalls.push(...root.PLMRPergolaScene.canonicalWalls(m,entry.id,pose).map(w=>({
            ...w,appearance:state.wallAppearance?.[w.sourceComponent]||w.appearance,
            label:(w.label||'Duvar')+' · P'+(w.nativeComponent.systemIndex+1)+' · '+w.nativeComponent.id
          })));
          for(const z of m.zones){
            const a=z.a,b=z.b,g=new T.BufferGeometry();
            const points=z.points|| (['front','back'].includes(z.face)?[[a[0],a[1],a[2]],[b[0],a[1],a[2]],[b[0],b[1],a[2]],[a[0],b[1],a[2]]]:
              [[a[0],a[1],a[2]],[a[0],a[1],b[2]],[a[0],b[1],b[2]],[a[0],b[1],a[2]]]);
            g.setAttribute('position',new T.Float32BufferAttribute(points.flat(),3));g.setIndex(z.triangles||[0,1,2,0,2,3]);g.computeVertexNormals();
            const mesh=new T.Mesh(g,new T.MeshBasicMaterial({color:0x38bdf8,side:T.DoubleSide,transparent:true,opacity:.018,depthWrite:false}));
            mesh.userData={isZonePicker:true,zone:{...z,owner:entry.id,axis:['front','back'].includes(z.face)?'x':'z',cx:(a[0]+b[0])/2,cz:(a[2]+b[2])/2-centerZ,bottomY:z.bottom-height/2,postBounded:false}};
            zoneInteraction?.initialise(mesh);built.group.add(mesh);nextZones.push(mesh);
          }
        }
      }catch(error){clear(next);throw error;}
      clear(assembly);assembly=next;owners=nextOwners;zoneMeshes=nextZones;motions=nextMotions;wallModels=nextWalls;
      scene.add(assembly);assembly.updateMatrixWorld(true);
      motions.forEach(fn=>fn(progress));sceneTools?.rebuild();sketch?.rebuild();presentationRevision++;refreshPresentation();resize();
    }
    function sceneState(){const s=root.PLMRPergolaScene.read();return {...s,groundY:0,templates:[],dimensionUnits:s.dimensionUnits};}
    function post(type,data){
      if(type==='scene-commit')callbacks.command?.(data.command);
      else if(type==='select-zone')callbacks.zone?.(data.zone);
      else if(type==='v13-edit-position')callbacks.settings?.(data);
      else if(type==='sketch-wall-update'){
        try{root.PLMRPergolaWalls.commit(data.wall,data.reason);}
        catch(error){callbacks.message?.(error.message);rebuild(latestModel);}
      }else if(type==='sketch-cell-delete'){
        callbacks.message?.('Duvar veya parapeti kendi 2D düzenleyicisinden silebilirsiniz.');
        rebuild(latestModel);
      }else if(type==='sketch-tool-changed'){currentTool=data.tool;callbacks.tool?.(data.tool);}
      else if(type==='v12-escape-request')tool('select');
    }
    // Values and endpoints come from the same native dimensions and physical parts as 2D.
    function pergolaMeasurements(){
      const definitions=[];
      for(const owner of owners){
        const model=owner.sourceModel,origin=model.assembly.origin.sourceX;
        const local=([x,y,z])=>[x,y-owner.height/2,z-owner.sourceCenterZ];
        for(const system of model.assembly.systems){
          if(model.configuration?.double)definitions.push({owner:owner.id,moduleIndex:system.index,key:'height',value:system.rearHeight,a:local([system.outerStartX,0,system.rearDatumZ]),b:local([system.outerStartX,system.rearHeight,system.rearDatumZ]),offset:[-420,0,0],id:owner.id+'|'+system.index+'|height',title:'Orta / mahya kotu'});
          definitions.push({owner:owner.id,moduleIndex:system.index,key:'height',value:system.frontHeight,
            a:local([system.outerEndX,0,system.frontDatumZ]),b:local([system.outerEndX,system.frontHeight,system.frontDatumZ]),offset:[420,0,0],
            id:owner.id+'|'+system.index+'|front-height',title:'P'+(system.index+1)+' · Ön yükseklik'});
        }
        const native=model.drawing.entities.filter(e=>e.type==='dimension'&&!e.hiddenDimension&&e.edit?.dimId?.startsWith('top_ray_spacing_'));
        for(const dimension of native){
          const system=model.assembly.systems[dimension.edit.raySystemIndex];
          definitions.push({owner:owner.id,moduleIndex:system.index,key:'intermediate',value:dimension.measuredValue,
            a:local([dimension.p1.x-origin,system.rearHeight,system.rearDatumZ]),b:local([dimension.p2.x-origin,system.rearHeight,system.rearDatumZ]),offset:[0,180,0],normal:[0,0,1],
            id:owner.id+'|'+dimension.edit.dimId,title:dimension.edit.label});
        }
        for(const gutter of model.components.filter(c=>c.kind==='gutter')){
          const nativeGutter=model.drawing.entities.find(e=>e.type==='dimension'&&e.edit?.dimId?.startsWith('gutter_length_')&&Math.abs(e.measuredValue-gutter.length)<.001&&Math.abs(e.p1.x-origin-gutter.start[0])<.001);
          // Native "Gizle" is authoritative in both the 2D projection and the 3D scene.
          // A hidden measurement must not be regenerated as an unconditional 3D label.
          if(nativeGutter?.hiddenDimension)continue;
          definitions.push({owner:owner.id,moduleIndex:gutter.systemIndex||0,key:'intermediate',value:gutter.length,
            a:local([gutter.start[0],gutter.bottomDatumY,gutter.start[2]]),b:local([gutter.end[0],gutter.bottomDatumY,gutter.end[2]]),offset:[0,-230,0],normal:[0,0,1],
            id:owner.id+'|'+(nativeGutter?.edit.dimId||gutter.id+'|length'),title:'Oluk parça boyu'});
        }
      }
      return definitions;
    }
    const environment={scene,camera,renderer,controls,skipModuleHeight:o=>!!o.sourceModel.configuration?.double,roofs:()=>owners,walls:()=>wallModels,zones:()=>zoneMeshes,pergolaMeasurements,
      referenceGeometry:()=>referenceGeometry||(referenceGeometry=root.PLMRSceneReferenceGeometry.collect([assembly])),
      state:sceneState,dimensionVisibility:()=>sceneState().dimensions,post,setTool:value=>tool(value),bulk:()=>false};
    sceneTools=root.PLMRRollingRoofSceneTools(environment);
    sketch=root.PLMRRollingRoofSceneEditor({
      scene,camera,renderer,controls,group:()=>wallHost,productGroups:()=>[assembly],
      walls:()=>wallModels,setWalls:value=>{wallModels=value;},sceneTools,post,
      interactive:()=>interactive,setInteractive:value=>{interactive=value;},
      setToolName:value=>{currentTool=value;callbacks.tool?.(value);},
      highlightPost:()=>{},decorateWallMesh:(mesh,w)=>{mesh.userData.component=w.nativeComponent;}
    });
    stage.append(document.querySelector('.rr-surface-tools'));
    root.PLMRV27Scene.attach({scene,camera,controls,roots:()=>owners,get nativeGroup(){return assembly;},bounds:()=>new T.Box3().setFromObject(assembly),ground:()=>0});
    function refreshPresentation(){for(let i=0;i<21;i++)root.PLMRV27Scene.tick();}
    cube=root.PLMRV25ViewCube({camera,controls});stage.append(cube.element);
    cube.element.style.right='12px';
    function zoneHit(event){
      const rect=canvas.getBoundingClientRect(),ray=new T.Raycaster();
      ray.setFromCamera(new T.Vector2((event.clientX-rect.left)/rect.width*2-1,-(event.clientY-rect.top)/rect.height*2+1),camera);
      scene.updateMatrixWorld(true);
      const objects=[];assembly.traverse(o=>{if(o.isMesh&&o.visible&&!o.userData.presentationAnnotation&&(!o.userData.isZonePicker||o.material.opacity>0))objects.push(o);});
      return ray.intersectObjects(objects,false)[0];
    }
    function clearPart(){partSelection=null;if(partOutline){clear(partOutline);partOutline=null;}}
    function tool(next){sketch.setTool(next==='pushpull'?'pushpull':'select');render();}
    let down=null;
    canvas.addEventListener('pointerdown',event=>{down={x:event.clientX,y:event.clientY};canvas.focus();});
    zoneInteraction=root.PLMRSceneInteraction.zones({canvas,tool:()=>currentTool,pick:event=>zoneHit(event)?.object});
    canvas.addEventListener('pointermove',event=>{if(view==='3D'){sketch.move(event);zoneInteraction.update(event);}});
    canvas.addEventListener('pointerleave',()=>{zoneInteraction.clear();down=null;});
    canvas.addEventListener('pointercancel',()=>{down=null;});
    canvas.addEventListener('pointerup',event=>{
      const start=down;down=null;
      if(event.button!==0)return;
      if(currentTool==='pushpull'){sketch.up(event);render();return;}
      if(!start||Math.hypot(event.clientX-start.x,event.clientY-start.y)>6)return;
      const hit=zoneHit(event);
      if(sketch.up(event)){clearPart();callbacks.part?.(null);render();return;}
      if(currentTool==='select'&&hit?.object.userData.zone)callbacks.zone?.(hit.object.userData.zone);
      else if(currentTool==='select'&&hit?.object.userData.component){
        const c=hit.object.userData.component,owner=owners.find(o=>{for(let p=hit.object;p;p=p.parent)if(p===o.group)return true;return false;});
        clearPart();partSelection={id:c.id,owner:owner?.id||'roof-main'};
        const box=new T.Box3();owner?.group.traverse(o=>{if(o.isMesh&&o.userData.component?.id===c.id)box.union(new T.Box3().setFromObject(o));});
        partOutline=new T.Box3Helper(box,0x1479b8);partOutline.userData.presentationAnnotation=true;scene.add(partOutline);
        callbacks.part?.(c,owner?.id||'roof-main');
      }else sceneTools.up(event);
      render();
    });
    canvas.addEventListener('keydown',event=>{if(sketch.key(event)){render();return;}if(event.key==='Escape'){sketch.cancel();clearPart();tool('select');render();}});
    canvas.addEventListener('keyup',event=>sketch.keyUp(event));
    function move(target){
      motionTarget=Math.max(0,Math.min(1,target));motionLast=performance.now();
    }
    function tick(){
      if(disposed)return;
      const now=performance.now(),dt=Math.min(1000,Math.max(0,now-motionLast));motionLast=now;
      if(progress!==motionTarget){
        const C=root.PLMRBioclimaticRoof,step=dt/C.animationDuration('antero');
        const clock=C.animationClock(null,'antero',progress);
        progress=C.animationProgress(null,'antero',motionTarget>progress?Math.min(motionTarget,clock+step):Math.max(motionTarget,clock-step));
        motions.forEach(update=>update(progress));
      }
      controls.update();sceneTools?.refreshDimensions();render();
    }
    function syncLoop(){renderer.setAnimationLoop(!disposed&&view==='3D'&&!document.hidden?tick:null);motionLast=performance.now();}
    document.addEventListener('visibilitychange',syncLoop);
    syncLoop();
    function dispose(){
      if(disposed)return;
      disposed=true;
      renderer.setAnimationLoop(null);document.removeEventListener('visibilitychange',syncLoop);observer.disconnect();sketch?.cancel();sceneTools?.setActive(false);controls.dispose();clear(assembly);clear(wallHost);renderer.dispose();
    }
    root.addEventListener('pagehide',e=>{if(!e.persisted)dispose();});
    const output=root.PLMRV24ViewerExports({scene,camera,renderer,controls});
    function clearModel(){
      zoneInteraction?.clear();clearPart();callbacks.part?.(null);
      clear(assembly);assembly=new T.Group();scene.add(assembly);
      clear(wallHost);wallHost.clear();scene.add(wallHost);
      owners=[];zoneMeshes=[];wallModels=[];interactive=[];motions=[];
      latestModel=null;referenceGeometry=null;
      sceneTools?.refreshDimensions();render();
    }
    return Object.freeze({
      rebuild,fit,move,tool,clearPart,clearModel,dae:output.dae,
      capture:(mime='image/png')=>{render();return renderer.domElement.toDataURL(mime,.92);},
      cameraState:()=>({position:camera.position.toArray(),target:controls.target.toArray(),up:camera.up.toArray(),fov:camera.fov}),
      motion(value){progress=Math.max(0,Math.min(1,Number(value)));motionTarget=progress;motions.forEach(fn=>fn(progress));render();},
      zoom(scale){camera.position.sub(controls.target).multiplyScalar(scale).add(controls.target);controls.update();render();},
      fov(value){root.PLMRV27Scene.fov(Number(value));render();},
      units(){sceneTools.refreshUnits();sceneTools.refreshDimensions();render();},
      zones(){zoneInteraction.clear();for(const mesh of zoneMeshes)mesh.visible=root.PLMRPergolaZones.allowed(mesh.userData.zone);render();},
      // Read-only visible point lookup used by interaction verification. A centre can
      // be hidden behind the now-closed triangle, so check the actual frontmost hit.
      contactDiagnostics(){
        const cloth=[],bars=[];assembly.updateMatrixWorld(true);assembly.traverse(m=>{if(m.isMesh&&m.userData.fabricState)cloth.push(m);if(m.isMesh&&m.name.startsWith('Kumaş taşıyıcı'))bars.push(m);});
        return {depthBits:renderer.getContext().getParameter(renderer.getContext().DEPTH_BITS),logDepth:renderer.capabilities.logarithmicDepthBuffer,
          contacts:bars.map(bar=>{const p=bar.parent.localToWorld(new T.Vector3(0,50,bar.position.z)),dir=new T.Vector3(0,-1,0).transformDirection(bar.parent.matrixWorld),ray=new T.Raycaster(p,dir);return ray.intersectObjects([bar,...cloth],false).slice(0,3).map(h=>({name:h.object.name,distance:h.distance,rank:(Array.isArray(h.object.material)?h.object.material[0]:h.object.material).userData.depthRank,depthWrite:(Array.isArray(h.object.material)?h.object.material[0]:h.object.material).depthWrite}));})};
      },
      screenPart(id){
        const box=new T.Box3();assembly.traverse(m=>{if(m.isMesh&&m.userData.component?.id===id)box.union(new T.Box3().setFromObject(m));});
        if(box.isEmpty())return null;
        const r=canvas.getBoundingClientRect(),fractions=[.5,.05,.95,0,1];
        for(const x of fractions)for(const y of fractions)for(const z of fractions){
          const p=new T.Vector3(box.min.x+(box.max.x-box.min.x)*x,box.min.y+(box.max.y-box.min.y)*y,box.min.z+(box.max.z-box.min.z)*z).project(camera);
          const q={clientX:r.left+(p.x+1)*r.width/2,clientY:r.top+(1-p.y)*r.height/2};
          if(document.elementFromPoint(q.clientX,q.clientY)!==canvas)continue;
          if(zoneHit(q)?.object.userData.component?.id===id)return{x:q.clientX,y:q.clientY};
        }
        return null;
      },
      screenWall(id,axis=2,sign=1){const w=wallModels.find(w=>w.id===id);if(!w)return null;const face=root.PLMRRollingRoofSketchCore.faces(w).find(f=>f.axis===axis&&f.sign===sign);if(!face)return null;const q=sketch.screenPoint(id,face,(face.u0+face.u1)/2,(face.v0+face.v1)/2),r=canvas.getBoundingClientRect();return{x:r.left+q.x,y:r.top+q.y,face};},
      screenZone(id){const mesh=zoneMeshes.find(m=>m.userData.zone.id===id);if(!mesh)return null;const bounds=new T.Box3().setFromObject(mesh),p=bounds.getCenter(new T.Vector3()).project(camera),r=canvas.getBoundingClientRect();return {x:r.left+(p.x+1)*r.width/2,y:r.top+(1-p.y)*r.height/2};},
      resources:()=>({...renderer.info.memory}),
      mode(value){view=value;syncLoop();stage.hidden=value!=='3D';sceneTools.setActive(value==='3D');document.getElementById('rrSceneOverlay').hidden=value!=='3D';resize();},
      theme(value){presentation.environment=value;refreshPresentation();render();},
      floor(value){presentation.floor=value;refreshPresentation();render();},
      solidDiagnostics(){
        const result=[];assembly.traverse(mesh=>{if(mesh.isMesh&&['triangle-frame','gutter','gutter-cap'].includes(mesh.userData.component?.kind))result.push({id:mesh.userData.component.id,name:mesh.name,kind:mesh.userData.component.kind,...root.PLMRSolidMesh.topology(mesh.geometry)});});return result;
      },
      inspect(){
        const owner=owners[0];
        function physicalBounds(id,world=false){
          if(!owner)return null;scene.updateMatrixWorld(true);const inverse=world?new T.Matrix4():owner.group.matrixWorld.clone().invert(),box=new T.Box3();
          owner.group.traverse(mesh=>{
            if(!mesh.isMesh||mesh.userData.component?.id!==id)return;
            mesh.geometry.computeBoundingBox();const b=mesh.geometry.boundingBox,matrix=mesh.matrixWorld.clone().premultiply(inverse);
            for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z])box.expandByPoint(new T.Vector3(x,y,z).applyMatrix4(matrix));
          });
          if(box.isEmpty())return null;
          const offset=world?new T.Vector3():new T.Vector3(0,owner.height/2,owner.sourceCenterZ);box.min.add(offset);box.max.add(offset);
          return {min:box.min.toArray(),max:box.max.toArray(),size:box.getSize(new T.Vector3()).toArray()};
        }
        const meshRecords=[];
        for(const o of owners){const inverse=o.group.matrixWorld.clone().invert();o.group.traverse(mesh=>{
          if(!mesh.isMesh||!mesh.userData.component)return;
          const c=mesh.userData.component,matrix=mesh.matrixWorld.clone().premultiply(inverse),mat=Array.isArray(mesh.material)?mesh.material[0]:mesh.material;
          meshRecords.push({id:c.id,kind:c.kind,axisZ:new T.Vector3(0,0,1).transformDirection(matrix).toArray(),
            color:'#'+mat.color.clone().convertLinearToSRGB().getHexString(),
            depthRank:mat.userData.depthRank,materialSide:mat.side,normal:mesh.geometry.attributes.normal?new T.Vector3().fromBufferAttribute(mesh.geometry.attributes.normal,0).transformDirection(matrix).toArray():null,polygonOffset:mat.polygonOffset,
            parameters:Object.fromEntries(Object.entries(mesh.geometry.parameters||{}).filter(([key,v])=>['width','height','depth'].includes(key)&&typeof v==='number'))});
        });}
        return {webgl:!!renderer.getContext(),draws,renderCalls:renderer.info.render.calls,progress,mode:view,
        configuration:latestModel?.configuration,selectedPart:partSelection,meshRecords,
        parts:latestModel?.components.map(c=>({id:c.id,kind:c.kind,label:c.label,section:c.section,start:c.start,end:c.end,size:c.size,position:c.position,rotationX:c.rotationX,prismVertices:c.prismVertices,mountFaceZ:c.mountFaceZ,railId:c.railId,joint:c.joint,depth:c.depth,actualPathLength:c.actualPathLength,trajectory:c.trajectory,attachmentRailId:c.attachmentRailId,attachmentDistance:c.attachmentDistance,wing:c.wing,x:c.x,railEdge:c.railEdge,clearance:c.clearance,length:c.length,editor:c.editor,bounds:physicalBounds(c.id),worldBounds:c.prismVertices?physicalBounds(c.id,true):undefined})),
        fabric:(()=>{const a=[];assembly.traverse(m=>{if(m.userData.fabricState){m.geometry.computeBoundingBox();a.push({...m.userData.fabricState,meshBounds:{min:m.geometry.boundingBox.min.toArray(),max:m.geometry.boundingBox.max.toArray()}});}});return a;})(),
        groups:owners.map(o=>o.id),tool:currentTool,camera:{position:camera.position.toArray(),target:controls.target.toArray(),damping:controls.enableDamping,dampingFactor:controls.dampingFactor,screenSpacePanning:controls.screenSpacePanning,mouseButtons:controls.mouseButtons},motionDuration:root.PLMRBioclimaticRoof.animationDuration('antero'),motionTarget,hoveredZone:zoneInteraction?.inspect(),sceneTools:sceneTools.getState(),
        zones:zoneMeshes.map(m=>({id:m.userData.zone.id,owner:m.userData.zone.owner,face:m.userData.zone.face,width:m.userData.zone.width,height:m.userData.zone.height,label:m.userData.zone.label,uid:m.userData.zone.zoneUid,key:m.userData.zone.key,isRoofZone:!!m.userData.zone.isRoofZone,visible:m.visible,opacity:m.material.opacity,color:m.material.color.getHexString()})),
        measurements:sceneTools.measurements(),
        walls:wallModels.map(w=>({id:w.id,source:w.sourceComponent,appearance:w.appearance,bounds:root.PLMRPergolaWalls.bounds(w),solids:w.solids,frame:w.frame})),sketch:sketch.getState(),
        triangles:latestModel?.components.filter(c=>c.kind==='triangle-frame').map(c=>({id:c.id,side:c.sideViewKey,...c.geometry})),memory:{...renderer.info.memory}};}
    });
  }
  root.PLMRJustPergolaViewer=Object.freeze({mount});
})(window);
