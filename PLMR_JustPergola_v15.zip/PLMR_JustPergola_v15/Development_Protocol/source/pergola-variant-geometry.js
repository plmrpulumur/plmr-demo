/* Pure millimetre geometry shared by variant projection, orthographic views and 3D. */
(function(root){
  'use strict';
  const add=(a,b)=>a.map((v,i)=>v+b[i]),sub=(a,b)=>a.map((v,i)=>v-b[i]),mul=(a,n)=>a.map(v=>v*n);
  const norm=a=>{const n=Math.hypot(...a);return n?mul(a,1/n):[0,0,1];};
  function frame(c,resolvedSection){
    const delta=sub(c.end,c.start),length=Math.hypot(...delta),axis=norm(delta),vertical=Math.abs(axis[1])>.999,transverse=Math.abs(axis[0])>.999;
    const section=resolvedSection||c.section||(c.profileSection?[c.profileSection.heightY,c.profileSection.depthZ]:[c.profileWidthX||c.profileEn||100,c.profileDepthZ||c.profileBoy||100]);
    const axes=vertical?[[1,0,0],[0,0,-1],[0,1,0]]:transverse?[[0,0,-Math.sign(axis[0])],[0,1,0],[Math.sign(axis[0]),0,0]]:[[1,0,0],[0,axis[2],-axis[1]],axis];
    return {center:mul(add(c.start,c.end),.5),length,vertical,transverse,axes,width:transverse?section[1]:section[0],height:transverse?section[0]:section[1]};
  }
  function table(points){
    const distances=[0];for(let i=1;i<points.length;i++)distances.push(distances.at(-1)+Math.hypot(...sub(points[i],points[i-1])));
    return {points,distances,length:distances.at(-1)};
  }
  function sample(path,distance){
    const d=Math.max(0,Math.min(path.length,distance));let hi=1;
    while(hi<path.distances.length-1&&path.distances[hi]<d)hi++;
    const a=path.points[hi-1],b=path.points[hi],t=(d-path.distances[hi-1])/Math.max(1e-9,path.distances[hi]-path.distances[hi-1]);
    const tangent=norm(sub(b,a)),sign=Math.sign(tangent[2])||1;
    return {point:add(a,mul(sub(b,a),t)),tangent,normal:[0,Math.abs(tangent[2]),-tangent[1]*sign]};
  }
  function atZ(path,z){
    const sign=Math.sign(path.points.at(-1)[2]-path.points[0][2])||1;
    let hi=1;while(hi<path.points.length-1&&sign*(path.points[hi][2]-z)<0)hi++;
    const a=path.points[hi-1],b=path.points[hi],t=Math.max(0,Math.min(1,(z-a[2])/(b[2]-a[2])));
    return sample(path,path.distances[hi-1]+t*(path.distances[hi]-path.distances[hi-1]));
  }
  function range(path,endZ){
    const sign=Math.sign(endZ-path.points[0][2])||1;
    return table([...path.points.filter(p=>sign*(p[2]-endZ)<-1e-6),atZ(path,endZ).point]);
  }
  function sweep(path,width,height){
    const positions=[],indices=[];
    for(let i=0;i<path.points.length;i++){
      const p=path.points[i],n=sample(path,path.distances[i]).normal;
      for(const [x,y]of [[-width/2,0],[width/2,0],[width/2,-height],[-width/2,-height]])positions.push(...add(add(p,[x,0,0]),mul(n,y)));
    }
    for(let r=0;r<path.points.length-1;r++)for(let k=0;k<4;k++){
      const a=r*4+k,b=r*4+(k+1)%4,c=b+4,d=a+4;indices.push(a,c,b,a,d,c);
    }
    indices.push(0,1,2,0,2,3);const end=(path.points.length-1)*4;indices.push(end,end+2,end+1,end,end+3,end+2);
    if(path.points.at(-1)[2]<path.points[0][2])for(let i=0;i<indices.length;i+=3)[indices[i+1],indices[i+2]]=[indices[i+2],indices[i+1]];
    return {positions,indices};
  }
  function ribbon(path,x0,x1,offset=0){
    const positions=[],indices=[];
    for(const p of path.points)positions.push(x0,p[1]+offset,p[2],x1,p[1]+offset,p[2]);
    for(let i=0;i<path.points.length-1;i++){const a=2*i;indices.push(a,a+2,a+1,a+1,a+2,a+3);}
    return {positions,indices};
  }
  function gutterContour(depth,height){const short=66,t=1.6;return [[-depth/2,0],[depth/2,0],[depth/2,height],[depth/2-35.5,height],[depth/2-35.5,t],[-depth/2+t,t],[-depth/2+t,short],[-depth/2,short]];}
  function vertices(c){
    if(c.meshData){const p=c.meshData.positions;return Array.from({length:p.length/3},(_,i)=>p.slice(i*3,i*3+3));}
    if(c.prismVertices)return c.prismVertices;
    if(c.corners)return c.corners;
    if(c.kind==='triangle-frame')return c.geometry.polygons.flatMap(poly=>poly.flatMap(([u,v])=>[-1,1].map(sign=>[c.x+sign*c.depth/2,c.y+v,c.z+(c.zSign||1)*u])));
    if(c.kind==='gutter')return [c.start[0],c.end[0]].flatMap(x=>gutterContour(c.profileSection.depthZ,c.profileSection.heightY).map(([z,y])=>[x,c.bottomDatumY+y,c.start[2]+(c.zSign||1)*z]));
    if(c.kind==='gutter-cap')return [c.x-c.thickness/2,c.x+c.thickness/2].flatMap(x=>c.points.map(([z,y])=>[x,c.y+y,c.z+(c.zSign||1)*z]));
    if(c.polygonXZ)return c.polygonXZ.flatMap(([x,z],i)=>[[x,c.bottomY,z],[x,c.startHeight==null?c.topY:((c.parapetView==='side'?i>=2:i===1||i===2)?c.endHeight:c.startHeight),z]]);
    if(c.start&&c.end){
      const f=frame(c),out=[];
      for(const x of [-1,1])for(const y of [-1,1])for(const z of [-1,1]){
        const center=c.kind==='rail'?sub(f.center,mul(f.axes[1],f.height/2)):f.center;
        out.push(add(add(add(center,mul(f.axes[0],x*f.width/2)),mul(f.axes[1],y*f.height/2)),mul(f.axes[2],z*f.length/2)));
      }return out;
    }
    if(c.size){const out=[],r=c.rotationX||0;for(const x of [-1,1])for(const y of [-1,1])for(const z of [-1,1]){
      const Y=y*c.size[1]/2,Z=z*c.size[2]/2;out.push(add(c.position,[x*c.size[0]/2,Y*Math.cos(r)-Z*Math.sin(r),Y*Math.sin(r)+Z*Math.cos(r)]));}return out;}
    return [];
  }
  function bounds(components){const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];for(const c of components)for(const p of vertices(c))for(let i=0;i<3;i++){min[i]=Math.min(min[i],p[i]);max[i]=Math.max(max[i],p[i]);}return Number.isFinite(min[0])?{min,max}:{min:[0,0,0],max:[0,0,0]};}
  function hull(points){
    const unique=[...new Map(points.map(p=>[p.map(n=>n.toFixed(5)).join(','),p])).values()].sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
    if(unique.length<=2)return unique;
    const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
    const half=list=>{const out=[];for(const p of list){while(out.length>=2&&cross(out.at(-2),out.at(-1),p)<=0)out.pop();out.push(p);}return out;};
    return [...half(unique).slice(0,-1),...half([...unique].reverse()).slice(0,-1)];
  }
  root.PLMRPergolaVariantGeometry=Object.freeze({add,sub,mul,norm,frame,table,sample,atZ,range,sweep,ribbon,gutterContour,vertices,bounds,hull});
})(window);
