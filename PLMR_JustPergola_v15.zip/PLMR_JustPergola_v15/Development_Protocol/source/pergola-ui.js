(function(root){
  'use strict';
  const $=id=>document.getElementById(id),clone=x=>JSON.parse(JSON.stringify(x)),native=root.PLMRPergolaNative;
  let viewer=null,view='3D',drawing=null,refreshFrame=0,ready=false,zoneVisible=true,zoneFaces={},settings=null,baseline=null;
  const main=document.importNode($('workspaceTemplate').content,true);document.body.append(main);
  const host=$('rrV45EngineHost');host.append($('plmr2DWorkspace'),$('pergola3d'));
  root.PLMRV24Libraries={PLMRNativeDae:root.PLMRNativeDae};
  function notify(text){const n=$('rrV45ToolbarMessage');n.textContent=text;n.classList.add('show');clearTimeout(notify.timer);notify.timer=setTimeout(()=>n.classList.remove('show'),3500);}
  function run(fn){try{return fn();}catch(error){notify(error.message);$('pergolaError').textContent=error.message;$('pergolaError').hidden=false;console.error(error);return false;}}
  function bind(id,fn){const n=$(id);if(n)n.onclick=()=>run(fn);}
  function proxy(id,target){bind(id,()=>$(target).click());}
  function clearDrawing(){
    drawing=null;baseline=null;selectedPart=null;
    closeSettings();
    viewer?.clearModel();
    $('rrV11SelectionActions').hidden=true;
    $('preview').replaceChildren();$('shellDetailBody').replaceChildren();
  }
  function build(){
    drawing=native.drawing();
    if(!drawing){clearDrawing();notify('Ayarlar bölümünden pergola ölçülerini girin.');return false;}
    const model=root.PLMRJustPergola.fromDrawing(drawing,'white');
    if(!baseline)baseline={legacy:native.legacy(),scene:root.PLMRPergolaScene.read()};
    if(!viewer)viewer=root.PLMRJustPergolaViewer.mount($('model3d'),{command:cmd=>run(()=>{root.PLMRPergolaScene.command(cmd);}),settings:data=>data?.owner&&data.owner!=='roof-main'?notify('Kopyanın ölçülerini değiştirmek için ana pergolayı düzenleyip yeni kopya oluşturun.'):openSettings(),zone:openZone,wall:editWall,part:selectPart,tool:syncTool,message:notify});
    viewer.rebuild(model);viewer.mode(view);viewer.zones();$('rrV45ZonesBtn').textContent=root.PLMRZones.visible()?'▧ Zone’lar Açık':'▧ Zone’lar Kapalı';
    viewer.theme($('v27Environment').value);syncDetails(model);syncUnits();syncDimensions();$('shellMotion').value=String(Math.round(viewer.inspect().progress*100));$('shellMotionValue').textContent='%'+$('shellMotion').value;$('rrV45ParapetHeight').value=drawing.input.parapet==='EVET'?String(drawing.input.parapetHeight):'0';$('pergolaError').hidden=true;
    return true;
  }
  function refresh(){if(refreshFrame)return;refreshFrame=requestAnimationFrame(()=>{refreshFrame=0;if(ready)run(build);});}
  function setView(next){
    view=next;$('plmr2DWorkspace').hidden=next==='3D';$('pergola3d').hidden=next!=='3D';
    $('rrV45Mode2DBtn').classList.toggle('on',next==='2D');$('rrV45Mode3DBtn').classList.toggle('on',next==='3D');
    const stage=document.querySelector('.v33-preview-stage');stage.classList.toggle('is-2d',next==='2D');stage.classList.toggle('is-3d',next==='3D');
    if(next==='3D'){if(!viewer)run(build);viewer?.mode(next);if(viewer&&!setView.fitted){viewer.fit();setView.fitted=true;}}
    else{viewer?.mode(next);native.embedded();requestAnimationFrame(()=>root.PulumurPreviewShell.fit());}
    $('pergolaDimensionFilter').hidden=true;
    syncDimensions();
  }
  function syncTool(tool){for(const [name,id]of Object.entries({pushpull:'rrV45PushPullToolBtn'})){const n=$(id);n.classList.toggle('on',tool===name);n.setAttribute('aria-pressed',String(tool===name));}}
  function tool(name){setView('3D');viewer?.tool(viewer.inspect().tool===name?'select':name);}
  function fit(){view==='3D'?viewer?.fit():root.PulumurPreviewShell.fit();}
  function download(name,blob){const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
  function syncDetails(model){
    const body=$('shellDetailBody');body.replaceChildren();const table=document.createElement('table'),head=table.createTHead().insertRow();
    for(const text of ['Poz','Ürün','Genişlik (mm)',model.configuration?.double?'Kanat açılımı (mm)':'Açılım (mm)','Arka H (mm)','Ön H (mm)','Cephe Bölgesi']){const th=document.createElement('th');th.textContent=text;head.append(th);}
    for(const s of model.assembly.systems){const row=table.insertRow();for(const value of ['P'+String(s.index+1).padStart(2,'0'),model.configuration?.derivedModelName||'Avila Lean',s.width,s.opening,s.rearHeight,s.frontHeight,model.zones.filter(z=>z.systemIndex===s.index).length])row.insertCell().textContent=String(value);row.ondblclick=()=>openSettings();}
    body.append(table);if($('pergolaProductHeading'))$('pergolaProductHeading').textContent='PLMR | '+(model.configuration?.derivedModelName||'Pergola');$('rrV45ProductSelect').selectedOptions[0].textContent='PLMR | '+(model.configuration?.derivedModelName||'Avila Lean');const meta=root.PulumurProjectModel.formDataFromModel(root.PulumurProjectState.getModel());
    for(const [label,value]of Object.entries({'Proje Kodu':meta.projectCode,'Müşteri':meta.customer,'Ülke':meta.country,'Müşteri Temsilcisi':meta.customerRepresentative,'Proje Adı':meta.project,'Proje Temsilcisi':meta.drawnBy,'Oluşturma':meta.date}))document.querySelector('[data-summary="'+label+'"]').textContent=value||'—';
    $('shellHistory').textContent='Geri alınabilir adım: '+root.PulumurDiagnostics.getHistory().entries;
  }
  function closeSettings(){settings?.remove();settings=null;}
  function openSettings(options={}){
    closeSettings();const legacy=native.legacy();
    if(options.add&&drawing){
      const d=drawing.input,n=d.positions.length;
      if(n>=30)throw Error('En fazla 30 sistem oluşturulabilir.');
      const widths=d.systems.map(x=>x.nominalWidth||x.outerWidth),last=d.positions[n-1];
      legacy.formData.systemCount=String(n+1);
      legacy.formData.width=widths.concat(widths[n-1]).join(';');
      for(const k of ['opening','rearHeight'])legacy.formData[k]=d.positions.map(p=>p[k]).concat(last[k]).join(';');
      legacy.formData.rayCount='';legacy.formData.postCount='';
    }
    if(options.values)Object.assign(legacy.formData,options.values);
    if(options.configuration)legacy.drawingState.pergolaConfiguration=root.PLMRPergolaDefinition.normalize(options.configuration);
    const back=document.createElement('div');back.id='rrV45SettingsModal';back.className='rr-settings-backdrop pergola-settings';
    back.innerHTML='<section class="rr-settings-dialog" role="dialog" aria-modal="true" aria-label="PLMR | Pergola Ayarları"><header class="rr-settings-head"><strong>PLMR | Pergola Ayarları</strong><small>PLMR | Pergola ürün ölçüleri</small><button type="button" aria-label="Ayarları kapat">×</button></header><div class="rr-settings-body"><form id="pergolaSettingsForm"></form></div></section>';
    const form=back.querySelector('form');form.noValidate=true;
    root.PLMRPergolaSettings.mount(back,legacy,next=>{
      native.commitLegacy(next,{sideFeaturesExplicit:true});closeSettings();refresh();setView(view);
      if(!setView.fitted){viewer?.fit();setView.fitted=true;}
    },closeSettings);
    back.querySelector('[aria-label="Ayarları kapat"]').onclick=closeSettings;
    back.onmousedown=event=>{if(event.target===back)closeSettings();};back.onkeydown=event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();closeSettings();}};
    (document.fullscreenElement||document.body).append(back);settings=back;back.querySelector('input').focus();
  }
  function openZone(zone){
    if(zone.isRoofZone){selectPart({id:'fabric-'+zone.systemIndex,kind:'fabric',label:'Kumaş · '+zone.label,systemIndex:zone.systemIndex},zone.owner||'roof-main');return;}
    const host=root.PLMRPergolaHost?.zoneActions;
    root.PLMRZoneActions.open(zone,host||{
      available:action=>action!=='dimension'&&!(action==='wall'&&zone.face==='back'),
      execute(action,z,close){
        if(action==='product'){close();openZoneProduct(z);}
        else if(action==='main-product'){close();openSettings({add:true});}
        else if(action==='switch'){root.PLMRPergolaScene.change(scene=>{scene.zoneRotations??={};scene.zoneRotations[z.id]=scene.zoneRotations[z.id]===180?0:180;});close();}
        else if(action==='wall'){root.PLMRPergolaWalls.addInZone(z,1000);close();}
        else if(action==='profile'){close();if(z.meta)native.selectZone(z.meta);else editWall({kind:'rear-wall',systemIndex:z.systemIndex});}
      }
    });
  }
  function openZoneProduct(zone){
    if(zone.owner&&zone.owner!=='roof-main'){notify('Kopya cephesinin ürün montajı ana uygulama entegrasyonunda etkinleşecek.');}
    document.querySelector('#pergolaZoneDialog')?.remove();
    const back=document.createElement('div');back.id='pergolaZoneDialog';back.className='v26-dialog';back.setAttribute('role','dialog');back.setAttribute('aria-label','Cepheye Ürün Yerleştir');
    back.innerHTML='<section class="v26-card"><header><div><small>CEPHE ÜRÜNÜ</small><h2>Cepheye Ürün Yerleştir</h2></div><button data-action="close" aria-label="Kapat">×</button></header><main><p class="v26-zone"></p><div class="v26-size"><label>Genişlik (mm)<input id="v26FacadeWidth" readonly></label><label>Yükseklik (mm)<input id="v26FacadeHeight" readonly></label></div><label class="v26-product">Ürün<select id="v26FacadeProduct" aria-label="Cephe ürünü"><option value="">Ürün seçin…</option><option value="guillotine">Giyotin Cam</option><option value="sliding">Sürme Cam</option><option value="balcony">Katlanır Cam</option><option value="zip">Zip Perde</option><option value="folding">Akordiyon Cam</option><option value="fixed">Sabit Doğrama</option><option value="door">Kapı</option></select></label><p class="v26-error" role="status">Cephe ürünlerinin montajı güncel uygulamaya bağlandıktan sonra etkinleşecek.</p></main><footer><button data-action="profiles">Profilleri Düzenle</button><span></span><button data-action="cancel">Vazgeç</button><button data-action="save" class="v26-primary" disabled>Kaydet</button></footer></section>';
    back.querySelector('.v26-zone').textContent=zone.label+' · '+({front:'Ön cephe',back:'Arka cephe',left:'Sol cephe',right:'Sağ cephe'}[zone.face]||'Cephe')+' · '+zone.id;
    back.querySelector('#v26FacadeWidth').value=Number(zone.width.toFixed(2));back.querySelector('#v26FacadeHeight').value=Number(zone.height.toFixed(2));
    function close(){back.remove();}back.querySelector('[data-action=close]').onclick=back.querySelector('[data-action=cancel]').onclick=close;
    if(zone.face==='back'||!zone.meta){const button=back.querySelector('[data-action=profiles]');button.disabled=true;button.title='Arka açıklık çelik dikme ve kiriş ölçülerinden türetilir.';}
    back.querySelector('[data-action=profiles]').onclick=()=>{close();if(zone.owner&&zone.owner!=='roof-main'){notify('Kopya ölçülerini ayrı düzenlemek için poz ayarlarını kullanın.');return;}native.selectZone(zone.meta);};
    back.onmousedown=e=>{if(e.target===back)close();};back.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape')close();};(document.fullscreenElement||document.body).append(back);back.querySelector('select').focus();
  }
  function editWall(component){
    const type=component.kind==='parapet'?'parapetEditor':'topBackWallEditor';
    const selector=component.kind==='parapet'&&component.parapetSegmentId?
      '[data-interaction-type="parapetEditor"][data-parapet-segment-id="'+component.parapetSegmentId+'"]':
      '[data-interaction-type="'+type+'"][data-system-index="'+(component.systemIndex||0)+'"]';
    native.editInteraction(selector);
  }
  let selectedPart=null;
  function selectPart(component,owner){
    selectedPart=component?{component,owner}:null;
    const panel=$('rrV11SelectionActions');panel.hidden=!component;
    if(!component)return;
    panel.querySelector('small').textContent=component.label||component.kind;
    $('rrV11SelectionEditBtn').onclick=()=>{
      if(owner!=='roof-main'){notify('Kopya parçasının ölçü düzenlemesi ana modele uygulanmaz.');return;}
      if(component.variantEditable){openSettings();$('pergolaSetting-curveRise')?.focus();}
      else if(component.editor)native.editInteraction(component.editor);
      else if(component.dimensionId){const e=drawing.entities.find(e=>e.edit?.dimId===component.dimensionId);if(e)native.selectZone({...e.edit,value:e.measuredValue,zoneId:e.edit.relatedZoneId});}
      else if(component.kind==='fabric'){openSettings();$('pergolaSetting-fabric')?.focus();}
      else if(['rear-wall','parapet'].includes(component.kind))editWall(component);
      else{const values=component.actualPathLength?[component.actualPathLength,...(component.section||[])]:component.size||component.section||[];native.partInfo({label:component.label||component.kind,view:'3D',value:values.map(v=>Number(v.toFixed(3))).join(' × '),passiveReason:'Sabit parçanın dış ölçüleridir. Yerleşimi ana pergola geometrisiyle birlikte güncellenir.'});}
    };
    $('rrV11SelectionEditBtn').textContent=(component.variantEditable||component.editor||component.dimensionId||component.kind==='fabric')?'Düzenle':'Bilgi';
    $('rrV14SelectionMotion').hidden=component.kind!=='fabric';$('rrV14SelectionMotion').onclick=()=>viewer?.move(viewer.inspect().progress>.5?0:1);
    const shift=$('pergolaPartShift');shift.hidden=component.kind!=='post'&&component.kind!=='side-support-post';
    shift.onclick=$('rrV11SelectionEditBtn').onclick;
    // 3D steel selection uses the native section ownership and history command.
    // Never hide a mesh as a substitute for deleting its source grid cell.
    const steel=['rear-steel-beam','rear-steel-post'].includes(component.kind);
    const del=$('rrV11SelectionDeleteBtn');del.hidden=!steel;
    del.onclick=()=>run(()=>{
      if(owner!=='roof-main')throw Error('Kopya parça ana sistemden silinemez.');
      if(!drawing||!steel)return;
      const i=component.systemIndex,sys=drawing.input.systems[i],key=String(i);
      if(!sys)throw Error('Çelik taşıyıcının poz bilgisi bulunamadı.');
      const legacy=native.legacy(),grids=legacy.drawingState.topBackWallGridState||{};
      const width=sys.outerEndX-sys.outerStartX;
      const existing=grids[key]?.cells?.length?grids[key]:drawing.input.topBackWallGridState?.[key];
      const cells=clone(existing?.cells?.length?existing.cells:[{
        id:'v12-steel-section-'+key,enabled:true,minX:0,maxX:width,
        startNearDepth:0,endNearDepth:0,startFarDepth:Math.max(1,Number(drawing.input.topWallH)||160),endFarDepth:Math.max(1,Number(drawing.input.topWallH)||160)
      }]);
      const axis=component.kind==='rear-steel-beam'?(component.start[0]+component.end[0])/2:component.start[0];
      const originX=root.PLMRJustPergola.fromDrawing(drawing,'white').assembly.origin.sourceX;
      const localX=axis+originX-sys.outerStartX;
      const target=cells.find(cell=>cell.enabled!==false&&localX>=cell.minX-.01&&localX<=cell.maxX+.01);
      if(!target)throw Error('Çelik taşıyıcının bağlı olduğu silinebilir bölüm bulunamadı.');
      target.enabled=false;
      legacy.drawingState.topBackWallGridState={...grids,[key]:{...(existing||{}),cells}};
      native.commitLegacy(legacy);
      selectedPart=null;panel.hidden=true;viewer?.clearPart();refresh();
    });
    panel.querySelector('[data-clear-part]').onclick=()=>{selectedPart=null;panel.hidden=true;viewer?.clearPart();};
  }
  function setUnits(key){const s=root.PLMRPergolaScene.read();s.dimensionUnits[key]=!s.dimensionUnits[key];if(!s.dimensionUnits.mm&&!s.dimensionUnits.inch)s.dimensionUnits[key==='mm'?'inch':'mm']=true;root.PLMRPergolaScene.change(n=>n.dimensionUnits=s.dimensionUnits);syncUnits();viewer?.units();}
  function syncUnits(){const u=root.PLMRPergolaScene.read().dimensionUnits;for(const key of ['mm','inch']){const b=$('rrV45'+(key==='mm'?'Mm':'Inch')+'Btn');b.classList.toggle('on',u[key]);b.classList.toggle('off',!u[key]);b.setAttribute('aria-pressed',String(u[key]));}}
  function layout(){
    root.PLMRPergolaProductPicker.open(native.legacy().drawingState.pergolaConfiguration,(values,configuration)=>openSettings({values:{...values,rayCount:'',postCount:''},configuration}));
  }
  bind('rrV14LayoutBtn',layout);bind('rrV45AddPositionBtn',()=>drawing?openSettings({add:true}):openSettings());
  bind('rrV45SettingsBtn',()=>openSettings());bind('rrV45Mode2DBtn',()=>setView('2D'));bind('rrV45Mode3DBtn',()=>setView('3D'));
  proxy('rrV15ProjectDownload','projectExportBtn');proxy('rrV15ProjectOpen','projectImportBtn');proxy('shellSave','projectExportBtn');proxy('rrV45Pdf2dBtn','pdfBtn');proxy('rrV45DxfBtn','generateBtn');
  bind('rrV45DaeBtn',()=>{setView('3D');if(!viewer)throw Error('Önce pergola oluşturun.');download(root.PLMRDrawingOutputNames.safeName(root.PLMRPergolaDocument.projectInfo(native.legacy().formData),'dae'),new Blob([viewer.dae()],{type:'model/vnd.collada+xml'}));});
  bind('rrV45CaptureBtn',()=>{if(!viewer)throw Error('Önce pergola oluşturun.');const a=document.createElement('a');a.href=viewer.capture();a.download='PLMR-Pergola.png';a.click();});
  for(const id of ['rrV45Pdf3dBtn','rrV22ScenesBtn','rrV22ShareBtn','rrV11ProductListPdfBtn','rrV45ProductionBtn']){const b=$(id);b.disabled=true;b.title='Ana uygulama entegrasyonunda bağlanacak.';}
  bind('rrV45ValidateBtn',()=>{root.PulumurDiagnostics.validateCurrentState();const m=drawing&&root.PLMRJustPergola.fromDrawing(drawing,'white');if(!m)throw Error('Önce pergola ölçülerini girin.');for(const z of m.zones)if(!(z.width>0&&z.height>0))throw Error('Geçersiz cephe bölgesi.');notify('Kontrol tamamlandı · '+m.assembly.systems.length+' sistem · '+m.zones.length+' cephe bölgesi.');});
  bind('rrV45MmBtn',()=>setUnits('mm'));bind('rrV45InchBtn',()=>setUnits('inch'));
  bind('rrV45PushPullToolBtn',()=>tool('pushpull'));
  document.querySelectorAll('[data-legacy-id]').forEach(b=>{const id=b.dataset.legacyId;b.disabled=id==='toolbarArBtn';b.onclick=()=>run(()=>{if(id==='toolbarRefreshBtn'){root.PulumurPreviewShell.refresh();refresh();}else if(id==='toolbarZoomInBtn')view==='3D'?viewer?.zoom(.82):root.PulumurPreviewShell.setZoom(root.PulumurPreviewShell.getZoom()*1.2);else if(id==='toolbarZoomOutBtn')view==='3D'?viewer?.zoom(1.22):root.PulumurPreviewShell.setZoom(root.PulumurPreviewShell.getZoom()/1.2);else if(id==='toolboxResetCameraBtn')fit();else if(id==='toolbarFullscreenBtn'){document.fullscreenElement?document.exitFullscreen():$('pergolaWorkspaceChrome').requestFullscreen();}});});
  $('v27Environment').onchange=e=>viewer?.theme(e.target.value);$('v28Fov').oninput=e=>{$('v28FovValue').textContent=e.target.value+'°';viewer?.fov(e.target.value);};
  // Ground selection uses the existing V34 presentation material provider.
  $('v27Floor').onchange=e=>viewer?.floor(e.target.value);
  const parapet=$('rrV45ParapetHeight');parapet.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'){const n=Number(parapet.value.replace(',','.'));if(!Number.isFinite(n)||n<0)return notify('Geçerli parapet yüksekliği yazın.');const l=native.legacy();const min=Math.min(...drawing.input.positions.map(p=>p.frontHeight));if(n>=min)return notify('Parapet oluk alt kotunu geçemez.');l.formData.parapet=n?'EVET':'HAYIR';l.formData.parapetHeight=String(n);run(()=>native.commitLegacy(l));}};
  bind('rrV45ZonesBtn',()=>{root.PLMRZones.setVisible(!root.PLMRZones.visible());viewer?.zones();});
  const zoneMenu=$('rrV45ZonesBtnArrow').nextElementSibling;
  zoneMenu.id='pergolaZoneFilter';document.body.append(zoneMenu);
  bind('rrV45ZonesBtnArrow',()=>{
    zoneMenu.hidden=!zoneMenu.hidden;
    if(zoneMenu.hidden)return;
    (document.fullscreenElement||document.body).append(zoneMenu);
    root.PLMRPergolaZones.buildZoneMenu(zoneMenu);
    const anchor=$('rrV45ZonesBtnArrow').getBoundingClientRect(),height=Math.min(390,zoneMenu.scrollHeight);
    zoneMenu.style.left=Math.max(12,Math.min(innerWidth-292,anchor.right-280))+'px';
    zoneMenu.style.top=Math.max(12,Math.min(innerHeight-height-12,anchor.bottom+4))+'px';
  });
  document.addEventListener('pointerdown',event=>{if(!zoneMenu.hidden&&!zoneMenu.contains(event.target)&&!$('rrV45ZonesBtnArrow').contains(event.target))zoneMenu.hidden=true;});
  function syncDimensions(){
    const d=root.PLMRPergolaScene.read().dimensions,enabled=d.main||d.intermediate;
    const button=$('rrV11DimensionsBtn');button.textContent=enabled?'Ölçüler Açık':'Ölçüler Kapalı';
    button.setAttribute('aria-pressed',String(!!enabled));button.dataset.visibilityState=enabled?'on':'off';
    native.refreshDimensions();
  }
  bind('rrV11DimensionsBtn',()=>{
    const d=root.PLMRPergolaScene.read().dimensions;
    root.PLMRPergolaScene.change(n=>{const enabled=!(d.main||d.intermediate);Object.assign(n.dimensions,{main:enabled,positions:enabled,total:enabled,roofs:enabled,intermediate:enabled,facades:enabled,byPosition:{},hiddenIds:{}});});syncDimensions();
  });
  const dimensionMenu=$('rrV11DimensionsBtnArrow').nextElementSibling;
  dimensionMenu.id='pergolaDimensionFilter';document.body.append(dimensionMenu);
  // Keep the native model-owned restore command reachable when the old
  // preview toolbar is hidden by the workspace shell. Retain its node/binding.
  const nativeRestoreDimensions=$('restoreHiddenDimensionsBtn');
  function buildDimensionMenu(){
    root.PLMRDimensionMenu.build(dimensionMenu,dimensionAdapter);
    if(nativeRestoreDimensions){nativeRestoreDimensions.classList.add('v33-tool','light');dimensionMenu.append(nativeRestoreDimensions);}
  }
  const dimensionAdapter={
    commands:{dimensions:()=>root.PLMRPergolaScene.read().dimensions,setDimensions:values=>{
      root.PLMRPergolaScene.change(next=>Object.assign(next.dimensions,values));
      syncDimensions();buildDimensionMenu();
    }},
    owners:()=>[{id:'roof-main',spec:{pozNo:1,freedomLayout:{modules:(drawing?.input.positions||[]).map((_,moduleIndex)=>({moduleIndex}))}}}],
    measurements:()=>root.PLMRPergolaDimensions.measurements(drawing,viewer?.inspect().measurements||[]),
    detailRows:()=>[], // No facade products installed by this standalone pergola engine.
    layout:()=>{} // Visibility is already owned and committed by the native scene state.
  };
  bind('rrV11DimensionsBtnArrow',()=>{
    dimensionMenu.hidden=!dimensionMenu.hidden;
    $('rrV11DimensionsBtnArrow').setAttribute('aria-expanded',String(!dimensionMenu.hidden));
    if(dimensionMenu.hidden)return;
    (document.fullscreenElement||document.body).append(dimensionMenu);
    buildDimensionMenu();
    const anchor=$('rrV11DimensionsBtnArrow').getBoundingClientRect();
    dimensionMenu.style.left=Math.max(12,Math.min(innerWidth-342,anchor.right-330))+'px';
    dimensionMenu.style.top=Math.max(12,Math.min(innerHeight-402,anchor.bottom+4))+'px';
  });
  document.addEventListener('pointerdown',event=>{if(!dimensionMenu.hidden&&!dimensionMenu.contains(event.target)&&!$('rrV11DimensionsBtnArrow').contains(event.target))dimensionMenu.hidden=true;});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'){dimensionMenu.hidden=true;zoneMenu.hidden=true;}});
  // Existing native commands remain authoritative for pergola-specific profile edits.
  const nativeCommands={rrV11MultiProfileAdd:'multiDimensionBtn',rrV11MultiProfileDelete:'bulkExtendBtn'};
  for(const[id,target]of Object.entries(nativeCommands))bind(id,()=>{$(target)?.click();});
  bind('rrV13GenerateZones',()=>{if(!drawing)throw Error('Önce pergola ölçülerini girin.');root.PLMRPergolaZones.generate();refresh();});
  bind('rrV11MultiProductAdd',()=>{
    const zones=root.PLMRZones.list().filter(z=>!z.isRoofZone&&root.PLMRPergolaZones.allowed(z));
    if(!zones.length)return notify('Önce Zone Oluştur ile cephe alanlarını oluşturun.');
    openZone({...zones[0],label:zones.length+' cephe alanı · '+zones.map(z=>z.label).join(', ')});
  });
  bind('rrV11MultiProductDelete',()=>notify('Bu bağımsız çizimde monte edilmiş cephe ürünü bulunmuyor.'));
  bind('rrV13CommonPost',()=>{$('postSettingsBtn').click();});
  document.querySelectorAll('button').forEach(b=>{if(b.textContent.trim()==='Pozları Düzenle')b.onclick=()=>openSettings();});
  bind('rrV11ResetDefaults',()=>{
    if(!baseline)return notify('Önce bir pergola oluşturun.');
    const next=clone(baseline.legacy),current=native.legacy();
    for(const key of ['projectCode','customer','country','customerRepresentative','project','drawnBy','date','version','description'])next.formData[key]=current.formData[key];
    const scene=clone(baseline.scene);scene.dimensionUnits=root.PLMRPergolaScene.read().dimensionUnits;
    scene.zoneFilters=root.PLMRV11Zones.defaults();scene.zonesVisible=true;
    native.commitLegacy(next,{scene,sideFeaturesExplicit:true});viewer?.tool('select');refresh();
  });
  bind('rrV16ResetAll',()=>{baseline=null;setView('2D');$('resetBtn').click();});
  bind('shellEntryToggle',()=>{const panel=document.querySelector('.v33-entry-panel');panel.classList.toggle('collapsed');panel.querySelector('.v33-entry-fields').hidden=panel.classList.contains('collapsed');document.querySelector('.v33-workspace-grid').style.setProperty('--v33-entry-width',panel.classList.contains('collapsed')?'52px':'220px');});
  bind('shellDrawerToggle',()=>{const drawer=document.querySelector('.v33-bottom-drawer');drawer.classList.toggle('collapsed');drawer.style.height=drawer.classList.contains('collapsed')?'48px':'260px';});bind('shellDetails',()=>{document.querySelector('.v33-bottom-drawer').classList.remove('collapsed');document.querySelector('.v33-bottom-drawer').style.height='260px';});
  bind('shellRetract',()=>{viewer?.move(0);$('shellMotion').value='0';$('shellMotionValue').textContent='%0';});bind('shellExtend',()=>{viewer?.move(1);$('shellMotion').value='100';$('shellMotionValue').textContent='%100';});$('shellMotion').oninput=e=>{viewer?.motion(Number(e.target.value)/100);$('shellMotionValue').textContent='%'+e.target.value;};
  document.querySelector('.v33-side-head button').onclick=()=>{const side=document.querySelector('.v33-side-toolbar');side.classList.toggle('collapsed');side.classList.toggle('open');side.querySelector('.v33-side-grid').hidden=side.classList.contains('collapsed');};
  new ResizeObserver(()=>{const side=document.querySelector('.v33-side-toolbar');document.querySelector('.v33-preview-stage').style.setProperty('--pergola-dock-width',Math.ceil(side.getBoundingClientRect().width+12)+'px');}).observe(document.querySelector('.v33-side-toolbar'));
  document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>notify(b.dataset.nav==='Yardım'?'Ayarlar → Ölçüler → Uygula. Cepheye tıklayın; bölgeleri ve profilleri düzenleyin.':'Bu çalışma yalnız pergola çizimi içindir.'));
  bind('shellLanguage',()=>{const n=$('languageSelect');n.value=n.value==='tr'?'en':'tr';n.dispatchEvent(new Event('change',{bubbles:true}));$('shellLanguage').textContent=n.value.toUpperCase()+'⌄';});
  $('preview').addEventListener('click',event=>{if(!event.target.closest('[data-interaction-type=pergolaVariantEditor]'))return;event.preventDefault();event.stopImmediatePropagation();openSettings();},true);
  root.addEventListener('plmr:pergola-drawing',e=>{drawing=e.detail.drawing;refresh();});root.addEventListener('plmr:project-restored',()=>{closeSettings();refresh();});root.addEventListener('plmr-project-file-loaded',refresh);
  root.addEventListener('plmr:project-sensitive-state-cleared',clearDrawing);
  function exportDrawing(format){
    if(!drawing)throw Error('Önce pergola oluşturun.');
    if(format==='SVG')return {svg:root.PulumurGeometry.renderSvg(drawing)};
    if(format==='DXF')return {text:root.PulumurModernDXF.toDxf(root.PulumurTechnical2DExport.cadDrawing(drawing))};
    if(format==='DAE')return {text:viewer.dae()};
    if(format==='JPEG'){
      const previous=view;
      try{
        setView('3D');
        const canvas=$('model3d').querySelector('canvas');
        return {dataUrl:viewer.capture('image/jpeg'),width:canvas.width,height:canvas.height,camera:viewer.cameraState()};
      }finally{setView(previous);}
    }
    throw Error('Pergola çıktı biçimi desteklenmiyor: '+format);
  }
  function setMotion(value){
    if(!Number.isFinite(value)||value<0||value>1)throw Error('Pergola hareket değeri geçersiz.');
    viewer?.motion(value);$('shellMotion').value=String(Math.round(value*100));$('shellMotionValue').textContent='%'+Math.round(value*100);
  }
  root.PLMRJustPergolaApp=Object.freeze({inspect:()=>({model:root.PulumurProjectState.getModel(),view,...viewer?.inspect()}),getView:()=>view,inspectContacts:()=>viewer?.contactDiagnostics(),inspectSolids:()=>viewer?.solidDiagnostics()||[],setView,openSettings,fit,motion:setMotion,exportDrawing,screenPart:id=>viewer?.screenPart(id),screenWall:(id,axis,sign)=>viewer?.screenWall(id,axis,sign),screenZone:id=>viewer?.screenZone(id)});
  const productSelect=$('rrV45ProductSelect');productSelect.hidden=true;const productHeading=document.createElement('strong');productHeading.id='pergolaProductHeading';productSelect.after(productHeading);for(const option of [...productSelect.options])if(option.value!=='pergo-rise')option.remove();
  native.embedded();ready=true;syncUnits();setView('3D');
  if(native.drawing())run(build);
})(window);
