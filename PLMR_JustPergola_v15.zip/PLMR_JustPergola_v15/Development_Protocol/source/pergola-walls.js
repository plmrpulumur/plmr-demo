/* Shared direct-modeling wall faces commit to native wall cells/segments. */
(function(root){
  'use strict';
  const clone=v=>JSON.parse(JSON.stringify(v));
  function bounds(w,native=false){
    const points=[];
    for(const s of root.PLMRRollingRoofSketchCore.cells(w))for(const x of [s.min[0],s.max[0]])for(const y of [s.min[1],s.max[1]])for(const z of [s.min[2],s.max[2]])points.push(root.PLMRRollingRoofSceneCore.wallPoint(w,[x,y,z]));
    const target=native?points.map(p=>{const pose=w.sourcePose||{},local=root.PLMRRollingRoofSceneCore.vector([p[0]-(pose.x||0),p[1]-(pose.y||0),p[2]-(pose.z||0)],-(pose.angle||0));local[2]+=w.sourceCenterZ||0;return local;}):points;
    return {min:[0,1,2].map(i=>Math.min(...target.map(p=>p[i]))),max:[0,1,2].map(i=>Math.max(...target.map(p=>p[i])))};
  }
  function commit(w,reason){
    if(w.sourceOwner!=='roof-main')throw Error('Bu kayıt eski bir kopyaya aittir; ana pergola değiştirilmedi.');
    const native=root.PLMRPergolaNative,drawing=native.drawing(),input=drawing.input;
    const model=root.PLMRJustPergola.fromDrawing(drawing,'white');
    const source=model.components.find(c=>c.id===w.sourceComponent);
    if(!source)throw Error('Duvarın native hücresi bulunamadı.');
    const scene=root.PLMRPergolaScene.read();scene.wallAppearance??={};scene.wallAppearance[source.id]=w.appearance||'white';
    if(reason==='wall-appearance'){native.commitScene(scene);return;}
    const b=bounds(w,true),legacy=native.legacy(),state=legacy.drawingState,system=model.assembly.systems[source.systemIndex];
    const dsystem=input.systems[source.systemIndex],origin=model.assembly.origin.sourceX;
    if(source.kind==='rear-wall'){
      const plan=clone(input.topBackWallGridState[String(source.systemIndex)]);
      const cell=plan.cells.find(c=>c.id===source.wallState.planCellId);
      const base=source.wallState.xOffset;
      cell.minX=b.min[0]-(dsystem.outerStartX-origin);cell.maxX=b.max[0]-(dsystem.outerStartX-origin);
      cell.startNearDepth=cell.endNearDepth=b.min[2]-base;
      cell.startFarDepth=cell.endFarDepth=b.max[2]-base;
      state.topBackWallGridState[String(source.systemIndex)]=plan;
      const key=source.systemIndex===input.systemCount-1&&input.systemCount>1?'right':source.systemIndex===0?'left':String(source.systemIndex);
      const side=key==='left'?state.backWallState.left:key==='right'?state.backWallState.right:(state.backWallState.middle[key]??={enabled:true});
      side.height=Math.max(source.topY,b.max[1]);side.depth=b.max[2]-b.min[2];side.xOffset=b.max[2]-system.rearDatumZ;
      const scopeKey=key==='left'?'0':key;
      const existing=clone(input.backWallGridState.side?.[scopeKey]||{bounds:{minX:0,maxX:side.depth,minY:0,maxY:side.height},cells:[]});
      if(!existing.cells.length)existing.cells=[{id:source.wallState.elevationCellId,minX:0,maxX:side.depth,minY:b.min[1],maxY:b.max[1]}];
      const elevation=existing.cells.find(c=>c.id===source.wallState.elevationCellId)||existing.cells[0];
      elevation.minY=b.min[1];elevation.maxY=b.max[1];
      if(existing.cells.length===1){elevation.minX=0;elevation.maxX=side.depth;}
      existing.autoHeight=false;existing.bounds={minX:Math.min(...existing.cells.map(c=>c.minX)),maxX:Math.max(...existing.cells.map(c=>c.maxX)),minY:Math.min(...existing.cells.map(c=>c.minY)),maxY:Math.max(...existing.cells.map(c=>c.maxY))};
      state.backWallGridState.side[scopeKey]=existing;
      // For a single system both exterior elevations describe the same rear wall.
      if(input.systemCount===1){state.backWallState.right=clone(side);state.backWallGridState.side.right=clone(existing);}
    }else{
      const side=source.parapetView==='side',key=source.sideViewKey;
      const list=side?clone(input.parapetSegments.side[key]):clone(input.parapetSegments.front);
      const segment=list.find(s=>s.id===source.parapetSegmentId)||list[0];
      if(!segment)throw Error('Parapet segmenti bulunamadı.');
      segment.start=side?b.min[2]-system.rearDatumZ:b.min[0]+origin-root.PulumurGeometry.K.systemStartX;
      segment.end=side?b.max[2]-system.rearDatumZ:b.max[0]+origin-root.PulumurGeometry.K.systemStartX;
      segment.directFaceEdit=true;segment.ownerSystemIndex=source.systemIndex;
      segment.baseElevation=b.min[1];segment.height=segment.startHeight=segment.endHeight=b.max[1];
      segment.thickness=side?b.max[0]-b.min[0]:b.max[2]-b.min[2];
      segment.normalOffset=side?(b.min[0]+b.max[0])/2-(key==='right'?system.outerEndX:system.outerStartX):b.max[2]-system.frontDatumZ;
      if(side)state.parapetSegments.side[key]=list;else state.parapetSegments.front=list;
    }
    const candidate=root.PulumurProjectModel.fromLegacy(legacy,root.PulumurProjectState.getModel());
    const raw=root.PulumurProjectModel.geometryInputFromModel(candidate),testDrawing=root.PulumurGeometry.buildDrawing(raw);
    const actual=root.PLMRJustPergola.fromDrawing(testDrawing,'white',raw).components.find(c=>c.id===source.id);
    if(!actual)throw Error('Duvar değişikliği 2D modelde oluşturulamadı.');
    const xs=actual.polygonXZ.map(p=>p[0]),zs=actual.polygonXZ.map(p=>p[1]);
    const min=[Math.min(...xs),actual.bottomY,Math.min(...zs)],max=[Math.max(...xs),actual.topY,Math.max(...zs)];
    if(min.some((v,i)=>Math.abs(v-b.min[i])>.1)||max.some((v,i)=>Math.abs(v-b.max[i])>.1))throw Error('Yüz değişikliği 2D duvar hücresiyle eşleşmedi; işlem uygulanmadı.');
    native.commitLegacy(legacy,{scene,sideFeaturesExplicit:true});
  }
  function addInZone(zone,height){
    if(zone.owner&&zone.owner!=='roof-main')throw Error('Bu cephe ana pergolaya ait değil.');
    const native=root.PLMRPergolaNative,legacy=native.legacy(),drawing=native.drawing(),model=root.PLMRJustPergola.fromDrawing(drawing,'white'),system=model.assembly.systems[zone.systemIndex],state=legacy.drawingState;
    const side=['left','right'].includes(zone.face),key=zone.face==='right'?'right':String(zone.meta?.sideViewKey??zone.sideViewKey??zone.systemIndex);
    state.parapetSegments??={front:[],side:{}};state.parapetSegments.side??={};
    if(legacy.formData.parapet!=='EVET'){
      const zero=(id,length)=>[{id,start:0,end:length,height:0,startHeight:0,endHeight:0}];
      state.parapetSegments.front=zero('front-clear',drawing.input.width);
      for(const s of model.assembly.systems)state.parapetSegments.side[String(s.index)]=zero('side-clear-'+s.index,s.opening);
      state.parapetSegments.side.right=zero('right-clear',model.assembly.systems.at(-1).opening);
    }
    const list=side?(state.parapetSegments.side[key]??=[]):state.parapetSegments.front;
    const start=side?Math.min(zone.a[2],zone.b[2])-system.rearDatumZ:Math.min(zone.a[0],zone.b[0])+model.assembly.origin.sourceX-root.PulumurGeometry.K.systemStartX;
    const end=start+zone.width,id='zone-wall-'+zone.id;
    const segment={id,start,end,height,startHeight:height,endHeight:height,thickness:100,baseElevation:zone.bottom||0,directFaceEdit:true,ownerSystemIndex:zone.systemIndex};
    const i=list.findIndex(s=>s.id===id);if(i<0)list.push(segment);else list[i]=segment;
    legacy.formData.parapet='EVET';legacy.formData.parapetHeight=String(height);native.commitLegacy(legacy,{sideFeaturesExplicit:true});
  }
  root.PLMRPergolaWalls=Object.freeze({commit,bounds,addInZone});
})(window);
