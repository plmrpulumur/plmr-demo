/* Same-origin PLMR host boundary. The host owns project IDs, history and saving. */
(function(root){
  'use strict';
  const embedded=new URLSearchParams(location.search).get('plmrEmbedded')==='1';
  if(!embedded)return;
  if(root.parent===root||location.origin==='null')throw Error('Gömülü pergola HTTP ana uygulaması içinde açılmalıdır.');
  const clone=x=>JSON.parse(JSON.stringify(x));
  let host=null,restoring=false,readOnly=true,paused=false,previousView='3D';
  const viewKeys=['dimensionUnits','dimensions','presentation','zoneFilters','zonesVisible'];
  function assertEditable(){if(readOnly)throw Error('Düzenlemek için ana uygulamanın çizim kilidini kaldırın.');}
  function capture(){
    const model=clone(root.PulumurProjectState.getModel());
    if(!model.positions?.length)return {workspace:null,view:{}};
    // Normalize the physical scene before separating view state. Otherwise the
    // first units/visibility edit turns null into defaults and looks physical.
    const scene=root.PLMRPergolaScene.read();
    model.workspaces.standalone.productId='PERGO_RISE';
    model.workspaces.standalone.project=scene;
    const view={nativeDimensions:clone(model.dimensions)};
    if(scene)for(const key of viewKeys){if(scene[key]!==undefined)view[key]=clone(scene[key]);delete scene[key];}
    // Project/customer/revision metadata is projected from PLMR at load time.
    // It is never a second project identity or customer record.
    model.metadata={product:model.metadata.product,moduleName:model.metadata.moduleName,engine:model.metadata.engine};
    model.dimensions={};delete model.revisionInfo;model.lastAction=null;
    return {workspace:{schema:'plmr-justpergola-workspace-v1',model},view};
  }
  function projectMetadata(info){
    return {projectCode:info.projectCode||'',customer:info.customerName||'',country:info.country||'',
      project:info.projectName||'',version:info.revision||'',date:info.date||info.createdAt||'',
      drawnBy:info.designer||info.projectRepresentative||'',customerRepresentative:info.customerRepresentative||'',description:info.description||''};
  }
  function load(packet,info){
    const source=packet?.workspace?.model;
    if(!source){
      restoring=true;
      try{root.PulumurProjectState.clearSensitiveState();}
      finally{restoring=false;}
      return;
    }
    const model=clone(source),view=packet.view||{};
    model.metadata={...model.metadata,...projectMetadata(info||{})};model.dimensions=clone(view.nativeDimensions||{});
    const scene=model.workspaces.standalone.project;
    if(scene)for(const key of viewKeys)if(view[key]!==undefined)scene[key]=clone(view[key]);
    const envelope=root.PulumurProjectSchema.createEnvelope(model,{appVersion:root.PulumurProjectState.appVersion});
    restoring=true;
    try{root.PulumurProjectState.restoreSnapshot(envelope,{resetZoom:false,resetHistory:true});}
    finally{restoring=false;}
  }
  function attach(adapter){
    if(host)throw Error('Pergola ana uygulamaya zaten bağlı.');
    if(!adapter||typeof adapter.change!=='function'||typeof adapter.undo!=='function'||typeof adapter.redo!=='function')throw Error('Pergola host sözleşmesi eksik.');
    host=adapter;readOnly=adapter.readOnly!==false;
    root.PLMRFinalMetadata={projectInfo:clone(adapter.projectInfo||{})};
    if(adapter.packet?.workspace)load(adapter.packet,adapter.projectInfo);
    return capture();
  }
  function changed(){
    if(!host||restoring)return;
    try{host.change(capture());}
    catch(error){host.error(error.message);}
  }
  root.addEventListener('plmr:pergola-drawing',changed);
  // The parent journal owns undo/redo while embedded.
  root.document.addEventListener('keydown',event=>{
    if(!host||/INPUT|TEXTAREA|SELECT/.test(event.target.tagName))return;
    if((event.ctrlKey||event.metaKey)&&['z','y'].includes(event.key.toLowerCase())){
      event.preventDefault();event.stopImmediatePropagation();if(readOnly)return;
      (event.key.toLowerCase()==='y'||event.shiftKey?host.redo:host.undo)();
    }
  },true);
  const viewButtons=new Set(['rrV45Mode2DBtn','rrV45Mode3DBtn','rrV45Pdf2dBtn','rrV45DxfBtn','rrV45DaeBtn','rrV45CaptureBtn','rrV11DimensionsBtnArrow','rrV11DimensionsBtn','rrV45MmBtn','rrV45InchBtn','shellExtend','shellRetract']);
  root.document.addEventListener('click',event=>{
    if(!readOnly)return;
    const b=event.target.closest('button');if(!b)return;
    if(viewButtons.has(b.id)||b.dataset.legacyId||b.closest('#pergolaDimensionFilter'))return;
    event.preventDefault();event.stopImmediatePropagation();
  },true);
  root.PLMRPergolaEmbedded=Object.freeze({capture,attach,load,assertEditable,
    setReadOnly(value){readOnly=!!value;},
    setMetadata(info){
      root.PLMRFinalMetadata={projectInfo:clone(info||{})};
      if(!root.PulumurProjectState.getModel().positions?.length)return;
      restoring=true;
      try{root.PLMRPergolaNative.refreshDocument();}
      finally{restoring=false;}
    },
    setActive(value){
      if(!root.PLMRJustPergolaApp)return;
      if(!value&&!paused){previousView=root.PLMRJustPergolaApp.getView();paused=true;root.PLMRJustPergolaApp.setView('2D');}
      else if(value&&paused){paused=false;root.PLMRJustPergolaApp.setView(previousView);}
    },
    command(id){const button=document.getElementById(id);if(!button||button.disabled)throw Error('Pergola komutu kullanılamıyor: '+id);button.click();},
    ready:()=>!!root.PLMRJustPergolaApp});
  root.addEventListener('pagehide',()=>{root.removeEventListener('plmr:pergola-drawing',changed);host=null;});
})(window);
