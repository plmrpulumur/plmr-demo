"""Create the standalone release archive and its SHA-256 manifest."""
from pathlib import Path
from hashlib import sha256
import json
import sys
import zipfile

root = Path(__file__).resolve().parent.parent
output = Path(sys.argv[1]).resolve()
if output.is_relative_to(root):
    raise SystemExit("Write the ZIP outside the release directory.")
manifest = root / "PACKAGE_SHA256.json"
paths = sorted(
    file for file in root.rglob("*")
    if file.is_file() and not file.is_symlink()
    and file != manifest and "__pycache__" not in file.parts
)
hashes = {file.relative_to(root).as_posix(): sha256(file.read_bytes()).hexdigest() for file in paths}
manifest.write_text(json.dumps({"release": root.name, "algorithm": "SHA256", "selfExcluded": manifest.name, "files": hashes}, indent=2) + "\n")
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
    for file in [*paths, manifest]:
        archive.write(file, root.name + "/" + file.relative_to(root).as_posix())
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(hashes) + 1
    for name, digest in hashes.items():
        assert sha256(archive.read(root.name + "/" + name)).hexdigest() == digest, name
print(json.dumps({"file": str(output), "files": len(hashes) + 1, "sha256": sha256(output.read_bytes()).hexdigest()}))
