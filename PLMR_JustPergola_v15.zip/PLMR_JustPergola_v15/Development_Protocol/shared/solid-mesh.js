/* Reflection-safe solid winding and deterministic depth ordering, without changing dimensions. */
(function(root){
  'use strict';
  function reverseFaces(geometry){
    if(geometry.index){const a=geometry.index;for(let i=0;i<a.count;i+=3){const value=a.getX(i+1);a.setX(i+1,a.getX(i+2));a.setX(i+2,value);}a.needsUpdate=true;}
    else for(const attribute of Object.values(geometry.attributes)){
      const data=attribute.array,size=attribute.itemSize;
      for(let i=0;i<attribute.count;i+=3)for(let k=0;k<size;k++){const a=(i+1)*size+k,b=(i+2)*size+k,v=data[a];data[a]=data[b];data[b]=v;}
      attribute.needsUpdate=true;
    }
    geometry.computeVertexNormals();return geometry;
  }
  function surface(material,rank){
    // The ordinary perspective depth buffer uses a small constant polygon offset.
    // Keep all native and exported coordinates exact; only coplanar raster order changes.
    // Do not bias by slope: steep side faces would be pulled through the covering plane.
    material.polygonOffset=true;
    material.polygonOffsetFactor=0;
    material.polygonOffsetUnits=-rank*4;
    material.userData.depthRank=rank;
    return material;
  }
  // Read-only welded-edge diagnostics of actual generated geometry (millimetres).
  function topology(geometry){
    const p=geometry.attributes.position,idx=geometry.index,edges=new Map();let volume=0,degenerate=0;
    const point=i=>[p.getX(i),p.getY(i),p.getZ(i)];
    const key=v=>v.map(n=>Math.round(n*1000)).join(',');
    for(let n=0;n<(idx?idx.count:p.count);n+=3){
      const v=[0,1,2].map(k=>point(idx?idx.getX(n+k):n+k)),keys=v.map(key);
      if(new Set(keys).size<3){degenerate++;continue;}
      const [a,b,c]=v;
      volume+=(a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6;
      for(let k=0;k<3;k++){const x=keys[k],y=keys[(k+1)%3],stamp=x<y?x+'|'+y:y+'|'+x;
        const e=edges.get(stamp)||{count:0,direction:0};e.count++;e.direction+=x<y?1:-1;edges.set(stamp,e);}
    }
    return {vertices:p.count,triangles:(idx?idx.count:p.count)/3,degenerate,
      boundaryEdges:[...edges.values()].filter(e=>e.count===1).length,
      nonManifoldEdges:[...edges.values()].filter(e=>e.count!==2).length,
      inconsistentEdges:[...edges.values()].filter(e=>e.direction!==0).length,signedVolume:volume};
  }
  root.PLMRSolidMesh=Object.freeze({reverseFaces,surface,topology});
})(window);
