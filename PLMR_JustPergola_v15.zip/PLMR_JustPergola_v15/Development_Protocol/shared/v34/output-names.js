/* V34 v5-roof-sheet output filename policy, extracted verbatim. */
(function(root){
  function safeName(info = {}, extension = 'dxf', view = '') {
    const name = String(info.projectCode || 'Proje').replace(/[<>:"/\\|?*\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '') || 'Proje';
    const raw = info.revision ?? 'DR00',
      revision = typeof raw === 'number' ? 'DR' + String(raw).padStart(2, '0') : String(raw).replace(/[<>:"/\\|?*\u0000-\u001f]/g, '').trim() || 'DR00';
    return view ? name + '-' + revision + '-' + view + '.' + extension : name + ' - ' + revision + '.' + extension;
  }
root.PLMRDrawingOutputNames=Object.freeze({safeName});
})(window);
