/* Pergola V5: dimensions and Push/Pull inferences only. No assembly transform commands. */
window.PLMRRollingRoofSceneTools=function(E){
'use strict';
const T=THREE,C=window.PLMRRollingRoofSceneCore,canvas=E.renderer.domElement;
let guide=null,snap=null,lock=null,alt=false,referenceMode=true;
const overlay=document.createElement('div');overlay.id='rrSceneOverlay';document.body.append(overlay);
const measureViewer=window.PLMRV15MeasureViewer(E);
function units(){return E.state().dimensionUnits||{mm:true,inch:false};}
function formatLength(value){const u=units(),parts=[];if(u.mm)parts.push(Math.round(value)+' mm');if(u.inch)parts.push((value/25.4).toFixed(2)+'"');return parts.join(' - ');}
function inputScale(){return !units().mm&&units().inch?25.4:1;}
function dispose(o){if(!o)return;o.parent?.remove(o);o.traverse(n=>{n.geometry?.dispose();for(const m of Array.isArray(n.material)?n.material:n.material?[n.material]:[])m.dispose();});}
function project(p){const q=p.clone().project(E.camera),r=canvas.getBoundingClientRect();return {x:r.left+(q.x+1)*r.width/2,y:r.top+(1-q.y)*r.height/2,visible:q.z<1&&q.z>-1&&q.x>-1&&q.x<1&&q.y>-1&&q.y<1};}
function corners(o){const pts=[];for(const x of [-o.width/2,o.width/2])for(const y of [-o.height/2,o.height/2])for(const z of [-o.depth/2,o.depth/2])pts.push(o.group.localToWorld(new T.Vector3(x,y,z)));return pts;}
function clearGuide(){dispose(guide);guide=null;snap=null;}
function showGuide(a,b,label){clearGuide();guide=new T.Line(new T.BufferGeometry().setFromPoints([a,b]),new T.LineDashedMaterial({color:0x14b8a6,dashSize:60,gapSize:40,depthTest:false,transparent:true,opacity:.75}));guide.computeLineDistances();guide.renderOrder=70;E.scene.add(guide);snap={label,point:b.toArray()};}
function references(exclude){const points=[],planes=[];const g=Number(E.state().groundY);planes.push({normal:new T.Vector3(0,1,0),at:g,label:'Zemin kotu'});for(const o of E.roofs()){if(o.id===exclude)continue;const cs=corners(o);for(const p of cs)points.push({point:p,label:'Ürün köşesi'});const u=new T.Vector3(1,0,0).applyQuaternion(o.group.quaternion),v=new T.Vector3(0,1,0),t=new T.Vector3(0,0,1).applyQuaternion(o.group.quaternion),center=o.group.getWorldPosition(new T.Vector3());for(const [n,size,label]of [[u,o.width,'Ürün sınırı'],[t,o.depth,'Ürün sınırı'],[v,o.height,'Ürün kotu']])for(const sign of [-1,1]){const p=center.clone().addScaledVector(n,size/2*sign);planes.push({normal:n,at:n.dot(p),point:p,label});}const beam=center.clone();beam.y+=o.height/2-260;planes.push({normal:v,at:beam.y,point:beam,label:'Oluk alt kotu'});}
for(const w of E.walls()){if(w.id===exclude)continue;for(const s of w.solids||[]){for(const x of [s.min[0],s.max[0]])for(const y of [s.min[1],s.max[1]])for(const z of [s.min[2],s.max[2]])points.push({point:new T.Vector3(...C.wallPoint(w,[x,y,z])),label:'Duvar köşesi'});const f=w.frame||C.zoneFrame(w.zone);for(const [axis,key]of [[0,'u'],[1,'v'],[2,'t']])for(const value of [s.min[axis],s.max[axis]]){const p=s.min.slice();p[axis]=value;const world=new T.Vector3(...C.wallPoint(w,p)),n=new T.Vector3(...f[key]);planes.push({normal:n,at:n.dot(world),point:world,label:axis===1?'Duvar kotu':'Duvar yüzü'});}}}
for(const t of E.state().templates||[]){const ps=C.footprint(t,g);for(const p of ps)points.push({point:new T.Vector3(...p),label:'Alan köşesi'});planes.push({normal:new T.Vector3(0,1,0),at:g+t.elevation,point:new T.Vector3(...ps[0]),label:'Platform üstü'});}
const physical=E.referenceGeometry?.();if(physical){points.push(...physical.points);planes.push(...physical.planes);}
return {points,planes};}
// Screen tolerance is independent of zoom. Leaving the tolerance releases the suggestion.
function snapDisplacement(start,n,delta,e,exclude){if(!referenceMode||e.altKey||alt){clearGuide();return {delta};}const target=start.clone().addScaledVector(n,delta),refs=references(exclude);let best=null,d=11;for(const plane of refs.planes){const dot=plane.normal.dot(n);if(Math.abs(dot)<.999)continue;const value=(plane.at-plane.normal.dot(start))/dot,p=start.clone().addScaledVector(n,value),A=project(target),B=project(p),dist=Math.hypot(A.x-B.x,A.y-B.y);if(dist<d&&B.visible){d=dist;best={delta:value,point:p,label:plane.label,ref:plane.point||p};}}if(snap&&Number.isFinite(snap.delta)){const held=new T.Vector3(...snap.point),A=project(target),B=project(held);if(Math.hypot(A.x-B.x,A.y-B.y)<18)best={delta:snap.delta,point:held,ref:held,label:snap.label};}if(lock)best=lock;if(best){showGuide(best.ref,best.point,best.label);snap.delta=best.delta;return best;}clearGuide();return {delta};}
function cancel(){clearGuide();lock=null;}
function key(e){if(e.key==='Alt')alt=true;if(e.key==='Shift'&&snap)lock={...snap,point:new T.Vector3(...snap.point),ref:new T.Vector3(...snap.point)};return false;}
function keyUp(e){if(e.key==='Alt')alt=false;if(e.key==='Shift')lock=null;}
return {formatLength,inputScale,project,references,snapDisplacement,clearGuide,cancel,key,keyUp,
 setTool:cancel,up:()=>false,move:()=>false,clearSelection:cancel,escape:cancel,
 setActive:value=>{overlay.hidden=!value;},refreshUnits:()=>measureViewer.rebuild(),
 rebuild:()=>measureViewer.rebuild(),refreshDimensions:()=>measureViewer.tick(),measurements:()=>measureViewer.inspect(),
 getState:()=>({operation:null,snap:snap?{...snap}:null,referencePlaneCount:references().planes.length,roofs:E.roofs().map(o=>({id:o.id,width:o.width,depth:o.depth,height:o.height}))})};
};
