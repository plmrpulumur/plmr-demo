/* Extracted V34 scene interaction policy; E supplies product-specific geometry only. */
(function(root){
  'use strict';
  function configure(controls){
    const T=root.THREE;
    controls.screenSpacePanning=true;
    controls.enableDamping=true;
    controls.dampingFactor=.08;
    controls.mouseButtons={LEFT:T.MOUSE.ROTATE,MIDDLE:T.MOUSE.DOLLY,RIGHT:T.MOUSE.PAN};
  }
  function zones(E){
    const toolboxSelectionMode=false;
function setZoneHighlight(mesh,active){
  if(!mesh||!mesh.material)return;
  if(toolboxSelectionMode){
    const eligible=Boolean(mesh.userData.toolboxEligible);
    const selected=Boolean(mesh.userData.toolboxSelected);
    mesh.material.opacity=selected?.30:(eligible?(active?.22:.13):.002);
    mesh.material.color.setHex(selected?0x16a34a:(eligible?0x38bdf8:0x64748b));
    return;
  }
  if(mesh.userData.zone?.isRoofZone){mesh.material.opacity=active?.14:0;mesh.material.color.setHex(0xff8c00);return;}
  const selected=Boolean(mesh.userData.selected);
  if(selected){
    mesh.material.opacity=.18;
    mesh.material.color.setHex(0xf59e0b);
    return;
  }
  mesh.material.opacity=active?(mesh.userData.occupied?.20:.16):(mesh.userData.occupied?.025:.018);
  mesh.material.color.setHex(mesh.userData.occupied?0x22c55e:0x38bdf8);
}

    let hovered=null,lastPointer=null;
    function clear(){if(hovered)setZoneHighlight(hovered,false);hovered=null;lastPointer=null;}
    function update(event){
      lastPointer=event;
      if(E.tool()!=='select'){clear();return;}
      if(event.buttons)return;
      const hit=E.pick(event),next=hit?.userData?.zone?hit:null;
      if(hovered&&hovered!==next)setZoneHighlight(hovered,false);
      hovered=next;
      if(next)setZoneHighlight(next,true);
      E.canvas.style.cursor=next?'pointer':'grab';
    }
    return {update,clear,changed:()=>{if(lastPointer&&!lastPointer.buttons)update(lastPointer);},
      initialise:mesh=>setZoneHighlight(mesh,false),inspect:()=>hovered?.userData.zone.id||null};
  }
  root.PLMRSceneInteraction=Object.freeze({configure,zones});
})(window);
