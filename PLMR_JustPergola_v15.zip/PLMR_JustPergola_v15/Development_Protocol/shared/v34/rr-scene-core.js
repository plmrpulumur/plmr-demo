/* Canonical placement and dimension-driven environment templates. Y is renderer up. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.PLMRRollingRoofSceneCore=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const clone=x=>JSON.parse(JSON.stringify(x)),rad=x=>x*Math.PI/180;
function pose(p={}){const out={x:Number(p.x||0),y:Number(p.y||0),z:Number(p.z||0),angle:Number(p.angle||0)};if(!Object.values(out).every(Number.isFinite))throw Error('Geçersiz konum/açı.');return out;}
function vector(v,angle){const a=rad(angle),c=Math.cos(a),s=Math.sin(a);return [c*v[0]-s*v[2],v[1],s*v[0]+c*v[2]];}
function zoneFrame(z){if(z.frameAngle){const f=zoneFrame({...z,frameAngle:0}),center=[z.frameCenter.x,0,z.frameCenter.z],delta=f.origin.map((v,i)=>v-center[i]);return {...f,origin:vector(delta,z.frameAngle*180/Math.PI).map((v,i)=>v+center[i]),u:vector(f.u,z.frameAngle*180/Math.PI),t:vector(f.t,z.frameAngle*180/Math.PI)};}const along=z.axis==='z'?[0,0,1]:[1,0,0],out=z.axis==='z'?[-Number(z.inward||1),0,0]:[0,0,-Number(z.inward||1)];return {origin:z.axis==='z'?[Number(z.cx||0)+Number(z.outerFaceV||0),Number(z.bottomY||0),Number(z.cz||0)-z.width/2]:[Number(z.cx||0)-z.width/2,Number(z.bottomY||0),Number(z.cz||0)+Number(z.outerFaceV||0)],u:along,v:[0,1,0],t:out};}
function wallPoint(w,p){const f=w.frame||zoneFrame(w.zone);return f.origin.map((x,i)=>x+f.u[i]*p[0]+f.v[i]*p[1]+f.t[i]*p[2]);}
return Object.freeze({clone,pose,vector,zoneFrame,wallPoint});
});
