/* Actual profile faces augment the V34 11px / 18px inference policy. */
(function(root){
  'use strict';
  function collect(roots){
    const T=root.THREE,planes=[],points=[],seen=new Set();
    for(const group of roots){
      group.updateWorldMatrix(true,true);
      group.traverse(mesh=>{
        const c=mesh.userData.component;
        if(!mesh.isMesh||!c||c.kind==='fabric'||c.polygonXZ||mesh.userData.isZonePicker)return;
        for(let node=mesh;node;node=node.parent)if(!node.visible)return;
        mesh.geometry.computeBoundingBox();const b=mesh.geometry.boundingBox;
        if(!b||b.isEmpty())return;
        const label='Profil yüzü · '+(c.label||c.kind),normalMatrix=new T.Matrix3().getNormalMatrix(mesh.matrixWorld);
        for(let axis=0;axis<3;axis++)for(const sign of [-1,1]){
          const local=b.getCenter(new T.Vector3());local.setComponent(axis,(sign<0?b.min:b.max).getComponent(axis));
          const point=local.applyMatrix4(mesh.matrixWorld),normal=new T.Vector3().setComponent(axis,sign).applyMatrix3(normalMatrix).normalize();
          const at=normal.dot(point),key=normal.toArray().map(n=>n.toFixed(6)).join(',')+':'+at.toFixed(3);
          if(!seen.has(key)){seen.add(key);planes.push({normal,at,point,label,componentId:c.id});}
        }
        for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z])
          points.push({point:new T.Vector3(x,y,z).applyMatrix4(mesh.matrixWorld),label:'Profil köşesi',componentId:c.id});
      });
    }
    return {planes,points};
  }
  root.PLMRSceneReferenceGeometry=Object.freeze({collect});
})(window);
