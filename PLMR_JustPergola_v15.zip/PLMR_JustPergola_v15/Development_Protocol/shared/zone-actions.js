/* Product-neutral facade action chooser. Host and standalone bind the same commands. */
(function(root){
  'use strict';if(root.PLMRZoneActions)return;let active=null;
  const commands=Object.freeze([['wall','Duvar Ekle · 1000 mm'],['profile','Profil Ekle'],['dimension','Ölçüyü Düzenle'],['switch','Yön Değiştir　⇆'],['product','Ürün Yerleştir'],['main-product','Ana Ürün Ekle']]);
  function close(){active?.remove();active=null;}
  function open(zone,adapter){
    close();const back=document.createElement('div');back.id='zoneActionDialog';back.className='plmr-zone-action-backdrop';back.setAttribute('role','dialog');back.setAttribute('aria-modal','true');back.setAttribute('aria-labelledby','zoneActionTitle');
    back.innerHTML='<section class="zone-action-card"><h2 id="zoneActionTitle"></h2><main><p id="zoneActionInfo"></p><div class="zone-action-grid"></div><p class="zone-action-error" role="alert"></p></main><footer><button type="button" data-zone-action="close">Kapat</button></footer></section>';
    back.querySelector('h2').textContent=zone.label;back.querySelector('#zoneActionInfo').textContent=Math.round(zone.width)+' × '+Math.round(zone.height)+' mm net alan. Yapılacak işlemi seçin.';
    const grid=back.querySelector('.zone-action-grid');
    for(const [id,label]of commands){const b=document.createElement('button');b.type='button';b.dataset.zoneAction=id;b.textContent=label;b.disabled=adapter.available?.(id,zone)===false;b.onclick=()=>{try{adapter.execute(id,zone,close);}catch(e){back.querySelector('.zone-action-error').textContent=e.message;}};grid.append(b);}
    back.querySelector('[data-zone-action=close]').onclick=close;back.onmousedown=e=>{if(e.target===back)close();};back.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape')close();};
    (document.fullscreenElement||document.body).append(back);active=back;grid.querySelector('button:not(:disabled)')?.focus();return back;
  }
  root.PLMRZoneActions=Object.freeze({open,close,commands});
})(window);
