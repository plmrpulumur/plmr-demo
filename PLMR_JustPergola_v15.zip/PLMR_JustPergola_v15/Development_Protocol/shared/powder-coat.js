/* Display-only material policy. Catalog colors and saved finish codes are unchanged. */
(function(root){
  'use strict';
  const THREE=root.THREE;
  let grain;
  const finishes={
    GLOSS:{roughness:.22,metalness:.025,clearcoat:.62,clearcoatRoughness:.18},
    MATTE:{roughness:.64,metalness:.015,clearcoat:.07,clearcoatRoughness:.6},
    TEXTURE:{roughness:.78,metalness:.01,clearcoat:0,clearcoatRoughness:1}
  };
  function texture(){
    if(grain)return grain;
    const size=64,data=new Uint8Array(size*size*4);
    let seed=73461;
    for(let i=0;i<data.length;i+=4){
      seed=(Math.imul(seed,1664525)+1013904223)>>>0;
      const value=98+(seed>>>25&63);
      data.set([value,value,value,255],i);
    }
    grain=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);
    grain.wrapS=grain.wrapT=THREE.RepeatWrapping;
    grain.repeat.set(7,7);
    grain.magFilter=THREE.LinearFilter;
    grain.minFilter=THREE.LinearMipmapLinearFilter;
    grain.generateMipmaps=true;
    grain.userData={...grain.userData,p3dvShared:true};
    grain.needsUpdate=true;
    return grain;
  }
  function create(color,finish,options={}){
    const key=['GLOSS','PARLAK'].includes(finish)?'GLOSS':finish==='TEXTURE'?'TEXTURE':'MATTE';
    const settings={...finishes[key],...options};
    if(key==='TEXTURE')Object.assign(settings,{bumpMap:texture(),bumpScale:.09});
    const material=new THREE.MeshPhysicalMaterial({color,...settings});
    material.userData.plmrPaintColor=new THREE.Color(color).getHex();
    material.color.convertSRGBToLinear();
    // The composite viewer uses the legacy linear output; isolated viewers use sRGB.
    material.onBeforeCompile=(shader,renderer)=>{
      if(renderer.outputEncoding===THREE.LinearEncoding){
        shader.fragmentShader=shader.fragmentShader.replace(
          '#include <encodings_fragment>','gl_FragColor = LinearTosRGB(gl_FragColor);'
        );
      }
    };
    material.customProgramCacheKey=()=> 'PLMR_POWDER_COAT_V22';
    return material;
  }
  root.PLMRPowderCoat=Object.freeze({create});
})(window);
