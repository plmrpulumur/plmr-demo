// V16 clean extraction from PLMR_V49 modules/p3dv/src/ral-colors.js.
// Only canonical swatch metadata is retained; no V49 runtime/state dependency.
const RAL_STANDARD_CODES = [
  "RAL 1013",
  "RAL 1035",
  "RAL 1313",
  "RAL 7016",
  "RAL 7039",
  "RAL 7106",
  "RAL 7421",
  "RAL 9003",
  "RAL 9005",
  "RAL 9006",
  "RAL 9016",
  "A-4252-V1-118",
  "A-4395-V1-118",
  "A-4513-V1-119"
]
const RAL_COLOR_CATALOG = [
  {
    "code": "RAL 1000",
    "hex": "#93966B",
    "image": "assets/colors/ral/ral-1000.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1001",
    "hex": "#998D66",
    "image": "assets/colors/ral/ral-1001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1002",
    "hex": "#988656",
    "image": "assets/colors/ral/ral-1002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1003",
    "hex": "#AC8117",
    "image": "assets/colors/ral/ral-1003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1004",
    "hex": "#A68112",
    "image": "assets/colors/ral/ral-1004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1005",
    "hex": "#987725",
    "image": "assets/colors/ral/ral-1005.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1006",
    "hex": "#A67626",
    "image": "assets/colors/ral/ral-1006.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1007",
    "hex": "#A67128",
    "image": "assets/colors/ral/ral-1007.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1011",
    "hex": "#836844",
    "image": "assets/colors/ral/ral-1011.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1012",
    "hex": "#A28D18",
    "image": "assets/colors/ral/ral-1012.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1013",
    "hex": "#ABA991",
    "image": "assets/colors/ral/ral-1013.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1014",
    "hex": "#A29775",
    "image": "assets/colors/ral/ral-1014.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1015",
    "hex": "#AAA289",
    "image": "assets/colors/ral/ral-1015.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1016",
    "hex": "#A3A727",
    "image": "assets/colors/ral/ral-1016.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1017",
    "hex": "#AC833F",
    "image": "assets/colors/ral/ral-1017.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1018",
    "hex": "#AFA21E",
    "image": "assets/colors/ral/ral-1018.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1019",
    "hex": "#7A7162",
    "image": "assets/colors/ral/ral-1019.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1020",
    "hex": "#75704E",
    "image": "assets/colors/ral/ral-1020.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1021",
    "hex": "#AC900C",
    "image": "assets/colors/ral/ral-1021.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1023",
    "hex": "#AC900C",
    "image": "assets/colors/ral/ral-1023.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1024",
    "hex": "#89763F",
    "image": "assets/colors/ral/ral-1024.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1027",
    "hex": "#806A28",
    "image": "assets/colors/ral/ral-1027.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1028",
    "hex": "#AA7328",
    "image": "assets/colors/ral/ral-1028.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1032",
    "hex": "#A28312",
    "image": "assets/colors/ral/ral-1032.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1033",
    "hex": "#AA752B",
    "image": "assets/colors/ral/ral-1033.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1034",
    "hex": "#A87C40",
    "image": "assets/colors/ral/ral-1034.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1035",
    "hex": "#575048",
    "image": "assets/colors/ral/ral-1035.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 1313",
    "hex": "#B6AF99",
    "image": "assets/colors/ral/ral-1313.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2000",
    "hex": "#A25925",
    "image": "assets/colors/ral/ral-2000.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2001",
    "hex": "#90402A",
    "image": "assets/colors/ral/ral-2001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2002",
    "hex": "#94332A",
    "image": "assets/colors/ral/ral-2002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2003",
    "hex": "#A55A27",
    "image": "assets/colors/ral/ral-2003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2004",
    "hex": "#A34323",
    "image": "assets/colors/ral/ral-2004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2008",
    "hex": "#A65326",
    "image": "assets/colors/ral/ral-2008.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2009",
    "hex": "#A24023",
    "image": "assets/colors/ral/ral-2009.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2010",
    "hex": "#9E4E2E",
    "image": "assets/colors/ral/ral-2010.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2011",
    "hex": "#A55927",
    "image": "assets/colors/ral/ral-2011.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 2012",
    "hex": "#A0523F",
    "image": "assets/colors/ral/ral-2012.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3000",
    "hex": "#862A28",
    "image": "assets/colors/ral/ral-3000.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3001",
    "hex": "#802828",
    "image": "assets/colors/ral/ral-3001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3002",
    "hex": "#7F2A28",
    "image": "assets/colors/ral/ral-3002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3003",
    "hex": "#70282A",
    "image": "assets/colors/ral/ral-3003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3004",
    "hex": "#5F262D",
    "image": "assets/colors/ral/ral-3004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3005",
    "hex": "#53262B",
    "image": "assets/colors/ral/ral-3005.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3007",
    "hex": "#3E282A",
    "image": "assets/colors/ral/ral-3007.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3009",
    "hex": "#5C3431",
    "image": "assets/colors/ral/ral-3009.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3011",
    "hex": "#672A2E",
    "image": "assets/colors/ral/ral-3011.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3012",
    "hex": "#966A57",
    "image": "assets/colors/ral/ral-3012.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3013",
    "hex": "#7A2D2E",
    "image": "assets/colors/ral/ral-3013.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3014",
    "hex": "#9C595A",
    "image": "assets/colors/ral/ral-3014.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3015",
    "hex": "#A27A80",
    "image": "assets/colors/ral/ral-3015.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3016",
    "hex": "#843630",
    "image": "assets/colors/ral/ral-3016.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3017",
    "hex": "#994449",
    "image": "assets/colors/ral/ral-3017.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3018",
    "hex": "#98363F",
    "image": "assets/colors/ral/ral-3018.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3020",
    "hex": "#962824",
    "image": "assets/colors/ral/ral-3020.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3022",
    "hex": "#9B5342",
    "image": "assets/colors/ral/ral-3022.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3027",
    "hex": "#8C2B31",
    "image": "assets/colors/ral/ral-3027.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 3031",
    "hex": "#842D33",
    "image": "assets/colors/ral/ral-3031.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4001",
    "hex": "#6A4967",
    "image": "assets/colors/ral/ral-4001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4002",
    "hex": "#733644",
    "image": "assets/colors/ral/ral-4002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4003",
    "hex": "#994768",
    "image": "assets/colors/ral/ral-4003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4004",
    "hex": "#59272F",
    "image": "assets/colors/ral/ral-4004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4005",
    "hex": "#5F4E73",
    "image": "assets/colors/ral/ral-4005.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4006",
    "hex": "#782857",
    "image": "assets/colors/ral/ral-4006.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4007",
    "hex": "#432639",
    "image": "assets/colors/ral/ral-4007.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4008",
    "hex": "#703B65",
    "image": "assets/colors/ral/ral-4008.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4009",
    "hex": "#796973",
    "image": "assets/colors/ral/ral-4009.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 4010",
    "hex": "#942F59",
    "image": "assets/colors/ral/ral-4010.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5000",
    "hex": "#34425C",
    "image": "assets/colors/ral/ral-5000.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5001",
    "hex": "#253F55",
    "image": "assets/colors/ral/ral-5001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5002",
    "hex": "#2A2F61",
    "image": "assets/colors/ral/ral-5002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5003",
    "hex": "#2B364C",
    "image": "assets/colors/ral/ral-5003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5004",
    "hex": "#272631",
    "image": "assets/colors/ral/ral-5004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5005",
    "hex": "#1E3F6C",
    "image": "assets/colors/ral/ral-5005.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5007",
    "hex": "#375370",
    "image": "assets/colors/ral/ral-5007.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5008",
    "hex": "#2D3942",
    "image": "assets/colors/ral/ral-5008.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5009",
    "hex": "#2B4A5F",
    "image": "assets/colors/ral/ral-5009.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5010",
    "hex": "#1E3D63",
    "image": "assets/colors/ral/ral-5010.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5011",
    "hex": "#26303D",
    "image": "assets/colors/ral/ral-5011.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5012",
    "hex": "#246489",
    "image": "assets/colors/ral/ral-5012.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5013",
    "hex": "#2A2F4A",
    "image": "assets/colors/ral/ral-5013.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5014",
    "hex": "#525F75",
    "image": "assets/colors/ral/ral-5014.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5015",
    "hex": "#1A5C84",
    "image": "assets/colors/ral/ral-5015.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5017",
    "hex": "#1A466E",
    "image": "assets/colors/ral/ral-5017.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5018",
    "hex": "#1D6A6F",
    "image": "assets/colors/ral/ral-5018.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5019",
    "hex": "#21496B",
    "image": "assets/colors/ral/ral-5019.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5020",
    "hex": "#1A3B48",
    "image": "assets/colors/ral/ral-5020.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5021",
    "hex": "#165A5F",
    "image": "assets/colors/ral/ral-5021.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5022",
    "hex": "#332D4F",
    "image": "assets/colors/ral/ral-5022.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5023",
    "hex": "#3D5370",
    "image": "assets/colors/ral/ral-5023.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 5024",
    "hex": "#4E7084",
    "image": "assets/colors/ral/ral-5024.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6000",
    "hex": "#2F5C50",
    "image": "assets/colors/ral/ral-6000.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6001",
    "hex": "#275A36",
    "image": "assets/colors/ral/ral-6001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6002",
    "hex": "#255033",
    "image": "assets/colors/ral/ral-6002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6003",
    "hex": "#3E4938",
    "image": "assets/colors/ral/ral-6003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6004",
    "hex": "#1D3D3F",
    "image": "assets/colors/ral/ral-6004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6005",
    "hex": "#1E3D34",
    "image": "assets/colors/ral/ral-6005.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6006",
    "hex": "#383D39",
    "image": "assets/colors/ral/ral-6006.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6007",
    "hex": "#2A342A",
    "image": "assets/colors/ral/ral-6007.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6008",
    "hex": "#313630",
    "image": "assets/colors/ral/ral-6008.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6009",
    "hex": "#283730",
    "image": "assets/colors/ral/ral-6009.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6010",
    "hex": "#345C36",
    "image": "assets/colors/ral/ral-6010.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6011",
    "hex": "#50654A",
    "image": "assets/colors/ral/ral-6011.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6012",
    "hex": "#2E3B3B",
    "image": "assets/colors/ral/ral-6012.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6013",
    "hex": "#5C5F4A",
    "image": "assets/colors/ral/ral-6013.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6014",
    "hex": "#3C3D37",
    "image": "assets/colors/ral/ral-6014.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6015",
    "hex": "#363B37",
    "image": "assets/colors/ral/ral-6015.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6016",
    "hex": "#125745",
    "image": "assets/colors/ral/ral-6016.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6017",
    "hex": "#396939",
    "image": "assets/colors/ral/ral-6017.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6018",
    "hex": "#397A36",
    "image": "assets/colors/ral/ral-6018.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6019",
    "hex": "#849B7F",
    "image": "assets/colors/ral/ral-6019.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6020",
    "hex": "#334033",
    "image": "assets/colors/ral/ral-6020.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6021",
    "hex": "#667A5F",
    "image": "assets/colors/ral/ral-6021.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6022",
    "hex": "#383933",
    "image": "assets/colors/ral/ral-6022.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6024",
    "hex": "#0B6944",
    "image": "assets/colors/ral/ral-6024.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6025",
    "hex": "#435C36",
    "image": "assets/colors/ral/ral-6025.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6026",
    "hex": "#0F4E45",
    "image": "assets/colors/ral/ral-6026.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6027",
    "hex": "#5C8986",
    "image": "assets/colors/ral/ral-6027.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6028",
    "hex": "#2A473F",
    "image": "assets/colors/ral/ral-6028.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6029",
    "hex": "#0B5A3A",
    "image": "assets/colors/ral/ral-6029.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6032",
    "hex": "#0F6948",
    "image": "assets/colors/ral/ral-6032.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6033",
    "hex": "#396A67",
    "image": "assets/colors/ral/ral-6033.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 6034",
    "hex": "#5D8384",
    "image": "assets/colors/ral/ral-6034.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7000",
    "hex": "#606B71",
    "image": "assets/colors/ral/ral-7000.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7001",
    "hex": "#6B7579",
    "image": "assets/colors/ral/ral-7001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7002",
    "hex": "#636154",
    "image": "assets/colors/ral/ral-7002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7003",
    "hex": "#5C5F57",
    "image": "assets/colors/ral/ral-7003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7004",
    "hex": "#767A7D",
    "image": "assets/colors/ral/ral-7004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7005",
    "hex": "#51585B",
    "image": "assets/colors/ral/ral-7005.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7006",
    "hex": "#595951",
    "image": "assets/colors/ral/ral-7006.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7008",
    "hex": "#5C5239",
    "image": "assets/colors/ral/ral-7008.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7009",
    "hex": "#47504B",
    "image": "assets/colors/ral/ral-7009.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7010",
    "hex": "#464C4A",
    "image": "assets/colors/ral/ral-7010.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7011",
    "hex": "#444C52",
    "image": "assets/colors/ral/ral-7011.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7012",
    "hex": "#465052",
    "image": "assets/colors/ral/ral-7012.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7013",
    "hex": "#464741",
    "image": "assets/colors/ral/ral-7013.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7015",
    "hex": "#424951",
    "image": "assets/colors/ral/ral-7015.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7016",
    "hex": "#333B3E",
    "image": "assets/colors/ral/ral-7016.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7021",
    "hex": "#2E3336",
    "image": "assets/colors/ral/ral-7021.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7022",
    "hex": "#3F4440",
    "image": "assets/colors/ral/ral-7022.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7023",
    "hex": "#61665F",
    "image": "assets/colors/ral/ral-7023.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7024",
    "hex": "#3A4147",
    "image": "assets/colors/ral/ral-7024.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7026",
    "hex": "#313D41",
    "image": "assets/colors/ral/ral-7026.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7030",
    "hex": "#6E706B",
    "image": "assets/colors/ral/ral-7030.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7031",
    "hex": "#49555D",
    "image": "assets/colors/ral/ral-7031.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7032",
    "hex": "#8A8A7E",
    "image": "assets/colors/ral/ral-7032.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7033",
    "hex": "#616960",
    "image": "assets/colors/ral/ral-7033.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7034",
    "hex": "#8F8F8F",
    "image": "assets/colors/ral/ral-7034.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7035",
    "hex": "#939798",
    "image": "assets/colors/ral/ral-7035.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7036",
    "hex": "#737277",
    "image": "assets/colors/ral/ral-7036.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7037",
    "hex": "#5C6164",
    "image": "assets/colors/ral/ral-7037.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7038",
    "hex": "#868883",
    "image": "assets/colors/ral/ral-7038.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7039",
    "hex": "#535550",
    "image": "assets/colors/ral/ral-7039.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7040",
    "hex": "#757A7E",
    "image": "assets/colors/ral/ral-7040.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7042",
    "hex": "#6C7376",
    "image": "assets/colors/ral/ral-7042.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7043",
    "hex": "#363F40",
    "image": "assets/colors/ral/ral-7043.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7044",
    "hex": "#8C8B85",
    "image": "assets/colors/ral/ral-7044.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7045",
    "hex": "#6B707A",
    "image": "assets/colors/ral/ral-7045.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7046",
    "hex": "#5A656E",
    "image": "assets/colors/ral/ral-7046.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7047",
    "hex": "#9C9BA0",
    "image": "assets/colors/ral/ral-7047.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7106",
    "hex": "#34302F",
    "image": "assets/colors/ral/ral-7106.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 7421",
    "hex": "#2D3034",
    "image": "assets/colors/ral/ral-7421.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8000",
    "hex": "#695937",
    "image": "assets/colors/ral/ral-8000.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8001",
    "hex": "#79532D",
    "image": "assets/colors/ral/ral-8001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8002",
    "hex": "#61443A",
    "image": "assets/colors/ral/ral-8002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8003",
    "hex": "#67462D",
    "image": "assets/colors/ral/ral-8003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8004",
    "hex": "#704031",
    "image": "assets/colors/ral/ral-8004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8007",
    "hex": "#5A3F2D",
    "image": "assets/colors/ral/ral-8007.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8008",
    "hex": "#5A432E",
    "image": "assets/colors/ral/ral-8008.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8011",
    "hex": "#4C362B",
    "image": "assets/colors/ral/ral-8011.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8012",
    "hex": "#573431",
    "image": "assets/colors/ral/ral-8012.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8014",
    "hex": "#40352F",
    "image": "assets/colors/ral/ral-8014.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8015",
    "hex": "#533633",
    "image": "assets/colors/ral/ral-8015.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8016",
    "hex": "#452F2A",
    "image": "assets/colors/ral/ral-8016.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8017",
    "hex": "#3D3330",
    "image": "assets/colors/ral/ral-8017.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8019",
    "hex": "#363739",
    "image": "assets/colors/ral/ral-8019.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8022",
    "hex": "#27282A",
    "image": "assets/colors/ral/ral-8022.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8023",
    "hex": "#7F4B2B",
    "image": "assets/colors/ral/ral-8023.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8024",
    "hex": "#5F4736",
    "image": "assets/colors/ral/ral-8024.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8025",
    "hex": "#5C4B3F",
    "image": "assets/colors/ral/ral-8025.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 8028",
    "hex": "#45362E",
    "image": "assets/colors/ral/ral-8028.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9001",
    "hex": "#ABA99D",
    "image": "assets/colors/ral/ral-9001.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9002",
    "hex": "#A2A39B",
    "image": "assets/colors/ral/ral-9002.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9003",
    "hex": "#D9D9D8",
    "image": "assets/colors/ral/ral-9003.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9004",
    "hex": "#2E3336",
    "image": "assets/colors/ral/ral-9004.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9005",
    "hex": "#0B0B0B",
    "image": "assets/colors/ral/ral-9005.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9006",
    "hex": "#7C7D7F",
    "image": "assets/colors/ral/ral-9006.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9007",
    "hex": "#6B6E6D",
    "image": "assets/colors/ral/ral-9007.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9010",
    "hex": "#D9D9D8",
    "image": "assets/colors/ral/ral-9010.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9011",
    "hex": "#2A2F34",
    "image": "assets/colors/ral/ral-9011.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9016",
    "hex": "#CCCFD0",
    "image": "assets/colors/ral/ral-9016.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9017",
    "hex": "#2B3033",
    "image": "assets/colors/ral/ral-9017.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "RAL 9018",
    "hex": "#989B96",
    "image": "assets/colors/ral/ral-9018.jpg",
    "kind": "ral",
    "name": ""
  },
  {
    "code": "A-4252-V1-118",
    "hex": "#81563A",
    "image": "assets/colors/ral/a-4252-v1-118.jpg",
    "kind": "wood-transfer",
    "name": "Wood Transfer"
  },
  {
    "code": "A-4395-V1-118",
    "hex": "#372312",
    "image": "assets/colors/ral/a-4395-v1-118.jpg",
    "kind": "wood-transfer",
    "name": "Wood Transfer"
  },
  {
    "code": "A-4513-V1-119",
    "hex": "#5B2F16",
    "image": "assets/colors/ral/a-4513-v1-119.jpg",
    "kind": "wood-transfer",
    "name": "Wood Transfer"
  }
]
window.PLMRRal={RAL_STANDARD_CODES,RAL_COLOR_CATALOG};
