from pathlib import Path
import hashlib, json, shutil

protocol = Path(__file__).resolve().parent
runtime = protocol.parent / "Uygulama"
if runtime.exists():
    shutil.rmtree(runtime)
runtime.mkdir()
shutil.copytree(protocol / "peri01", runtime, dirs_exist_ok=True)
for name in ("source", "shared"):
    shutil.copytree(protocol / name, runtime / name, ignore=shutil.ignore_patterns("index.html"))
shutil.copyfile(protocol / "source/index.html", runtime / "index.html")
files = {
    str(p.relative_to(runtime)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted(runtime.rglob("*"))
    if p.is_file()
}
(runtime / "SOURCE_SHA256.json").write_text(json.dumps(files, indent=2) + "\n")
