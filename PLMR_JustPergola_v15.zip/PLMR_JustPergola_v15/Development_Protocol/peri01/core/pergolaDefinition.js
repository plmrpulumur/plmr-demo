/* Product identity and editable drawing inputs. Shared by model, UI and geometry. */
(function(root){
  'use strict';
  const SERIES=['Andes','Avila'],LINEAR=['Lean','Lean-Suspend','Lean-Wing','Lean-Quad'],CURVED=['Curve','Curve-Suspend','Curve-Wing','Curve-Quad','Curve-Quad-Wing'];
  const LAYOUTS=['single','equal','variable','independent','rear-aligned','colon','colon-mixed','custom'];
  function normalize(value){
    const raw=value||{};if(raw.schema&&raw.schema!=='plmr-pergola-definition-v1')throw Error('Pergola tanım şeması desteklenmiyor.');const series=raw.series??'Avila',railType=raw.railType??'Linear';
    if(!SERIES.includes(series)||!['Linear','Curved'].includes(railType))throw Error('Pergola seri veya ray tipi desteklenmiyor.');
    const family=railType==='Linear'?LINEAR:CURVED,pergolaType=raw.pergolaType??family[0];
    if(!family.includes(pergolaType))throw Error('Pergola tipi seçilen ray ailesiyle uyumlu değil.');
    const layoutPlanId=raw.layoutPlanId??'single';if(!LAYOUTS.includes(layoutPlanId))throw Error('Pergola yerleşim planı desteklenmiyor.');
    const g=raw.geometry||{},geometry={};
    for(const [key,fallback]of [['curveRise',80.2493053656],['anchorRise',1200],['stayDiameter',40]]){
      const n=Number(g[key]??fallback);if(!Number.isFinite(n)||n<=0||n>20000)throw Error('Geçerli '+key+' çizim ölçüsü girin.');geometry[key]=n;
    }
    return {schema:'plmr-pergola-definition-v1',series,railType,pergolaType,derivedModelName:series+' '+pergolaType,layoutPlanId,geometry};
  }
  function traits(value){
    const c=normalize(value),quadWing=c.pergolaType==='Curve-Quad-Wing',continuous=c.pergolaType==='Curve-Quad';
    const wing=['Lean-Wing','Curve-Wing'].includes(c.pergolaType),quad=continuous||quadWing||c.pergolaType==='Lean-Quad';
    return {...c,curved:c.railType==='Curved',suspended:c.pergolaType.endsWith('-Suspend'),wing,quad,quadWing,continuous,double:wing||quad,centralSteel:wing||quadWing||c.pergolaType==='Lean-Quad'};
  }
  function types(railType){return [...(railType==='Curved'?CURVED:LINEAR)];}
  function upgradeEnvelope(raw,checksum){
    const next=JSON.parse(JSON.stringify(raw));
    if(Number(next.schemaVersion)!==2)throw Error('PROJECT_SCHEMA_UPGRADE_SOURCE_INVALID');
    if(next.checksum&&next.checksum!==checksum(next.projectModel))throw Error('PROJECT_CHECKSUM_INVALID');
    next.schemaVersion=3;next.projectModel.schemaVersion=3;
    next.projectModel.pergola=normalize(next.projectModel.pergola||{layoutPlanId:'custom'});
    next.checksum=checksum(next.projectModel);return next;
  }
  root.PLMRPergolaDefinition=Object.freeze({SERIES,LINEAR,CURVED,LAYOUTS,normalize,traits,types,upgradeEnvelope});
})(typeof globalThis!=='undefined'?globalThis:this);
