# V15 ana PLMR bağlantısı

Başlangıç ana kaynak: kullanıcının doğruladığı `plmrpulumur/plmr-demo` main, `4430d5f4013159236d4a5a0856b1c15eb6442d56`, paket kimliği 51.0.0. Çalışma dalı `codex/justpergola-v15`. Canlı yayın/merge yapılmadı.

## Gerçek uygulanan bağlantı

Mevcut `drawing-engine/embedded.html` ve `PLMRUnifiedDrawingWorkspaceV4` ürün kayıt arabirimi kullanılır. Mevcut ürün seçicisinde Pergola açılır. Ana uygulamanın React arayüzü, CSS dosyaları, sol menüsü, müşteri/firma/proje verisi ve mevcut diğer ürün motorları değiştirilmez. Native V15 çalışma alanı same-origin iframe içinde yalnız çizim yüzeyi olarak açılır; kendi kopya menü/başlık/proje paneli gömülü modda gösterilmez.

Tek kalıcı kayıt sahibi mevcut ana `modelState` ve onun proje kayıt/revizyon servisidir:

- Fiziksel Pergola modeli: `modelState.sceneEditor.justPergola`.
- Görünürlük/birim/sunum: mevcut `sceneEditor.sharedProductLayout.justPergolaView`. Ana sunucu teknik fingerprint'i bu mevcut görünüm alanını dışarıda tutar.
- Müşteri/proje/revizyon/firma: ana metadata'dan projeksiyon. Alt modelde ayrı müşteri kaydı tutulmaz.
- Değişiklik: native model → host doğrulaması → beklenen mevcut snapshot karşılaştırması → mevcut ana history → ana snapshot.
- Undo/redo: gömülü modda ana journal'a gider. Boş duruma dönüşte eski 2D/3D sahne ve seçim temizlenir.
- Kilit: mevcut `PLMRFinalReadOnly` kararı fiziksel host yazmasını engeller. Görünüm değişikliği fiziksel modeli değiştirmez.
- Dışa aktarım: mevcut toolbar Pergola'nın gerçek native SVG/DXF/PDF/DAE yolunu çağırır. Host SVG/PDF_2D ve görüntü/camera mesajı gerçek Pergola'dan gelir. Desteklenmeyen 3D PDF ve başka ürünlerle birleşik teknik çıktı açık hata verir.
- Görünmeyen ürün çalışma alanı/ana sekme aktif değilken Pergola 3D animasyon döngüsü durdurulur.

Bu, yeni proje veritabanı veya bağımsız yetkilendirme sistemi değildir. Host'taki küçük sözleşme yeni ürün verisini doğrular; native tam proje doğrulaması kendi motorundadır. Sunucuda yeni ürünün tam veri sözleşmesi/teklif/üretim kabulü henüz tamamlanmadı; production kullanıma hazır sayılmaz.

## Ticari sınır

Kullanıcı, Andes/Avila çeşitleri için **ayrı ticari ürünler** kararı verdi. Antero UUID/kodu kullanılmaz. `justpergola:Avila:Lean` gibi motor anahtarları ticari UUID değildir. Mevcut merkezi resolver bunları tanımadığı için teklif/üretim dönüşümü bloke olur. Ana React/Supabase gerçek proje kaydı + revizyon + teklif/üretim E2E kabulü geçti iddiası yoktur. Yerel mevcut ana `.plmr` dosya kaydı ve yeniden açma ayrı olarak geçti.

V51'in güncel React/TypeScript geliştirme ağacı mevcut main'de yok. Git geçmişi ve yedek dalları da tarandı; `plmr-v46/v46-source` altında bazı bileşenler ve Cloud kaynakları bulundu, fakat giriş, ortak domain ve build betiklerinin bir kısmı eksik. Eski kısmi kaynak güncel V51 yerine geçirilmedi. Supabase'den yayımdaki 3 fonksiyon alındı; platform bundle'ı tek başına tam geliştirme ağacı değildir. Ayrıntı: `Entegrasyon/SOURCE_ACCESS.json`.

## Ana dalı geri yükleme ve build

Teslimdeki Git bundle ve yama, inceleme ve geri alınabilir yerel geliştirme içindir. Başlangıç commit'i mevcut temiz bir repo kopyasında çalışın. Canlı main'e merge/push veya deployment için ayrıca açık onay gerekir.

```sh
git fetch /path/to/PLMR_JustPergola_v15/Entegrasyon/main-plmr-v15.bundle codex/justpergola-v15
git switch -c codex/justpergola-v15 FETCH_HEAD
npm run build
npm run verify
```

Bundle kullanılamazsa aynı başlangıç commit'inde `git apply --check` ile `Entegrasyon/main-plmr-v15.patch` dosyasını inceleyin. Python 3, mevcut JustPergola build betiği için gereklidir. Ana repo `justpergola/Development_Protocol` düzenleme kaynağıdır; `scripts/build-justpergola.mjs` aynı kaynaktan `drawing-engine/justpergola` üretir. Yalnız runtime'a elle yama yapılmaz. `npm run build`, sonra mevcut V51 yayın build'ini çalıştırır; yayın yapmaz.

## Gerçek entegrasyon testi

Ana repo kökünü HTTP ile servis edin. Test bağımlılıkları için bu V15 paketindeki `Test-Mantik` içinde `npm ci` çalıştırın; modül çözümlemesi gerekiyorsa `NODE_PATH` bu dizinin `node_modules` yoluna ayarlanabilir.

```sh
PLMR_MAIN_URL=http://localhost:8000/drawing-engine/embedded.html PLMR_CHROMIUM_CONFIG=/path/to/chromium.json PLMR_TEST_OUTPUT=/path/to/work/integration node /path/to/PLMR_JustPergola_v15/Entegrasyon/tests/integration-browser.cjs
```

Test, gerçek V51 motorunu gerçek tarayıcıda çalıştırır; üst pencere yalnız sentetik proje bağlamıdır. Gerçek kullanıcı/PIN/firma oturumu ve canlı Supabase yazması yoktur. Ana uygulama ticari kayıt/üretim kabulünün yerine geçmez.
