"""Read-only ZIP CRC/SHA/source provenance verification, then optional clean extraction."""
import json,hashlib,sys,zipfile
from pathlib import Path
archive=Path(sys.argv[1]);destination=Path(sys.argv[2]) if len(sys.argv)>2 else None
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist();assert len(names)==len(set(names))
    roots={n.split('/')[0] for n in names};assert len(roots)==1;prefix=next(iter(roots))+'/'
    for n in names:
        assert not n.startswith('/') and '..' not in Path(n).parts
        assert not ('Test-Mantik/' in n and n.lower().endswith(('.png','.jpg','.pdf','.dae','.dxf'))),n
    manifest=json.loads(z.read(prefix+'PACKAGE_SHA256.json'));assert manifest['selfExcluded']=='PACKAGE_SHA256.json';assert 'PACKAGE_SHA256.json' not in manifest['files']
    assert set(names)=={prefix+n for n in manifest['files']}|{prefix+'PACKAGE_SHA256.json'}
    for name,digest in manifest['files'].items():assert hashlib.sha256(z.read(prefix+name)).hexdigest()==digest,name
    required=['Uygulama/index.html','DEVIR_NOTU.md','READ_ME_FIRST.txt','BAGLANTI_REHBERI.md','BUTTON_MAP.json','Test-Mantik/KABUL.md','Development_Protocol/build.py','Development_Protocol/references/all-pergola-models-reference.dxf','Uygulama/source/assets/pergola-types/curve-quad-wing.svg']
    assert all(prefix+n in names for n in required)
    assert b'JustPergola V15' in z.read(prefix+'Uygulama/index.html')
    if destination:
        assert not destination.exists(),'Use a new empty extraction directory.'
        z.extractall(destination)
    print(json.dumps({'status':'PASS','files':len(names),'crc':True,'allSha256':True,'selfExcluded':True,'requiredFiles':True,'noInternalTestImages':True,'zipSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'cleanRoot':str(destination/next(iter(roots))) if destination else None},indent=2))
