/* Protected V10 native entity baseline, independently preserved before replacement. */
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]),prefix=fs.readFileSync(root+'/Test-Mantik/v11-model-matrix.cjs','utf8').split('const types=')[0],c=Function('require','process',prefix+'return c;')(require,process),gold=JSON.parse(fs.readFileSync(root+'/Test-Mantik/v11-native-baseline.json'));const results=[];
for(const fixture of gold.fixtures){
 c.raw={...c.PulumurGeometry.SAMPLE_INPUT,systemCount:'1',width:'4000',opening:'4500',rearHeight:'3200',frontHeight:'2600',date:'16.11.2026 00:00',rayCount:'',postCount:'',...fixture};
 const d=c.PulumurGeometry.buildDrawing(c.raw),hash=crypto.createHash('sha256').update(JSON.stringify(d.nativeEntities.map(e=>{const v={...e};delete v.entityId;if(v.presentationRole==='product-name'){delete v.value;delete v.height;}return v;}))).digest('hex');assert.equal(hash,gold.hashes[fixture.id],fixture.id+' native math/entities changed');
 for(const units of [{mm:true,inch:false},{mm:false,inch:true},{mm:true,inch:true}]){const drawing=c.PulumurGeometry.buildDrawing({...c.raw,__dimensionUnits:units});assert.equal(drawing.input.width,d.input.width);assert.equal(drawing.input.opening,d.input.opening);const layer=units.mm&&units.inch?'OLCULENDIRME_MM_INCH':units.mm?'OLCULENDIRME_MM':'OLCULENDIRME_INCH';assert(drawing.entities.filter(e=>e.type==='dimension').every(e=>e.layer===layer));}
 results.push({fixture:fixture.id,nativeHash:hash,unitsPhysicalInvariant:true});
}
fs.writeFileSync(path.join(process.env.PLMR_TEST_OUTPUT,'v11-native-parity.json'),JSON.stringify({status:'PASS',sourceZipSha256:gold.sourceZipSha256,normalization:gold.normalization,results},null,2));console.log('PASS six native fixtures and 18 unit modes');
