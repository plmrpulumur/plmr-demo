# V15 DXF açık kabul ve araştırma

Özgün V14 kaynağından 5 dosya yeniden üretildi: 70 DIMENSION, 31 DIMASSOC. V15'te aynı girdilerle 70 DIMENSION ve 33 DIMASSOC var. Bu sayılar CAD nesnesi/bağ yapısı ve referans koordinatı denetimidir. AutoCAD'de gerçek parça STRETCH davranışı veya bütün ölçülerin semantik olarak doğru parçayı izlemesi kanıtlanmadı.

Yeni destek, mevcut modelspace LINE uçları ve düz LWPOLYLINE kenar iç noktalarıdır. Nesne kimliği gerçek export handle'ıdır. Polyline referansında sıfır GS marker yerine kenar marker'ı ve gerçek WCS noktası yazılır. Aynı pozdaki sağ/sol görünüş ve karşı kanatlar ayrı tutulur. Ölçülen koordinat toleransı 0.001 mm'dir; farklı ölçüm koordinatı yakın diye kabul edilmez.

| Örnek | Gerçek ölçü | V14 bağ | V15 bağ | Açık |
|---|---:|---:|---:|---:|
| Lean | 11 | 7 | 8 | 3 |
| Lean-Suspend | 12 | 4 | 6 | 6 |
| Curve | 11 | 7 | 8 | 3 |
| Curve-Quad | 18 | 6 | 4 | 14 |
| Curve-Quad-Wing | 18 | 7 | 7 | 11 |
| Toplam | 70 | 31 | 33 | 37 |

Curve-Quad'daki iki bağın kaldırılması, karşı kanat/görünüş kısıtlamasının sonucudur; sayı artırmak için eski eşleşmeler geri getirilmedi. Kalanlar gerçek DIMENSION olarak kalır; geometri değişimini otomatik izledikleri iddia edilmez.

Açık gruplar: oluk altı/zemin yükseklikleri, askı üst kotu, karşılıklı kanatların nominal açılımı, mahya ve sürekli toplam derinlik, bazı üst sistem genişliği datumları. Fiziksel karşılıklar native INSERT içindeki bağlantı geometrisi, ARC veya ölçülen koordinattan ofsetli merkez/datum içerebilir. Mevcut destek bunlar için güvenli alt nesne/parametre yolu kurmuyor. Native blokları patlatmak veya görünmez sahte geometri eklemek çözüm olarak kullanılmadı.

Kaynak: `Development_Protocol/peri01/src/dxfModernEngine.js`. Dinamik metin/stil: `source/pergola-document.js`. Sayısal ölçü birimleri mm olarak korunur; inch stili 1/25.4 dönüşümünü uygular. Diyagonal ölçüler mevcut sabit açılı doğrusal DIMENSION yazımıyla korunmuştur. Gerçek hizalı, açısal, radyal ve bütün diğer CAD tipleri tamamlandı sayılmaz.

Bağımsız Python testi, kaynak geometriyi değiştirip mevcut referansı açık bir yorumlayıcıyla çözerek ezdxf'e yeniden çizdirir. Otomatik AutoCAD reaktörü çalıştırmaz. Sonraki zorunlu adım `autocad/KABUL.md` içindeki gerçek CAD turu ve bağlantısız datumların gerçek referans sözleşmesidir.
