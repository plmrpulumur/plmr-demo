# V8 kabul kaydı — 10 Kasım 2026

Teslim V7'nin ayrı çalışma kopyasından üretildi. Özgün V7 ZIP SHA256: b14baa23a89861ae613216965fb8e7ddb4186f950afb12f2980fa1acd6fd37c6. Kullanıcının proje örneği değiştirilmedi; bu pakete müşteri örneği konulmadı. V7 raporları Arsiv-V7'de tarihsel kanıttır.

| Doğrulama | Güncel kanıt | Sonuç / sınır |
|---|---|---|
| İki seri × sekiz tip × yedi plan | model-matrix.json | 112 kombinasyon; sonlu geometri, benzersiz parça/zone kimlikleri, tip destekleri, ray yayı ve orta nokta askıları, dışa dönük kapalı ray katıları. Andes/Avila fiziksel geometri hashleri aynı. |
| Aynı matris, yan kayıt + üçgen açık | model-matrix-glazing.json | 112 kombinasyon; aynı fiziksel mantık kontrolleri. |
| Yerli Lean matematiği | native-model.json | 17 ölçü/yerleşim/çelik/sac/oluk birleşim örneği; mm/inch fiziksel değişmezliği. |
| Gerçek ürün seçimleri | v8-products.json | 23 UI uygulaması: iki seride sekiz tip, kavisli Wing'de diğer altı plan ve history tekrar seçimi. 8 tip save/reopen; iptal atomik; orta dikme zone'ları; 7 yeniden çizimde geometri/doku sayaçları sabit. |
| Kavisli ürün düzenleme | v8-product-edit.json | Gerçek 2D genişlik editörü → 3D iki kumaş; kavis/askı/çap girdileri; geçersiz taslak; iki kanatta katlanma ve model değişmezliği. |
| Şema / tarihsel kayıt | v8-schema.json | Eski şema 2 örnekleri → 3; eski alanlar ve snapshotlar aynen; iki göç merkezi aynı; checksum/tip/sürüm reddi. |
| Mevcut akış regresyonu | v8-browser.json | 18 grup: menüler, otomatik ray/dikme, renkler, yan kayıt, kumaş, zone filtre/kodları, Push/Pull, birim, çıktılar, reset, yedi plan. |
| Seçim ve eski dosya regresyonu | v8-regression.json | 10 grup: 3D dikme kaydırma/undo/redo, ray/doğrama/oluk editörleri, filtre, V1/V3 dosya açılışı ve geçersiz taslak. |
| Ortak sahne davranışı | v8-interaction.json | 8 grup: V34 kamera, mavi zone hover, 5200ms Antero saat, profil ekle/snap/Alt, çelik arka zone, native yerleşim. |
| V5 uyumluluğu | v8-compatibility.json | 3 grup: V5 import, çelik/sac seçenekleri ve zone UID save/reopen, 2D/çıktı uyumu. |
| Gerçek 8× PDF/DXF/DAE dosyası | v8-exports.json | Ayrı XML/DXF/PDF okuyucu: kimlik/ref, mm, kapalı dışa dönük katılar, iki kanatta kumaş yüz yönü, ölçü layerları, logo ve PDF header/EOF. Harici CAD uygulaması kullanılmadı. |
| Temiz ZIP açılışı | package-smoke.json, package-check.json | Ayrı klasöre çıkarılmış pakette dört yeni Curved kartı, Curve-Wing gerçek 3D, iki kumaş, iki merkez dikme, dört askı ve 2D açıldı; eksik kaynak/JS hatası yok. |
| Kaynak / runtime | source-check.json | 92 JS sözdizimi; 135 runtime dosyası kaynakla bayt eşit; sağlayıcı hashleri; silinen kontroller. |

Testler Chromium 151 / ANGLE SwiftShader / file:// üzerinde 1560×960 masaüstü görünümünde çalıştı. Gerçek UI eylemleri Playwright ile yapıldı; inspect çağrıları salt okunur gözlemdir. Görsel gözden geçirme VISUAL_REVIEW.md içindedir. Ekran görüntüleri geçici test kanıtıdır, teslimde bulunmaz. Test indirmeleri de kullanıcı dosyaları değildir ve teslimin runtime'ına eklenmez.

Tekrar çalıştırma (proje kökünden):

```bash
python3 Development_Protocol/build.py
python3 Test-Mantik/verify-source.py .
PLMR_TEST_OUTPUT=/tmp/plmr-v8-results node Test-Mantik/v8-model-matrix.cjs .
PLMR_TEST_GLAZING=1 PLMR_TEST_OUTPUT=/tmp/plmr-v8-results node Test-Mantik/v8-model-matrix.cjs .
PLMR_TEST_OUTPUT=/tmp/plmr-v8-results node Test-Mantik/v8-schema.cjs .
node Test-Mantik/v8-native-model.cjs .
```

Çıktı dizinini önceden oluşturun. Tarayıcı testleri için Playwright ve Chromium gerekir. Testler PLMR_CHROMIUM_CONFIG JSON dosyasından launch seçeneklerini, CODEX_PRIMARY_RUNTIME_NODE_MODULES üzerinden Playwright paketini, PLMR_TEST_OUTPUT üzerinden çıktı klasörünü okur. v8-products.cjs indirilen 8 tip dosyasını üretir; v8-exports.py bu klasörü okur. v8-product-edit.cjs üçüncü argüman olarak üretilmiş Curve-Wing.plmr dosyasını alır. Kullanıcının özel eski örneğine ait V7 kabul senaryosu bu V8 kabulünde yeniden çalıştırılmadı; tarihsel testi/raporu V7 arşivindedir.

Düzeltmeler: görsel kart CSS yüksekliği; ters kanatta kumaş yüz yönü; eski şema dosyası parse yoluna göç; iki noktalı 2D izdüşümün yanlış kapalı polyline işareti. Son kaynak üzerinden ilgili testler yeniden çalıştırıldı. İlk başarısız geçici testler başarı kanıtı sayılmaz. Yoğun eşzamanlı yazılımsal render altında bir dikme testi zaman aşımına uğradı; ayrı UI tekrarında ve izole incelemede işlem doğrulandı. Sayaç kararlılığı genel GPU MB/performans garantisi değildir.

Sınırlar: Bu teslim yerel bağımsız çizim motorudur. Canlı ana uygulama/çoklu firma/gerçek üretim veya harici CAD import onayı değildir. Kavis/askı varsayılanları düzenlenebilir çizim girdisidir; üreticiye ait statik/imalat teyidi verilmedi. V7'ye kayıplı kayıt dönüşümü desteklenmez.
