# PLMR JustPergola V8

İki seri / sekiz ürün tipi / yedi yerleşim, gerçek tip geometrisi, kalıcı ürün tanımı ve yeni ürün kartları tamamlandı. Eski kart paketi kullanılmaz. Sekiz yeni kart toplam 75.456 bayttır.

112 kombinasyon iki seçenek durumunda CPU mantık testinden geçti. Tarayıcıda 23 ürün/plan uygulaması, 8 tip kayıt açılışı ve PDF/DXF/DAE çıktısı; dört kavisli düzenleme kontrolü ve mevcut akışların regresyon testleri doğrulandı. Ayrıntılı kanıt ve sınırlar Test-Mantik/KABUL.md.

Şema 3 eski dosyaları göç ettirir; yeni kayıtlar eski uygulamada açılmaz. Üretici kavis/askı ölçüleri yerine açıkça düzenlenebilir çizim girdileri vardır. Statik/imalat onayı verilmez. Host entegrasyonu ve canlı yayın yapılmadı.

Başlatma READ_ME_FIRST.txt, kaynak ve buton bağlantıları BAGLANTI_REHBERI.md / BUTTON_MAP.json, devir DEVIR_NOTU.md içindedir.
