PLMR JUSTPERGOLA V8
===================
Başlat: Uygulama/index.html dosyasını güncel masaüstü Chrome veya Edge ile açın.
İnternet gerekmez. Tüm klasörü birlikte çıkarın; ZIP içinden tek HTML çalıştırmayın.

Yerleşim Seç → Seri / Ray Tipi → Ürün Tipi → 7 yerleşimden biri → Ayarlar → Uygula.
İptal veya kapatma mevcut çizimi değiştirmez.

Yeni assets pergola.zip içindeki 8 görsel kullanılır; kartlar 512×512 WebP olarak yaklaşık 75 KB'dır.
Önceki kart paketi kullanılmaz ve bu teslimde bulunmaz.

2D/3D aynı ürün tanımından türetilir. Mevcut Lean profil seti korunur.
Kavis ve askı boyutları ayarlardaki düzenlenebilir çizim girdileridir; bunlar imalat/statik hesap onayı değildir.

Dosya şeması 3'tür. Eski yerli dosyalar açılışta kopya üzerinde taşınır.
Yeni dosyaları eski V7 uygulamasında açmayın; eski uygulama yeni ürün tiplerini bilmez.

İlk incelenecekler: DEVIR_NOTU.md, BAGLANTI_REHBERI.md, Test-Mantik/KABUL.md.
Kaynak Development_Protocol altında, çalıştırılabilir çıktı Uygulama altındadır.
python3 Development_Protocol/build.py ile aynı runtime yeniden üretilir.
Ana uygulamaya henüz bağlanmadı; canlı yayın yapılmadı.
