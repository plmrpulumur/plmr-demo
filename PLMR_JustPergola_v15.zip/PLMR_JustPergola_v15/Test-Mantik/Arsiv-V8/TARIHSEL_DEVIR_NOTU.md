# PLMR JustPergola V8 devir notu

Çalıştırma: klasörü çıkarıp Uygulama/index.html dosyasını açın. Seri ve Ray Tipi filtresinden sonra ürün tipini seçin; altındaki yedi yerleşimden birini seçip Ayarlar'da Uygula deyin. Kapat/Vazgeç çizimi değiştirmez.

Yalnız kullanıcının son verdiği assets pergola.zip içindeki kartlar kullanılır. Önceki kart paketi kullanılmaz. Sekiz kart 512×512 WebP, toplam 75.456 bayt. Harita ve kaynak hashleri Development_Protocol/V8_CARD_ASSETS.json içindedir.

| Tip ailesi | Fiziksel davranış |
|---|---|
| Lean / Curve | Arka taşıyıcı + ön dikmeler; düz / dairesel kavisli ray. |
| Suspend | Ön dikme yok; askı her rayın gerçek yay uzunluğunun orta noktasına gelir. Duvar veya çelik arka taşıyıcı seçilebilir. |
| Wing | Dış dikme ve arka duvar yok; yüksek orta dikmeler, simetrik karşı kanatlar ve askılar. Bir normal iki raylı modülde 2 orta dikme, 4 askı. |
| Lean-Quad | Dört dış köşe dikmesi, karşılıklı iki eğimli kanat. |
| Curve-Quad | Dış dikmeler üzerinde sürekli yuvarlak kemer; orta teğet yatay, iki kanat. |

Andes ve Avila profil/hesap matematiği aynıdır. Yeni tiplerde 2D fiziksel kontur izdüşümleri, 3D ile aynı montajdan türetilir; Lean ayrıntılı native çizimi korunur. Kumaş her kanatta genişlik boyunca tektir. Kapanınca oluğa uzar, açılınca geriye katlanır; ortak Antero hareket saati kullanılır.

Varsayılan yeni girdiler: kavis yükseliği 150 mm, askı üst kot farkı 800 mm, askı borusu çapı 40 mm. Bunlar üreticiden teyit edilmiş imalat ölçüleri değildir. Ayarlar'dan düzenlenir. Curve-Quad yarıçapı orta/uç kotlarından hesaplanır. Ankraj/statik boyutlandırma veya yeni profil kataloğu bu teslimin parçası değildir.

Kayıt şeması 3: tip bilgisi ProjectModel.pergola alanında korunur. Eski yerli şema 1/2 dosyaları kaynak ve eski snapshotlar değiştirilmeden göç ettirilir; bozuk checksum ve bilinmeyen tipler reddedilir. Şema 3 dosyasını V7 ile açmak desteklenmez; sessiz Lean dönüşümü yapılmaz.

Bağlantı işi hazırlık seviyesindedir. Kaynak, kayıt, scene, buton ve çıktı sahipleri BAGLANTI_REHBERI.md'dedir. Firma/proje yetkisi, kilit/revizyon, fiyat ve ürün UUID eşlemesi host sahibinde kalır. Kamera/zone/snap ortak sağlayıcıları korunmuştur. PDF 3D, AR, cephe ürünü montajı gibi host servisleri önceki bağımsız sürümdeki gibi devre dışıdır.

Test kapsamı ve komutlar Test-Mantik/KABUL.md. Kaynak / runtime SHA doğrulaması ve ZIP manifesti pakete dahildir. Tarayıcı kontrolleri Chromium/SwiftShader üzerinde yerelde yapıldı; harici CAD uygulaması veya canlı sunucu testi yapılmadı.
