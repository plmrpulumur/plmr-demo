# V8 görsel inceleme

Yeni assets pergola.zip içindeki sekiz kartın 512×512 WebP karşılıkları, mevcut PLMR penceresinde incelendi. Dört tip kartı tam kare görünür; seçili turkuaz sınır/vurgu belirgindir; ürün tipinden sonra yedi izometrik yerleşim kartı gelir. Kartlar önceki paketten alınmadı.

Lean/Curve, Suspend, Wing ve Quad 3D ekranları incelendi. Wing'de dış ayak yerine iki merkez dikme ve dört karşılıklı askı; Quad'da dış köşe ayakları; Curved modellerde dairesel ray yolu okunur. Profil renkleri yerli 2D'nin güçlü şematik renkleridir. Sahnede kamera, zone ve form dili mevcut ortak arayüzden gelir.

Yeni tiplerin 2D üst/ön/yan görünüşleri ve Curve-Wing PDF'sinin bir A0 sayfası incelendi. Üstte iki kanat, altta ön ve yan görünüş, ortak antet/logo, native kırmızı ölçüler ve gerçek parça renkleri vardır. Ölçü düzenleme 2D'de gerçek tıklama ile doğrulandı. Kavisli iki kanat kumaş katlanması UI üzerinden kontrol edildi.

İnceleme yerel Chromium/SwiftShader görüntüleriyle sınırlıdır; tüm müşteri kombinasyonları için fiziksel üretim doğrulaması sayılmaz. Ekran görüntüleri bu pakete eklenmedi.
