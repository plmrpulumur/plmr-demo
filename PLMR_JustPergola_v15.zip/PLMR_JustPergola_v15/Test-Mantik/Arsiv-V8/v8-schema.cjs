/* Migration preserves historical snapshots and rejects invalid definitions. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict'),{webcrypto}=require('crypto');
const root=path.resolve(process.argv[2]),c=vm.createContext({console,TextEncoder,crypto:webcrypto});c.window=c;
for(const f of ['core/pergolaDefinition.js','core/productPresentation.js','core/projectModel.js','core/validation.js','persistence/schema.js','persistence/revisionCore.js','persistence/schemaRegistryCenter.js'])vm.runInContext(fs.readFileSync(path.join(root,'Uygulama',f),'utf8'),c,{filename:f});
(async()=>{const results=[];
 for(const name of ['previous-v3-copy.plmr','v5-wall-track-zones.plmr','v6-steel-no-sheet.plmr']){
  c.raw=JSON.parse(fs.readFileSync(path.join(root,'Test-Mantik/fixtures',name)));const original=JSON.stringify(c.raw);
  const migrated=vm.runInContext('PulumurRevisionCore.migrateProjectEnvelope(raw)',c);assert.equal(migrated.schemaVersion,3);assert.equal(migrated.projectModel.pergola.derivedModelName,'Avila Lean');assert.equal(JSON.stringify(c.raw),original);
  for(const key of Object.keys(c.raw.projectModel))if(key!=='schemaVersion'&&key!=='pergola')assert.deepEqual(JSON.parse(JSON.stringify(migrated.projectModel[key])),c.raw.projectModel[key],name+' '+key);
  const report=await vm.runInContext('PulumurSchemaRegistryCenter.migrate(raw,{targetVersion:3})',c);assert.deepEqual(report.output,migrated);c.upgraded=migrated;assert.deepEqual(vm.runInContext('PulumurRevisionCore.migrateProjectEnvelope(upgraded)',c),migrated);
  vm.runInContext('PulumurProjectSchema.normalizeEnvelope(upgraded)',c);results.push({name,sourceVersion:c.raw.schemaVersion,targetVersion:3,status:'PASS',snapshotsUnchanged:true});
 }
 c.raw=JSON.parse(fs.readFileSync(path.join(root,'Test-Mantik/fixtures/v5-wall-track-zones.plmr')));c.raw.projectModel.topology.raw.width='12345';assert.throws(()=>vm.runInContext('PulumurRevisionCore.migrateProjectEnvelope(raw)',c),/CHECKSUM/);await assert.rejects(()=>vm.runInContext('PulumurSchemaRegistryCenter.migrate(raw,{targetVersion:3})',c),/CHECKSUM/);
 c.raw.schemaVersion=99;assert.throws(()=>vm.runInContext('PulumurRevisionCore.migrateProjectEnvelope(raw)',c),/UNSUPPORTED/);
 for(const bad of [{pergolaType:'Other'},{railType:'Curved',pergolaType:'Lean'},{series:'Other'},{geometry:{curveRise:0}},{geometry:{stayDiameter:Infinity}},{schema:'future'}]){c.bad=bad;assert.throws(()=>vm.runInContext('PLMRPergolaDefinition.normalize(bad)',c));}
 c.raw=JSON.parse(JSON.stringify(c.upgraded));delete c.raw.projectModel.pergola;c.raw.checksum='';assert.throws(()=>vm.runInContext('PulumurProjectSchema.normalizeEnvelope(raw)',c),/DEFINITION_MISSING/);
 const result={status:'PASS',results,checksumTamperRejected:true,unsupportedVersionRejected:true,invalidDefinitionsRejected:6,explicitDefinitionRequired:true};fs.writeFileSync(path.join(process.env.PLMR_TEST_OUTPUT,'v8-schema.json'),JSON.stringify(result,null,2));console.log('PASS schema migration, immutable history, checksum and invalid definition rejection');
})().catch(e=>{console.error(e);process.exitCode=1});
