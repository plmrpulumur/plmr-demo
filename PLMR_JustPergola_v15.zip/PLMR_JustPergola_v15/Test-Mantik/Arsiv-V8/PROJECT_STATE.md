# V8 çalışma durumu

Başlangıç: teslim edilmiş V7, SHA256 `b14baa23a89861ae613216965fb8e7ddb4186f950afb12f2980fa1acd6fd37c6`. Ayrı V8 kopyası üzerinde çalışıldı; V7 ve özgün kullanıcı girdileri değiştirilmedi.

Geçerli kararlar: V3 çalışma protokolü; V8 yol haritası v2; yalnız yeni assets pergola.zip; Andes/Avila ortak profil ve hesap seti. Ürün tipi ile yerleşim planı ayrı kavramlardır. İki aşama aynı popup içindedir. Eski kart paketi runtime ve kaynak tesliminde yoktur.

Tamamlanan uygulama: sekiz ürün tipi, iki seri, yedi native yerleşim; açık kalıcı ürün tanımı; gerçek kavis yolu/askı/merkez veya dış dikmeler; ortak fiziksel parçaların 2D/3D izdüşümü; aynı yay uzunluğu üzerinde kumaş katlanması; şema 3 ve eski kayıt göçü; yeni kartlar 512×512 WebP toplam 75.456 bayt.

Doğrulama kanıtlarının güncel listesi Test-Mantik/KABUL.md içindedir. Eski V7 raporları Arsiv-V7 altındadır ve bu sürümün kabulü sayılmaz. Geçici tarayıcı ekran görüntüleri teslim paketine dahil değildir.

Kaynak sahipleri ve host bağlantı sırası BAGLANTI_REHBERI.md; buton yönlendirmeleri BUTTON_MAP.json. Ana uygulamaya montaj veya canlı yayın yapılmadı. Üreticiye ait doğrulanmış askı/kavis/statik değerleri verilmediği için yeni geometri ölçüleri açık düzenlenebilir çizim girdileridir. Tamamlanmış çizim üretim/statik sertifikası sayılmaz.
