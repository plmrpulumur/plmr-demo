# PLMR JustPergola V9

Curve-Quad'ın kumaşı arka uçta toplanır; kemer boyunca tek kesintisiz ray/kumaş hattı vardır. Lean-Quad orta çeliğini normal pergolanın mevcut kiriş/dikme tanımlarından alır; kesitler aynı native editörden düzenlenir.

Yeni tiplerin 2D ve DXF'leri aynı native ray kesiti, mekanizma, oluk ve dikme bağlantı bloklarını, trapez taramasını kullanır. Mekanik blok dış ölçüleri 3D parçalarıyla karşılaştırıldı. Lean-Quad kartı ve yerleşim izometrileri gerçek çelik montajından güncellendi.

112 kombinasyon iki seçenek durumunda, 49 detay/zarf örneği, gerçek Quad hareketi/çelik editörü/save-reopen, 8 tip son PDF/DXF/DAE çıktısı ve etkilenen native/regresyon kontrolleri doğrulandı. Ayrıntılar Test-Mantik/KABUL.md; sınırlar ve bağlantı sahipleri DEVIR_NOTU.md / BAGLANTI_REHBERI.md içindedir.
