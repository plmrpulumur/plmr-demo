# V11 — çalışma sürüyor

Başlangıç V10 ZIP SHA256 f729d4504cec4fbdd25f7b4f7555c6e5c3235afcdf2377baa0296e37bf02d583. Ayrı V11 kopyası.
Yeni kullanıcı DXF SHA256 9a8a66307155ac7c3aabc978c678e8b629c025c43096dedadc571ee85f71abca; özgün dosya korunur. Development_Protocol/references altındaki kopya aynıdır.

İncelendi: 13 model/taşıyıcı örneği, 9 ürün tipi; DXF mm. Curve-Quad-Wing, merkez çeliğin iki yüzündeki ayrı kavisli kanatlar ve dış dikmelerdir; tek sürekli kemer olan Curve-Quad'dan ayrıdır.

Kök neden: önceki variant 2D yolu 3D kutularından üretilip native ön ray görünüşü ve side mekanizma birleşik oluk bloğunu kaybediyordu. Yeni yol native PERI01 top/front/side üreticisini kullanıyor; yalnız tip değişiklikleri ve kavisli yan raylar değişiyor. Üst/ön görünüş ölçeklenmez. Aynı entity'ler önizleme/PDF/DXF'e gider; kavis DXF'te gerçek ARC olur.

Uygulandı (doğrulama sürüyor): 5. Curved kart/tip tanımı, merkezi çelik ve çift kavis; bütün karşılıklı sistemlerde gerçek merkez çelik yüz/100mm datum; native görünüş türetimi; 4 çizgili kavisli ray (131mm ana profil ve native64.7/10mm iç kontur); bir kez çizilen ortak ön görünüş, modül sahipliğiyle aynalanan üst görünüş; asıl native side editörleri; referanstan türeyen yeni varsayılan kavis yüksekliği80.2493 ve askı üst kot farkı1200. Eski kayıtların seçilmiş değerleri ezilmez.

İlk CPU matrisi126 seri/tip/yerleşim modeli geçti; bu final kabul değildir. Devam: gerçek UI9tip, kaynak DXF ile bağımsız geometri kıyası, çoklu/kademeli kolon yerleşimleri, save/reopen/undo/dim編集, kaynak/runtime/kayıt/temiz ZIP doğrulaması, V11 devir.
