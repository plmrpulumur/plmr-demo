"""Independent file readers; no application geometry or renderer imports."""
from pathlib import Path
import json, sys, xml.etree.ElementTree as ET
from collections import Counter

folder=Path(sys.argv[1]);ns={'c':'http://www.collada.org/2005/11/COLLADASchema'};results=[]
for kind in ['Lean','Lean-Suspend','Lean-Wing','Lean-Quad','Curve','Curve-Suspend','Curve-Wing','Curve-Quad']:
    root=ET.parse(folder/(kind+'.dae')).getroot()
    assert root.find('c:asset/c:unit',ns).attrib['meter']=='0.001'
    ids=[e.attrib['id'] for e in root.iter() if 'id' in e.attrib];assert len(ids)==len(set(ids));idset=set(ids)
    for e in root.iter():
        for key in ['url','source','target']:
            ref=e.attrib.get(key,'')
            if ref.startswith('#'):assert ref[1:] in idset,(kind,ref)
    solids=0;fabrics=0
    for geo in root.findall('c:library_geometries/c:geometry',ns):
        name=geo.attrib.get('name','').lower();mesh=geo.find('c:mesh',ns)
        a=list(map(float,mesh.find('c:source/c:float_array',ns).text.split()));points=[a[i:i+3] for i in range(0,len(a),3)]
        assert all(abs(v)<1e8 for v in a)
        indices=list(map(int,mesh.find('c:triangles/c:p',ns).text.split()));assert max(indices)<len(points)
        closed=any(token in name for token in ['gutter_ray_connection','suspension_stay','_ray_','_ask','_orta_ta','_oluk_','_dIkme_'.lower(),'tasIyIcI'.lower()])
        if 'pvc_kumas' in name:
            fabrics+=1;normal_z=[]
            for i in range(0,len(indices),3):
                p,q,r=[points[j] for j in indices[i:i+3]]
                normal_z.append((q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0]))
            assert max(normal_z)>0 and sum(normal_z)>0,(kind,'cloth oriented area')
            direction=Counter()
            for i in range(0,len(indices),3):
                tri=indices[i:i+3]
                for j in range(3):
                    a,b=tri[j],tri[(j+1)%3];direction[tuple(sorted((a,b)))]+=1 if a<b else -1
            assert all(abs(v)<=1 for v in direction.values()),(kind,'cloth shared edge winding')
        if not closed:continue
        edges=Counter();directions=Counter();volume=0
        for i in range(0,len(indices),3):
            tri=[points[j] for j in indices[i:i+3]];keys=[tuple(round(v*1000) for v in p) for p in tri]
            if len(set(keys))<3:continue
            p,q,r=tri;volume+=(p[0]*(q[1]*r[2]-q[2]*r[1])+p[1]*(q[2]*r[0]-q[0]*r[2])+p[2]*(q[0]*r[1]-q[1]*r[0]))/6
            for j in range(3):
                p,q=keys[j],keys[(j+1)%3];key=tuple(sorted((p,q)));edges[key]+=1;directions[key]+=1 if p<q else -1
        assert all(v==2 for v in edges.values()),(kind,name,'open solid')
        assert all(v==0 for v in directions.values()),(kind,name,'inconsistent faces')
        assert volume>0,(kind,name,'inward solid');solids+=1
    assert fabrics==(1 if kind=='Curve-Quad' else 2 if kind.endswith(('Wing','Quad')) else 1),(kind,fabrics)
    assert solids>5
    rows=(folder/(kind+'.dxf')).read_text().splitlines();pairs=[(k.strip(),v) for k,v in zip(rows[::2],rows[1::2])]
    assert any(k=='9' and v=='$INSUNITS' and pairs[i+1]==('70','4') for i,(k,v) in enumerate(pairs))
    assert any(k=='2' and v=='PLMR - LOGO' for k,v in pairs)
    assert {'Ölçüler - Ana','Ölçüler - Detay'} <= {v for k,v in pairs if k=='8'},kind
    assert not any(k=='1' and 'IPR-' in v for k,v in pairs)
    inserted=[];entity=[]
    for k,v in pairs:
        if k=='0':
            if entity and entity[0]==('0','INSERT'):inserted.extend(value for code,value in entity if code=='2')
            entity=[]
        entity.append((k,v))
    required={'PergoRise Ray Kafası Üst Görünüş'}
    if kind!='Curve-Quad':required.add('PergoRise Ray Arka Mekanizma Üst Görünüş')
    if kind!='Lean':required|={'PergoRise Ray Profili','PergoRise Oluk Yan Görünüş'}
    assert required<=set(inserted),(kind,required-set(inserted))
    pdf=(folder/(kind+'.pdf')).read_bytes();assert pdf.startswith(b'%PDF') and b'%%EOF' in pdf[-100:]
    results.append({'type':kind,'closedSolids':solids,'fabrics':fabrics,'uniqueIdsAndReferences':True,'dxfMillimetres':True,'nativeBlockInserts':len(inserted),'pdfHeaderAndEof':True})
result={'status':'PASS','scope':'independent XML/DXF/PDF structure readers; external CAD applications not run','results':results}
(folder/'v10-exports.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS 8 type DXF/PDF/DAE readers')
