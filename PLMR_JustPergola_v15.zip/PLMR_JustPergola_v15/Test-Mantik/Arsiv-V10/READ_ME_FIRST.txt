PLMR JUSTPERGOLA V10
====================
Paketi çıkarıp Uygulama/index.html dosyasını Chrome veya Edge ile açın.
Tüm klasörü birlikte tutun. Çevrimdışı çalışır.

Yerleşim Seç → Seri/Ray Tipi → Ürün Tipi → Yerleşim → Ayarlar → Uygula.

Bu sürüm: 4 mm L aparat ve ray temasları; açılı askı kesimleri; çelik montajı;
kumaş toplama sınırı ve 30 mm saçak; Curve-Quad simetrik ön kafalar ve dört
çatı kayıt istasyonu; özgün referans 2D arka mekanizma; rijit native bloklar;
kompakt ayarlar; özel çelik kesitleri ve ortak cephe işlem ekranı.

Çelik kesiti: 3D çelik parçayı seç → Düzenle → Uygula → Profil Seçimi.
Kiriş ve dikmede Diğer seçeneği özel kesit ölçülerini açar.
Şema 3 korunur. Mevcut proje dosyaları aynı native kayıt yoluyla açılır.

Ayrıntılar: DEVIR_NOTU.md, BAGLANTI_REHBERI.md, Test-Mantik/KABUL.md.
Referans 2D yeniden değiştirilmemelidir; frozen-reference.json koruma kaydıdır.
Ana uygulamaya bağlantı henüz yapılmadı; ortak zone kartının host adaptörü
rehberde açıklanır. Kaynak build: python3 Development_Protocol/build.py
