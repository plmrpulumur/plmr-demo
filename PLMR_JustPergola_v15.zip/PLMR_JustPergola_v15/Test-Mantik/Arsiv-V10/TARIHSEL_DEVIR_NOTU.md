# PLMR JustPergola V10 — devir notu

Başlangıç, teslim edilmiş V9 paketidir: SHA256 `4abfdb983fa8e6c2357c847336d8cd635018c2459381fc15c27b02350482087a`. Özgün teslim değiştirilmedi; ayrı V10 kopyası geliştirildi. Kullanıcının V3 protokolü Development_Protocol altında aynen korunur.

Çalıştırma: tüm paketi çıkarıp `Uygulama/index.html` dosyasını açın. Kaynak `Development_Protocol` altındadır. Runtime'a elle yama yapılmaz: `python3 Development_Protocol/build.py`.

Geçerli kararlar:
- Referans Lean 2D yan görünüşündeki özgün arka mekanizma INSERT'i geri alındı. Dikdörtgen zarf çizimi kaldırıldı. Onaylı blok kütüphanesi değişmedi. `Test-Mantik/frozen-reference.json` altı referans örneğinin çizim imzalarını ve kaynak/blok hashlerini sabitler. Kullanıcı yeniden yetkilendirmeden bu referansı veya imza dosyasını güncellemeyin.
- Diğer tiplerin mekanizma ve aksesuar blokları özgün ölçüleriyle, rijit dönüşümle kullanılır. Genel profil dış görünüşüne sonradan et kalınlığı çizgileri eklenmez. Gerçek kesit bloklarının özgün iç detayları korunur. Ön görünüş arka duvar/taşıyıcı/askı ve çatı arkası detaylarını göstermez.
- `source/pergola-mounting.js` tüm tiplerin ortak temas sahibidir. Oluk üzerindeki L aparat 4 mm'dir; rayın dış yüzüne dayanır. Ray ve oluk arasına dolu bir dikdörtgen yerleştirilmez. Arka mekanizmanın dış zarfı korunur, rayın girdiği kanal boştur. Böylece mekanizma küçültülerek veya profil boyu değiştirilerek çakışma gizlenmez.
- Askı borularının uçları duvar/çelik yüzü ve ray üst temas düzleminde açılı kesilir. Çelik askı dikmesi kirişin montaj yüzüne göre konumlanır; kiriş, uzun askı dikmelerinin yüzlerinde kesilir. Karşılıklı mekanizmalar çeliğin iki ayrı yüzüne monte edilir.
- Kumaş tek parça davranışını ve ortak Antero hareket zamanlamasını korur. Geri toplandığında ön taşıyıcının ön yüzü arka sacın öndeki sınırına gelir. Ön taşıyıcı da kumaşın altındadır. Kumaş taşıyıcının ön bitiminden 30 mm devam eder.
- Curve-Quad: sürekli kemer ve tek kumaş; iki uçta simetrik ön kafa. Arka mekanizma yok. Her ray aralığında dört çatı kayıt istasyonu: arkadaki iki kayıt, orta ve ön kayıt. Arka sacın arka sınırı rayın arka ucundadır. İki uçtaki ray/oluk uzaması aynıdır.
- Ayarlar kompakt yerleşimdedir; ürün adı başlıktadır. İstenen iki yanal ofset alanı kaldırıldı; eski projelerdeki verileri silinmedi. Kiriş ve dikme için aynı native çelik editöründe özel kesit girilebilir. 3D parçanın Düzenle eylemi aynı native editörü açar.
- Tavan zone rengi ana uygulamadaki `#ff8c00`, hover opaklığı .14, pasif opaklık 0'dır. Cephe mavi hover davranışı korunur. Cephe tıklaması önce ortak altı eylemli kartı açar. Doğrudan ürün yerleşimine atlamaz.

Tek kalıcı ürün modeli ProjectModel'dir, şema 3 korunur. Profil değişimi, duvar, ölçü ve kesit işlemleri native commit/history yolundan geçer. Animasyon/kamera/çıktı kaydı fiziksel girdiyi değiştirmez. Mevcut kart varlıkları ve güçlü profil renkleri korunur; yasaklanan eski kart paketi kullanılmaz.

Buton, model ve host bağlantıları BAGLANTI_REHBERI.md ve BUTTON_MAP.json'dadır. Ortak cephe kartının tek sahibi `shared/zone-actions.js`dir. Ana uygulamada aynı ekranı/komutları ikinci kez yazmayın; mevcut host işlemlerini adaptöre bağlayın. Cephe ürün motorlarının gerçek montajı ana uygulamanın servisidir; standalone pakette bu motorlar eklenmedi. Arka çelik açıklıkta bağımsız duvar ekleme de host duvar servisine bırakılmıştır; standalone kartta bu işlem pasiftir.

Son doğrulama girişi: Test-Mantik/KABUL.md. Eski V9 kanıtları Arsiv-V9 altındadır; bu sürümün PASS kanıtı yerine kullanılmaz. Canlı uygulamaya montaj veya yayın yapılmadı. Dış CAD programı çalıştırılmadı; gerçek indirilen dosyalar bağımsız XML/DXF/PDF okuyucularıyla incelendi.
