# JustPergola V10

Bu sürüm 3D montaj temaslarını ve ürünlerden türetilen 2D görünüşleri düzeltir. 4 mm L plaka rayın dışında, oluk üzerinde yer alır. Arka mekanizma dış boyutu korunurken ray için kanal açılır; askı uçları montaj yüzlerine açılı kesilir. Çelik dikme/kiriş ve karşılıklı kanat bağlantıları ortak datumdan türetilir.

Referans 2D'de özgün arka mekanizma bloğu geri getirildi ve sabitlendi. Türetilmiş tiplerde mekanizma bloklarının kutuya göre esnetilmesi, dış görünüşlere ek hollow-rect çizgileri ve ön görünüşte gereksiz arka detaylar kaldırıldı. Curve-Quad iki simetrik ön kafa ucu ve dört kayıt istasyonu kullanır. Kumaş ön taşıyıcısının toplama sınırı, altta yerleşimi ve 30 mm saçak uygulandı.

Ayarlar kompakt; ürün adı üstte. Gereksiz yanal ofset alanları kaldırıldı. Özel çelik kiriş/dikme kesitleri aynı native düzenleyiciyle girilir. Cephe önce ortak işlem kartını açar; tavan zone rengi ana uygulamayla aynıdır. Bağlantı için aynı kart sağlayıcısını kullanan host adaptörü belgelenmiştir. Proje şeması 3, native history ve veri sahipliği korunur.

Doğrulama: 336 model kombinasyonu; donmuş referans/birim/şema kontrolleri; sekiz tipte gerçek UI, kumaş, 2D/3D ve 24 çıktı dosyası; bağımsız dosya okuyucuları; kaynak/runtime eşitliği ve temiz paket açılışı. Ayrıntı Test-Mantik/KABUL.md'dedir. Eski V9 sonuçları tarihsel arşivdir.

Canlı ana uygulamaya bağlantı/yayın yapılmadı. Gerçek cephe ürün motorları ile arka çelik cephenin bağımsız duvar servisi hosttan bağlanır. Paket bu servisler için ikinci bir uygulama kurmaz. Kullanılacak varlıklar, buton/komut sahipleri ve tekil sağlayıcı bağlantıları BAGLANTI_REHBERI.md / BUTTON_MAP.json'dadır.
