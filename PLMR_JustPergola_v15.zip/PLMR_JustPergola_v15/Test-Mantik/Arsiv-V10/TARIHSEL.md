Bu klasör V10 tarihsel kaynak/kanıt kayıtlarıdır. V11 doğrulaması yerine kullanılamaz. V11 kabulü ../KABUL.md içindedir.
