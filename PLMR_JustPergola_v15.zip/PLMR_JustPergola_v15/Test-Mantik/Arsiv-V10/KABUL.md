# V10 güncel kabul — 16 Kasım 2026

Başlangıç: teslim edilmiş V9 ZIP SHA256 `4abfdb983fa8e6c2357c847336d8cd635018c2459381fc15c27b02350482087a`. Ayrı V10 kopyası. Eski raporlar Arsiv-V9 altındadır ve güncel PASS yerine kullanılmaz.

| Talep | Kanıt |
|---|---|
| L aparat 4 mm, rayın içine girmez | `model-matrix*.json`: 336 modelde 4 mm alanı, kapalı/dışa dönük L katısı; dış ray yüzünde yan plaka ve oluk üstünde ayak. Aradaki boşluğu dolduran eski dikdörtgen çizilmez. |
| Arka mekanizma/ray, duvar/çelik temasları | Mekanizma dış zarfını koruyan gerçek kanal; ray hacminde dolu mekanizma yok. Aynı matrisler kanal sınırlarını ve katı topolojisini kontrol eder. Karşı kanatlar kirişin iki yüzünden türetilir. |
| Askıların açılı kesimi ve çelik birleşimi | Matrislerde bütün askı vertexleri iki kesim düzleminin doğru tarafında; katılar kapalı ve yüz yönleri tutarlı. Kirişler uzun askı dikmelerinin yüzlerinde biter; kiriş/dikme iç içe hacmi yok. |
| Kumaş ön taşıyıcı, toplama sınırı, 30 mm saçak | `v10-acceptance.json`: sekiz tipte gerçek kaydırıcı %0/%50/%100; ön taşıyıcı ön yüzü sac bitiş datumuna .01 mm içinde gelir. Taşıyıcı kumaş altında; gerçek kumaş geometrisinde terminal saçak var. Antero zamanlama sağlayıcısı değişmedi. |
| Referans 2D restore edilir ve korunur | `v10-reference.json`, `frozen-reference.json`: özgün yan arka mekanizma INSERT'i, blok kütüphanesi ve altı çizim imzası. Dikdörtgen zarf entity'si yok. Aynı imzalar ayrı koşuda tekrar doğrulandı. |
| Yeni tipler referanstan türetilir | Gerçek UI'daki sekiz tipte özgün mekanizma/aksesuar INSERT'leri, scaleX/scaleY=1. Yeni dış görünüş profilinde ek hollow-rect çizimi kaldırıldı. Ön görünüş gizli arka taşıyıcı/çatı detaylarını çizmez. Lean-Suspend ve Curve-Quad PDF üst/ön/yan görünüşleri ayrıca rasterleştirilip incelendi. |
| Curve-Quad | 112 kombinasyon matrislerinde arka mekanizma yok; her ray aralığında dört kayıt istasyonu. Gerçek UI'da iki uçta toplam dört ön kafa INSERT'i, sürekli tek kemer/kumaş, arka toplama ve sac sınırı. |
| Ayarlar | Gerçek UI'da istenen iki ofset alanı yok; ürün adı başlıkta; masaüstü diyalog dış kaydırma olmadan sığar. Önceki kayıt değerleri silinmez. |
| Zone ekranı/renk | Gerçek cephe tıklaması altı eylemli ortak kartı açar; doğrudan ürün seçici açılmaz. Tavan #ff8c00, pasif 0 / hover .14; kaynak V34 bioclimatic-roof-viewer politikası. Switch native history yoluyla kaydolur. |
| 3D native editör / özel çelik | Gerçek 3D çelik parça seçimi → Düzenle → aynı native form; özel 140×180×4 kiriş ve 120×140×4 dikme girildi, 3D kesit ve save/reopen korundu. Temiz paket smoke testi, Profil Ekle'nin 3D'de native editörü açmasını ve Ana Ürün Ekle taslağının iptal bütünlüğünü de kontrol eder. |
| Tüm seri/tip/yerleşimler | `model-matrix.json`, `model-matrix-glazing.json`, `model-matrix-steel.json`: 2 seri × 8 tip × 7 plan = 112; üç seçenek durumunda toplam 336. Sonlu geometri, benzersiz kimlikler, seri eşdeğerliği, destek/askı/ray sayıları, kapalı katılar ve temas düzlemleri. |
| Birimler / eski kayıt / checksum | Altı native örnekte 18 mm/inch/birlikte kontrolü; `v10-schema.json`: önce checksum doğrulama, şema 3, eski kayıt ve snapshot koruma, uygunsuz tanım reddi. |
| Gerçek dosyalar | Sekiz tipte 24 gerçek DXF/PDF/DAE indirmesi; `v10-exports.json` bağımsız XML/DXF/PDF okur. DAE mm, ID/ref, kapalı katı yüzleri ve kumaş ortak kenar yönleri; DXF özgün INSERT, logo ve birimler; PDF yapı kontrolü. Katlanmış kumaşın kıvrımları gereği bazı yüz normalleri aşağı bakabilir; tutarlı ortak kenar yönü ve pozitif toplam yönlenmiş alan kontrol edilir. |
| Kaynak ve paket | `source-check.json`: 95 JS sözdizimi / 138 runtime dosyası, kaynakla bayt eşitliği ve hashler. `package-smoke.json`: ayrı klasöre çıkarılan ZIP'te gerçek WebGL, iki Quad, native 2D blokları, ortak kart ve 3D native editörü. `package-check.json`: manifest ve CRC kontrolü. |

`v10-products-intermediate.json`, bu turdaki 23 ürün/plan UI örneği, iptal, undo/redo, kayıt/çıktı ve tekrar çizim kontrolünün ara kaydıdır. Son kaynak için sekiz tipin hareket/çıktı ve odaklı UI akışları ayrıca yeniden çalıştırılmıştır; ara kayıt final geometri kanıtı yerine kullanılmaz.

Ortam: yerel Chromium 151 / ANGLE SwiftShader, file://, 1560×960; temiz paket 1440×900. Gerçek tıklama/form/kaydırıcı eylemleri kullanıldı; inspect salt okunur ölçümdür. PDF rasteri Poppler ile okundu. AutoCAD/SketchUp açılışı veya canlı host montajı yapılmadı. İç test PNG/PDF/DAE/DXF dosyaları uygulama paketine eklenmedi; test kaynakları ve sonuç JSON'ları bulunur.

Sınır: gerçek cephe ürün montajı ve arka çelik açıklıkta bağımsız duvar ekleme mevcut host servislerine bağlanmalıdır. Standalone içinde bunlara ikinci bir ürün motoru yazılmadı; ortak kartın adaptörü BAGLANTI_REHBERI.md'dedir.

Tekrar çalıştırma: `python3 Development_Protocol/build.py`; `python3 Test-Mantik/verify-source.py .`; Node testlerine paket kökünü, `PLMR_TEST_OUTPUT` ile yazılabilir sonuç klasörünü verin. Tarayıcıda `CODEX_PRIMARY_RUNTIME_NODE_MODULES` Playwright'ı, `PLMR_CHROMIUM_CONFIG` Chromium launch JSON'unu gösterir. `v10-products.cjs` sentetik .plmr örnekleri üretir; bu klasörü `v10-acceptance.cjs` üçüncü argümanı yapın. `v10-exports.py` gerçek çıktı klasörünü okur. `v10-reference.cjs` koruma dosyasını salt okunur denetler; `--record` var olan koruma dosyasını üzerine yazamaz.
