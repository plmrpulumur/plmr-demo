/* Compare actual V14 baseline and V15 physical outputs, not historical V11 hashes. */
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),crypto=require('crypto');
const current=path.resolve(process.argv[2]),baseline=path.resolve(process.argv[3]);
function load(root){const prefix=fs.readFileSync(root+'/Test-Mantik/v11-model-matrix.cjs','utf8').split('const types=')[0];return Function('require','process',prefix+'return c;')(require,{...process,argv:['node','test',root]})}
const a=load(baseline),b=load(current),types=['Lean','Lean-Suspend','Lean-Wing','Lean-Quad','Curve','Curve-Suspend','Curve-Wing','Curve-Quad','Curve-Quad-Wing'];let count=0;
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');const cases=[];
for(const type of types)for(const card of b.PLMRPergolaLayouts.cards){
 const raw={...b.PulumurGeometry.SAMPLE_INPUT,...card.values,rayCount:'',postCount:'',__pergola:{series:'Avila',railType:type.startsWith('Curve')?'Curved':'Linear',pergolaType:type,layoutPlanId:card.id}};
 const da=a.PulumurGeometry.buildDrawing(raw),db=b.PulumurGeometry.buildDrawing(raw);
 const ma=a.PLMRJustPergola.fromDrawing(da,'white',raw),mb=b.PLMRJustPergola.fromDrawing(db,'white',raw);
 assert.equal(hash(ma.components),hash(mb.components),type+' '+card.id+' physical parts changed');
 const physical=d=>d.entities.filter(e=>['line','polyline','circle','insert'].includes(e.type)).map(e=>{const q={...e};delete q.projectionView;return q});
 assert.equal(hash(physical(da)),hash(physical(db)),type+' '+card.id+' physical 2D projection changed');
 cases.push({type,layout:card.id,parts:mb.components.length,componentsSha256:hash(mb.components)});count++;
}
fs.writeFileSync(path.join(process.env.PLMR_TEST_OUTPUT,'v15-native-parity.json'),JSON.stringify({status:'PASS',cases:count,scope:'Actual V14/V15 physical 2D entity and 3D component byte comparison; projection identity metadata intentionally excluded',results:cases},null,2));console.log('PASS',count,'V14/V15 physical projection and part comparisons');
