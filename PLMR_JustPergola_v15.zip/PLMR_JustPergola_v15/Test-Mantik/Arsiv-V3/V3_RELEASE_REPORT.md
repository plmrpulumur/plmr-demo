# JustPergola V3 değişiklik raporu

3.0.0 — bağımsız pergola teslimi, 09.11.2026.

V2'nin native çizim motoru güncel V34 ekranına bağlandı. Üçgen doğrama için native profil geometrisi, cephe boşlukları için native dikme/cam kaydı/parapet kuralları kullanıldı. Yatay profiller bölgeyi fiziksel yüzeylerine göre böler. Ekran içinde kesilen düzenleyiciler, 2D ölçü filtresi bağlantısı, dış genişlik ve poz yüksekliği etiketleri düzeltildi.

Paylaşılan taşıma, kopyalama ve döndürme gerçek ProjectModel komutlarıyla kaydedilir. Kopya snapshot'ı ana pergoladan bağımsızdır. V1 içe aktarma, PDF/DXF/DAE ve yerel .plmr akışı korunur.

Güncel kabul: Test-Mantik/KABUL.md. Yerel Chromium/SwiftShader'da 19 grup; ayrıca 6 native geometri/DXF senaryosu ve dosya yapı kontrolü geçti. Görseller açılarak incelendi. Bu sonuç canlı yayın, donanım performansı veya üretim/statik onayı değildir.

FinalProcess V34 entegrasyonu ve cephe ürünlerinin montajı talep gereği sonraki aşamadır. Özgün V34 paketi değiştirilmedi. Kopya ölçüsünü ayrı düzenleme ve servis gerektiren düğmeler bu bağımsız pakette etkin değildir.
