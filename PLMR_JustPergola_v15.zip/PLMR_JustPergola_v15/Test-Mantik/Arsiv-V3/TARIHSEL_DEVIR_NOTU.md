# PLMR JustPergola V3 — 3.0.0

Tarih: 09.11.2026. Kapsam: bağımsız pergola çizimi. Durum: kapsam içi uygulama ve yerel kabul tamamlandı; V34 entegrasyonu sonraki aşamadır.

## Başlangıç ve kilitli kararlar

- Başlangıç: plmr_justpergola_v2.zip. SHA-256 `0f5e5c1438b99f1306628071db1770545cdcb40a869b059a5ae805a0279f67c8`.
- Görsel referans ve ortak araç kaynağı: PLMR_FinalProcess_v34.zip. Özgün ZIP değiştirilmedi.
- Yalnız pergola; mevcut V34 ekran bileşenleri, toolbarlar, renkler ve düğmeler kullanılır. Yeni bir görsel sistem kurulmadı.
- Cephe ürünlerinin montajı ve FinalProcess kayıt/poz entegrasyonu sonraki aşamadır. Seçim listesi hazırdır; Kaydet montajı bu pakette pasiftir.
- Native PERI01 hesap, geometri, DXF/PDF, ProjectModel, kayıt ve history yetkili kaynaktır. 3D bu çizimi türetir; kendi rakip ölçü modelini üretmez.

## Kaynak / üreteç / çalışma dosyaları

- Development_Protocol/peri01: native hesap, çizim, model, history, persistence ve export. app.js içindeki PLMRPergolaNative adaptör sınırıdır.
- Development_Protocol/source: V34 ekran montajı, pergola UI, 3D projeksiyon/viewer ve sahne komut adaptörü.
- Development_Protocol/shared: Three.js ve ortak sağlayıcılar; shared/v34: gerçek V34 araçları, CSS, font ve marka varlıkları.
- V34_SHARED_ORIGINS.json özgün köken/hash kaydıdır. V34_ADAPTER_STATUS.json güncel karşılaştırmadır. v15-measure-viewer.js dışında köken listesi birebir korunur; bu sağlayıcıya yalnız isteğe bağlı poz yüksekliği desteği eklendi, eski V34 fallback'i korunur.
- Uygulama: bu kaynaklardan build.py ile üretilen, dosyadan doğrudan açılan çalışma sürümü. Bağımsız elle yamalanmaz.
- Uygulama/SOURCE_SHA256.json: üretilen çalışma dosyaları; PACKAGE_SHA256.json: teslim dosyaları; Test-Mantik/ACCEPTANCE_SOURCES_SHA256.json: kabulün kaynak bağı.

## Tamamlanan değişiklikler

- V34 ekranı, ayarlar/yerleşim, poz ekleme, 2D/3D, kayıt ve mevcut export düğmeleri bağlandı.
- Üçgen doğrama native 2D profil poligonlarından, aynı eğim/bölme kuralıyla oluşturulur; ayrı basit çubuk yaklaşımı kaldırıldı.
- Cephe boşlukları native dikme/cam kaydı/parapet sınırlarından alınır. Yatay profillerde profil yüzeyleri dışında ayrı alt/üst boşluklar oluşur.
- Bölge seçimi, ölçü ve ürün listesi; native profil düzenleme bağlantısı hazırdır.
- Paylaşılan taşıma/kopyalama/rotasyon araçları ProjectModel içindeki workspaces.standalone.project verisine bağlandı. Kopya oluşturma bağımsız giriş snapshot'ı alır; ana pergoladaki değişiklik kopyayı değiştirmez.
- Ekran yerleşiminde kesilen native düzenleyici pencereleri viewport sınırında kaydırılabilir hale getirildi.
- V34 ölçü düğmesi 2D native ölçü filtresini de yönetir. 3D dış genişlik etiketi mekanizma netini göstermeyecek şekilde düzeltildi; poz yükseklikleri ayrı gösterilir.
- Dosya sürümü 3.0.0 olarak güncellendi. Eski V1/V2 okuma korundu.

## Doğrulama ve kullanım

ZIP'i tamamen çıkarıp Uygulama/index.html açın. Kurulum/npm/sunucu gerekmez; 3D için WebGL gerekir.
Build: `python3 Development_Protocol/build.py`.
Paket: `python3 Development_Protocol/package.py /mutlak/yol/plmr_justpergola_v3.zip`.
Güncel tek kabul girişi Test-Mantik/KABUL.md; gerçek komutlar ve sınırlar buradadır.
19 güncel kabul grubu, ayrıca 6 native geometri/DXF eşleşme senaryosu ve çıktı yapı kontrolü PASS. Chromium/SwiftShader, file:// kullanıldı. Görseller açılarak incelendi. Tarihsel V2 kanıtı ayrı Arsiv-V2 klasöründedir.
Kayıt sahibi native ProjectModel'dir. Poz/copy dönüşleri aynı modelin standalone çalışma alanında saklanır. Migration/reset/canlı yayın uygulanmadı.

## Açık sınırlar / sonraki adım

Bu bağımsız pergola tesliminin zorunlu açık kabulü yoktur. FinalProcess V34 entegrasyonu yapılmadı ve bu aşamada yapılmayacak.
Cephe ürünleri listesi seçim için hazır; montaj, bulut kayıt, teklif/üretim, sahne paylaşımı ve 3D PDF servisleri bağlanmadı. Ayrı kopya ölçü formu yoktur; kopya ölçü etiketi ana pergola formunu yanlışlıkla açmaz, açıklama gösterir.
Native yan cephe bölgeleri Cam Kaydı ve etkin yan görünüş kurallarını izler. Bu kurallar V2 motorundan korunmuştur.
Donanım GPU, harici CAD import ve statik/üretim onayı yapılmadı.
Sonraki somut adım: kullanıcı incelemesinden sonra ayrıca istenirse V34 kayıt/poz sözleşmesine entegrasyon; ardından cephe ürünlerinin gerçek montajı. Bu paket entegrasyonu başlatmaz.
