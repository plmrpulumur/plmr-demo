/* Current V3 acceptance: UI operations and read-only geometry assertions are labelled separately. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright':'playwright');
const root=path.resolve(process.argv[2]||'.'),out=path.resolve(process.env.PLMR_TEST_OUTPUT||'checks/current');
fs.mkdirSync(out,{recursive:true});
(async()=>{
const browser=await chromium.launch(JSON.parse(fs.readFileSync(process.env.PLMR_CHROMIUM_CONFIG))),page=await browser.newPage({viewport:{width:1440,height:900},acceptDownloads:true});
page.setDefaultTimeout(15000);
const errors=[],requests=[],results=[];let step='start';
page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>requests.push(r.url()));
const record=(name,details={})=>{results.push({name,status:'VERIFIED',...details});console.log('PASS',name)};
const read=()=>page.evaluate(()=>PLMRJustPergolaApp.inspect());
const model=()=>page.evaluate(()=>PulumurProjectState.getModel());
const nativeModel=()=>page.evaluate(()=>{const m=PLMRJustPergola.fromDrawing(PLMRPergolaNative.drawing(),'white');return{zones:m.zones,components:m.components,systems:m.assembly.systems}});
async function settings(values){await page.locator('#rrV45SettingsBtn').click();for(const[k,v]of Object.entries(values)){const n=page.locator('#pergolaSetting-'+k);if(await n.evaluate(n=>n.tagName==='SELECT'))await n.selectOption(v);else await n.fill(v);}await page.locator('#pergolaSettingsApply').click();await page.waitForFunction(()=>!document.getElementById('rrV45SettingsModal'));}
async function selectRoofUi(){
 const screens=(await read()).sceneTools.roofs[0].screens;
 // Click along the front post's projected edge, allowing for its physical section.
 for(const [lo,hi]of [[5,7],[1,3]])for(const delta of [0,-3,3,-6,6]){
  const a=screens[lo],b=screens[hi],x=a.x+(b.x-a.x)*.45+delta,y=a.y+(b.y-a.y)*.45;
  const overCanvas=await page.evaluate(({x,y})=>document.elementFromPoint(x,y)?.tagName==='CANVAS',{x,y});
  if(!overCanvas)continue;
  await page.mouse.click(x,y);
  if((await read()).sceneTools.selectedId==='roof-main')return;
 }
 assert.fail('No front post could be selected through the canvas');
}
async function download(selector,name){const pending=page.waitForEvent('download');await page.locator(selector).click();const d=await pending;await d.saveAs(path.join(out,name));return path.join(out,name);}
try{
await page.goto(pathToFileURL(path.join(root,'Uygulama/index.html')).href);assert.equal(await page.title(),'PLMR | JustPergola V3');
step='create';await settings({systemCount:'1',width:'4000',opening:'4500',rearHeight:'3200',frontHeight:'2600',glassTrack:'EVET',triangleJoinery:'EVET',structureColor:'RAL 7016',fabric:'RAL 9016'});
await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().renderCalls>0);let current=await read();assert(current.webgl&&current.renderCalls>0);assert.equal(current.zones.length,3);assert.equal(current.triangles.length,2);assert.equal(current.measurements.find(m=>m.key==='width').value,4000);record('UI · initial form and WebGL',{renderCalls:current.renderCalls});
step='zone';let front=current.zones.find(z=>z.face==='front');const point=await page.evaluate(id=>PLMRJustPergolaApp.screenZone(id),front.id);await page.mouse.click(point.x,point.y);await page.locator('#pergolaZoneDialog').waitFor();assert.equal(Number(await page.locator('#v26FacadeWidth').inputValue()),front.width);assert.equal(await page.locator('#v26FacadeProduct option').count(),8);await page.locator('#v26FacadeProduct').selectOption('fixed');assert(await page.locator('#pergolaZoneDialog [data-action=save]').isDisabled());await page.locator('#pergolaZoneDialog [data-action=cancel]').click();record('UI · facade click and selection list');
step='zone filters';await page.locator('#rrV45ZonesBtn').click();await page.locator('#rrV45ZonesBtn').click();await page.locator('#rrV45ZonesBtnArrow').click();await page.locator('#rrV45ZonesBtnArrow + div input').first().uncheck();await page.locator('#rrV45ZonesBtnArrow + div input').first().check();await page.locator('#rrV45ZonesBtnArrow').click();record('UI · zone visibility controls');
step='triangle';await page.locator('#rrV45Mode2DBtn').click();assert.equal(await page.locator('#preview').getAttribute('data-interactive'),'true');
const before=(await nativeModel()).components.filter(c=>c.kind==='triangle-frame');await page.locator('#preview [data-interaction-type=triangleEditor][data-side-view-key="0"]').first().click({force:true});await page.locator('#triangleDivisionInput').fill('4');await page.locator('#triangleEditorForm button[type=submit]').click();let triangles=(await nativeModel()).components.filter(c=>c.kind==='triangle-frame');assert.equal(triangles[0].geometry.polygons.length,5);assert.deepEqual(triangles[0].geometry.polygons[0],before[0].geometry.polygons[0]);assert.deepEqual(triangles[1],before[1]);record('UI · triangle divisions preserve outline and opposite side');
step='undo';await page.locator('#preview').click({position:{x:8,y:8}});await page.keyboard.press('Control+z');assert.equal((await nativeModel()).components.find(c=>c.kind==='triangle-frame').geometry.polygons.length,3);await page.keyboard.press('Control+y');assert.equal((await nativeModel()).components.find(c=>c.kind==='triangle-frame').geometry.polygons.length,5);record('UI · native undo and redo');
step='wall';
// Native dimension hit areas may overlap the wall's bounding-box center.
// Pick an exposed wall point using the browser's actual hit test.
const wallPoint=await page.evaluate(()=>{for(const n of document.querySelectorAll('#preview [data-interaction-type=topBackWallEditor]')){const r=n.getBoundingClientRect();for(const a of [.25,.5,.75])for(const b of [.25,.5,.75]){const x=r.left+r.width*a,y=r.top+r.height*b;if(document.elementFromPoint(x,y)?.closest('[data-interaction-type=topBackWallEditor]')===n)return{x,y};}}return null;});
assert(wallPoint,'exposed rear-wall surface');await page.mouse.click(wallPoint.x,wallPoint.y);await page.locator('#topWallColumns').fill('2');await page.locator('#topBackWallEditorForm button[type=submit]').click();assert.equal(Object.values((await model()).frontView.topBackWallGridState)[0].cells.length,2);record('UI · rear wall subdivision');
step='profile';await page.locator('#rrV11DimensionsBtnArrow').click();await page.locator('#rrV11DimensionsBtnArrow + div input[data-key=all]').check();await page.locator('#rrV11DimensionsBtnArrow').click();const zonePoint=await page.evaluate(()=>{const n=document.querySelector('#preview [data-dim-id="front_post_gap_1"]');return !!n});assert(zonePoint);await page.locator('#preview [data-dim-id="front_post_gap_1"] .dimension-text-hit').first().click({force:true});await page.locator('#dimensionEditForm [value=addHorizontalProfile]').check();await page.locator('#dimensionEditApply').click();assert.equal((await model()).frontView.horizontalProfiles.length,1);assert((await nativeModel()).components.some(c=>c.kind==='horizontal-profile'));assert.equal((await nativeModel()).zones.filter(z=>z.face==='front').length,2);record('UI · native profile insertion and clear subzones');
step='parapet';await settings({parapet:'EVET',parapetHeight:'450',opening:'4700'});const m=await nativeModel();assert(m.zones.every(z=>z.bottom>=447));assert(m.components.filter(c=>c.polygonXZ).length>=4);record('UI · parapet and opening update');
step='invalid';const saved=await model();await page.locator('#rrV45SettingsBtn').click();await page.locator('#pergolaSetting-width').fill('0');await page.locator('#pergolaSettingsApply').click();assert(await page.locator('#pergolaSettingsError').textContent());assert.deepEqual(await model(),saved);await page.locator('#pergolaSettingsCancel').click();record('UI · invalid form leaves model unchanged');
step='exports';const file=await download('#rrV15ProjectDownload','edited.plmr');const envelope=JSON.parse(fs.readFileSync(file));assert.equal(envelope.appVersion,'3.0.0');await download('#rrV45Pdf2dBtn','edited.pdf');assert.equal(fs.readFileSync(path.join(out,'edited.pdf')).subarray(0,4).toString(),'%PDF');await download('#rrV45DxfBtn','edited.dxf');await page.locator('#rrV45Mode3DBtn').click();await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().renderCalls>0);await download('#rrV45DaeBtn','edited.dae');assert(fs.readFileSync(path.join(out,'edited.dae'),'utf8').includes('<COLLADA'));record('UI · project, PDF, DXF, DAE downloads');
step='motion';const stable=await model();await page.locator('#shellRetract').click();await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().progress===0);await page.locator('#shellExtend').click();await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().progress===1);assert.deepEqual(await model(),stable);record('UI · fabric animation preserves project');
step='roundtrip';await settings({width:'5000'});await page.locator('#projectImportInput').setInputFiles(file);await page.waitForFunction(()=>PulumurProjectState.getModel().topology.raw.width==='4000');assert.deepEqual((await model()).frontView,saved.frontView);record('UI · save and reopen preserves wall/profile edits');
step='matrix';const matrix=await page.evaluate(()=>{
const rows=[];const base=PulumurProjectModel.geometryInputFromModel(PulumurProjectState.getModel());
for(const cfg of [
 {name:'single shallow',systemCount:'1',width:'4000',opening:'2500',rearHeight:'3100',frontHeight:'2600'},
 {name:'single deep',systemCount:'1',width:'6000',opening:'6500',rearHeight:'4200',frontHeight:'2600'},
 {name:'equal pair',systemCount:'2',width:'8000',opening:'4500',rearHeight:'3200',frontHeight:'2600'},
 {name:'variable pair',systemCount:'2',width:'4000;4500',opening:'4500;5200',rearHeight:'3200;3400',frontHeight:'2600'},
 {name:'independent pair',systemCount:'2',width:'4000;500;4000;NO',opening:'4500;4500',rearHeight:'3200;3200',frontHeight:'2600'}]){
 const input={...base,...cfg,rayCount:'',postCount:'',__triangleDivisionState:{left:4,right:3,middle:{}},__frontHorizontalProfiles:[],__horizontalFacadeProfiles:{front:[],side:{}}};
 const drawing=PulumurGeometry.buildDrawing(input),m=PLMRJustPergola.fromDrawing(drawing,'white',input);
 const checks={finite:m.zones.every(z=>[...z.a,...z.b,z.width,z.height].every(Number.isFinite)),unique:new Set(m.zones.map(z=>z.id)).size===m.zones.length,positive:m.zones.every(z=>z.width>0&&z.height>0),placeable:m.zones.every(z=>z.meta.canPlaceProduct),walls:m.components.filter(c=>c.kind==='rear-wall').map(c=>c.polygonXZ),plan:drawing.entities.filter(e=>e.type==='polyline'&&e.layer==='TOPWALL').map(e=>e.points.map(([x,y])=>[x-m.assembly.origin.sourceX,-y])),triangles:m.components.filter(c=>c.kind==='triangle-frame').map(c=>({side:c.sideViewKey,polygons:c.geometry.polygons}))};
 rows.push({name:cfg.name,systems:m.assembly.systems.length,zoneCount:m.zones.length,checks});
}
return rows;});
for(const row of matrix){assert(row.checks.finite&&row.checks.unique&&row.checks.positive&&row.checks.placeable,row.name);const sort=a=>a.map(poly=>poly.map(p=>p.map(v=>v===0?0:v)).sort()).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));assert.deepEqual(sort(row.checks.walls),sort(row.checks.plan),row.name+' wall projection');}record('Model · geometry combination matrix',{cases:matrix});
step='placement';
// Start through the shared toolbar and real canvas, then select a projected grip.
await page.locator('#rrV45MoveToolBtn').click();
await selectRoofUi();
await page.locator('#rrV45Rotate90Btn').click();
await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().sceneTools.roofs[0].pose.angle===90);
assert.equal((await read()).sceneTools.roofs[0].renderedPose.angle,90);
record('UI · rigid rotation and rendered pose');
await page.locator('#rrV45MoveToolBtn').click();
await selectRoofUi();
const grip=page.locator('.rr-grip:visible').first();await grip.click();
const canvasBox=await page.locator('#model3d canvas').boundingBox();
const destination={x:canvasBox.x+canvasBox.width*.65,y:canvasBox.y+canvasBox.height*.72};
await page.keyboard.down('Alt');await page.mouse.move(destination.x,destination.y);await page.mouse.click(destination.x,destination.y);await page.keyboard.up('Alt');
await page.waitForFunction(()=>{const p=PLMRJustPergolaApp.inspect().sceneTools.roofs[0].pose;return Math.abs(p.x)+Math.abs(p.z)>1;});
const moved=(await read()).sceneTools.roofs[0];assert(Math.abs(moved.pose.x-moved.renderedPose.x)<1e-6);assert(Math.abs(moved.pose.z-moved.renderedPose.z)<1e-6);record('UI · grip movement and model pose');
await page.locator('#rrV45CopyToolBtn').click();
await selectRoofUi();await page.locator('.rr-grip:visible').first().click();
await page.keyboard.down('Alt');await page.mouse.move(destination.x-140,destination.y-70);await page.mouse.click(destination.x-140,destination.y-70);await page.keyboard.up('Alt');
await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().groups.length===2);
const withCopy=await model(),copyInput=structuredClone(withCopy.workspaces.standalone.project.copies[0].input);
await settings({width:'4600'});assert.deepEqual((await model()).workspaces.standalone.project.copies[0].input,copyInput);
record('UI · independent copy snapshot');
await download('#rrV15ProjectDownload','placement.plmr');
await settings({width:'4800'});
await page.locator('#projectImportInput').setInputFiles(path.join(out,'placement.plmr'));
await page.waitForFunction(()=>PulumurProjectState.getModel().topology.raw.width==='4600');
await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().groups.length===2);
assert.deepEqual((await model()).workspaces.standalone.project,(JSON.parse(fs.readFileSync(path.join(out,'placement.plmr')))).projectModel.workspaces.standalone.project);
record('UI · placement and copy file roundtrip');
step='layouts';await page.locator('#rrV14LayoutBtn').click();await page.locator('[data-layout=variable]').click();await page.locator('#pergolaSettingsApply').click();await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().measurements.filter(m=>m.owner==='roof-main'&&m.key==='width').length===2);
const labels=(await read()).measurements.filter(m=>m.owner==='roof-main');
assert.deepEqual(labels.filter(m=>m.key==='width').map(m=>m.value),[4000,4500]);
assert.deepEqual(labels.filter(m=>m.key==='height').map(m=>m.value),[3200,3400]);
record('UI · variable layout and per-position dimensions');
await page.screenshot({path:path.join(out,'variable.png')});
step='legacy';await page.locator('#projectImportInput').setInputFiles(path.join(root,'Test-Mantik/fixtures/previous-v1-two-positions.plmr'));
await page.waitForFunction(()=>PulumurProjectState.getModel().topology.raw.width==='4000;100;3600;NO');
assert.equal((await model()).topology.raw.opening,'4500;4100');assert.equal((await read()).groups.length,1);record('UI · legacy V1 import');
await page.locator('#projectImportInput').setInputFiles(path.join(out,'edited.plmr'));await page.waitForFunction(()=>PulumurProjectState.getModel().topology.raw.width==='4000');
step='final';await page.screenshot({path:path.join(out,'final.png')});assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
fs.writeFileSync(path.join(out,'current.json'),JSON.stringify({status:'PASS',environment:'Chromium / ANGLE SwiftShader, file://, 1440x900',results,errors,failedRequests:requests},null,2));
}catch(error){await page.screenshot({path:path.join(out,'failure.png')}).catch(()=>{});fs.writeFileSync(path.join(out,'failure.json'),JSON.stringify({step,error:error.stack,errors,results},null,2));throw error;}finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
