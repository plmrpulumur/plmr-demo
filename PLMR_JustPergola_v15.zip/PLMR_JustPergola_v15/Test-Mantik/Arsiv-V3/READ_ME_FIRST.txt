PLMR JustPergola V3 · 3.0.0
ZIP dosyasını tamamen çıkarın. Uygulama/index.html dosyasını açın.
Kurulum, npm veya yerel sunucu gerekmez. 3D için WebGL gerekir.

1. Ayarlar: sistem adedi, genişlik, açılım, arka ve ön yüksekliği girin.
   Birden fazla farklı ölçü için noktalı virgülle liste kullanabilirsiniz.
   Yerleşim Seç düğmesi hazır tekli/çoklu yerleşimleri açar.
2. 2D / 3D arasında geçiş yapın. 2D görünüşte ölçü veya parçaya tıklayarak
   mevcut PERI01 düzenleyicilerini kullanın. Ölçüler menüsünden Tüm ölçüler'i açın.
3. Cam Kaydı etkinse geçerli yan cephe bölgeleri de oluşturulur.
   Üçgen Doğrama seçeneğini Ayarlar'dan etkinleştirin; 2D görünüşte
   doğramaya tıklayarak bölme sayısını düzenleyin.
4. 3D cephe bölgesine tıklayın: ölçüler ve ürün seçim listesi açılır.
   Profilleri Düzenle mevcut PERI01 düzenleyicisini açar.
5. Taşı/Kopyala: pergolanın fiziksel bir parçasını seçin, mavi köşeye
   tıklayın, hedefi gösterip tıklayın. Escape işlemi iptal eder.
   90° / Açı düğmeleri seçilen grubu döndürür.
6. Proje Dosyası İndir / Aç ile .plmr kaydedip tekrar açın.
   2D PDF, DXF, 3D DAE ve görüntü indirmeleri mevcut düğmelere bağlıdır.

Bu paket bağımsız pergola çizimidir. FinalProcess V34 entegrasyonu ve
cephe ürünlerinin montajı sonraki aşamadır. Bu nedenle ürün seçilebilir;
montaj Kaydet düğmesi ve ana uygulama servislerine bağlı işlevler pasiftir.
Kopyalar oluşturuldukları andaki bağımsız ölçüleri saklar. Kopya ölçüsünü
ayrı düzenleme bu pakette yoktur; ana pergolayı düzenleyip yeniden kopyalayın.

Kaynaklar, test komutları ve sınırlar: DEVIR_NOTU.md / Test-Mantik/KABUL.md.
