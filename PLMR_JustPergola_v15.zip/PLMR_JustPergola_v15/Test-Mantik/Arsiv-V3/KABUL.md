# JustPergola 3.0.0 — güncel kabul

Tarih: 09.11.2026. Durum: bağımsız pergola kapsamı VERIFIED.

## Kabul matrisi

| Kullanıcı işlemi / beklenen sonuç | Güncel kanıt | Sonuç |
| --- | --- | --- |
| V34 ekran bileşenleri, renk, toolbar ve düğmeler; bağımsız pergola ayarları | current.json: initial form; kaynak kökeni Development_Protocol/V34_ADAPTER_STATUS.json | VERIFIED |
| Cepheye gerçek canvas tıklaması; ölçüler ve 7 ürünlük seçim listesi | current.json: facade click and selection list | VERIFIED |
| Zone görünürlük/cephe filtreleri | current.json: zone visibility controls | VERIFIED |
| Üçgen bölme değişimi, dış çerçevenin ve karşı tarafın korunması; undo/redo | current.json: triangle divisions, native undo and redo | VERIFIED |
| Arka duvar bölünmesi ve 2D plan / 3D duvar koordinatları | current.json: rear wall subdivision; 5 model birleşimi; geometry.json | VERIFIED |
| Yatay profil ekleme ve profil yüzeyleri dışında ayrı cephe boşlukları | current.json: native profile insertion and clear subzones | VERIFIED |
| Parapet/açılım değişimi; geçersiz formun sağlam modele dokunmaması | current.json: parapet and opening update; invalid form | VERIFIED |
| PDF, DXF, DAE ve .plmr gerçek düğme indirmeleri | current.json; exports-current.json | VERIFIED |
| Kumaş aç/kapat hareketinde ana modelin korunması | current.json: fabric animation | VERIFIED |
| Duvar/profil ve poz/kopya ayarlarını kaydet/aç | current.json: save and reopen; placement and copy file roundtrip | VERIFIED |
| Gerçek toolbar, canvas ve köşe tıklamalarıyla taşıma, döndürme, kopyalama | current.json: rigid rotation; grip movement; independent copy | VERIFIED |
| Değişken ölçülü yerleşimde ayrı dış genişlik ve poz yüksekliği | current.json: variable layout and per-position dimensions | VERIFIED |
| Eski V1 kayıt geçişi | current.json: legacy V1 import; fixtures/previous-v1-two-positions.plmr | VERIFIED |
| Native 2D geometri ve DXF davranışının V2 ile korunması | geometry.json: 6 senaryo, çizim öğeleri/bloklar/katmanlar ve DXF birebir | VERIFIED |

`current.json` 19 kabul grubu içerir: 18 UI grubu ve 5 birleşimi kapsayan 1 model grubu.
`geometry.json` ayrı 6 CPU/model/DXF senaryosudur. Tekrar koşuları yeni kapsam olarak sayılmamıştır.
Gerçek Chromium / ANGLE SwiftShader WebGL, file://, 1440×900 kullanılmıştır. Runtime hatası ve başarısız varlık isteği yoktur.
`exports-current.json`: 1 sayfalık PDF; 56 DAE geometri dizisi, mm birimi, sonlu koordinatlar, benzersiz kimlikler ve çözümlenen referanslar; DXF yapı kontrolü.
`package-check.json`: temiz ZIP çıkarma, CRC/hash manifesti, yeni klasörde WebGL açılışı ve varlık yükleri PASS.
Görseller çalışma sırasında açılarak incelendi; iç tarayıcı ekran görüntüleri pakete eklenmedi.

## Yeniden çalıştırma

Paket kökünden, Playwright ve Chromium kurulu ortamda:

```bash
python3 Development_Protocol/build.py
PLMR_CHROMIUM_CONFIG=/mutlak/yol/chromium.json PLMR_TEST_OUTPUT=/mutlak/yol/sonuclar node Test-Mantik/current-browser.cjs .
node Test-Mantik/geometry.cjs . /mutlak/yol/V2/Uygulama > /mutlak/yol/sonuclar/geometry.json
python3 Test-Mantik/exports.py /mutlak/yol/sonuclar
PLMR_CHROMIUM_CONFIG=/mutlak/yol/chromium.json node Test-Mantik/package-smoke.cjs .
python3 Development_Protocol/package.py /mutlak/yol/plmr_justpergola_v3.zip
```

Chromium ayar örneği: `{ "headless": true, "args": ["--use-angle=swiftshader", "--enable-unsafe-swiftshader"] }`.
Ortam gerektiğinde executablePath ve sandbox ayarını ayrıca sağlar. CODEX_PRIMARY_RUNTIME_NODE_MODULES yoksa testler standart `playwright` paketini kullanır.
Kaynak/çalıştırılabilir bağ: ACCEPTANCE_SOURCES_SHA256.json ve Uygulama/SOURCE_SHA256.json.
Arsiv-V2 klasörü tarihsel başlangıç kanıtıdır; güncel V3 başarısı olarak kullanılmaz.

## Kapsam dışında / sınanmadı

FinalProcess V34 entegrasyonu, canlı servisler, cephe ürünlerini monte etme, sahne paylaşımı, 3D PDF/üretim paketi, AR ve ayrı kopya ölçü düzenleyicisi bu turun kapsamı değildir; ilgili düğmeler pasif veya açıklamalıdır.
Donanım GPU/gerçek cihaz performansı, hedef CAD uygulamasına import ve statik/üretim onayı sınanmadı. Yazılım geometrisi bu onayların yerine geçmez.
