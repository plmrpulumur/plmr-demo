/* CPU/model regression. This does not replace browser/WebGL acceptance. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.resolve(process.argv[2]||'.'),baseline=path.resolve(process.argv[3]);
const scripts=['core/productPresentation.js','src/appLimits.js','ui/inputLimitPolicy.js','core/multiPositionRules.js','blocks/filteredBlocks.js','src/peri01ExcelBridge.js','src/peri01Geometry.js','src/modernDxfTemplate.js','src/dxfModernEngine.js'];
function context(dir,project){const c=vm.createContext({console});c.window=c;for(const file of [...scripts,...(project?['core/projectModel.js','shared/ral-colors.js','modules/p3dv/products/pergo-rise/pergo-rise-derived-geometry.js','source/pergola-model.js']:[])])vm.runInContext(fs.readFileSync(path.join(dir,file),'utf8'),c,{filename:file});return c;}
const old=context(baseline),current=context(path.join(root,'Uygulama'),true),results=[];
const fixtures=[{name:'single',systemCount:'1',width:'4000',opening:'4500',rearHeight:'3200',frontHeight:'2600'},
{name:'short shallow',systemCount:'1',width:'3500',opening:'2500',rearHeight:'3100',frontHeight:'2600'},
{name:'deep automatic side supports',systemCount:'1',width:'6000',opening:'6500',rearHeight:'4200',frontHeight:'2600'},
{name:'two equal',systemCount:'2',width:'8000',opening:'4500',rearHeight:'3200',frontHeight:'2600'},
{name:'two variable',systemCount:'2',width:'4000;4500',opening:'4500;5200',rearHeight:'3200;3400',frontHeight:'2600'},
{name:'separated',systemCount:'2',width:'4000;500;4000;NO',opening:'4500;4500',rearHeight:'3200;3200',frontHeight:'2600'}];
const json=x=>JSON.parse(JSON.stringify(x));
for(const cfg of fixtures){const raw={...cfg,glassTrack:'EVET',triangleJoinery:'EVET',parapet:'EVET',parapetHeight:'450',rayCount:'',postCount:'',__triangleDivisionState:{left:4,right:3,middle:{}}};old.input=raw;current.input=raw;
const a=vm.runInContext('PulumurGeometry.buildDrawing({...PulumurGeometry.SAMPLE_INPUT,...input})',old),b=vm.runInContext('PulumurGeometry.buildDrawing({...PulumurGeometry.SAMPLE_INPUT,...input})',current);
for(const key of ['entities','blocks','layerStyle'])assert.deepEqual(json(b[key]),json(a[key]),cfg.name+' '+key);
old.drawing=a;current.drawing=b;const dxfA=vm.runInContext('PulumurModernDXF.toDxf(drawing)',old),dxfB=vm.runInContext('PulumurModernDXF.toDxf(drawing)',current);assert.equal(dxfA,dxfB,cfg.name+' DXF');
const m=vm.runInContext('PLMRJustPergola.fromDrawing(drawing,"white",input)',current);for(const z of m.zones){assert(z.width>0&&z.height>0);assert([...z.a,...z.b].every(Number.isFinite));assert(z.meta.canPlaceProduct);}
for(const t of m.components.filter(c=>c.kind==='triangle-frame')){const expected=t.sideViewKey==='right'?4:5;assert.equal(t.geometry.polygons.length,expected);for(const p of t.geometry.polygons)for(const point of p)assert(point.every(Number.isFinite));}
results.push({name:cfg.name,nativeEntities:b.entities.length,exactNativeDrawing:true,exactDxf:true,zones:m.zones.length,triangles:m.components.filter(c=>c.kind==='triangle-frame').length,dxfSha256:crypto.createHash('sha256').update(dxfB).digest('hex')});}
console.log(JSON.stringify({status:'PASS',layer:'CPU / model / DXF',baseline:'plmr_justpergola_v2',results},null,2));
