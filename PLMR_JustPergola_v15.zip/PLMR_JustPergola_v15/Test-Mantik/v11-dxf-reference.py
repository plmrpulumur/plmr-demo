"""Independent CAD reader: supplied reference vs exported modelspace, mm and native contours."""
from pathlib import Path
from collections import Counter
import json,math,sys,hashlib
import ezdxf
from ezdxf import bbox
root=Path(sys.argv[1]);folder=Path(sys.argv[2]);report=Path(sys.argv[3])
refpath=root/'Development_Protocol/references/all-pergola-models-reference.dxf'
assert hashlib.sha256(refpath.read_bytes()).hexdigest()=='9a8a66307155ac7c3aabc978c678e8b629c025c43096dedadc571ee85f71abca'
ref=ezdxf.readfile(refpath);rm=ref.modelspace();frames=[];cache=bbox.Cache()
for frame in rm.query('LWPOLYLINE[layer=="Dış Çerçeve"]'):
    pts=list(frame.get_points('xy'));xmin,xmax=min(p[0] for p in pts),max(p[0] for p in pts);ymin,ymax=min(p[1] for p in pts),max(p[1] for p in pts)
    entities=[]
    for e in rm:
        if e.dxf.layer=='Dış Çerçeve':continue
        b=bbox.extents([e],cache=cache)
        if b.has_data and xmin<=(b.extmin.x+b.extmax.x)/2<xmax and ymin<=(b.extmin.y+b.extmax.y)/2<ymax:entities.append(e)
    frames.append(entities)
# Repeated wall/steel examples are represented by the same native accessory set.
indices={'Lean':0,'Lean-Quad':2,'Lean-Suspend':3,'Lean-Wing':5,'Curve':6,'Curve-Quad-Wing':8,'Curve-Suspend':9,'Curve-Quad':11,'Curve-Wing':12}
def inserts(es):return Counter(e.dxf.name.removesuffix('__MIRROR') for e in es if e.dxftype()=='INSERT' and e.dxf.name.startswith('PergoRise'))
results=[]
for kind,idx in indices.items():
    doc=ezdxf.readfile(folder/(kind+'.dxf'));m=doc.modelspace();audit=doc.audit();assert not audit.errors,(kind,audit.errors)
    assert doc.units==4
    actual=inserts(m);expected=inserts(frames[idx]);exceptions=[]
    if kind=='Curve-Suspend':
        # Explicit user decision in this task: no outside front columns.
        expected={k:v for k,v in expected.items() if not k.startswith('PergoRise Dikme')};expected=Counter(expected)
        exceptions.append('User confirmed no front columns; legacy reference columns omitted')
    if kind=='Curve-Wing':
        # Source top is only a half, source side is full, with leftover front columns.
        expected=Counter({k:v for k,v in expected.items() if not k.startswith('PergoRise Dikme')})
        expected['PergoRise Ray Arka Mekanizma Üst Görünüş']=4;expected['PergoRise Ray Kafası Üst Görünüş']=4
        exceptions.append('Full two-wing plan and no outside columns; consistent with source side and approved model')
    assert actual==expected,(kind,actual-expected,expected-actual)
    for e in m.query('INSERT'):
        if e.dxf.name.startswith('PergoRise'):assert abs(abs(e.dxf.xscale)-1)<1e-9 and abs(abs(e.dxf.yscale)-1)<1e-9,(kind,e.dxf.name)
    arc=list(m.query('ARC[layer=="Ray - Yan Görünüş"]'))
    count=8 if kind in ['Curve-Wing','Curve-Quad-Wing'] else 4 if kind.startswith('Curve') else 0
    assert len(arc)==count,(kind,len(arc),count)
    # Every four contour arcs share one circle and one angular sweep, offsets are PERI01 0/64.7/74.7/131mm.
    for i in range(0,len(arc),4):
        group=arc[i:i+4];r=max(a.dxf.radius for a in group)
        assert all((a.dxf.center-group[0].dxf.center).magnitude<1e-6 for a in group)
        assert sorted(round(r-a.dxf.radius,4) for a in group)==[0,64.7,74.7,131]
        assert all(abs(a.dxf.start_angle-group[0].dxf.start_angle)<1e-6 and abs(a.dxf.end_angle-group[0].dxf.end_angle)<1e-6 for a in group)
    for e in m.query('LWPOLYLINE[layer=="Ray - Üst Görünüş"]'):
        p=list(e.get_points('xy'));w=max(x for x,y in p)-min(x for x,y in p);assert abs(w-80)<1e-5 or abs(w-13)<1e-5,(kind,w)
    front=list(m.query('LWPOLYLINE[layer=="Ray - Ön Görünüş"]'));assert len(front)>=2
    assert all(abs(max(p[1] for p in e.get_points('xy'))-min(p[1] for p in e.get_points('xy'))-467)<1e-5 for e in front)
    assert not any('IPR-' in e.dxf.get('text','') for e in m.query('TEXT MTEXT'))
    results.append({'type':kind,'referenceFrame':idx,'nativeInsertCount':sum(actual.values()),'nativeInsertNamesAndCountsMatch':True,'unitScaleNativeAccessories':True,'sideRailArcs':count,'frontRailSilhouetteMm':467,'auditErrors':len(audit.errors),'referenceExceptions':exceptions})
# Exact primary reference: coordinates of every native rail/post/roof-register polyline and gutter.
primary=ezdxf.readfile(folder/'Lean.dxf').modelspace()
def signature(e):
    return (e.dxf.layer,tuple((round(float(x),5),round(float(y),5)) for x,y in e.get_points('xy')))
layers={'Ray - Üst Görünüş','Ray - Ön Görünüş','Ray - Yan Görünüş','POST','FABRIC','PROFILE'}
a=Counter(signature(e) for e in frames[0] if e.dxftype()=='LWPOLYLINE' and e.dxf.layer in layers)
b=Counter(signature(e) for e in primary if e.dxftype()=='LWPOLYLINE' and e.dxf.layer in layers)
assert not a-b,('Primary reference contours differ',a-b)
result={'status':'PASS','scope':'ezdxf independent reader; not AutoCAD execution or fabrication approval','sourceReferenceSha256':hashlib.sha256(refpath.read_bytes()).hexdigest(),'primaryNativeExactPolylines':sum(a.values()),'coordinateToleranceMm':0.00001,'results':results,'curveNote':'Source manually drafted circular radii and mechanism tangents differ slightly. Native attachment endpoints and configured rise/apex govern a single consistent circle; manual gaps are not reproduced.'}
report.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('PASS 9 types; native block counts/scale, true circular arcs, 16 primary reference contours')
