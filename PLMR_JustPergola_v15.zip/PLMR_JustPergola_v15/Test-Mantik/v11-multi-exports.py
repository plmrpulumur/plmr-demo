"""Independent multi-layout CAD reader: actual files vs expected side-view count and global POZ identity."""
from pathlib import Path
import json,sys
import ezdxf
folder=Path(sys.argv[1]);reports=json.loads(Path(sys.argv[2]).read_text())['results'];items=[]
for p in sorted(folder.glob('multi-*.dxf')):
    key=p.stem[6:];record=next(r for r in reports if r['type']=='Curve-Quad-Wing' and r['layout']==key)
    d=ezdxf.readfile(p);a=d.audit();assert not a.errors;assert d.units==4
    arcs=list(d.modelspace().query('ARC[layer=="Ray - Yan Görünüş"]'));assert len(arcs)==8*record['sideViews'],(key,len(arcs),record)
    titles=[e.plain_text() if e.dxftype()=='MTEXT' else e.dxf.text for e in d.modelspace().query('TEXT MTEXT')];names=[t for t in titles if 'Avila Curve-Quad-Wing' in t]
    assert len(names)==2*record['systems']
    for i in range(1,record['systems']+1):assert sum(t.endswith('POZ '+str(i)) for t in names)==2,(key,names)
    assert p.with_suffix('.pdf').read_bytes().startswith(b'%PDF')
    items.append({'layout':key,'systems':record['systems'],'sideViews':record['sideViews'],'realArcs':len(arcs),'uniquePrintedPositions':True,'auditErrors':0})
assert len(items)==6
(folder/'v11-multi-exports.json').write_text(json.dumps({'status':'PASS','results':items},indent=2)+'\n');print('PASS six multi DXF/PDF files: native arcs and printed position ownership')
