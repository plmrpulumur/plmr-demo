const assert=require('node:assert/strict'),fs=require('fs');const path=require('path'),Module=require('module');
const sourceFile=path.join(__dirname,'../Entegrasyon/supabase-deployed/plmr-platform-index.ts');
let code=fs.readFileSync(sourceFile,'utf8');code=code.slice(0,code.lastIndexOf('// ../Cloud/edge-v21.ts')).replace('import { createClient } from "npm:@supabase/supabase-js@2.95.0";','');
const recovered=new Module(sourceFile,module);recovered._compile(code+'\nmodule.exports={createCloudHandler,assertFinalScene,assertFinalQuoteReady,finalTechnicalScene,drawingFingerprint};',sourceFile);
const e=recovered.exports;
const results=[];function pass(name){results.push({name,status:'PASS'});console.log('PASS',name)}
(async()=>{
 const snapshot=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/v15-main-pergola.plmr'),'utf8')).snapshot,changed=structuredClone(snapshot),view=structuredClone(snapshot);
 e.assertFinalScene(snapshot);changed.modelState.sceneEditor.justPergola.model.positions[0].width+=100;
 view.modelState.sceneEditor.sharedProductLayout.justPergolaView={...view.modelState.sceneEditor.sharedProductLayout.justPergolaView,dimensions:{main:false}};
 assert.notDeepEqual(e.finalTechnicalScene(snapshot),e.finalTechnicalScene(changed));assert.deepEqual(e.finalTechnicalScene(snapshot),e.finalTechnicalScene(view));pass('Deployed technical scene tracks physical Pergola edits and excludes existing view-layout data');
 assert.throws(()=>e.assertFinalQuoteReady({drawingScene:snapshot,sceneRows:[{kind:'roof',referenceKey:'justpergola:Avila:Lean'}]}),/ticari/);pass('Separate Pergola engine key rejected until real commercial registration');
 let writes=0,companyReads=[];const actor={userId:'synthetic-user',username:'testuser',fullName:'Synthetic user',roleId:'VIEWER',status:'ACTIVE',memberships:[{companyId:'company-a',roleId:'VIEWER',status:'ACTIVE',permissionOverrides:{},dataScopeOverrides:{}}]};
 const company={companyId:'company-a',code:'TEST',status:'ACTIVE',licenseStart:'2000-01-01',licenseEnd:'2099-12-31',userLimit:5,settings:{companyName:'Synthetic company'}};
 const db={authenticate:async()=>({id:actor.userId,profile:{is_active:true,role:'viewer'}}),directory:async()=>({users:[actor],companies:[company]}),get:async(scope,key)=>{if(scope!=='platform')companyReads.push(scope);return {key,value:null,version:0}},cas:async()=>{writes++;throw Error('Unexpected write')}};
 const handler=e.createCloudHandler(db,()=>true);const request=body=>new Request('https://example.invalid',{method:'POST',body:JSON.stringify(body),headers:{'Content-Type':'application/json'}});
 let response=await handler(request({action:'record_get',companyId:'company-b',store:'drawing.projects',key:'x'}));assert.equal(response.status,403);assert.deepEqual(companyReads,[]);pass('Foreign company rejected before reading its business record');
 response=await handler(request({action:'record_put',companyId:'company-a',store:'drawing.projects',key:'x',value:{},expectedVersion:0}));assert.equal(response.status,403);assert.equal(writes,0);pass('Viewer cannot write a project; no backend mutation called');
 db.authenticate=async()=>({id:actor.userId,profile:{is_active:false,role:'viewer'}});response=await handler(request({action:'record_get',companyId:'company-a',store:'drawing.projects',key:'x'}));assert.equal(response.status,403);pass('Inactive account rejected');
 fs.writeFileSync(path.join(process.env.PLMR_TEST_OUTPUT||__dirname,'v15-edge-audit.json'),JSON.stringify({status:'PASS',scope:'Recovered deployed plmr-platform v54 business logic; synthetic backend unit tests, no live user/tenant writes',results},null,2));
})().catch(error=>{console.error(error);process.exitCode=1});
