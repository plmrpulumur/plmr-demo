/* Source-backed V12 selection-controller contract. Not a real browser/WebGL test. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const rootPath=path.resolve(process.argv[2]||'.');
const src=fs.readFileSync(path.join(rootPath,'Test-Mantik/v11-model-matrix.cjs'),'utf8').split('const types=')[0];
const c=Function('require','process',src+'return c;')(require,process);
const ui=fs.readFileSync(path.join(rootPath,'Uygulama/source/pergola-ui.js'),'utf8');
const start=ui.indexOf('  function selectPart(component,owner){'),end=ui.indexOf('  function setUnits(',start);
assert(start>0&&end>start,'Selection controller source not found');
const source=ui.slice(start,end);
let tests=0;
for(const [type,targetKind] of [['Lean','rear-steel-beam'],['Lean','rear-steel-post'],['Lean-Suspend','rear-steel-beam'],['Curve','rear-steel-beam'],['Curve','rear-steel-post']]){
  const raw={...c.PulumurGeometry.SAMPLE_INPUT,rayCount:'',postCount:'',
    __pergola:{series:'Avila',railType:type==='Curve'?'Curved':'Linear',pergolaType:type,layoutPlanId:'single'},
    __rearSupport:{type:'steel'},
    __topBackWallGridState:{'0':{cells:[{id:'steel-part-0',enabled:true,minX:0,maxX:2000,startNearDepth:0,endNearDepth:0,startFarDepth:160,endFarDepth:160},
      {id:'steel-part-1',enabled:true,minX:2000,maxX:4000,startNearDepth:0,endNearDepth:0,startFarDepth:160,endFarDepth:160}]}}};
  let drawing=c.PulumurGeometry.buildDrawing(raw),model=c.PLMRJustPergola.fromDrawing(drawing,'white',raw);
  const steels=model.components.filter(x=>['rear-steel-beam','rear-steel-post'].includes(x.kind));
  assert(steels.length>0,'No steel parts to select '+type);
  let legacy={formData:{},drawingState:{topBackWallGridState:structuredClone(raw.__topBackWallGridState)}};
  let commits=0,clears=0,refreshes=0;
  const buttons=new Map(),part={hidden:true,querySelector(sel){return sel==='small'?{set textContent(v){}}:{onclick:null};}};
  const $=id=>id==='rrV11SelectionActions'?part:(buttons.has(id)?buttons.get(id):(buttons.set(id,{hidden:false,onclick:null,textContent:''}),buttons.get(id)));
  const native={legacy(){return structuredClone(legacy);},commitLegacy(next){legacy=structuredClone(next);commits++;const nextRaw={...raw,__topBackWallGridState:legacy.drawingState.topBackWallGridState};drawing=c.PulumurGeometry.buildDrawing(nextRaw);model=c.PLMRJustPergola.fromDrawing(drawing,'white',nextRaw);}};
  const root={PLMRJustPergola:{fromDrawing:()=>({assembly:{origin:{sourceX:c.PLMRJustPergola.fromDrawing(drawing,'white',raw).assembly.origin.sourceX}}})}};
  const viewer={clearPart(){clears++;}};
  // Execute actual selection function and its bound delete-button handler;
  // the thin document and native adapters are simulated, not a real DOM.
  const selectPart=Function('root','native','drawingAccessor','viewer','run','refresh','notify','document','$','clone',
    `let selectedPart=null;let drawing;function setDrawing(value){drawing=value;}${source}\nreturn {selectPart,setDrawing};`)(root,native,()=>drawing,viewer,fn=>fn(),()=>{refreshes++;},()=>{},{$},$,structuredClone);
  selectPart.setDrawing(drawing);
  const target=steels.find(x=>x.kind===targetKind);
  assert(target,'Steel beam missing '+type);
  selectPart.selectPart(target,'roof-main');
  assert.equal($('rrV11SelectionDeleteBtn').hidden,false,'delete action should display');
  $('rrV11SelectionDeleteBtn').onclick();
  assert.equal(commits,1,'delete must commit exactly once');
  const remaining=model.components.filter(x=>x.kind===targetKind).length;
  assert(remaining<steels.filter(x=>x.kind===targetKind).length,'selected steel source cell must disappear '+type+' '+targetKind);
  assert(clears===1&&refreshes===1,'post delete should clear selected and refresh');
  tests+=4;
}
console.log('PASS source-backed selection controller '+tests+' checks (not browser/WebGL)');
