# V11 görsel değerlendirme

Gerçek tarayıcı 2D ekranları dokuz tipte üretildi. Curve-Quad-Wing, Curve-Quad ve karma üç poz örnekleri açılıp değerlendirildi: özgün ray/oluk/mekanizma, top/front/side düzeni, tek/çift kemer ayrımı ve modül bazlı aynalama görüldü. Yeni Quad-Wing'in gerçek WebGL 3D ekranında merkez çelik, iki kumaş ve dış dikmeler incelendi; hafif SVG kartı açılıp kontrol edildi.

Gerçek PDF çıktıları Poppler ile rasterleştirildi. Curve-Quad-Wing, Curve-Quad, Lean-Suspend ve üç kademeli poz içeren colon-mixed örneği açılıp değerlendirildi. Kontrolde görülen iki sunum kusuru düzeltildi: uzun tip/poz adının modülden taşması ve askı üst kotunun arka yükseklik yazısına yaklaşması. Açı etiketi askı/ray temasından aşağı taşındı. Son dosyalar yeniden indirildi. Antet aynı sağlayıcıdan, üst/ön/yan görünüşler tek çizimden gelir. Çoklu görünüşlerin ayrımı ve POZ 1/2/3 sahipliği kontrol edildi.

Bu gözlem piksel düzeyinde her olası ölçünün garantisi değildir. Sayısal montaj/kimlik/ölçü ve dosya kontrolleri ayrı raporlardadır. Test görüntüleri kullanıcı talebi olmadığı için pakete veya kalıcı çıktıya eklenmedi.
