# Kullanıcı DXF inceleme kaydı

Kaynak `Development_Protocol/references/all-pergola-models-reference.dxf` (mm, AC1032), 796 modelspace entity, 13 çerçeve. Çerçeve sırası: 0 Lean duvar; 1 Lean çelik; 2 Lean-Quad; 3 Lean-Suspend duvar; 4 Lean-Suspend çelik; 5 Lean-Wing; 6 Curve duvar; 7 Curve çelik; 8 yeni Curve-Quad-Wing; 9 Curve-Suspend duvar; 10 Curve-Suspend çelik; 11 Curve-Quad; 12 Curve-Wing.

Standart iki raylı native aksesuar INSERT sayıları (logo/trapez hatch hariç): Lean20, Lean-Quad34, Lean-Suspend10, Lean-Wing18, Curve20, Curve-Quad-Wing34, Curve-Quad26. Curve-Suspend referans20'den kullanıcı kararıyla ön dikmesiz10 olur. Curve-Wing referansın yarım plan/eskiden kalan ön dikmelerinden düzeltilmiş tam dikmesiz çift kanatta18 olur. İsim/adet kıyası bağımsız ezdxf okuyucusundadır. Modern DXF'in __MIRROR blokları aynı native bloğun yansıması olarak normalize edilir, ek fiziksel aksesuar sayılmaz.

Ana Lean plan/ön/yan ray, dikme, çatı kaydı ve olukta 16 LWPOLYLINE noktaları aynı koordinatlarda 0.00001 mm hassasiyetle kıyaslandı. Native duvar/çelik seçenekleri farklı olsa da ortak ray/oluk/dikme matematiği aynıdır. Aksesuarlar scale=1'dir.

Kavis referansında bazı uç/teğet noktaları elle değiştirilmiş: Curve yarıçapı 28612.66187552554, yay kiriş boyu 4282.920746; özgün montaj uçları arasındaki kiriş 4299.318 mm civarıdır. Curve-Quad referansında yaklaşık 9145.714 mm yan yay kirişi, 9100 mm nominal planla birebir aynı değildir. Bu farklar gizlenmedi. Öncelik kullanıcının birinci referansı PERI01 montaj matematiğidir; tek tutarlı daireyi gerçek montaj uçları ve seçilmiş yükselme/tepe kotu tanımlar. Bu nedenle elle ayrılmış referans uçları tekrar edilmez. Varsayılan orta yükselme referansın yaklaşık80.2493 mm kabarmasına dayanır; yarıçap referansına uymak için uç bağlantısı bozularak kopyalanmaz.

Curve-Quad tek kemer, arka toplanan tek kumaş ve bir ürün adıyla gösterilir. Quad-Wing iki bağımsız eğimli kavis ve merkez çeliğe yüz montajıdır; iki kumaş ve iki karşılıklı üst görünüş ürün etiketi korunur.
