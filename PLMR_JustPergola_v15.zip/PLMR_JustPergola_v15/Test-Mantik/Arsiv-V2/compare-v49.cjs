const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),vm=require('node:vm'),crypto=require('node:crypto');
const v49=path.resolve(process.argv[2]||'work/v49/GitHub');
const app=path.resolve(process.argv[3]||'work/versioned/PLMR_JustPergola_v2');
const out=path.resolve(process.argv[4]||'test-browser/peri-r1');
const source=path.join(app,'Development_Protocol/peri01');
const context=vm.createContext({console});
const scripts=['core/productPresentation.js','src/appLimits.js','ui/inputLimitPolicy.js','core/multiPositionRules.js',
 'blocks/filteredBlocks.js','src/peri01ExcelBridge.js','src/peri01Geometry.js',
 'src/modernDxfTemplate.js','src/dxfModernEngine.js'];
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
for(const name of scripts){
 const original=fs.readFileSync(path.join(v49,name));
 assert.deepEqual(fs.readFileSync(path.join(source,name)),original,name);
 assert.deepEqual(fs.readFileSync(path.join(app,'Uygulama',name)),original,name);
 vm.runInContext(original.toString(),context,{filename:name});
}
const contextGlobals=vm.runInContext('({build:PulumurGeometry.buildDrawing,dxf:PulumurModernDXF.toDxf})',context);
const results=[];
for(const fixture of ['base','edited','legacy-two-positions']){
 const observed=JSON.parse(fs.readFileSync(path.join(out,fixture+'.json'),'utf8'));
 const reference=contextGlobals.build(observed.input);
 const normalize=value=>JSON.stringify(value);
 for(const key of ['entities','blocks','layerStyle'])assert.equal(normalize(observed[key]),normalize(reference[key]),fixture+' '+key);
 reference.hiddenLayers={'Ölçüler - Ana':false,'Ölçüler - Detay':true};
 const expected=contextGlobals.dxf(reference);
 fs.writeFileSync(path.join(out,fixture+".v49.dxf"),expected);
 const exported=fs.readFileSync(path.join(out,fixture+'.dxf'),'utf8');
 assert.equal(hash(exported),hash(expected),fixture+' DXF');
 const pairs=exported.split(/\r?\n/);
 const blockNames=[], inserts=[], types={};
 for(let i=0;i+1<pairs.length;i+=2){
  if(pairs[i].trim()!=='0')continue;
  const type=pairs[i+1];
  types[type]=(types[type]||0)+1;
  if(type!=='BLOCK'&&type!=='INSERT')continue;
  for(let j=i+2;j+1<pairs.length&&pairs[j].trim()!=='0';j+=2){
   if(pairs[j].trim()==='2'){(type==='BLOCK'?blockNames:inserts).push(pairs[j+1]);break}
  }
 }
 assert(inserts.length>=10&&blockNames.length>20);
 for(const name of inserts)assert(blockNames.includes(name),name);
 results.push({fixture,entities:reference.entities.length,libraryBlocks:Object.keys(reference.blocks).length,
  dxfBlockDefinitions:blockNames.length,dxfInserts:inserts.length,referencedBlocks:[...new Set(inserts)],
  sha256:hash(exported),lineTypeCounts:types,exactDxf:true});
}
console.log(JSON.stringify({status:'PASS',source:'PLMR_V49(1).zip / GitHub',unchangedScripts:scripts,results},null,2));
