const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright':'playwright');
const app=path.resolve(process.argv[2]||'work/versioned/PLMR_JustPergola_v2');
const out=path.resolve(process.env.PLMR_TEST_OUTPUT||'test-browser/peri-r1');
fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=await chromium.launch(JSON.parse(fs.readFileSync(process.env.PLMR_CHROMIUM_CONFIG||'test-browser/chromium.json')));
 const page=await browser.newPage({viewport:{width:1560,height:960},acceptDownloads:true});
 page.setDefaultTimeout(12000);
 const errors=[],dialogs=[],external=[];
 page.on('pageerror',e=>{errors.push(e.message);console.error(e.stack)});
 page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url())});
 page.on('dialog',async d=>{dialogs.push(d.message());await d.dismiss()});
 try{
  await page.goto(pathToFileURL(path.join(app,'Uygulama/index.html')).href);
  assert.equal(await page.title(),'PLMR | JustPergola V2');
  const fields={systemCount:'1',width:'4000',opening:'4500',rearHeight:'3200',frontHeight:'2600',structureColor:'RAL 7016 TEXTURE',fabric:'#e1d9c4',fabricProfiles:'RAL 9016',extras:'KABUL'};
  for(const [id,value] of Object.entries(fields))await page.locator('#'+id).fill(value);
  await page.click('#previewBtn');
  await page.waitForFunction(()=>document.querySelector('#preview svg')&&document.querySelector('#statusText').textContent.startsWith('Hazır'));
  const formIds=['customer','project','drawnBy','date','systemCount','width','opening','rearHeight','frontHeight','rayCount','postCount','parapet','parapetHeight','glassTrack','structureColor','fabric','fabricProfiles','motor','remote','led','dimmer','extras','triangleJoinery','waterStandard'];
  for(const id of formIds)assert.equal(await page.locator('#'+id).count(),1,id);
  const state=()=>page.evaluate(()=>PulumurProjectState.getModel());
  const original=await state();
  const drawing=()=>page.evaluate(()=>{
   const d=PulumurPreviewShell.refresh();
   const input=PulumurProjectModel.geometryInputFromModel(PulumurProjectState.getModel());
   return {input, entities:d.entities, blocks:d.blocks, layerStyle:d.layerStyle};
  });
  const collect=async name=>fs.writeFileSync(path.join(out,name+'.json'),JSON.stringify(await drawing()));
  const download=async(id,file)=>{
   const pending=page.waitForEvent('download',{timeout:30000});await page.click(id);
   const d=await pending;await d.saveAs(path.join(out,file));return d.suggestedFilename();
  };
  await collect('base');
  await download('#generateBtn','base.dxf');
  await download('#pdfBtn','base.pdf');
  assert.equal(fs.readFileSync(path.join(out,'base.pdf')).subarray(0,4).toString(),'%PDF');
  await page.screenshot({path:path.join(out,'2d.png')});
  await page.click('#expandPreviewBtn');
  await page.waitForFunction(()=>document.querySelector('#preview').dataset.interactive==='true');
  const toolNames=await page.locator('#previewToolbox button:visible').allTextContents();
  for(const text of ['Çoklu Ölçü Düzenleme','Dikme Ayarları','Detay Kopyala'])assert(toolNames.some(n=>n.trim()===text),text);
  await page.screenshot({path:path.join(out,'tools.png')});
  const opening=page.locator('#preview .dimension-text-hit[data-edit-field="opening"], #preview [data-edit-field="opening"] .dimension-text-hit');
  const [first]=await opening.all();
  if(first){
   await first.click({force:true});
  }else{
   const locator=page.locator('#preview [data-edit-field="opening"]').first();
   await locator.click({force:true});
  }
  await page.locator('#dimensionEditInput').fill('4700');
  await page.click('#dimensionEditApply');
  const raw=()=>page.evaluate(()=>PulumurProjectState.getModel().topology.raw);
  assert.equal((await raw()).opening,'4700');
  await page.click('#undoPreviewBtn');
  assert.equal((await raw()).opening,'4500');
  await page.click('#redoPreviewBtn');
  assert.equal((await raw()).opening,'4700');
  const wall=page.locator('#preview [data-interaction-type="topBackWallEditor"]').first();
  await wall.click({force:true});
  await page.locator('#topWallColumns').fill('2');
  await page.click('#topBackWallEditorForm button[type=submit]');
  const wallCount=async()=>page.evaluate(()=>PulumurPreviewShell.refresh().input.topBackWallGridState['0'].cells.length);
  assert.equal(await wallCount(),2);
  await page.click('#showAllDims');
  await page.locator('#dimensionFilterMaster').uncheck();
  await page.locator('#dimensionFilterMaster').check();
  await page.click('#dimensionFilterClose');
  await page.locator('#preview [data-dim-id="front_post_gap_1"] .dimension-text-hit').first().click({force:true});
  await page.locator('#dimensionEditForm [value="addHorizontalProfile"]').check();
  await page.click('#dimensionEditApply');
  assert.equal((await state()).frontView.horizontalProfiles.length,1);
  await page.click('#showMainDims');
  await page.click('#glassTrackQuickBtn');
  await page.click('#triangleJoineryQuickBtn');
  await page.click('#expandPreviewBtn');
  await page.locator('#parapet').selectOption('EVET');
  await page.locator('#parapetHeight').fill('450');
  await page.locator('#waterStandard').selectOption('HAYIR');
  await page.click('#previewBtn');
  await collect('edited');
  await download('#generateBtn','edited.dxf');
  await download('#projectExportBtn','edited.plmr');
  assert.equal(JSON.parse(fs.readFileSync(path.join(out,'edited.plmr'),'utf8')).appVersion,'2.0.0');
  await page.click('#view3d');
  const inspect=()=>page.evaluate(()=>PLMRJustPergolaApp.inspect());
  await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().renderCalls>0);
  assert(await page.locator('#pergolaError').isHidden());
  const three=await inspect();
  assert(three.webgl&&three.groups.includes('Pergola P01'));
  assert(three.walls.some(w=>w.includes('Arka duvar'))&&three.walls.some(w=>w.includes('Parapet')));
  const projected=await page.evaluate(()=>{
    const drawing=PulumurPreviewShell.refresh();
    const model=PLMRJustPergola.fromDrawing(drawing,'white');
    const plan=drawing.entities.filter(e=>e.type==='polyline'&&e.layer==='TOPWALL').map(e=>e.points.map(([x,y])=>[x-model.assembly.origin.sourceX,-y]).sort());
    const walls=model.components.filter(c=>c.kind==='rear-wall').map(c=>c.polygonXZ.slice().sort());
    return {opening:model.assembly.systems[0].opening,plan,walls,sideTracks:model.components.filter(c=>c.kind==='glass-track').map(c=>c.sideViewKey),parts:[...new Set(model.components.map(c=>c.kind))]};
  });
  assert.equal(projected.opening,4700);
  assert.deepEqual(projected.sideTracks,['0','right']);
  assert.deepEqual(JSON.parse(JSON.stringify(projected.plan)),JSON.parse(JSON.stringify(projected.walls)));
  for(const kind of ['rail','rail-rear-mechanism','rail-front-head','post','gutter','roof-register-profile','trapez-sheet','glass-track','water-outlet','triangle-joinery','horizontal-profile'])assert(projected.parts.includes(kind),kind);
  await page.click('#retract');
  await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().progress===0);
  await page.click('#extend');
  await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().progress===1);
  await page.screenshot({path:path.join(out,'3d.png')});
  await download('#dae','edited.dae');
  await page.click('#view2d');
  await page.locator('#opening').fill('4500');
  await page.click('#previewBtn');
  await page.locator('#projectImportInput').setInputFiles(path.join(out,'edited.plmr'));
  await page.waitForFunction(()=>PulumurProjectState.getModel().topology.raw.opening==='4700');
  assert.equal(await wallCount(),2);
  await page.click('#expandPreviewBtn');
  await page.waitForFunction(()=>document.querySelector('#preview').dataset.interactive==='true');
  const target=await page.waitForFunction(()=>{
    const nodes=[...document.querySelectorAll('#preview [data-interaction-type="topBackWallEditor"]')];
    for(const node of nodes){
      const r=node.getBoundingClientRect();
      for(const a of [.5,.25,.75])for(const b of [.5,.25,.75]){
        const x=r.left+r.width*a,y=r.top+r.height*b;
        if(document.elementFromPoint(x,y)?.closest('[data-interaction-type="topBackWallEditor"]')===node)return {x,y};
      }
    }
    return null;
  });
  const point=await target.jsonValue();
  await page.mouse.click(point.x,point.y);
  await page.locator('#topWallSupportType').selectOption('steel');
  await page.click('#topBackWallEditorForm button[type=submit]');
  await page.click('#rearSteelProfileForm button[type=submit]');
  const steel=await page.evaluate(()=>{
    const drawing=PulumurPreviewShell.refresh();
    return PLMRJustPergola.fromDrawing(drawing,'white').components.filter(c=>c.kind.startsWith('rear-steel-')).map(c=>c.kind);
  });
  assert(steel.includes('rear-steel-beam')&&steel.includes('rear-steel-post'));
  await page.click('#expandPreviewBtn');
  if(process.env.PLMR_V1_FIXTURE){
   await page.locator('#projectImportInput').setInputFiles(process.env.PLMR_V1_FIXTURE);
   await page.waitForFunction(()=>PulumurProjectState.getModel().topology.raw.width==='4000;100;3600;NO');
   assert.equal((await raw()).opening,'4500;4100');
   await collect('legacy-two-positions');
   await download('#generateBtn','legacy-two-positions.dxf');
   await page.click('#view3d');
   await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().groups.includes('Pergola P02'));
   assert(await page.locator('#pergolaError').isHidden());
  }
  assert.deepEqual(errors,[]);assert.deepEqual(dialogs,[]);assert.deepEqual(external,[]);
  console.log(JSON.stringify({status:'PASS',toolNames,fields:formIds.length,originalWidth:original.topology.raw.width,
    editedOpening:4700,wallCells:2,projected,steel,three:{groups:three.groups,webgl:three.webgl,renderCalls:three.renderCalls},pdf:true}));
  assert.deepEqual(errors,[]);assert.deepEqual(dialogs,[]);assert.deepEqual(external,[]);
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
