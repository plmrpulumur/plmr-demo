"""Independent DXF audit: dynamic DIMENSION text and safe physical associativity."""
from pathlib import Path
from collections import Counter
import ezdxf,math,json
root=Path(__file__).resolve().parent.parent
folder=root/'Test-Mantik/v14-output'
results=[]
for name in ['Lean','Lean-Suspend','Curve','Curve-Quad','Curve-Quad-Wing']:
    doc=ezdxf.readfile(folder/(name+'.dxf'))
    assert not doc.audit().errors, f'{name}: DXF structural audit failed'
    model=doc.modelspace();dims=list(model.query('DIMENSION'))
    assert len(dims)>3, (name,'Missing CAD DIMENSIONs')
    assert all(e.dxf.get('text')=='<> mm' for e in dims),(name,'Found fixed dimension text')
    assert all(e.dxf.dimstyle=='PLMR_DIM_MM' for e in dims)
    associates=[e for e in doc.objects if e.dxftype()=='DIMASSOC']
    assert associates, (name,'Missing geometry-linked CAD dimensions')
    for assoc in associates:
        tags=assoc.xtags.subclasses[1]
        dim_handle=next(t.value for t in tags if t.code==330)
        dim=doc.entitydb.get(dim_handle)
        assert dim is not None and dim.dxftype()=='DIMENSION',(name,'invalid associated dimension handle')
        assert dim.has_extension_dict,(name,'dimension missing extension dictionary')
        assert dim.get_extension_dict().get('ACAD_DIMASSOC') is assoc,(name,'bad DIMASSOC dictionary link')
        assert any(x.code==90 and x.value==3 for x in tags),(name,'not both anchor points associated')
        refs=[x.value for x in tags if x.code==331]
        markers=[x.value for x in tags if x.code==91]
        assert len(refs)==len(markers)==2,(name,'expected two matching geometry handles')
        for i,(ref,marker) in enumerate(zip(refs,markers)):
            poly=doc.entitydb.get(ref)
            assert poly is not None and poly.dxftype()=='LWPOLYLINE',(name,'associated geometry not a polyline')
            points=list(poly.get_points('xy'))
            assert 0<=marker<len(points),(name,'invalid CAD polyline vertex marker')
            x,y=points[marker]
            base=[dim.dxf.defpoint2,dim.dxf.defpoint3][i]
            angle=math.degrees(math.atan2(dim.dxf.defpoint3.y-dim.dxf.defpoint2.y,dim.dxf.defpoint3.x-dim.dxf.defpoint2.x))
            measured_error=abs(x-base.x) if abs(math.cos(math.radians(angle)))>0.7 else abs(y-base.y)
            assert measured_error <0.002,(name,'wrong measured coordinate in geometry association',measured_error)
    for dim in dims:
        assert dim.get_measurement()>0,(name,'Invalid calculated measurement')
    # CAD dimension editor equivalent: move the second definition point,
    # then let the DXF library regenerate the dimension's graphic block.
    target=next(e for e in dims if abs(e.get_measurement()-4000)<1)
    before=target.get_measurement()
    p=target.dxf.defpoint3
    target.dxf.defpoint3=(p.x+125,p.y,p.z)
    after=target.get_measurement()
    assert abs(after-before-125)<0.001,(name,'Measurement did not update')
    target.render()
    cached=[e.dxf.text for e in target.get_geometry_block() if e.dxftype() in ('MTEXT','TEXT')]
    assert any('4125' in x for x in cached),(name,'Rebuilt display text did not follow modified dimension geometry',cached)
    results.append({'type':name,'cadDimensions':len(dims),'trueDimensionObjects':True,'dynamicText':True,'matchingPhysicalVertexAssociations':len(associates),'exampleStretchFromMm':before,'exampleStretchToMm':after,'reconstructedDisplay':cached,'structuralAudit':'PASS'})
report={'status':'PASS','scope':'R2013 DXF parsing, DIMASSOC objects and dynamically recalculated dimension block; not native AutoCAD STRETCH or geometry-only user interaction','results':results}
(folder/'v14-dxf-acceptance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS V14 DXF:',len(results),'products',sum(x['cadDimensions'] for x in results),'dimension objects',sum(x['matchingPhysicalVertexAssociations'] for x in results),'geometry associations')
