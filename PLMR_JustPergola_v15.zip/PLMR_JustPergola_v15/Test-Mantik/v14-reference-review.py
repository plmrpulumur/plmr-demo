"""Read-only analysis of the user-supplied V14 technical CAD reference."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import ezdxf
root=Path(__file__).resolve().parent.parent
old=root/'Development_Protocol/references/all-pergola-models-reference.dxf'
new=root/'Development_Protocol/references/pergola-reference-v14.dxf'
docs=[ezdxf.readfile(str(p)) for p in (old,new)]
models=[list(d.modelspace()) for d in docs]
counts=[Counter(e.dxftype() for e in rows) for rows in models]
old_names=Counter(e.dxf.text for e in models[0] if e.dxftype()=='MTEXT' and e.dxf.text.startswith('Avila'))
new_names=Counter(e.dxf.text for e in models[1] if e.dxftype()=='MTEXT' and e.dxf.text.startswith('Avila'))
assert docs[1].header['$INSUNITS']==4,'reference should be millimetres'
assert len(models[1])>len(models[0])
assert counts[1]['DIMENSION']>counts[0]['DIMENSION']
assert counts[1]['LWPOLYLINE']>counts[0]['LWPOLYLINE']
assert sum('Lean' in key for key in new_names)>=4 and sum('Curve' in key for key in new_names)>=4
assoc=[sum(x.dxftype()=='DIMASSOC' for x in d.objects) for d in docs]
report={'status':'PASS','review':'Reference geometry was read, not auto-applied; original native geometry is preserved',
  'baseline':{'filename':old.name,'sha256':sha256(old.read_bytes()).hexdigest(),'entities':len(models[0]),'types':dict(counts[0]),'dimassocs':assoc[0]},
  'userV14':{'filename':new.name,'sha256':sha256(new.read_bytes()).hexdigest(),'entities':len(models[1]),'types':dict(counts[1]),'dimassocs':assoc[1],'units':'mm','productLabels':dict(new_names)},
  'netAdditions':dict(counts[1]-counts[0]),'scope':'New plan reference is a verification baseline, not a license to replace working PERI01 blocks'}
folder=root/'Test-Mantik/v14-output';folder.mkdir(exist_ok=True)
(folder/'v14-reference-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS: V14 user reference:',len(models[1]),'entities;',counts[1]['DIMENSION'],'dimensions;',assoc[1],'associativity objects')
