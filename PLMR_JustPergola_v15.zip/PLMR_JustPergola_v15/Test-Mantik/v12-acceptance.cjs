/* V12 behavior tests; old V11 fixtures intentionally kept unchanged. */
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||'.');
const src=fs.readFileSync(root+'/Test-Mantik/v11-model-matrix.cjs','utf8').split('const types=')[0];
const c=Function('require','process',src+'return c;')(require,process);
const types=['Lean','Lean-Suspend','Lean-Wing','Lean-Quad','Curve','Curve-Suspend','Curve-Wing','Curve-Quad','Curve-Quad-Wing'];
const cards=c.PLMRPergolaLayouts.cards;const result={cases:[],errors:[],tests:0};
const eps=.085;const G=c.PLMRPergolaVariantGeometry;
function norm(p,q){return Math.hypot(...p.map((v,i)=>v-q[i]));}
function T(x,y,rot){const a=rot*Math.PI/180;return [x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a)];}
function hole(e,b){const circles=(b.entities||[]).filter(x=>x.type==='circle');let h=circles[0];if(e.name==='PergoRise Ray Arka Mekanizma Yan Görünüş'){const mounts=circles.filter(x=>Math.abs((x.r||0)-7.75)<.05&&x.x>80&&x.x<145);h=mounts.sort((a,b)=>a.y-b.y)[0]||h;}const [x,y]=T(e.mirrorX?-h.x:h.x,h.y,e.rotation||0);return [x+e.x,y+e.y];}
for(const type of types)for(const card of cards){
 c.input={...c.PulumurGeometry.SAMPLE_INPUT,...card.values,rayCount:'',postCount:'',glassTrack:'HAYIR',triangleJoinery:'HAYIR',parapet:'HAYIR',__pergola:{series:'Avila',railType:type.startsWith('Curve')?'Curved':'Linear',pergolaType:type,layoutPlanId:card.id}};
 const d=c.PulumurGeometry.buildDrawing(c.input),m=c.PLMRJustPergola.fromDrawing(d,'white',c.input);
 const rails=m.components.filter(e=>e.kind==='rail');
 for(const r of rails){
  const expectedRear=type==='Curve-Quad'?30:0;
  assert.equal(r.extensionMm.rear,expectedRear);
  assert.equal(r.extensionMm.front,30);
  const startDistance=norm(r.start,r.standardStart),endDistance=norm(r.end,r.standardEnd);
  if(!r.curveRadius){assert(Math.abs(startDistance-expectedRear)<eps,[type,card.id,r.id,startDistance]);assert(Math.abs(endDistance-30)<eps,[type,card.id,r.id,endDistance]);}
  else{
   const oldLen=r.actualPathLength-(expectedRear+30),newLen=r.actualPathLength;
   // Each projected centreline endpoint must be about 30 mm from the original stock ends.
   assert(Math.abs(startDistance-2*r.curveRadius*Math.sin(expectedRear/(2*r.curveRadius)))<eps,[type,card.id,r.id,startDistance]);
   assert(Math.abs(endDistance-2*r.curveRadius*Math.sin(30/(2*r.curveRadius)))<eps,[type,card.id,r.id,endDistance]);
   assert(newLen>oldLen+29.99);
  }
  result.tests+=3;
 }
 const views=d.orthographicViews;
 const topEntities=d.entities.filter(e=>e.viewType==='TOP');
 const topBounds=c.PulumurGeometry.bounds(topEntities,d.blocks);
 const rearBounds=views.filter(v=>v.kind==='REAR').reduce((acc,v)=>({minX:Math.min(acc.minX,v.bounds.minX),maxX:Math.max(acc.maxX,v.bounds.maxX),minY:Math.min(acc.minY,v.bounds.minY),maxY:Math.max(acc.maxY,v.bounds.maxY)}),{minX:Infinity,maxX:-Infinity,minY:Infinity,maxY:-Infinity});
 const moduleCenter=(Math.min(...d.input.systems.map(s=>s.outerStartX))+Math.max(...d.input.systems.map(s=>s.outerEndX)))/2;
 assert(rearBounds.minY>=topBounds.maxY+999.999,`rear group overlaps top ${type} ${card.id}`);
 assert(Math.abs((rearBounds.minX+rearBounds.maxX)/2-moduleCenter)<.02,`rear group not symmetric to module span ${type} ${card.id}`);
 result.tests+=2;
 for(const s of m.assembly.systems){
  assert(views.some(v=>v.kind==='SIDE'&&v.systemIndex===s.index&&v.side==='right'),type+card.id+' missing right');
  assert(views.some(v=>v.kind==='REAR'&&v.systemIndex===s.index),type+card.id+' missing rear');
  assert(d.entities.some(e=>e.viewType==='REAR'&&e.systemIndex===s.index&&e.type==='polyline'),type+card.id+' missing rear geometry');result.tests+=3;
 }
 if(type!=='Curve-Quad'){
  const firstSides=views.filter(v=>v.kind==='SIDE');
  for(const s of firstSides){
   const relevant=d.entities.filter(e=>e.viewType==='SIDE'&&e.systemIndex===s.systemIndex&&e.name);
   const ws=relevant.filter(e=>e.name==='PergoRise Ray Duvar Bağlantı Set'),ms=relevant.filter(e=>e.name==='PergoRise Ray Arka Mekanizma Yan Görünüş');
   for(const wing of ['main','opposite']){
    const wall=ws.find(e=>(e.wing||'main')===wing),mech=ms.find(e=>(e.wing||'main')===wing);
    if(!wall||!mech)continue;
    const h1=hole(wall,d.blocks[wall.name]),h2=hole(mech,d.blocks[mech.name]);
    assert(norm(h1,h2)<.01,`lower hole not aligned ${type} ${card.id} ${s.id} ${wing}: ${norm(h1,h2)}`);result.tests++;
   }
  }
 }
 result.cases.push({type,layout:card.id,rails:rails.length,views:views.length,entities:d.entities.length});
}
// Same 2D/3D deletion state. Turning off the only rear steel grid cell must
// remove beam/post entities and editable steel pieces from both projections.
for(const enabled of [true,false]){
 let raw={...c.PulumurGeometry.SAMPLE_INPUT,__rearSupport:{type:'steel'},__topBackWallGridState:{'0':{cells:[{id:'steel-0',enabled,minX:0,maxX:4000,startNearDepth:0,endNearDepth:0,startFarDepth:160,endFarDepth:160}]}}};
 let d=c.PulumurGeometry.buildDrawing(raw),m=c.PLMRJustPergola.fromDrawing(d,'white',raw);
 const nd=d.nativeEntities.filter(e=>['rearSteelBeam','rearSteelPost'].includes(e.semantic)).length;
 const steels=m.components.filter(e=>['rear-steel-beam','rear-steel-post'].includes(e.kind));
 const obj=steels.length;
 if(enabled)for(const steel of steels){
  const sys=d.input.systems[steel.systemIndex],axis=steel.kind==='rear-steel-beam'?(steel.start[0]+steel.end[0])/2:steel.start[0];
  const localX=axis+m.assembly.origin.sourceX-sys.outerStartX;
  assert(localX>=-.01&&localX<=sys.outerEndX-sys.outerStartX+.01,'3D selection does not map to native steel grid');
  result.tests++;
 }
 console.log('steel '+enabled+' native '+nd+' model '+obj);
 assert.equal(nd>0,enabled);assert.equal(obj>0,enabled);result.tests+=2;
}
// Native dimension IDs are nonenumerable. The projected view must not lose
// their hidden flags or convert them into visible duplicate dimensions.
{
 const raw={...c.PulumurGeometry.SAMPLE_INPUT};const d=c.PulumurGeometry.buildDrawing(raw);
 const e=d.nativeEntities.find(e=>e.type==='dimension'&&e.dimensionId);
 assert(e,'missing native dimension id');
 const hiddenRaw={...raw,__hiddenDimensionIds:[e.dimensionId],__dimensionVisibility:{},__pergola:{series:'Avila',railType:'Linear',pergolaType:'Lean'}};
 const hidden=c.PulumurGeometry.buildDrawing(hiddenRaw);
 const matches=hidden.entities.filter(x=>x.type==='dimension'&&(x.dimensionId||x.edit?.dimId)===e.dimensionId);
 assert(matches.length>0,'hidden ID dropped by projection');
 assert(matches.every(x=>x.hiddenDimension===true),'hidden dimension reappeared');
 result.tests+=matches.length;
}
fs.writeFileSync(process.env.PLMR_TEST_OUTPUT+'/v12-acceptance.json',JSON.stringify({status:'PASS',...result},null,2));
console.log('PASS V12 acceptances',result.cases.length,'cases',result.tests,'assertions');
