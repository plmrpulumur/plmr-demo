from pathlib import Path
import json,math,sys,ezdxf
folder=Path(sys.argv[1]);results=[]
for name in ['line-horizontal','line-diagonal','wrong-measured-coordinate','foreign-projection']:
 doc=ezdxf.readfile(folder/(name+'.dxf'));assert not doc.audit().errors
 dimension=doc.modelspace().query('DIMENSION')[0];assert dimension.dimtype==0
 if name=='line-diagonal':assert abs(dimension.get_measurement()-math.sqrt(20000))<1e-6
 results.append({'case':name,'auditErrors':0,'dimensionType':'rotated linear','value':dimension.get_measurement()})
report={'status':'PASS','scope':'Independent ezdxf parsing; diagonal uses preserved fixed-angle linear dimension; native aligned/angular CAD acceptance remains open','results':results}
(folder/'v15-dxf-edge-parser.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS four independent DXF edge parsers')
