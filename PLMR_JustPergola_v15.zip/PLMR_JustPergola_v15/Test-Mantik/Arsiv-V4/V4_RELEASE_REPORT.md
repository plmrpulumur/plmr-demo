# V4 değişiklik raporu
Ayar/form/antet görünümünün ayrışması, eski modal CSS ve ayrı native belge tablolarından kaynaklanıyordu. Tek ortak dialog stylesheet ve özgün V34 antetiyle giderildi; hesap hücreleri korunur.
3D'de tek montaj seçimi, native fiziksel parçaları taşıyan mesh kimliklerinin seçim aracına bağlanmamasından kaynaklanıyordu. Parça kimliği ve native komut yönlendirmesi eklendi; bütün pergola taşıma/kopyalama araçları korunur.
Kumaşın ters hareketi ve tek düzlem ölçeklemesi özgün Antero yerleşimiyle değiştirildi. Ray uçları, travers, aldoks ve oluk parçaları aynı 2D kaynağından türetilir.
Ölçü filtresinde poz anahtarı ve ölçülerin poz sahipliği ortaklaştırıldı. Eski ürün formları/çizicileri ve antet çizicileri kaynaktan kaldırıldı.
Doğrulanan kapsam ve bağımsız çıktı kontrolü: Test-Mantik/KABUL.md.
