/* CPU/model matrix; source-derived values, separate from real browser evidence. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||'.'),runtime=path.join(root,'Uygulama');
const context=vm.createContext({console});context.window=context;context.parent=context;
for(const f of ['core/productPresentation.js','src/appLimits.js','ui/inputLimitPolicy.js','core/multiPositionRules.js','blocks/filteredBlocks.js','src/peri01ExcelBridge.js','src/peri01Geometry.js','core/projectModel.js','shared/ral-colors.js','shared/v34/v15-core.js','shared/technical2d-export.js','shared/final-project-date.js','shared/v53-titleblock.js','source/pergola-document.js','modules/p3dv/products/pergo-rise/pergo-rise-derived-geometry.js','source/pergola-parts.js','source/pergola-model.js','src/modernDxfTemplate.js','src/dxfModernEngine.js'])vm.runInContext(fs.readFileSync(path.join(runtime,f),'utf8'),context,{filename:f});
const fixtures=[{name:'single',width:'4000'},{name:'shallow',width:'3500',opening:'2500'},
{name:'deep',width:'6000',opening:'6500',rearHeight:'4200'},
{name:'at10500',width:'10500',postCount:'5'},{name:'over10500',width:'10501',postCount:'5'},
{name:'12000',width:'12000',systemCount:'2',postCount:'5'},
{name:'21000',width:'21000',systemCount:'3',postCount:'7'},
{name:'twoEqual',systemCount:'2',width:'8000'},
{name:'variable',systemCount:'2',width:'4000;4500',opening:'4500;5200',rearHeight:'3200;3400'},
{name:'independent',systemCount:'2',width:'4000;500;4000;NO',opening:'4500;4500',rearHeight:'3200;3200'},
{name:'threeEqual',systemCount:'3',width:'15000',postCount:'7'},
{name:'parapet',width:'6400',parapet:'EVET',parapetHeight:'450'}];
const results=[];
for(const fixture of fixtures){context.cfg={...fixture};const result=vm.runInContext(`(()=>{const raw={...PulumurGeometry.SAMPLE_INPUT,systemCount:'1',opening:'4500',rearHeight:'3200',frontHeight:'2600',rayCount:'3',postCount:'',glassTrack:'EVET',triangleJoinery:'EVET',...cfg};const drawing=PulumurGeometry.buildDrawing(raw);const m=PLMRJustPergola.fromDrawing(drawing,'white',raw);return{raw,drawing,m};})()`,context),{drawing,m,raw}=result;
function finite(value,where){if(typeof value==='number')assert(Number.isFinite(value),where);else if(value&&typeof value==='object')for(const[k,v]of Object.entries(value))finite(v,where+'.'+k);}
finite(m.components,fixture.name);finite(drawing.entities,fixture.name);assert(m.components.length>10);assert(!m.components.some(c=>['rear-profile','front-profile','fabric-stack','area-product'].includes(c.kind)));
for(const rail of m.components.filter(c=>c.kind==='rail')){const sys=drawing.input.systems[rail.systemIndex],p=drawing.input.positions[rail.systemIndex];context.args={d:drawing.input,sys,p};const r=vm.runInContext('PulumurGeometry.physicalRay(args.d,args.sys,args.p)',context);const s=m.assembly.systems[rail.systemIndex];assert(Math.abs(rail.start[1]-r.startY)<1e-7);assert(Math.abs(rail.end[2]-(r.endZ+s.rearDatumZ))<1e-7);assert.equal(rail.section[1],131);}
for(const register of m.components.filter(c=>c.kind==='roof-register-profile')){assert.equal(register.section[0],130);assert.equal(register.section[1],30);assert(Math.abs(register.start[1]+65-register.rayAlignment.leftY)<1e-7);}
for(const tri of m.components.filter(c=>c.kind==='triangle-frame')){assert.equal(tri.depth,55);assert.equal(tri.clearance,5);assert(Math.abs(Math.abs(tri.x-tri.railEdge)-32.5)<1e-7);}
const gutters=m.components.filter(c=>c.kind==='gutter');for(const gutter of gutters.filter(c=>c.jointAfter))assert(drawing.input.postCenterXs.some(x=>Math.abs(x-m.assembly.origin.sourceX-gutter.end[0])<1e-7));
const dimensionParts=drawing.entities.filter(e=>e.edit?.dimId?.startsWith('gutter_length_'));assert(dimensionParts.length>=gutters.length);for(const gutter of gutters)assert(dimensionParts.some(e=>Math.abs(e.measuredValue-gutter.length)<1e-7));
for(const mode of [{mm:true,inch:false},{mm:false,inch:true},{mm:true,inch:true}]){context.raw={...raw,__dimensionUnits:mode};const changed=vm.runInContext('PulumurGeometry.buildDrawing(raw)',context);assert.equal(changed.input.width,drawing.input.width);assert.deepEqual(JSON.parse(JSON.stringify(changed.input.postCenterXs)),JSON.parse(JSON.stringify(drawing.input.postCenterXs)));const expected=mode.mm&&mode.inch?'OLCULENDIRME_MM_INCH':mode.mm?'OLCULENDIRME_MM':'OLCULENDIRME_INCH';assert(changed.entities.filter(e=>e.type==='dimension').every(e=>e.layer===expected));}
results.push({name:fixture.name,width:drawing.input.width,systems:m.assembly.systems.length,parts:m.components.length,gutterLengths:gutters.map(c=>c.length),unitInvariance:true});}
// Exact R-outline-only removal: retain every other native mechanical contour and hole.
if(process.argv[3]){const baseline=vm.createContext({});baseline.window=baseline;vm.runInContext(fs.readFileSync(path.join(path.resolve(process.argv[3]),'Development_Protocol/peri01/blocks/filteredBlocks.js'),'utf8'),baseline);const old=baseline.PulumurFilteredBlocks.blocks,now=context.PulumurFilteredBlocks.blocks;
for(const[name,index]of [['PergoRise Oluk Yan Kapak',5],['PergoRise Oluk Yan Görünüş Birleştirilmiş',10]])assert.deepEqual(JSON.parse(JSON.stringify(now[name].entities)),JSON.parse(JSON.stringify(old[name].entities.filter((_,i)=>i!==index))));assert(!now['RISING LOGO']);}
console.log(JSON.stringify({status:'PASS',layer:'CPU/model',results,logo:'R outlines only; all other native cap entities retained'},null,2));
