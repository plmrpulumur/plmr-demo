V4 tarihsel kanıt ve testleri. V5 güncel kabulü değildir. V5 talepleri metadata düzenleyicisi ve rigid araçlar gibi bazı V4 beklentilerini kaldırmıştır.
