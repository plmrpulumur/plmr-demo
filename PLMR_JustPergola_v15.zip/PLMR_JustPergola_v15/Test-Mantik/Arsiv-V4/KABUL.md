# JustPergola 4.0.0 — güncel kabul

09.11.2026. Güncel giriş yalnız bu belgedir. Kapsam: bağımsız pergola V4.

| Son kullanıcı beklentisi / işlem | Güncel kanıt | Durum |
| --- | --- | --- |
| Ayarlar, tüm native dialoglar, proje bilgileri ve Calculator ortak V34 görsel dili | v4-browser.json: form tokens / Calculator / project info; v4-regression.json: repeated cancel | VERIFIED |
| 2D ürün yerleştirme satırları ve eski ürün üreticileri kaldırıldı | v4-browser.json: product tables absent; kaynak kontrolü | VERIFIED |
| Ortak antet ve aynı proje verisi; üç birim katmanı/stili | v4-browser.json: metadata, unit layers, real exports | VERIFIED |
| 3D parça seçimi ve dikme kaydırma | v4-browser.json: physical post / rail selection; v4-regression.json: side track / Aldoks / gutter | VERIFIED |
| Yan kayıt 40×130 uygulaması, Aldoks bölme düzenleme, undo/redo | v4-regression.json | VERIFIED |
| Antero aralıklı kumaş katlanması; Aç geriye, Kapat oluğa | v4-browser.json: fabric animation | VERIFIED |
| Ray uçları 2D/3D ortak; travers 130×30; aldoks 55 ve 5mm net boşluk | v4-model.json: 12 senaryo; v4-browser.json: actual WebGL mesh bounds | VERIFIED |
| Native dış zarfla aksesuarlar, temiz oluk kapağı ve L/U oluk | v4-browser.json: geometry; v4-model.json: yalnız R konturu kaldırımı; gerçek görsel inceleme | VERIFIED |
| Uzun oluk ekleri dikme ekseninde, 2D uzunluk zinciri ile 3D parçalar eşit | v4-browser.json: 12000 örneği; v4-model.json: sınır/uzun/değişken/bağımsız | VERIFIED |
| Ana/ara/toplam/poz ve poz bazlı filtreler iki görünümde aynı | v4-browser.json; v4-regression.json: per-position visibility | VERIFIED |
| Yerleşim kartları şemalı | v4-browser.json: layout thumbnails | VERIFIED |
| Eski V1/V3 ve yeni V4 kayıtlar, kopya snapshot/poz koruma | v4-browser.json: roundtrip; v4-regression.json: legacy imports | VERIFIED |
| Calculator iç aktarım/dış iptal atomik, geçersiz girdi veri değiştirmiyor | v4-regression.json | VERIFIED |
| Gerçek PDF/DXF/DAE indirmesi ve bağımsız format yapısı | v4-browser.json; exports-current.json | VERIFIED |
| Kaynak–runtime–paket bağı ve temiz ZIP açılışı | ACCEPTANCE_SOURCES_SHA256.json; package-check.json | VERIFIED |

14 ana tarayıcı grubu, 10 ek tarayıcı regresyon grubu ve 12 ayrı CPU/model senaryosu vardır. Aynı testin tekrar koşuları yeni kapsam sayılmadı. Ortam: Chromium 151 / ANGLE SwiftShader, gerçek yazılımsal WebGL, file://, 1560×960. Güncel tarayıcı çalıştırmalarında pageerror ve başarısız kaynak yükü yoktur. Ekranlar ve PDF açılarak incelendi; iç test ekran görüntüleri pakete eklenmedi.

## Yeniden çalıştırma

Playwright/Chromium ve Python kurulu ortamda, paket kökünden:

```bash
python3 Development_Protocol/build.py
PLMR_CHROMIUM_CONFIG=/mutlak/yol/chromium.json PLMR_TEST_OUTPUT=/mutlak/yol/sonuc node Test-Mantik/v4-browser.cjs .
PLMR_CHROMIUM_CONFIG=/mutlak/yol/chromium.json PLMR_TEST_OUTPUT=/mutlak/yol/sonuc node Test-Mantik/v4-regression.cjs .
node Test-Mantik/v4-model.cjs . /mutlak/yol/PLMR_JustPergola_v3 > /mutlak/yol/sonuc/v4-model.json
python3 Test-Mantik/exports.py /mutlak/yol/sonuc
PLMR_CHROMIUM_CONFIG=/mutlak/yol/chromium.json node Test-Mantik/package-smoke.cjs .
```

V3 yolu yalnız kapaktaki R konturu dışındaki her native öğenin aynen korunduğunu karşılaştırır; diğer 12 model senaryosu V3 yolu olmadan da çalışır. Chromium JSON örneği: `{"headless":true,"args":["--use-angle=swiftshader","--enable-unsafe-swiftshader"]}`. Gerekirse executablePath ekleyin. CODEX_PRIMARY_RUNTIME_NODE_MODULES yoksa standart playwright paketi kullanılır.

## Sınırlar

Oluk uzunluk eşiğinin dayanağı ve bölünemeyen açıklık sınırı DEVIR_NOTU.md'dedir. Aksesuarlar dış ölçü zarfıdır; ayrıntılı mekanik üretim mesh'i değildir. Harici CAD programında import, donanım GPU performansı veya statik/üretim onayı yapılmadı.
V34 tam uygulama/bulut entegrasyonu, cephe ürünü montajı ve ayrı kopya ölçü formu bu kapsamda yoktur. Önceki raporlar Arsiv-V3 / Arsiv-V2 altında tarihsel kayıttır; mevcut kaynak için güncel kanıt değildir.
