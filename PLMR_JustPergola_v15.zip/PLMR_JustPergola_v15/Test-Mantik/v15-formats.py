"""Independent file readers; no application geometry or renderer imports."""
from pathlib import Path
import json, sys, math, xml.etree.ElementTree as ET
import ezdxf, fitz
from collections import Counter

folder=Path(sys.argv[1]);ns={'c':'http://www.collada.org/2005/11/COLLADASchema'};results=[]
for kind in ['Lean','Lean-Suspend','Lean-Wing','Lean-Quad','Curve','Curve-Suspend','Curve-Wing','Curve-Quad','Curve-Quad-Wing']:
    root=ET.parse(folder/(kind+'.dae')).getroot()
    assert root.find('c:asset/c:unit',ns).attrib['meter']=='0.001'
    ids=[e.attrib['id'] for e in root.iter() if 'id' in e.attrib];assert len(ids)==len(set(ids));idset=set(ids)
    for e in root.iter():
        for key in ['url','source','target']:
            ref=e.attrib.get(key,'')
            if ref.startswith('#'):assert ref[1:] in idset,(kind,ref)
    solids=0;fabrics=0
    for geo in root.findall('c:library_geometries/c:geometry',ns):
        name=geo.attrib.get('name','').lower();mesh=geo.find('c:mesh',ns)
        a=list(map(float,mesh.find('c:source/c:float_array',ns).text.split()));points=[a[i:i+3] for i in range(0,len(a),3)]
        assert all(abs(v)<1e8 for v in a)
        indices=list(map(int,mesh.find('c:triangles/c:p',ns).text.split()));assert max(indices)<len(points)
        closed=any(token in name for token in ['gutter_ray_connection','suspension_stay','_ray_','_ask','_orta_ta','_oluk_','_dIkme_'.lower(),'tasIyIcI'.lower()])
        if 'pvc_kumas' in name:
            fabrics+=1;normal_z=[]
            for i in range(0,len(indices),3):
                p,q,r=[points[j] for j in indices[i:i+3]]
                normal_z.append((q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0]))
            assert max(normal_z)>0 and sum(normal_z)>0,(kind,'cloth oriented area')
            direction=Counter()
            for i in range(0,len(indices),3):
                tri=indices[i:i+3]
                for j in range(3):
                    a,b=tri[j],tri[(j+1)%3];direction[tuple(sorted((a,b)))]+=1 if a<b else -1
            assert all(abs(v)<=1 for v in direction.values()),(kind,'cloth shared edge winding')
        if not closed:continue
        edges=Counter();directions=Counter();volume=0
        for i in range(0,len(indices),3):
            tri=[points[j] for j in indices[i:i+3]];keys=[tuple(round(v*1000) for v in p) for p in tri]
            if len(set(keys))<3:continue
            p,q,r=tri;volume+=(p[0]*(q[1]*r[2]-q[2]*r[1])+p[1]*(q[2]*r[0]-q[0]*r[2])+p[2]*(q[0]*r[1]-q[1]*r[0]))/6
            for j in range(3):
                p,q=keys[j],keys[(j+1)%3];key=tuple(sorted((p,q)));edges[key]+=1;directions[key]+=1 if p<q else -1
        assert all(v==2 for v in edges.values()),(kind,name,'open solid')
        assert all(v==0 for v in directions.values()),(kind,name,'inconsistent faces')
        assert volume>0,(kind,name,'inward solid');solids+=1
    assert fabrics==(1 if kind=='Curve-Quad' else 2 if kind.endswith(('Wing','Quad')) else 1),(kind,fabrics)
    assert solids>5
    doc=ezdxf.readfile(folder/(kind+'.dxf'))
    assert not doc.audit().errors,(kind,'DXF audit')
    assert doc.header['$INSUNITS']==4
    dims=list(doc.modelspace().query('DIMENSION'))
    assert len(dims)>3 and all(d.dxf.text=='<> mm' for d in dims)
    assert all(d.dxf.dimstyle=='PLMR_DIM_MM' for d in dims)
    pdf=fitz.open(folder/(kind+'.pdf'))
    assert pdf.page_count==1
    text=pdf[0].get_text()
    assert kind in text and 'SAĞ YAN GÖRÜNÜŞ' in text and 'ARKA GÖRÜNÜŞ' in text
    for block in pdf[0].get_text('dict')['blocks']:
        for line in block.get('lines',[]):
            for span in line['spans']:
                x0,y0,x1,y1=span['bbox']
                assert x0>=-.5 and y0>=-.5 and x1<=pdf[0].rect.width+.5 and y1<=pdf[0].rect.height+.5,(kind,'PDF text clipped')
    results.append({'type':kind,'closedSolids':solids,'fabrics':fabrics,'nativeDimensions':len(dims),'dxfAuditErrors':0,'pdfPages':pdf.page_count,'pdfTextClipping':False,'uniqueDaeIdsAndReferences':True})
report={'status':'PASS','scope':'Independent ezdxf, PyMuPDF and XML readers; no external CAD or production engineering approval','results':results}
(folder/'v15-formats.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS 9 native DXF/PDF/DAE independent file readers')
