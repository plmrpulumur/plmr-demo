# V5 güncel kabul — 09.11.2026

Tek güncel giriş bu dosyadır. V4/V3/V2 raporları tarihsel arşivdir.
Test edilen kaynak hashleri `ACCEPTANCE_SOURCES_SHA256.json` içindedir.

| Talep / kullanıcı işlemi | Doğrulanan sonuç | Kanıt |
|---|---|---|
| Ayarlar → sayı ve seçenek değiştir | Native auto ray/post; manuel→auto; motor/kumanda/kumaş/LED/su çıkışı | v5-browser.json, v5-boundary.json |
| 2D/3D profil görünümü | Native güçlü palet; yeşil üçgen, farklı profil renkleri | v5-browser.json; PDF görsel incelemesi |
| Kumaş aç/kapat ve ara hareket | Sistem başına tek geniş kumaş; taşıyıcılar altta; native model değişmez | v5-browser.json, v5-model.json |
| Ray ve mekanizma yerleşimi | Gerçek mesh eksenleri paralel, uç düzlemleri temaslı; native prizma boyları | v5-browser.json |
| Trapez/travers/yan kayıt | Rayla aynı eğim; travers 130; native üst planla kayıt/destek konumu aynı | v5-model.json |
| Sağ/sol kayıt ofset ve uzunluk | 2D ve 3D aynı native alan; varsayılan dış yüz ve dikme teması eşit | v5-browser.json |
| Duvar Push/Pull ve yüzey | Native hücre/segment aktarımı; top+75, rear-100, renk, undo/redo; çakışma atomik ret | v5-browser.json, v5-boundary.json |
| Zone Oluştur ve filtre | V34 ad/UID, tavan/cephe/poz/tekil/arama; kayıtla kimlik korunur | v5-browser.json |
| Yerleşim | Yedi kart, ':' ve karma gruplar; otomatik sayılar ve fiziksel oluk zinciri | v5-browser.json, v5-model.json |
| Kaldırılacak araçlar | Rigid dönüş UI/aktif uygulaması ve metadata modalı kaldırılmış | v5-browser.json, source-check.json |
| Çoklu ürün düğmeleri | Düğmeler geri; mevcut cephe seçici açılır, montaj sınırı açık gösterilir | v5-boundary.json |
| Varsayılana Döndür | İlk geçerli çizim; güncel birimleri korur | v5-browser.json |
| Profil düzenleme, Calculator, iptal | Gerçek parça tıklama/komut; nested cancel; tek history işlemi | v5-regression.json, v5-boundary.json |
| Kaydet/aç ve eski kayıt | V5 duvar/ofset/renk/zone; V1/V3 native veri; eski pasif kopyalar korunur | v5-browser.json, v5-regression.json |
| Ölçü birimi ve çıktı | 3D ölçü=2D; mm/inch fiziksel geometriyi değiştirmez; PDF/DXF/DAE yapı kontrolü | v5-model.json, v5-regression.json, exports-current.json |
| Kaynak/paket | 78 JS syntax; 112 runtime kaynak eşleşmesi; CRC/hash ve temiz WebGL açılışı | source-check.json, package-smoke.json, PACKAGE_SHA256.json |

18 ana, 10 regresyon ve 4 sınır **kontrol grubu** geçti; bu sayılar bağımsız bütün ürün senaryolarının toplamı değildir. Ayrıca 14 CPU/model senaryosu geçti. Tekrar koşuları sayıya eklenmedi. Ortam Chromium 151, ANGLE SwiftShader, file://, 1560×960. Temiz paket açılışı 1440×900. Browser console hatası/başarısız kaynak yükü yok.

Başlangıç hataları ve test düzeltmeleri: native commitLegacy history kaydı eksikliği ve parapet sabit erişimi düzeltildi; zone filtre portalı kesilmesi giderildi. Eski testin V3'te olmayan lateralOffset alanı beklentisi, belgeli 0 migration'ı ile güncellendi. Undo/redo sonrası bekleyen görüntü karesi için sabit uyku yerine iki RAF tamamlanması beklenir. RGB gamma dönüşümünde en fazla 1/255 kanal toleransı kullanılır. +100 duvar denemesinin komşu parapete çarpması beklenen ret davranışıdır; boy değişikliği -100 ile ayrıca doğrulandı.

Sınırlar: gerçek cephe montajı bu bağımsız pakette bağlı değildir. Eğik parapetler native 2D editörüyle düzenlenir; ortak dikdörtgen Push/Pull bunlara uygulanmaz. Kaynak incelemesi V49 ray gövdesinin doğrudan boy editörü olmadığını, ray arası ölçü etiketinin editör açtığını gösterir; bu tarihsel tespit güncel UI testi olarak sayılmadı. Donanım GPU, mobil, harici CAD import, üretim uygunluğu ve canlı entegrasyon sınanmadı. İç ekran görüntüleri pakete eklenmedi.
