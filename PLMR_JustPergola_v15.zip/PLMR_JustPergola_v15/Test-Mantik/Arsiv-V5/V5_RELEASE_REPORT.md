# V5 değişiklik raporu

V4'ün native çizim/kayıt/çıktı sahipliği korunarak son talep uygulandı. Güçlü native renkler, tek kumaş ve alttaki taşıyıcılar, ray mekanizma paralelliği, native plan üzerinden yan kayıt/destek hizası, yan ofset ayarları ve donanım/otomatik adet seçenekleri tamamlandı.

Güncel V34 zone kimlik/filtre ve gerçek duvar yüz Push/Pull bileşenleri bağlandı. Yüz değişiklikleri ayrı sahne çizimi olarak kalmaz; native hücre/segmentlere doğrulanarak kaydedilir. History kayıt açığı ve parapet sabit erişimi düzeltildi. ':' yerleşimler ve farklı ön kotlarda oluk ölçü zinciri doğrulandı.

Taşı/Kopyala/Döndür aktif uygulaması ve gereksiz proje bilgi penceresi silindi. Önceki kayıtların pasif konum/kopya bilgileri korunur. Çoklu ürün düğmeleri geri getirildi; gerçek cephe montajı önceki bağımsız paket sınırı içinde hâlâ bağlı değildir.

Ayrıntılı kabul: Test-Mantik/KABUL.md. 32 gerçek tarayıcı kontrol grubu, 14 CPU/model senaryosu; bağımsız PDF/DXF/DAE kontrolü ve temiz çıkarma WebGL açılışı. Testler donanım GPU veya üretim onayı değildir. Kullanılabilir kaynak ve runtime aynı pakettedir; canlıya yükleme yapılmadı.
