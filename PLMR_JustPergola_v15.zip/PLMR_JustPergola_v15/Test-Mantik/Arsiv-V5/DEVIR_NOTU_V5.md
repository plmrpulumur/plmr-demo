# PLMR JustPergola V5 — 5.0.0

09.11.2026. Bağımsız pergola çizim paketi. Güncel kabulün tek girişi `Test-Mantik/KABUL.md`.

## Başlangıç ve çalışma sınırı

Başlangıç: `plmr_justpergola_v4.zip`, SHA256 `323eb3de2ad369a2511527d947c753005c7c77af0b97b1a16f76c21a253bb899`. Özgün paket değiştirilmedi. Güncel uygulama davranış referansı PLMR_FinalProcess_v34'tür. Native hesap temeli V2'de dondurulmuş V49 kökenli PERI01 kaynağıdır; tarihsel karşılaştırma `Test-Mantik/Arsiv-V2/v49-parity.json` içindedir. Yeni bir V49 arşivi incelenmiş gibi bir iddia yoktur.

Bu paket FinalProcess'e veya buluta kurulmadı. Proje bilgilerini değiştiren ek pencere yoktur; mevcut host uygulamasının metadata sözleşmesi korunur.

## Çalıştırma, kaynak ve derleme

ZIP'i tamamen çıkarın ve `Uygulama/index.html` açın. Sunucu/npm kurulumu gerekmez; 3D için WebGL gerekir.

- `Development_Protocol/peri01`: yetkili ProjectModel, native doğrulama, hesap, 2D, komut/history, kayıt ve çıktı.
- `Development_Protocol/source`: pergola arayüzü; native veriden fiziksel 3D projeksiyon, tek kumaş, ortak renkler, zone ve duvar adaptörleri.
- `Development_Protocol/shared`: ortak antet, birim, Antero hareketi ve V34 bileşenleri. `V34_SHARED_ORIGINS.json` başlangıç hashlerini, `V34_ADAPTER_STATUS.json` güncel uyarlamaları ve silinmiş dosyaları gösterir. `V4_SHARED_ORIGINS.json` hâlâ kullanılan ortak antet/tarih/hareket kaynağının köken kaydıdır.
- `Uygulama`: yalnız build çıktısı; elle ayrı düzenlenmez. `SOURCE_SHA256.json` her runtime dosyasını kaynağa bağlar.
- `Test-Mantik/ACCEPTANCE_SOURCES_SHA256.json`: test edilen runtime hashleri. `PACKAGE_SHA256.json` paket dosyalarını kapsar, kendisini dışarıda bırakır.

```bash
python3 Development_Protocol/build.py
python3 Test-Mantik/verify-source.py .
node Test-Mantik/v5-model.cjs .
# Gerçek tarayıcı testleri Playwright ve Chromium gerektirir.
# PLMR_CHROMIUM_CONFIG: executablePath/args içeren JSON; PLMR_TEST_OUTPUT: sonuç klasörü.
node Test-Mantik/v5-browser.cjs .
node Test-Mantik/v5-regression.cjs .
node Test-Mantik/v5-boundary.cjs .
python3 Test-Mantik/exports.py "$PLMR_TEST_OUTPUT"
python3 Development_Protocol/package.py /mutlak/yol/plmr_justpergola_v5.zip
```

## Son geçerli kararlar

2D profil renkleri native canlı palete döndürüldü; üçgenler yeşil, raylar mavi, dikmeler mor, yan kayıt turuncu, travers sarı ve oluk kırmızıdır. 3D varsayılan şematik renkler aynı sağlayıcıdan gelir. Ölçü çizgileri, üç mm/inch katmanı ve ortak antet korunur.

Her sistemde genişlik boyunca tek kumaş vardır; ray araları kumaşı ayırmaz. Kumaş taşıyıcıları kumaşın altındadır. Antero katlanma kuralı korunur: Kapat oluğa uzatır, Tam Aç arkaya toplar; ara hareket kalıcı modeli değiştirmez.

Ön/arka mekanizma kutuları rayın gerçek teğet ve normalini izler; ray uçlarıyla temas eden yüzler aynı düzlemdedir. Trapez sac ray üst düzlemini izler. Yan kayıt ve yan desteklerin konumu native üst görünüş poligonlarından alınır. Sağ/sol kayıt görünürlüğü, içe/dışa ofset ve uzunluk Ayarlar'da düzenlenir. Dış yüzey/dikme teması varsayılan ayarda eşittir; kullanıcı ofseti bilinçli olarak bu hizayı değiştirir.

Otomatik ray ve dikme sayıları native ExcelBridge hesabından gelir. Kullanıcı manuel sayı girerse korunur; alanı temizlemek otomatiği açar. Motor, motora bağlı kumanda, kumaş, LED/dimmer ve standart dışı su çıkış seçenekleri geri bağlandı. Calculator dış ayar taslağına aktarır; dış Uygula tek geri alınabilir işlemdir.

V34 gerçek duvar/parapet yüz seçimi, sayısal ve mouse Push/Pull, komşu çakışma kontrolü ve yüzey materyal seçicisi bağlandı. Dikdörtgen yüz düzenlemeleri native duvar hücreleri/parapet segmentlerine aktarılır; 2D ve kayıt aynı veriyi okur. Uyumsuz 2D sonuç ön kontrolde reddedilir. Üst yüz yüksekliği, alt kot, normal ofset ve kalınlık kayıt alanları normalize edilir. Eğimli yerel parapetler native eğimli şekillerini ve 2D düzenleyicisini korur; ortak dikdörtgen Push/Pull editörü bu şekillere uygulanmaz.

Zone'lar açıkça Zone Oluştur ile üretilir. Güncel V34 benzersiz Poz kodu/UID kaydı, tavan/cephe/poz/tekil filtreleri ve kod araması kullanılır. Yeni kimlikler geometri komutu içinde kaydedilir; render veriyi değiştirmez. Bir kaydın adı yalnız ön/arka/sağ/sol değildir.

Yerleşim kartları: tekli, toplam genişlikten eşit bölme, değişken ölçü listesi, W;G;W;NO aralıklı pozlar, açılım ;NO arka hizası, ':' tam bağımsız gruplar ve grup içinde aralıklı birleşik durum. ':' yalnız genişlik alanında native kurala uygundur. Bağımsız grupta ön kot farklıysa oluk 2D ölçü zinciri de fiziksel 3D bölümlerini izler.

Taşı/Kopyala/Döndür araçları ve aktif komut uygulamaları kaldırıldı; yanlış Bioclimatic ürün HUD'u yoktur. Eski kayıtlardaki konum ve kopya snapshot'ları veri kaybı olmaması için pasif okunur; yeni kopya/rigid dönüş oluşturulmaz. Dikme kaydırma native profil düzenlemesi olarak kalır.

Çoklu Ürün Ekle/Sil yan araç düğmeleri geri getirildi. Önceki aşamadaki bağımsız paket sınırı devam eder: gerçek cephe ürünü montajı bağlı değildir; Ekle mevcut cephe seçim penceresini açık sınırlama mesajı ve pasif Kaydet ile açar. Sil monte ürün bulunmadığını bildirir. Eski 2D ölçü penceresindeki kaldırılmış ürün formları geri getirilmedi.

Proje Bilgileri Düzenle butonu, içeriği ve ayrı modalı silindi. Salt okunur özet ve ortak antet aynı metadata'yı kullanır. Varsayılana Döndür ilk geçerli çizimi geri getirir, güncel metadata ve birimleri korur; tüm projeyi sıfırlama ayrı işlemdir.

V49 sorusunun cevabı: incelenen V49 kökenli native kaynakta üst görünüş ray gövdesi doğrudan boy editörü açmaz; raylar arası ölçü etiketi düzenlenebilir. Rayın eğik boyu açılım ve yükseklik hesabından türetilir.

## Kayıt, kök neden ve doğrulama

Tek kalıcı sahip native ProjectModel'dir. Yeni yan kayıt ofseti eski kayıtlarda 0 olarak tamamlanır. Wall appearance ve zone registry aynı standalone workspace kaydındadır. Veri silen migration/reset uygulanmadı.

Push/Pull kabulünde native commitLegacy'nin sonraki değişiklikleri geçmişe eklemeyebildiği saptandı: restore koruması otomatik kaydı bastırıyordu. Commit sonunda imza tekilleştirmesiyle history kaydı eklendi. Gerçek Ctrl+Z/Ctrl+Y, Calculator, ayarlar ve profil akışlarıyla doğrulandı. Parapet aktarımındaki yanlış sabit erişimi de düzeltildi.

18 ana + 10 regresyon + 4 sınır tarayıcı kontrol grubu; 14 CPU/model senaryosu geçti. Chromium 151 / ANGLE SwiftShader, file://, 1560×960; gerçek WebGL çizimi ve pointer/form/klavye kullanıldı. 78 JS dosyası sözdizimi ve 112 runtime dosyası kaynak eşleşmesi doğrulandı. Gerçek indirilen PDF/DXF/DAE dosyaları bağımsız yapı kontrolünden geçti; PDF görsel olarak da incelendi. Donanım GPU performansı veya harici CAD import/üretim onayı değildir.

V4/V3/V2 kanıtları `Test-Mantik/Arsiv-*` altındadır; güncel kabul sayılmaz. İç tarayıcı ekran görüntüleri, Chromium ve cache teslimde yoktur. Temiz çıkarma ve paket açılış sonucu `Test-Mantik/package-smoke.json` dosyasındadır.

Kapsam içi V5 çizim güncellemesinde açık hata yoktur; sonraki adım kullanıcı incelemesidir. FinalProcess entegrasyonu, gerçek cephe montajı, bulut/teklif/üretim, AR, paylaşım ve 3D PDF servisleri bu bağımsız çalışma aşamasının dışında kalır.
