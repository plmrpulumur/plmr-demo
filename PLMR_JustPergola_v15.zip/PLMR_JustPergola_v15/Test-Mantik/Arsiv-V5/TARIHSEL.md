V5 tarihsel kaynak ve sonuçları. V6 kabulü değildir. V6 güncel giriş Test-Mantik/KABUL.md.
