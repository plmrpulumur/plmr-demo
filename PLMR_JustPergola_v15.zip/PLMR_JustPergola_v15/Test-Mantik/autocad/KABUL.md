# AutoCAD kabulü — ÇALIŞTIRILMADI

Bu ortamda AutoCAD/accoreconsole yoktur. ezdxf dosya açma, tanım noktası değiştirme veya açık bir referans yorumlayıcısının yeniden hesaplaması, AutoCAD STRETCH başarısı değildir.

Temiz kopyada yapılacak zorunlu kontrol:

1. V15'ten `Lean.dxf`, `Curve.dxf`, `Curve-Quad.dxf` üretin. Bir kopyasını ayırın.
2. Dosyayı gerçek AutoCAD'de açın; audit hatalarını ve görünüş/ölçü yerleşimini kaydedin.
3. `DIMASSOC=2` ve `ACAD_DIMASSOC` sözlük/handle bağlarını inceleyin.
4. 4100 mm oluk boyu gibi iki referansı aynı fiziksel profile bağlı ölçüyü seçin. Başlangıç değerini kaydedin.
5. Yalnız kaynak fiziksel geometriyi seçen crossing seçimiyle STRETCH +125 mm uygulayın. DIMENSION, ölçü tanım noktaları ve ölçünün grafik bloğu seçim setine girmesin.
6. Ölçünün otomatik 4225 mm olup olmadığını gözleyin. Gerekli `REGEN`/`DIMREGEN` davranışını ayrıca kaydedin. Değer yanlış parçayı takip ederse FAIL verin.
7. Köşe, profil kenarının iç noktası ve LINE uç referanslarını ayrı deneyin. Sağ/sol ve karşı kanat birbirini yanlış izlememeli.
8. Undo/redo ve kaydet/kapat/yeniden aç sonrasında aynı ölçüyü tekrar deneyin.
9. mm, inch ve çift gösterimde fiziksel modelin mm kaldığını; stil, ok, yazı ve alternatif birim değerini doğrulayın.
10. Bağlantısız 37 ölçü için mevcut teknik datum/native INSERT/ARC ilişkisini belirleyin. Rastgele yakın geometriye bağlamayın. Gerekirse `DIMREASSOCIATE` ile gerçek karşılığını araştırın.
11. Kullanılan hizalı/açısal ölçüler için gerçek CAD tipini ve güncellemeyi ayrıca doğrulayın; mevcut diyagonal doğrusal ölçü testi bunların yerine geçmez.

Kanıt kaydı: AutoCAD sürümü, işletim sistemi, kaynak hashleri, ilk/son DXF/DWG kopyası, tam seçim ve komut sırası, önce/sonra değer, kayıt/aç sonucu, PASS/FAIL ve hata. Henüz hiçbir adım AutoCAD'de çalıştırılmadı.
