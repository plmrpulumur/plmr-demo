# Denetim kapsamı — tam sistem onayı değildir

Kaynakta izlenen yollar: native form/ProjectModel/snapshot/history → geometri → 2D projeksiyon → 3D model → WebGL → DXF/PDF/DAE; ölçü görünürlüğü; çelik hücre sahipliği; V51 host snapshot/ürün seçimi/yerel kayıt/geçmiş/kilit/metadata/çıktı; yayımdaki firma/rol/oturum handler'ı ve RPC geçişi.

Gerçek test edilen yollar ve sayıları `KABUL.md` içindedir. Bir dosyanın hash/sözdizimi kontrolünden geçmesi, bütün işlevlerinin çalıştırıldığı anlamına gelmez. 378 model senaryosu, bütün ana uygulama iş süreçlerinin denetlendiği anlamına gelmez.

Açık / yalnız kısmen incelenmiş kapsam:

- Bütün arayüz düğmeleri ve seçeneklerinin her ürün/rol/firma birleşimi.
- Her geometri elemanının referans DXF ile bağımsız mühendislik ve görünürlük/örtüşme denetimi; geçmiş native referansların korunduğu ve belirli montaj/yerleşim kurallarının geçtiği doğrulandı.
- Gerçek AutoCAD ilişkileri, hizalı/açısal tipler, STRETCH ve kayıt/aç.
- Ana React/Supabase kimlikli proje/poz/revizyon/teklif/üretim akışı; geçmiş onaylı müşteri kayıtları.
- Kopyaların bütün bağımsız düzenleme/taşıma/dönüş ve revizyon kombinasyonları; mevcut üründe kapalı cephe montajı/animasyon paylaşımı/3D PDF.
- Gerçek ağ gecikmesi/yük testi, donanım GPU performansı, MB cinsinden bellek sızıntısı ölçümü ve uzun süreli kullanım.
- Kimlikli PIN/rol/çok firma ve gerçek eşzamanlı kayıt/kullanıcı oluşturma kabulü.

Bu maddeler tamamlanmış veya PASS olarak sınıflandırılmadı. V15, doğrulanan düzeltme ve entegrasyon geliştirmesinin teslimidir; kapsamlı hedefin tamamlandığına ilişkin rapor değildir.
