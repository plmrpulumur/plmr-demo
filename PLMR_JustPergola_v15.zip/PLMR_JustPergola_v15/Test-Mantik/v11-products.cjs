/* Product selection, actual WebGL, native persistence and output acceptance. */
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
const root=path.resolve(process.argv[2]),out=path.resolve(process.env.PLMR_TEST_OUTPUT);fs.mkdirSync(out,{recursive:true});
(async()=>{
 const b=await chromium.launch(JSON.parse(fs.readFileSync(process.env.PLMR_CHROMIUM_CONFIG))),p=await b.newPage({viewport:{width:1560,height:960},acceptDownloads:true}),results=[],errors=[],failed=[];let step='boot';p.setDefaultTimeout(18000);p.on('pageerror',e=>errors.push(e.stack));p.on('requestfailed',r=>failed.push(r.url()));
 const model=()=>p.evaluate(()=>PulumurProjectState.getModel()),state=()=>p.evaluate(()=>PLMRJustPergolaApp.inspect()),settle=()=>p.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 async function download(id,name){const event=p.waitForEvent('download');await p.locator(id).click();await(await event).saveAs(path.join(out,name));}
 async function choose(series,type,layout='single'){
  await p.locator('#rrV14LayoutBtn').click();await p.locator('#pergolaSeries').selectOption(series);await p.locator('#pergolaRailType').selectOption(type.startsWith('Curve')?'Curved':'Linear');
  assert.equal(await p.locator('[data-pergola-type]').count(),type.startsWith('Curve')?5:4);assert.equal(await p.locator('[data-layout]').count(),0);
  await p.locator('[data-pergola-type="'+type+'"]').click();assert.equal(await p.locator('[data-layout]').count(),7);
  const images=await p.locator('[data-pergola-type] img').evaluateAll(ns=>ns.map(n=>({src:n.getAttribute('src'),width:n.naturalWidth,height:n.getBoundingClientRect().height})));
  for(const i of images){assert(i.src.startsWith('source/assets/pergola-types/'));assert.equal(i.width,512);assert(i.height>100);}
  if(type==='Lean-Wing'&&series==='Avila')await p.screenshot({path:path.join(out,'picker.png')});
  await p.locator('[data-layout="'+layout+'"]').click();await p.locator('#pergolaSettingsApply').click();await p.waitForFunction(()=>!document.getElementById('rrV45SettingsModal'));await settle();
  const s=await state();assert(s.webgl&&s.renderCalls>0);assert.equal(s.configuration.derivedModelName,series+' '+type);assert.equal(s.configuration.layoutPlanId,layout);assert.equal((await model()).schemaVersion,3);
  assert.equal(s.fabric.length,(await p.evaluate(()=>PLMRPergolaNative.drawing().input.systemCount))*(type==='Curve-Quad'?1:s.configuration.double?2:1));assert(s.fabric.every(f=>f.continuous));
  for(const c of s.parts){if(c.start)assert(c.start.every(Number.isFinite),c.id);if(c.bounds)assert(c.bounds.min.concat(c.bounds.max).every(Number.isFinite),c.id);}
  assert.equal(new Set(s.parts.map(c=>c.id)).size,s.parts.length,'unique physical component ids');
  assert(s.meshRecords.filter(m=>m.kind==='fabric'&&m.parameters.height===1).every(m=>m.normal[1]>0),'cloth faces upward on both wings');
  if(['Lean-Wing','Curve-Wing'].includes(type)){assert(s.parts.some(c=>c.kind==='central-mast'));assert(!s.parts.some(c=>c.kind==='post'));}
  if(type.endsWith('Suspend'))assert(!s.parts.some(c=>c.kind==='post'));
  if(type.startsWith('Curve'))assert(s.parts.filter(c=>c.kind==='rail').every(c=>c.trajectory.points.length>100));
  await p.locator('#rrV45Mode2DBtn').click();assert(await p.locator('#preview svg').count());assert(await p.evaluate(()=>PLMRPergolaNative.drawing().entities.length>20));await p.locator('#rrV45Mode3DBtn').click();await settle();
  results.push({series,type,layout,parts:s.parts.length,fabrics:s.fabric.length,status:'PASS'});console.log('PASS',series,type,layout);
 }
 try{
  await p.goto('file://'+path.join(root,'Uygulama/index.html'));assert.equal(await p.title(),'PLMR | JustPergola V11');
  const empty=await model();await p.locator('#rrV14LayoutBtn').click();await p.locator('#pergolaRailType').selectOption('Curved');await p.locator('[data-pergola-type=Curve-Wing]').click();await p.locator('#rrV14LayoutDialog header button').click();assert.deepEqual(await model(),empty);
  for(const series of ['Andes','Avila'])for(const type of ['Lean','Lean-Suspend','Lean-Wing','Lean-Quad','Curve','Curve-Suspend','Curve-Wing','Curve-Quad','Curve-Quad-Wing']){
   step=series+' '+type;await choose(series,type);
   if(series==='Avila'){
    await download('#rrV15ProjectDownload',type+'.plmr');const before=await model(),saved=JSON.parse(fs.readFileSync(path.join(out,type+'.plmr')));assert.equal(saved.schemaVersion,3);assert.deepEqual(saved.projectModel.pergola,before.pergola);
    await p.locator('#rrV45Mode2DBtn').click();await download('#rrV45DxfBtn',type+'.dxf');await download('#rrV45Pdf2dBtn',type+'.pdf');await p.locator('#rrV45Mode3DBtn').click();await download('#rrV45DaeBtn',type+'.dae');assert.deepEqual(await model(),before,'exports are read only');
    await p.locator('#projectImportInput').setInputFiles(path.join(out,type+'.plmr'));await settle();assert.deepEqual((await model()).pergola,before.pergola);assert.equal((await state()).configuration.pergolaType,type);
    await p.screenshot({path:path.join(out,type+'.png')});
   }
  }
  for(const type of ['Curve-Wing','Curve-Quad-Wing'])for(const layout of ['equal','variable','independent','rear-aligned','colon','colon-mixed']){step=type+' '+layout;await choose('Avila',type,layout);if(type==='Curve-Quad-Wing'){await p.locator('#rrV45Mode2DBtn').click();await download('#rrV45DxfBtn','multi-'+layout+'.dxf');await download('#rrV45Pdf2dBtn','multi-'+layout+'.pdf');await p.screenshot({path:path.join(out,'multi-'+layout+'.png')});await p.locator('#rrV45Mode3DBtn').click();}}
  step='cancel draft';const intact=await model();await p.locator('#rrV14LayoutBtn').click();await p.locator('#pergolaRailType').selectOption('Linear');await p.locator('[data-pergola-type=Lean]').click();await p.locator('[data-layout=single]').click();await p.locator('#pergolaSettingsCancel').click();assert.deepEqual(await model(),intact);
  step='history';await choose('Andes','Lean-Suspend');await p.locator('#model3d canvas').first().focus();await p.keyboard.press('Control+z');await settle();assert.equal((await model()).pergola.pergolaType,'Curve-Quad-Wing');await p.keyboard.press('Control+y');await settle();assert.equal((await model()).pergola.derivedModelName,'Andes Lean-Suspend');
  step='zones';await p.locator('#projectImportInput').setInputFiles(path.join(out,'Lean-Wing.plmr'));await settle();await p.locator('#rrV13GenerateZones').click();await settle();let s=await state();assert(s.zones.some(z=>!z.isRoofZone&&z.face==='back'));assert.equal(new Set(s.zones.map(z=>z.uid)).size,s.zones.length);assert.equal(new Set(s.zones.map(z=>z.label)).size,s.zones.length);
  step='rebuild lifecycle';const samples=[];for(let i=0;i<7;i++){await p.locator('[data-legacy-id=toolbarRefreshBtn]').click();await settle();samples.push((await state()).memory);}for(const m of samples.slice(2))assert.deepEqual(m,samples[2]);
  assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);fs.writeFileSync(path.join(out,'v11-products.json'),JSON.stringify({status:'PASS',cases:results.length,results,cancelAtomic:true,nativeSaveReopenTypes:9,outputTypes:9,history:true,wingCentralZones:true,rebuildSamples:samples,errors,failed},null,2));
 }catch(e){await p.screenshot({path:path.join(out,'failure.png')}).catch(()=>{});fs.writeFileSync(path.join(out,'failure.json'),JSON.stringify({step,error:e.stack,results,errors,failed},null,2));throw e;}finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
