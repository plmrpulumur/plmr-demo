/* Same JS native drawing and DXF serializer as application download, no browser. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||'.');const prefix=fs.readFileSync(root+'/Test-Mantik/v11-model-matrix.cjs','utf8').split('const types=')[0];
const c=Function('require','process',prefix+'return c;')(require,process);
for(const f of ['src/modernDxfTemplate.js','src/dxfModernEngine.js'])vm.runInContext(fs.readFileSync(path.join(root,'Uygulama',f),'utf8'),c,{filename:f});
const out=process.env.PLMR_TEST_OUTPUT;
const testResults=[];
for(const type of ['Lean','Lean-Suspend','Curve','Curve-Quad','Curve-Quad-Wing']){
 const raw={...c.PulumurGeometry.SAMPLE_INPUT,__pergola:{series:'Avila',railType:type.startsWith('Curve')?'Curved':'Linear',pergolaType:type,layoutPlanId:'single'}};
 const drawing=c.PulumurGeometry.buildDrawing(raw);
 const text=c.PulumurModernDXF.toDxf(c.PulumurTechnical2DExport.cadDrawing(drawing));
 assert(text.length>100000,'DXF empty');
 const file=path.join(out,type+'.dxf');fs.writeFileSync(file,text);
 testResults.push({type,characters:text.length,views:drawing.orthographicViews.map(v=>v.kind+'/'+(v.side||'')),entities:drawing.entities.length});
}
fs.writeFileSync(path.join(out,'v12-dxf-exports.json'),JSON.stringify({status:'PASS',scope:'Native CAD output engine executed in VM; file format checked independently',testResults},null,2));
console.log('PASS',testResults.length,'native DXF serializers');
