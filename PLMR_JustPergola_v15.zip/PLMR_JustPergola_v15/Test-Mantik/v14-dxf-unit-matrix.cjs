/* V14 native DXF path, all 9 pergola product families x 3 display modes. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||'.');
const prefix=fs.readFileSync(root+'/Test-Mantik/v11-model-matrix.cjs','utf8').split('const types=')[0];
const c=Function('require','process',prefix+'return c;')(require,process);
for(const f of ['src/modernDxfTemplate.js','src/dxfModernEngine.js'])vm.runInContext(fs.readFileSync(path.join(root,'Uygulama',f),'utf8'),c,{filename:f});
const products=['Lean','Lean-Suspend','Lean-Wing','Lean-Quad','Curve','Curve-Suspend','Curve-Wing','Curve-Quad','Curve-Quad-Wing'];
const modes=[{mm:true,inch:false},{mm:false,inch:true},{mm:true,inch:true}];
const result=[];
for(const product of products)for(const units of modes){
 const raw={...c.PulumurGeometry.SAMPLE_INPUT,__dimensionUnits:units,__pergola:{series:'Avila',railType:product.startsWith('Curve')?'Curved':'Linear',pergolaType:product,layoutPlanId:'single'}};
 const drawing=c.PulumurGeometry.buildDrawing(raw);
 const dims=drawing.entities.filter(e=>e.type==='dimension'&&!e.hiddenDimension);
 const dynamic=units.inch&&!units.mm?'<>"':'<> mm';
 assert(dims.length>0,'missing native dimensions');
 assert(dims.every(e=>e.textOverride===dynamic),'native dimension text override is not dynamic '+product+JSON.stringify(units));
 assert(dims.every(e=>/\d/.test(e.previewText)), 'preview should still show measured snapshot');
 const output=c.PulumurModernDXF.toDxf(c.PulumurTechnical2DExport.cadDrawing(drawing));
 assert(output.includes('AcDbDimension'),'not a native DIMENSION');
 assert(output.includes(`1\r\n${dynamic}\r\n`),'dynamic CAD text missing');
 // Anonymous *D blocks retain cached display MTEXT until CAD regeneration;
 // only the parent DIMENSION code 1 is allowed to control measurements.
 result.push({product,units,dimensions:dims.length,size:output.length});
}
const dst=path.join(process.env.PLMR_TEST_OUTPUT||path.join(root,'Test-Mantik','v14-output'),'v14-dxf-unit-matrix.json');
fs.writeFileSync(dst,JSON.stringify({status:'PASS',cases:result.length,results:result},null,2)+'\n');
console.log('PASS V14 dynamic dimensions for',result.length,'product x unit-mode cases');
