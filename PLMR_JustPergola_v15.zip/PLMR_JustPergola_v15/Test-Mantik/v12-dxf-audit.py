"""Independent ezdxf 1.4+ check of actual JS-exported files, not browser/AutoCAD."""
import json,sys
from pathlib import Path
import ezdxf
folder=Path(sys.argv[1]);results=[]
for name in ('Lean','Lean-Suspend','Curve','Curve-Quad','Curve-Quad-Wing'):
 file=folder/(name+'.dxf');assert file.is_file(),file
 d=ezdxf.readfile(file);m=d.modelspace()
 assert d.header['$INSUNITS']==4,(name,'not mm')
 title=[e.text for e in m.query('MTEXT')]
 assert any('ARKA GÖRÜNÜŞ' in t for t in title),(name,'no rear elevation')
 assert any('SAĞ YAN GÖRÜNÜŞ' in t for t in title),(name,'no right elevation')
 assert any('SOL YAN GÖRÜNÜŞ' in t for t in title),(name,'no left elevation')
 assert len(m.query('DIMENSION'))>2,(name,'no dimensions')
 if name.startswith('Curve'):assert len(m.query('ARC'))>=4,(name,'missing CAD arcs')
 inserts=[e.dxf.name for e in m.query('INSERT')]
 assert 'PLMR - LOGO' in inserts,(name,'logo')
 assert not (name=='Curve-Quad' and any('Ray Arka Mekanizma Yan Görünüş'==x for x in inserts))
 results.append({'type':name,'entities':len(m),'arcs':len(m.query('ARC')),'dimensions':len(m.query('DIMENSION')),'inserts':len(inserts),'rearAndBothSides':True,'insunits':'mm'})
 report={'status':'PASS','scope':'ezdxf structure, units, CAD arcs, rear/right/left titles; not AutoCAD or rendered UI','results':results}
 (folder/'v12-dxf-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print('PASS',len(results),'independently parsed DXFs')
