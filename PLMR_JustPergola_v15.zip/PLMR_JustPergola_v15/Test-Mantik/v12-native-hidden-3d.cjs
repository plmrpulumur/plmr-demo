/* Source-based 2D -> 3D dimension visibility contract; not a WebGL test. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const rootPath=path.resolve(process.argv[2]||'.');
const src=fs.readFileSync(path.join(rootPath,'Test-Mantik/v11-model-matrix.cjs'),'utf8').split('const types=')[0];
const c=Function('require','process',src+'return c;')(require,process);
const viewer=fs.readFileSync(path.join(rootPath,'Uygulama/source/pergola-viewer.js'),'utf8');
const begin=viewer.indexOf('    function pergolaMeasurements(){'),end=viewer.indexOf('    const environment=',begin);
assert(begin>0&&end>begin,'V12 3D dimension source not found');
const method=viewer.slice(begin,end);
let count=0;
for(const type of ['Lean','Curve','Lean-Quad']){
  const raw={...c.PulumurGeometry.SAMPLE_INPUT,__pergola:{series:'Avila',railType:type==='Curve'?'Curved':'Linear',pergolaType:type,layoutPlanId:'single'}};
  const build=hidden=>{
    const input={...raw,__hiddenDimensionIds:hidden};
    const d=c.PulumurGeometry.buildDrawing(input),m=c.PLMRJustPergola.fromDrawing(d,'white',input),sys=m.assembly.systems;
    const height=Math.max(...sys.map(s=>s.rearHeight)),minZ=Math.min(...sys.map(s=>s.backExtentZ??s.rearDatumZ)),maxZ=Math.max(...sys.map(s=>s.frontDatumZ));
    const owners=[{id:'roof-main',sourceModel:m,height,sourceCenterZ:(minZ+maxZ)/2}];
    const inspect=Function('owners',method+'return pergolaMeasurements();')(owners);
    return {d,m,inspect};
  };
  const normal=build([]),target=normal.d.entities.find(e=>e.type==='dimension'&&e.edit?.dimId?.startsWith('gutter_length_'));
  assert(target,'Native gutter dimension missing '+type);
  assert(normal.inspect.some(m=>m.id==='roof-main|'+target.edit.dimId),'Gutter not projected to 3D '+type);
  const hidden=build([target.edit.dimId]);
  assert(hidden.d.entities.some(e=>e.edit?.dimId===target.edit.dimId&&e.hiddenDimension),'Native hidden flag missing '+type);
  assert(!hidden.inspect.some(m=>m.id==='roof-main|'+target.edit.dimId),'Hidden 2D gutter reappeared in 3D '+type);
  assert(!c.PLMRPergolaDimensions.measurements(hidden.d).some(e=>e.id==='roof-main|'+target.edit.dimId),'3D menu lists a hidden native measurement '+type);
  const restored=build([]);assert(restored.inspect.some(m=>m.id==='roof-main|'+target.edit.dimId),'Restored native 3D dimension not visible '+type);
  count+=5;
  if(type==='Lean'||type==='Curve'){
    // Explicit 3-ray fixture exercises the separate top spacing dimension ID.
    raw.rayCount='3';
    const spaced=build([]),spacing=spaced.d.entities.find(e=>e.type==='dimension'&&e.edit?.dimId?.startsWith('top_ray_spacing_'));
    assert(spacing,'Native top ray spacing absent '+type);
    assert(spaced.inspect.some(m=>m.id==='roof-main|'+spacing.edit.dimId),'3D top spacing absent '+type);
    const concealed=build([spacing.edit.dimId]);
    assert(concealed.d.entities.some(e=>e.edit?.dimId===spacing.edit.dimId&&e.hiddenDimension),'2D top spacing remains visible '+type);
    assert(!concealed.inspect.some(m=>m.id==='roof-main|'+spacing.edit.dimId),'Hidden 2D top spacing reappeared in 3D '+type);
    count+=3;
  }
}
console.log('PASS V12 native 2D/3D measure synchronization '+count+' checks (source/model, not WebGL)');
