"""Source/build/model/CAD checks. Browser commands are documented in KABUL.md."""
from pathlib import Path
import argparse,os,subprocess,sys
root=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');p.add_argument('--out',type=Path,default=root/'Test-Mantik/v15-output');p.add_argument('--baseline',type=Path);args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
env={**os.environ,'PLMR_TEST_OUTPUT':str(args.out.resolve())}
def run(command,extra=None):subprocess.run(command,cwd=root,env={**env,**(extra or {})},check=True)
run([sys.executable,'Development_Protocol/build.py'])
run([sys.executable,'Test-Mantik/verify-source.py',str(root)])
for name in ['v12-acceptance.cjs','v12-ui-steel-controller.cjs','v12-dxf-exports.cjs','v14-dxf-unit-matrix.cjs','v15-dxf-edge-cases.cjs','v15-visibility.cjs','v11-multiple-views.cjs']:
 run(['node','Test-Mantik/'+name,str(root)])
run([sys.executable,'Test-Mantik/v15-dxf-audit.py',str(args.out)])
run([sys.executable,'Test-Mantik/v15-dxf-edge-parser.py',str(args.out)])
if args.baseline:run(['node','Test-Mantik/v15-native-parity.cjs',str(root),str(args.baseline.resolve())])
if args.full:
 for extra in [{},{'PLMR_TEST_STEEL':'1'},{'PLMR_TEST_GLAZING':'1'}]:run(['node','Test-Mantik/v12-model-matrix.cjs',str(root)],extra)
print('PASS requested source/model/CAD checks; browser, native AutoCAD and authenticated main save are separate acceptances.')
