"""Read-only syntax and source/runtime provenance validation."""
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
source=root/'Development_Protocol'
runtime=root/'Uygulama'
manifest=json.loads((runtime/'SOURCE_SHA256.json').read_text())
for name,digest in manifest.items():
    output=runtime/name
    original=source/('source/index.html' if name=='index.html' else name if name.startswith(('source/','shared/')) else 'peri01/'+name)
    assert hashlib.sha256(output.read_bytes()).hexdigest()==digest,name
    assert output.read_bytes()==original.read_bytes(),name
scripts=list(runtime.rglob('*.js'))
for file in scripts:
    subprocess.run(['node','--check',str(file)],check=True,capture_output=True)
for name,status in json.loads((source/'V34_ADAPTER_STATUS.json').read_text()).items():
    file=source/'shared/v34'/name
    assert file.exists()!=status['removed'],name
    if file.exists():assert hashlib.sha256(file.read_bytes()).hexdigest()==status['currentSha256'],name
overrides=json.loads((source/'V15_CHANGED_SOURCES.json').read_text())
for name,item in json.loads((source/'V12_CHANGED_SOURCES.json').read_text()).items():
    if name in overrides or name in json.loads((source/'V14_CHANGED_SOURCES.json').read_text()): continue
    if item['status']=='removed':assert not (source/name).exists(),name
    else:assert hashlib.sha256((source/name).read_bytes()).hexdigest()==item['currentSha256'],name
for name,item in json.loads((source/'V14_CHANGED_SOURCES.json').read_text()).items():
    if name in overrides: continue
    assert hashlib.sha256((source/name).read_bytes()).hexdigest()==item['currentSha256'],name
for name,item in overrides.items():
    assert hashlib.sha256((source/name).read_bytes()).hexdigest()==item['currentSha256'],name
html=(source/'source/index.html').read_text()
assert 'JustPergola V15' in html
assert "15.0.0" in (source/'peri01/src/app.js').read_text()

for name in ['rrV45MoveToolBtn','rrV45CopyToolBtn','rrV45Rotate90Btn','rrV45RotateAngleBtn','shellMetadata','editProjectInfoBtn','pergolaMetadata']:
    assert 'id="'+name+'"' not in html,name
print(json.dumps({'status':'PASS','jsSyntaxFiles':len(scripts),'runtimeFiles':len(manifest),'sourceRuntimeByteAgreement':True,'providerHashesVerified':True,'removedControlsVerified':True},indent=2))
