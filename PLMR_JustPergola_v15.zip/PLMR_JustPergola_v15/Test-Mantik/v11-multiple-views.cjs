/* Multiple/stepped modules: side dimension ownership and circle radii, without rendering mocks. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');const root=path.resolve(process.argv[2]),prefix=fs.readFileSync(root+'/Test-Mantik/v11-model-matrix.cjs','utf8').split('const types=')[0],c=Function('require','process',prefix+'return c;')(require,process),results=[];
for(const type of ['Lean-Quad','Lean-Suspend','Lean-Wing','Curve','Curve-Suspend','Curve-Quad','Curve-Wing','Curve-Quad-Wing'])for(const card of c.PLMRPergolaLayouts.cards){
 const raw={...c.PulumurGeometry.SAMPLE_INPUT,...card.values,rayCount:'',postCount:'',glassTrack:'HAYIR',triangleJoinery:'HAYIR',__pergola:{series:'Avila',railType:type.startsWith('Curve')?'Curved':'Linear',pergolaType:type,layoutPlanId:card.id}},d=c.PulumurGeometry.buildDrawing(raw),m=c.PLMRJustPergola.fromDrawing(d,'white',raw);
 for(const label of d.entities.filter(e=>e.presentationRole==='product-name')){const index=d.input.systems.findIndex(s=>label.x>=s.outerStartX&&label.x<=s.outerEndX);assert(index>=0);const width=d.input.systems[index].outerEndX-d.input.systems[index].outerStartX;assert(label.height*label.value.length*.58<=width*.82+.001,'Product label overflows module');if(d.input.systemCount>1)assert(label.value.endsWith('POZ '+(index+1)),type+card.id+' printed position ownership');}
 const views=d.orthographicViews.filter(v=>v.kind==='SIDE');assert(views.length);
 for(const v of views){
  const p=d.input.positions[v.systemIndex],es=d.entities.filter(e=>e.viewType==='SIDE'&&e.systemIndex===v.systemIndex),dims=es.filter(e=>e.type==='dimension'&&e.edit?.view==='Side');
  for(const e of dims){const f=e.edit.field;if(['opening','frontHeight','rearHeight'].includes(f)){assert(Math.abs(e.measuredValue-p[f])<.00001,type+card.id+' wrong module dimension '+f);}}
  const rs=es.filter(e=>e.arc).map(e=>e.arc.radius),rail=m.components.find(p=>p.kind==='rail'&&p.systemIndex===v.systemIndex);if(type.startsWith('Curve'))assert(rs.some(r=>Math.abs(r-rail.curveRadius)<.00001));
 }
 for(const side of ['left','right']){const own=views.filter(v=>v.side===side);for(let i=1;i<own.length;i++)assert(own[i].bounds.maxY<=own[i-1].bounds.minY-999.999,'Side views overlap');}
 if(m.configuration.double){for(const s of m.assembly.systems){const depth=d.entities.find(e=>e.edit?.dimId==='pergola_total_depth_'+s.index);assert(depth);assert(Math.abs(depth.measuredValue-(s.frontDatumZ-s.backExtentZ))<1e-6);const postWidth=d.input.rearSupport?.beamProfile?.planDepth||100;assert(Math.abs(s.mirrorDatumZ-s.rearDatumZ+postWidth/2)<.00001,type+card.id+' steel face spacing');}}
 results.push({type,layout:card.id,systems:d.input.systemCount,sideViews:views.length,status:'PASS'});
}
fs.writeFileSync(path.join(process.env.PLMR_TEST_OUTPUT,'v11-multiple-views.json'),JSON.stringify({status:'PASS',cases:results.length,results},null,2));console.log('PASS',results.length,'native multi-view ownership/layout cases');
