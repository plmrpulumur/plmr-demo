/* V14 user DXF: Curve-Quad whole-roof plan title is at physical full-depth centre. */
const fs=require('fs'),assert=require('node:assert/strict');
const prefix=fs.readFileSync('./Test-Mantik/v11-model-matrix.cjs','utf8').split('const types=')[0];
const c=Function('require','process',prefix+'return c;')(require,process);
const layouts=c.PLMRPergolaLayouts.cards;
let cases=0;
for(const card of layouts){
 const raw={...c.PulumurGeometry.SAMPLE_INPUT,...card.values,rayCount:'',postCount:'',__pergola:{series:'Avila',railType:'Curved',pergolaType:'Curve-Quad',layoutPlanId:card.id}};
 const drawing=c.PulumurGeometry.buildDrawing(raw),model=c.PLMRJustPergola.fromDrawing(drawing,'white',raw);
 const titles=drawing.entities.filter(e=>e.presentationRole==='product-name'&&e.viewType==='TOP');
 assert.equal(titles.length,model.assembly.systems.length,card.id+' must have one continuous roof title per poz');
 for(const system of model.assembly.systems){
  const expected=-(system.frontDatumZ+system.backExtentZ)/2;
  const x=(system.outerStartX+system.outerEndX)/2+model.assembly.origin.sourceX;
  const e=titles.find(t=>Math.abs(t.x-x)<1);
  assert(e,card.id+' missing system title');
  assert(Math.abs(e.y-expected)<.001,card.id+' title is not at full-roof centre');cases++;
 }
}
const report={status:'PASS',cases,product:'Curve-Quad',scope:'Native upper-view product label full-depth centre; other physical geometry unchanged'};
fs.writeFileSync('./Test-Mantik/v14-output/v14-top-centering.json',JSON.stringify(report,null,2)+'\n');
console.log('PASS V14 Curve-Quad full plan centre for',cases,'positions');
