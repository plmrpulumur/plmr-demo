const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),{pathToFileURL}=require('node:url');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
(async()=>{const b=await chromium.launch(JSON.parse(fs.readFileSync(process.env.PLMR_CHROMIUM_CONFIG))),p=await b.newPage({viewport:{width:1440,height:900}}),errors=[],failed=[];p.on('pageerror',e=>errors.push(e.message));p.on('requestfailed',r=>failed.push(r.url()));
try{
 await p.goto(pathToFileURL(path.resolve(process.argv[2],'Uygulama/index.html')).href);assert.equal(await p.title(),'PLMR | JustPergola V9');
 await p.locator('#rrV14LayoutBtn').click();await p.locator('[data-pergola-type=Lean-Quad]').click();
 const image=await p.locator('[data-pergola-type=Lean-Quad] img').evaluate(n=>({src:n.getAttribute('src'),width:n.naturalWidth}));
 assert(image.src.endsWith('lean-quad.svg'));assert.equal(image.width,512);
 await p.locator('[data-layout=single]').click();await p.locator('#pergolaSettingsApply').click();await p.waitForFunction(()=>PLMRJustPergolaApp.inspect().parts?.some(p=>p.kind==='rear-steel-beam'));
 await p.locator('#rrV14LayoutBtn').click();await p.locator('#pergolaRailType').selectOption('Curved');await p.locator('[data-pergola-type=Curve-Quad]').click();assert.equal(await p.locator('[data-layout]').count(),7);await p.locator('[data-layout=single]').click();await p.locator('#pergolaSettingsApply').click();await p.waitForFunction(()=>PLMRJustPergolaApp.inspect().configuration?.pergolaType==='Curve-Quad'&&PLMRJustPergolaApp.inspect().fabric.length===1);
 await p.locator('#shellMotion').fill('100');await p.locator('#shellMotion').dispatchEvent('input');const s=await p.evaluate(()=>PLMRJustPergolaApp.inspect());assert(s.webgl&&s.renderCalls>0);assert.equal(s.fabric[0].collectionEnd,'rear');assert(s.fabric[0].meshBounds.max[2]<0);
 await p.locator('#rrV45Mode2DBtn').click();assert(await p.locator('#preview svg').count());assert(await p.evaluate(()=>PLMRPergolaNative.drawing().entities.some(e=>e.nativeBlockSource==='PergoRise Ray Arka Mekanizma Üst Görünüş')));
 assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);console.log(JSON.stringify({status:'PASS',title:await p.title(),webgl:true,leanQuadSteel:true,leanQuadSvg:image,curveQuadRearCollection:true,native2dBlocks:true,errors,failedResources:failed}));
}finally{await b.close();}})().catch(e=>{console.error(e);process.exitCode=1});
