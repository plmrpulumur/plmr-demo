/* Native block envelope parity and physical Quad invariants, independent of WebGL. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]),prefix=fs.readFileSync(path.join(root,'Test-Mantik/v9-model-matrix.cjs'),'utf8').split('const types=')[0];
const c=Function('require','process',prefix+'return c;')(require,{...process,argv:['node','test',root]});const results=[];
for(const type of ['Lean-Suspend','Lean-Wing','Lean-Quad','Curve','Curve-Suspend','Curve-Wing','Curve-Quad'])for(const card of c.PLMRPergolaLayouts.cards){
 c.input={...c.PulumurGeometry.SAMPLE_INPUT,...card.values,rayCount:'',postCount:'',glassTrack:'EVET',triangleJoinery:'EVET',__pergola:{pergolaType:type,railType:type.startsWith('Curve')?'Curved':'Linear'}};
 const {drawing:d,model:m}=vm.runInContext('(()=>{const drawing=PulumurGeometry.buildDrawing(input);return {drawing,model:PLMRJustPergola.fromDrawing(drawing,"white",input)}})()',c);
 const hardware=d.entities.filter(e=>e.nativeBlockSource&&['rail-rear-mechanism','rail-front-head','post-upper-connection','post-lower-connection','gutter-cap','gutter-ray-connection'].includes(e.componentKind));
 for(const kind of ['rail-rear-mechanism','rail-front-head','gutter-cap'])assert(hardware.some(e=>e.componentKind===kind),type+' '+card.id+' '+kind);
 for(const e of hardware){
  const p=m.components.find(p=>p.id===e.physicalPartId),b=c.PLMRPergolaVariantGeometry.bounds([p]),q=c.PulumurGeometry.bounds([e],d.blocks);
  const w=e.viewType==='SIDE'?b.max[2]-b.min[2]:b.max[0]-b.min[0],h=e.viewType==='TOP'?b.max[2]-b.min[2]:b.max[1]-b.min[1];
  assert(Math.abs(q.width-w)<1e-5,`${type} ${e.nativeBlockSource} ${e.viewType} width`);assert(Math.abs(q.height-h)<1e-5,`${type} ${e.nativeBlockSource} ${e.viewType} height`);
 }
 const sheets=m.components.filter(p=>p.kind==='trapez-sheet');assert.equal(d.entities.filter(e=>e.type==='hatch'&&e.patternKind==='fabric').length,sheets.length);
 if(type==='Lean-Quad'){
  const beams=m.components.filter(p=>p.kind==='rear-steel-beam');assert.equal(beams.length,m.positions.length);assert(m.components.some(p=>p.kind==='rear-steel-post'));assert(!m.components.some(p=>p.kind==='ridge-beam'));
  for(const beam of beams){const bb=c.PLMRPergolaVariantGeometry.bounds([beam]);for(const part of m.components.filter(p=>p.kind==='rail-rear-mechanism'&&p.systemIndex===beam.systemIndex)){const b=c.PLMRPergolaVariantGeometry.bounds([part]);assert(Math.abs(part.wing==='opposite'?b.max[2]-bb.min[2]:b.min[2]-bb.max[2])<1e-6,'mechanism flush to its own steel face');}}
 }
 if(type==='Curve-Quad'){
  assert(!m.components.some(p=>['ridge-beam','rear-steel-post','rear-steel-beam'].includes(p.kind)));
  for(const position of m.positions){assert.equal(position.roofs.length,1);const r=position.roofs[0];assert.equal(r.collectionEnd,'rear');const z=m.assembly.systems[position.roofs.indexOf(r)]?.rearDatumZ;assert(r.trajectory.points[0][2]<r.trajectory.points.at(-1)[2]);}
  for(const rail of m.components.filter(p=>p.kind==='rail')){assert.equal(rail.trajectory.points.length,257);assert(rail.continuousArch);const centre=m.assembly.systems[rail.systemIndex].rearDatumZ;assert(rail.start[2]<centre&&rail.end[2]>centre);}
 }
 results.push({type,layout:card.id,hardwareInserts:hardware.length,trapezHatches:sheets.length,status:'PASS'});
}
const result={status:'PASS',cases:results.length,results};fs.writeFileSync(path.join(process.env.PLMR_TEST_OUTPUT,'v9-native-details.json'),JSON.stringify(result,null,2));console.log('PASS',results.length,'native-detail/Quad geometry cases');
