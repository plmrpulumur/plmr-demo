# JustPergola V9 → ana uygulamaya bağlantı rehberi

Bu paket bağımsız ve çevrimdışı çalışan çizim motorudur. Bu sürüm ana uygulamaya monte edilmedi. Bağlantı aşamasında mevcut firma/proje/teklif/revizyon yetkileri ana uygulamada kalmalıdır. Teklif veya üretim kaydı burada yaratılmaz. Ana uygulamadaki proje bilgi ekranı yeniden oluşturulmaz.

## Kaynak ve çalıştırma

`Uygulama/index.html` çalıştırılabilir giriş; `Development_Protocol/source/index.html` bunun kaynağıdır. `Uygulama` içine elle düzeltme yapılmaz. `python3 Development_Protocol/build.py` native motoru, pergola adaptörünü ve ortak sağlayıcıları aynı kaynaktan üretir. `Uygulama/SOURCE_SHA256.json` her runtime dosyasını kaynakla eşler. Ana uygulamaya aktarılacak gerçek çalışma içeriği `Uygulama`dır; geliştirme ve tarihsel test klasörleri yayın varlığı değildir.

| Sorumluluk | Yetkili kaynak | Çıktı / tüketici |
|---|---|---|
| Ana fiziksel veri, şema, eski proje dönüşümü | `peri01/core/projectModel.js`, `persistence/*` | ProjectModel, `.plmr` |
| Doğrulama, komut, undo/redo | `peri01/core/projectCommandService.js`, `history/*`, `src/app.js` | Tek native commit yolu |
| 2D geometri ve profil referansları | `peri01/src/peri01Geometry.js` | Native drawing entities, ölçüler, SVG, DXF |
| Modelden türetilmiş fiziksel montaj | `peri01/modules/p3dv/products/pergo-rise/pergo-rise-derived-geometry.js` | Ray/oluk/dikme/sac datumu |
| 3D uyarlaması | `source/pergola-model.js`, `pergola-parts.js`, `pergola-viewer.js` | Native geometriye bağlı mesh; ikinci kalıcı model yok |
| Sahne görünürlüğü ve kayıtlı seçenekler | `source/pergola-scene.js` | `workspaces.standalone.project` |
| Form taslağı ve kabuk | `source/pergola-settings.js`, `pergola-ui.js` | Uygula / iptal; native komut yönlendirme |
| Ortak davranış | `shared/v34/*`, `shared/bioclimatic-roof-core.js` | Kamera, zone, snap, ölçü menüsü, Antero hareketi |

Bu tabloda göreli kaynak yolları `Development_Protocol` altındadır. SVG/3D sahne native modelden okunur. Kamera, geçici seçim ve animasyon karesi ürün ölçülerini yazmaz. Kalıcı düzenlemenin akışı: kullanıcı → form taslağı/komut → doğrulama → native ProjectModel/history → native 2D → türetilmiş 3D → çıktı. Form iptali son sağlam modeli korur.

## Buton ve olay bağlantıları

Kabuk butonlarının bağlandığı tek yer `source/pergola-ui.js` içindeki `bind`, `proxy` ve `data-legacy-id` yönlendirmeleridir. Yerli 2D işlemlerin sahibi `peri01/src/app.js`dir. Aynı buton için ana uygulamada ikinci dinleyici bırakılmamalıdır.

| Görünen kontrol / DOM kimliği | Sahibi / çağrı | Model veya çıktı etkisi |
|---|---|---|
| Ayarlar `rrV45SettingsBtn` | `openSettings` → `PLMRPergolaSettings` | Taslak; Uygula native commit; iptal yazmaz |
| Yerleşim Seç `rrV14LayoutBtn` | `layout` → `PLMRPergolaProductPicker` → `PLMRPergolaLayouts.cards` | Seri/ray/tip seçimi ve 7 native şema form taslağına gelir; Uygula ile kayıt |
| Poz Ekle `rrV45AddPositionBtn` | `openSettings({add:true})` | Native topoloji doğrulamasından geçer |
| PLMR Calculator `pergolaCalculatorBtn` | Ayarlar içinden native calculator | Dış taslağa aktarır; tek başına kalıcı kayıt yapmaz |
| 2D / 3D `rrV45Mode2DBtn`, `rrV45Mode3DBtn` | `setView` | Görünüm; native ürün ölçüleri değişmez |
| Projeyi Kaydet `shellSave`, Proje Dosyası İndir `rrV15ProjectDownload` | `projectExportBtn` proxy → native proje export komutu | Standalone `.plmr`; ana uygulamanın sunucu kaydı değildir |
| Proje Dosyası Aç `rrV15ProjectOpen` | `projectImportBtn` → `projectImportInput` | Native şema doğrulaması ve eski kayıt desteği |
| PDF 2D `rrV45Pdf2dBtn` | `pdfBtn` proxy | Native SVG/antet/birim çıktısı |
| DXF `rrV45DxfBtn` | `generateBtn` → `cadDrawing` → `PulumurModernDXF.toDxf` | Aynı native drawing; V34 CAD renk politikası |
| DAE `rrV45DaeBtn` | `viewer.dae()` → `PLMRV24ViewerExports` / `PLMRNativeDae` | Gerçek 3D mesh; poz grupları, mm birim |
| Görüntü Al `rrV45CaptureBtn` | `viewer.capture()` | PNG; proje kaydı değişmez |
| Kontrol Et `rrV45ValidateBtn` | Native diagnostics ve türetilmiş zone sınırları | Kontrol; mühendislik/statik onayı değildir |
| mm / inch `rrV45MmBtn`, `rrV45InchBtn` | `setUnits` → scene change | Gösterim tercihi; fiziksel değerler mm kalır |
| Ölçüler `rrV11DimensionsBtn` / ok | Scene dimensions + `PLMRDimensionMenu.build` | Kategori / poz / yön / tekil ölçü; 2D, 3D, kayıt, çıktı |
| Zone Oluştur `rrV13GenerateZones` | `PLMRPergolaZones.generate` | Kalıcı benzersiz zone sahipliği |
| Zone’lar / ok `rrV45ZonesBtn`, `rrV45ZonesBtnArrow` | Ortak zone görünürlüğü ve menüsü | Tavan / cephe / poz / tekil / kod arama |
| Push/Pull `rrV45PushPullToolBtn` | Ortak `rr-sketch-viewer` / scene tools | Native duvar/parapet commit; profil yüzleri snap hedefi |
| Parapet H `rrV45ParapetHeight` | Enter → `commitLegacy` | Native parapet yüksekliği doğrulanır |
| Düzenle `rrV11SelectionEditBtn` / `pergolaPartShift` | `selectPart` → native `editInteraction` | Seçili profil türünün native editörü |
| Ortak Dikme `rrV13CommonPost` | `postSettingsBtn` proxy | Native dikme editörü |
| Çoklu Profil Ekle / Sil `rrV11MultiProfileAdd`, `rrV11MultiProfileDelete` | `multiDimensionBtn`, `bulkExtendBtn` proxy | Yerli 2D çoklu komut akışı |
| Çoklu Ürün Ekle / Sil `rrV11MultiProductAdd`, `rrV11MultiProductDelete` | Standalone cephe alanı seçimi / bilgi | Ana uygulamada ürün montaj servisine bağlanacak; bu pakette cephe ürün motoru yok |
| Varsayılana Döndür `rrV11ResetDefaults` | İlk geçerli çizim baseline → native commit | Birim/proje bilgisi korunur; Resetle ile aynı değildir |
| Resetle `rrV16ResetAll` | Native `resetBtn` | Çizim ve history temizlenir |
| Kapat / Tam Aç / kaydırıcı | `shellRetract`, `shellExtend`, `shellMotion` → viewer motion | Tek kumaş; Antero 5,2 sn; geçici animasyon |
| Kamera araçları | `data-legacy-id` → viewer zoom/fit veya native 2D preview | Görünüm değişir |
| Ortam / Zemin / FOV | `v27Environment`, `v27Floor`, `v28Fov` | Mevcut ortak sahne sağlayıcısı |

PDF 3D, sahne seçme/paylaşma, ürün listesi PDF, üretim paketi ve AR kabukta devre dışıdır. Gelecekte ana uygulamanın gerçek servisleri bağlanana kadar bu butonlar başarılı işlem gibi sunulmamalıdır. Taşı/Kopyala/Döndür ve ikinci proje bilgi düzenleyicisi silinmiştir; tekrar eklenmemelidir.

`BUTTON_MAP.json`, 90 statik isimli butonun HTML kaynağını ve bağlandığı kaynak satırlarını ayrıca listeler. Dinamik profil/ölçü/duvar pencerelerinin kontrolleri `peri01/src/app.js`; dinamik ana ayarların kontrolleri `source/pergola-settings.js` içinde oluşturulur. Bu envanter kaynak gezinme içindir; davranış kanıtı `Test-Mantik` altındadır.

## Mevcut API sınırı

`PLMRPergolaNative` native uygulama girişidir: `drawing()`, `legacy()`, `options()` okur; `commitLegacy` ve `commitScene` doğrulanan yazma yollarıdır. `editInteraction` gerçek native editörü açar. `PLMRPergolaScene.change` kayıtlı sahne tercihini aynı native yoldan günceller. Bu API’leri atlayarak form alanı veya mesh pozisyonuna yazmak, 2D/3D/history eşitliğini bozar.

`PLMRJustPergolaApp.inspect()`, `inspectSolids()`, `inspectContacts()`, `screenPart`, `screenWall`, `screenZone` salt okunur doğrulama araçlarıdır; kayıt servisi değildir. `plmr:pergola-drawing` native çizim değiştiğinde adaptörü yeniler; `plmr:project-restored` ve `plmr-project-file-loaded` geri yükleme yollarını yeniler. Aynı olayı hosttan tekrar native modele yazan bir döngü kurulmaz.

İlk güvenli bağlantı mevcut bağımsız belgeyi aynı origin içinde ayrı iframe olarak tutmaktır; bu bir gelecek entegrasyon önerisidir, bu pakette yeni bir postMessage köprüsü uygulanmamıştır. Böylece mevcut `PLMR*` globalleri ve `rrV*` DOM kimlikleri ana Bioclimatic çalışma alanıyla çakışmaz. Tek ortak DOM’a geçilecekse önce hostun mevcut workspace mount/unmount sözleşmesi okunmalı; kabuk değil yalnız motor sağlayıcısı monte edilmelidir. Hostun kaydetme/kilit/revizyon/firma kontrolleri bu geçişte bağlanıp ayrıca test edilmelidir.

## Logo ve antet bağlantısı

Ana uygulamadaki gerçek logo kaynağı:
`Development_Protocol/03_DEVELOPMENT_SOURCE/public/assets/brand/drawing-logos/PLMR_2D_Logo_V1.svg`

Dağıtım yolu:
`Uygulama/github/assets/brand/drawing-logos/PLMR_2D_Logo_V1.svg`

Bu pakette birebir varlık:
`Uygulama/shared/v34/branding/drawing-logos/PLMR_2D_Logo_V1.svg`.

`shared/v34/default-drawing-logo.js`, bu SVG’nin 6 kapalı poligonunu aynı koordinat yönüne çevrilmiş çevrimdışı DrawingLogo verisi olarak taşır; yeni logo çizimi değildir. `shared/v34/final-company-logo.js` V34 sağlayıcısı birebir korunmuştur. Antet `shared/v53-titleblock.js` ve `source/pergola-document.js` üzerinden kurulur. `PLMRFinalMetadata.projectInfo.drawingLogo` verilirse firma logosu kullanılır, aksi halde aynı PLMR varlığı uygulanır. Inline vektör kullanımı yerel PDF/DXF çıktısında dosya URL / CORS / canvas kaynak sorununu önler. Antet önizlemesi artık blok içindeki logo stroke bilgisini kullanır; kesik görünüm üreten çok ince genel blok çizgisi kullanılmaz.

Proje bilgi eşlemesi `PLMRPergolaDocument.projectInfo(raw)` içindedir: `projectCode`, `customer→customerName`, `project→projectName`, `country`, `version→revision`, `date`, `description/extras`, `customerRepresentative`, `drawnBy→designer`. Ana uygulama bu alanları kendi yetkili proje kaydından sağlamalıdır; standalone form yeni bilgi sahibi yapılmamalıdır. `PLMRDrawingOutputNames.safeName` güncel V34 adlandırma fonksiyonudur: proje kodu + revizyon + uzantı.

## Ölçüler, geometri, renkler

Native birim mm’dir; inch sadece `25.4` dönüşümüyle gösterilir. Üç ortak ölçülendirme katmanı `OLCULENDIRME_MM`, `OLCULENDIRME_INCH`, `OLCULENDIRME_MM_INCH`dir. `PLMRPergolaDimensions` native ölçü kimliğini güncel ortak kategori/poz/yöne bağlar. Ortak menü gövdeleri V34 `v15-project-ui.js` / `v17-ui.js`den alınmış, global host komutlarını değiştirmeden bağımlılık enjeksiyonu ile bağlanmıştır. Cephe ürünleri kurulmadığı için bu kategorinin alt poz listesi henüz yoktur.

Görünür adlar `PERGOLA · POZ n`dir. Eski projelerdeki `IPR-01` gibi iç grup kimlikleri değişmez: bunlar görünen poz adı değildir; kaydı, zone sahipliğini veya geometri referansını kırmamak için korunur. DAE grup anahtarlarında da bulunabilir.

Yan kayıtlar native üst görünüş poligonlarından türetilir. V7’de ön referans her sistemin kendi oluk datumuna bağlandı; 4500/5200 mm arka hizalı bağımsız örnekte bitişler 4400/5100 mm olur. V49 kökeni V2 donmuş native kaynak ve `Arsiv-V2/v49-parity.json` karşılaştırmasına dayanır; özgün V49 ZIP bu çalışma ortamında mevcut değildir. Birinci sistemin datumunu bütün sistemlerde kullanmak yeni bağımsız yerleşimde yanlıştı.

`source/pergola-colors.js` güçlü native profil paletidir. Geçerli RAL/hex seçimi korunur. Eski kayıttaki tanımsız `-3` değeri veri olarak korunur; sunumda bütün profillerin griye düşmesi yerine native palet kullanılır. Kumaş her hareket hattında tam genişlikte tek sürekli yüzeydir; Wing/Lean-Quad iki hat, Curve-Quad bir hat kullanır. Taşıyıcılar altta, katlama temas düzlemleri üzerindeki kumaş bağlantıları kesintisizdir.

Yansımayla eksen değiştiren üçgen/oluk/kapak extrusionlarının yüz yönleri `shared/solid-mesh.js` içinde düzeltilir. Aynı modül mevcut perspektif derinlik tamponunda sabit materyal poligon ofsetini sağlar. Kumaş taşıyıcıları dış bakışta kumaştan önce boyanır ve yarışan temas derinliğini yazmaz; alttan bakışta normal opak katı olarak kalır. Sacın yerleşimi, native kaydın gerçek üst köşe zarfından türetilir: yatay kayıt derinliği ile ray eğimi merkez kotunu tek başına yetersiz kılıyordu. Sac/kayıt köşesi için stencil destek maskesi kullanılır; en öndeki diğer opak profiller/duvarlar maskeyi sıfırlar. Yalnız bu temas örneklerine uygulanan yardımcı yüzey fiziksel parça değildir; seçim, snap ve DAE dışında kalır, kendi geometri ve materyali viewer yaşam döngüsünde temizlenir. Bu yalnız GPU derinlik karşılaştırmasıdır: native koordinatlar, profil boyutları ve DAE geometri noktaları kaydırılmaz. Otomatik Boolean birleşim yapılmaz; ayrı fiziksel parçalar ayrı kalır. Sacın üretici kalınlığı native kaynakta tanımlı olmadığından 3D sac çift yüzlü sıfır kalınlıklı sınır yüzeyidir; uydurma sac kesiti eklenmedi.

## Yaşam döngüsü ve geçişte doğrulanacaklar

3D viewer bir kez mount edilir; model değişiminde assembly, materyaller, ölçü ve seçim kaynakları temizlenip kurulur. Animasyon döngüsü 2D/gizli sayfada durur. `pagehide` observer/kontrol/renderer kaynaklarını temizler. Bu sürüm tam sayfa yaşam döngüsünü destekler; aynı DOM’da keyfi sök-tak host yaşam döngüsü henüz uygulanıp doğrulanmadı. İframe kaldırılmasıyla sayfa kaynakları sonlandırılabilir; inline mount istenirse açık dispose/abonelik temizliği bağlantı kapsamına eklenmelidir.

Host bağlantısında kabul: ana proje aç → doğru pergola workspace → native tek değişiklik → host dirty/kilit/revizyon → 2D/3D aynı geometri → kaydet/yeniden aç → undo/redo → firma değişimi → workspace kapat/aç → çıktı. Logo, proje bilgisi ve dosya adı aynı ana kayıttan gelmelidir. Bu paketin yerel testleri canlı firma yetkisi, sunucu atomik kaydı, AutoCAD/SketchUp içe aktarma veya mühendislik/imalat onayı yerine geçmez.

## Ürün tipi ve görsel bağlantısı

| Sorumluluk | Kaynak | Entegrasyon kuralı |
|---|---|---|
| Ürün tanımı | `peri01/core/pergolaDefinition.js` | `ProjectModel.pergola` tek kalıcı tanım: series, railType, pergolaType, derivedModelName, layoutPlanId, geometry. |
| İki aşamalı pencere | `source/pergola-product-picker.js` | Aynı `rrV14LayoutDialog`; filtre ve tip seçimi geçici; ayarlar Uygula tek commit. |
| Tip kartları | `source/assets/pergola-types/*.{webp,svg}` | Yedi kart yeni assets pergola.zip; Lean-Quad gerçek modelden SVG; yol/hash eşlemesi `V9_CARD_ASSETS.json`. |
| Yerleşim önizlemeleri | `pergola-product-picker.js: iso` | Gerçek türetilmiş montajdan SVG; ayrı kalıcı kart geometrisi tutulmaz. |
| Tip geometrisi | `source/pergola-variants.js` | Yerli Lean montajını kullanır; askılar/merkez dikmeler/karşı kanat/kavis buradan türetilir. |
| Ortak koordinatlar | `source/pergola-variant-geometry.js` | mm, yol/teğet/yay uzunluğu/kesit ve fiziksel dış sınırlar. |
| 2D görünümler | `source/pergola-orthographic.js` | Yeni tiplerde aynı fiziksel parçaların üst/ön/yan izdüşümü; Lean mevcut ayrıntılı 2D motorunu kullanır. |
| Kayıt göçü | `peri01/persistence/revisionCore.js`, `schemaRegistryCenter.js` | Şema 2→3 ortak `upgradeEnvelope`; eski checksum doğrulanır, kaynak/snapshot değiştirilmez. |

Yükleme sırası önemlidir: ürün tanımı ProjectModel'den önce; yerli türetilmiş geometri ve ürün projeksiyonları `src/app.js`'den önce; UI sonradan. Runtime `index.html` sırasını koruyun. Host firması, proje metadata ve kilit/revizyon izinleri host tarafında kalır. Model adını `derivedModelName` üzerinden gösterin; PERGO_RISE iç motor kimliğini Bioclimatic adı olarak göstermeyin. Andes/Avila için sahte profil farkı üretmeyin. Yeni şema 3 kayıtlarını V7'ye kayıplı dönüştürmeyin.

Yeni tiplerin geometrisi kaydedilmiş mesh değildir: tek modelden türetilir. Kumaş açılımı gerçek ray yay uzunluğunu izler. Wing ve Lean-Quad'da her kanat bir sürekli kumaştır. Curve-Quad'da arka uçtan ön uca tek kesintisiz kumaş vardır. Wing'de merkez dikmeler arasındaki gerçek açıklıklar zone olur; Quad yan zone'ları dış dikmeler arasında tam açıklıktır. Sahnede kamera/hareket kareleri fiziksel girdileri değiştirmez.

Çizim girdileri: normal Curved için kavis yüksekliği varsayılan 150 mm; askı üst farkı 800 mm; askı borusu dış çapı 40 mm. Bunlar üreticiden doğrulanmış ürün katalog değerleri değildir. Curve-Quad sürekli kemerinin yarıçapı orta/uç kotlarından türetilir. Bağlantı plakası, ankraj, kesit dayanımı ve üretim boyu hesabı bu sürümde tasdik edilmez.

## V9 düzeltmeleri ve sahiplik

Curve-Quad: `continuousQuad` yalnız bu tipi kesintisiz kemere dönüştürür; kumaşın yolu arka dış uçtan ön dış uca gider. Ortadaki arka mekanizma ve toplama sacları kaldırılır; tek sac/kayıt grubu arka uca taşınır. Diğer tiplerin toplama yönü değişmez.

Lean-Quad: native normal pergolanın `rearSupport` çelik profil tanımları ve `rearSteel` montajı kullanılır. `ProjectModel.normalize` ve doğrudan geometri girişi bu tipte çeliği zorunlu kılar. Ayna ekseni çelik kirişin merkezidir; mekanizmalar iki ayrı yüze oturur. Bu nedenle toplam derinlik iki kanat açılımına kiriş plan derinliğini ekler. Kiriş/dikme kesitleri 2D üst görünüşte aynı native çelik editöründen düzenlenir ve aynı model alanına yazılır.

`source/pergola-native-details.js`, yeni tiplerin fiziksel izdüşümlerine mevcut blok isimleriyle INSERT yerleştirir. `pergola-orthographic.js` görünüş yerleşimi ve native ölçü/editör kimliklerini yönetir. Yeni modül HTML'de orthographic modülünden önce yüklenir. Ray/oluk konturu fonksiyonlarının sahibi native `peri01Geometry.js`'dir. Blok kütüphanesi V8 ile aynıdır. Dış zarfı prizma olan 3D aksesuar ile detaylı 2D blok aynı dış ölçülere oturtulur.

Yeni Lean-Quad kartı `node Development_Protocol/regenerate-cards.cjs` ile gerçek modelden üretilir; ardından Python build çalıştırılır. Önceki Lean-Quad WebP aktif paketten çıkarıldı; kaynak referansı ve V8 teslimi korunur. Kart haritası ve hashler V9_CARD_ASSETS.json'dedir. Şema 3 kalır, yeni paralel kalıcı model yoktur.
