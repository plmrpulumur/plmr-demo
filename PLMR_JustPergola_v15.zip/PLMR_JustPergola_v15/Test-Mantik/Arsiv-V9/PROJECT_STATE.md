# V10 çalışma durumu — 16 Kasım 2026

Başlangıç: teslim edilmiş V9 ZIP SHA256 4abfdb983fa8e6c2357c847336d8cd635018c2459381fc15c27b02350482087a. Ayrı V10 çalışma kopyası. V9 teslimi korunur.

Uygulanan, kabul doğrulaması devam eden: özgün arka mekanizma 2D bloğunun geri alınması; esnetilmeyen native aksesuar blokları; türetilmiş ön görünüşlerde gizli arka taşıyıcıların kaldırılması; 4 mm L aparat; mekanizma/ray temas kesimi; askılarda duvar/çelik ve ray yüzlerinde açılı kesim; çelik askı dikme-kiriş datum düzeltmesi; Curve-Quad simetrik ön kafalar ve dört çatı kayıt istasyonu; çatı kayıtlarının ray üst kotuna alınması; kumaş toplama sınırı ve 30 mm saçak; ortak zone eylem kartı; ana uygulamanın #ff8c00 tavan zone rengi; özel çelik kiriş kesiti; ayarlarda kompakt yerleşim ve gereksiz yan ofset alanlarının kaldırılması.

Devam: tüm ürün/yerleşim/duvar-çelik mantık matrisi; gerçek tarayıcıda temas/kumaş/zone/düzenleme; SVG/PDF/DXF/DAE karşılaştırmaları; referans 2D dondurma kaydı; entegrasyon belgeleri; temiz paket kontrolü.

Canlı uygulamaya bağlanmadı. Cephe ürünlerinin gerçek montajı mevcut ana uygulamadaki ürün sağlayıcıya aittir; ortak eylem kartı bu sağlayıcıya adaptörle bağlanır.
