PLMR JUSTPERGOLA V9
===================
Paketi çıkarıp Uygulama/index.html dosyasını Chrome veya Edge ile açın.
Tüm klasörü birlikte tutun. İnternet gerekmez.

Curve-Quad artık arka uçta toplanır; kesintisiz ray/kumaş hattı vardır.
Lean-Quad ortadaki gerçek çelik kiriş/dikmelerle çizilir.
Çelik kesitlerini 2D üst görünüşte orta taşıyıcıya tıklayıp native editörden değiştirin.
Yeni tiplerin 2D ve DXF'lerinde mevcut pergolanın ray/mekanizma/oluk/bağlantı blokları ve trapez taraması kullanılır.
Lean-Quad kartı ve yerleşim görselleri çelik sisteme göre güncellendi.

Yerleşim Seç → Seri/Ray Tipi → Ürün Tipi → Yerleşim → Ayarlar → Uygula.
Şema 3 korunur. Eski kayıtlar açılır; özgün dosyalar değiştirilmez.

Ayrıntılar: DEVIR_NOTU.md, BAGLANTI_REHBERI.md, Test-Mantik/KABUL.md.
Kaynak build: python3 Development_Protocol/build.py
Teknik kart üretimi: node Development_Protocol/regenerate-cards.cjs (sonra build).
