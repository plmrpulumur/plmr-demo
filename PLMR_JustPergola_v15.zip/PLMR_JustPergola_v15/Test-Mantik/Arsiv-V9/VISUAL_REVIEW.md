# V9 görsel inceleme

Curve-Quad gerçek 3D ekranında %0, %50 ve %100 hareket konumları incelendi. Kemer kesintisiz; kumaş ortadan geçer ve arka uçta katlanır. Çatı sacı/kayıtları arka uçtadır. Lean-Quad'ta dört dış ayak ve ortadaki çelik kiriş/dikmeler görünür; karşılıklı düz eğimli kanatlar korunur.

Lean-Quad ürün kartı gerçek montajdan SVG olarak üretildi; orta çelik griyle ayrılır. Yedi yerleşimin izometrileri de güncel montajı kullanır. Diğer yedi ürün kartı kullanıcının son assets pergola.zip paketinden gelen aynı görsellerdir. Yasaklanan önceki kart paketi kullanılmadı.

Son kaynaktan alınan Lean-Quad ve Curve-Quad PDF'leri rasterlenip açılarak incelendi: üst, ön ve yan görünüş; native ray/mekanizma/oluk detayları, sarı trapez taraması, orta çelik, kırmızı native ölçüler ve ortak antet/logo görünür. Diğer tipler de gerçek dosya indirme ve bağımsız format kontrolünden geçti. İnceleme yerel yazılımsal WebGL ve PDF ile sınırlıdır.
