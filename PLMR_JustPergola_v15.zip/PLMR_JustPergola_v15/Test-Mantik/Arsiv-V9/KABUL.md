# V9 güncel kabul — 10 Kasım 2026

Başlangıç teslim edilmiş V8 ZIP: SHA256 `9a69a2e79593a76d6a6754888de42b661611b38358d18c8ae75433a28b4c1478`. Ayrı V9 kopyasında çalışıldı; özgün V8, kullanıcı protokolü ve referans görselleri korundu. Önceki kabul raporları `Arsiv-V8` altındadır; bu sürüm için PASS sayılmaz.

| Talep / korunan davranış | Doğrulama ve güncel kanıt |
|---|---|
| Curve-Quad arkada toplanır | `v9-quad-browser.json`: gerçek kumaş vertex sınırları kapalı durumda kemerin iki ucunu kapsar; %100 açıldığında arka uçta kalır; %50 katlanma kontrol edildi. Ortada mekanizma/kumaş toplama grubu yok; tek kesintisiz ray ve kumaş hattı var. |
| Lean-Quad orta çelik | `v9-native-details.json`, `v9-quad-browser.json`: normal pergoladan türeyen kiriş/dikmeler; mekanizmalar kirişin iki karşı yüzüne sıfır oturur. Aynı native profil editöründe 120×120 dikme, 100×200 kiriş seçildi; 3D ve save/reopen doğrulandı. |
| Yerli 2D detay ve ölçü | `v9-native-details.json`: 7 yeni tip × 7 plan, toplam 49 örnekte gerçek blok INSERT dış ölçüleri fiziksel parçaların ilgili izdüşümüyle eşleşir. Ray, mekanizma, oluk, dikme bağlantıları; native trapez taraması. |
| İki seri / sekiz tip / yedi plan | `model-matrix.json`: 112 kombinasyonda sonlu geometri, kimlik, destek, askı, kapalı ray katısı ve seri eşdeğerliği. `model-matrix-glazing.json`: aynı matris, yan kayıt ve üçgen doğrama açık. Bunlar 112 kombinasyonun iki seçenek durumudur. |
| Gerçek UI ürün ve kayıt akışı | `v9-products.json`: 23 ürün/plan uygulaması; 8 tip save/reopen ve çıktı; iptal/undo/redo; zone kimliği ve 7 tekrar çizimde sabit geometri/doku sayaçları. |
| Son kaynakla 8 tip dosya çıktısı | `v9-outputs.json`: her tipe ait proje UI'dan açıldı; DXF/PDF/DAE indirildi; gerçek SVG daireleri sıfır yarıçapa düşmedi; çıktı işlemi ProjectModel'i değiştirmedi. |
| Bağımsız çıktı okuma | `v9-exports.json`: 8 tip gerçek DXF INSERT adları, mm, logo/ölçü katmanları; DAE benzersiz ID/ref, kapalı dışa dönük katılar, kumaş yönü/adedi; PDF yapısı. Harici AutoCAD/SketchUp koşusu değildir. |
| Native Lean hesabı | `native-model.json`: 17 ölçü/yerleşim/sac/çelik/oluk örneği; birim değişimi fiziksel değerleri değiştirmez. |
| Şema ve eski dosya | `v9-schema.json`: şema 3, checksum reddi ve eski şema göçleri; tarihsel alan/snapshot koruma. Yeni veri şeması gerekmedi. |
| Etkilenen çalışan akış | `v9-browser.json`: 18 mevcut akış grubu; renk, otomatik ray/dikme, seçenekler, zone/filtre, Push/Pull, ölçü birimleri, kayıt/çıktı/reset ve yerleşim. `v9-product-edit.json`: kavisli ürünün gerçek 2D genişlik editörü, geometri girdileri, geçersiz taslak ve kumaş hareketi. |
| Temiz paket açılışı | `package-smoke.json`, `package-check.json`: ayrı klasöre çıkarılmış V9; güncel Lean-Quad SVG ve orta çelik, Curve-Quad arka toplama, native 2D bloklar ve gerçek WebGL açıldı; eksik varlık/JS hatası yok. |
| Kaynak/runtime | `source-check.json`: 93 JS sözdizimi ve 136 runtime dosyası kaynakla bayt eşit; sağlayıcı ve değişen kaynak hashleri. |

Native blok kütüphanesi `peri01/blocks/filteredBlocks.js`, V8 ile bayt eşittir. Ortak ray/oluk kontur fonksiyonları iki çizim yolu tarafından kullanılır. Yeni tiplerin fiziksel izdüşümünde mevcut kesit ve aksesuar blokları yerleştirilir; kavisli rayın yan görünüşü aynı profilin kavis boyunca türetilmiş dış çizgisidir. 3D aksesuarlar önceki kullanıcı kararı uyarınca dış ölçüleri temsil eden prizmalardır; 2D bloklardaki her delik 3D'ye işlenmez.

Başlangıçta yeniden üretilen V8 bulguları: Curve-Quad'da iki kumaş orta bölgeden başlıyordu; Lean-Quad'da orta çelik parça yoktu; yeni tiplerde mekanik INSERT sayısı sıfırdı. V9 bunları düzeltti. Testte ayrıca yeni tiplerin profil tıklama alanlarının `previewOnly` nedeniyle SVG'den elendiği görüldü ve düzeltildi; çelik editörü gerçek tıklamayla yeniden doğrulandı. Ters kanatta daire detaylarını korumak için native pozitif ölçek + mirror-X/rotation sözleşmesi kullanıldı.

Ortam: Chromium 151 / ANGLE SwiftShader / file:// / masaüstü 1560×960. Test dosyalarındaki inspect çağrıları salt okunur gözlemdir; tıklama, form ve klavye adımları gerçek UI'dır. Ekran/PDF'ler incelendi; kullanıcı istemediği için iç ekran görüntüleri pakete eklenmedi. Grafik sayaçları MB veya donanım performans garantisi değildir.

Tekrar çalıştırma: `python3 Development_Protocol/build.py`, `python3 Test-Mantik/verify-source.py .`. Node testlerine proje kökünü argüman olarak verin ve var olan çıktı klasörünü `PLMR_TEST_OUTPUT` ile belirtin. Tarayıcı testleri Playwright'ı `CODEX_PRIMARY_RUNTIME_NODE_MODULES` üzerinden, Chromium launch JSON'unu `PLMR_CHROMIUM_CONFIG` üzerinden alır. `v9-products.cjs` sekiz tip `.plmr` test örneğini üretir; bu klasör `v9-outputs.cjs` ve `v9-quad-browser.cjs` üçüncü argümanıdır. `v9-product-edit.cjs` üçüncü argümanı Curve-Wing.plmr'dır. `v9-exports.py` gerçek çıktı klasörünü okur. `regenerate-cards.cjs`, uygulamanın gerçek modeli üzerinden Lean-Quad SVG kartını yeniden üretir; ardından build çalıştırılır.

Canlı ana uygulama montajı yapılmadı. Statik/imalat onayı bu çizim kontrolünün kapsamında değildir. Önceki devre dışı host servisleri bu turda etkinleştirilmedi. Paket açılışı ve CRC/hash sonucu paket kontrol kaydında ayrıca yer alır.
