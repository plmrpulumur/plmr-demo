# PLMR JustPergola V9 devir notu

Başlangıç: V8 ZIP SHA256 9a69a2e79593a76d6a6754888de42b661611b38358d18c8ae75433a28b4c1478. V8 ve kullanıcı referansları değişmedi; ayrı V9 kopyası geliştirildi.

Çalıştırma: paketi çıkarıp Uygulama/index.html dosyasını açın. Kaynak Development_Protocol altında; runtime'a elle yama yapılmaz. Build: python3 Development_Protocol/build.py. Lean-Quad kartını yeniden üretmek için önce node Development_Protocol/regenerate-cards.cjs çalıştırılır.

Geçerli son kararlar:
- Curve-Quad: tek kesintisiz kemer ve kumaş hattı, arka uçta toplama. Orta mekanizma/mahya toplaması yok; sac/kayıt seti arka uçta. Diğer tiplerin hareket yönleri korunur.
- Lean-Quad: dört dış ayak ve ortada native normal pergola çelik kirişi/dikmeleri. Karşı kanatlar kirişin iki yüzüne oturur. Toplam derinlik iki kanat açılımı + kiriş plan derinliğidir. Kesitler mevcut 2D çelik editöründen değişir.
- 2D: aynı native ray kesiti, mekanizma, oluk, dikme bağlantısı ve trapez tarama blokları. Kavisli yan ray aynı profilin yol boyunca izdüşümüdür. Blok kütüphanesi V8 ile byte eşittir.
- Lean-Quad tip kartı ve tüm yerleşim izometrileri gerçek modelden güncellendi. Diğer yedi kart kullanıcının son assets pergola.zip paketindendir. Yasaklanan eski kart paketi kullanılmaz.

Ana veri sahibi native ProjectModel'dir; şema 3 korundu. Tipten türeyen davranış düzeltildi, paralel kalıcı model eklenmedi. Eski kayıt checksum'u normalize edilmeden doğrulanır; özgün dosya ve snapshotlar yerinde değiştirilmez. Kaydetme/undo/redo native yoldadır. Kamera, hareket ve CAD indirme fiziksel veriyi değiştirmez.

Kaynaklar: peri01/src/peri01Geometry.js ortak ray/oluk konturları ve blok sahibi; source/pergola-variants.js tip montajı/continuousQuad; source/pergola-native-details.js yerli blokları fiziksel izdüşüme bağlar; source/pergola-orthographic.js görünüş/ölçü/editör; source/pergola-viewer.js gerçek sahne ve kumaş. pergola-native-details.js orthographic'ten önce yüklenir; kesin sıra source/index.html içindedir. Ayrıntılı buton/host bağlantıları BAGLANTI_REHBERI.md ve BUTTON_MAP.json'dadır.

Doğrulama: Test-Mantik/KABUL.md tek güncel giriş belgesidir. 112 kombinasyon iki seçenek durumunda; 49 native blok/zarf örneği; gerçek UI'da Quad hareketi/çelik editörü/save-reopen, 23 ürün/plan uygulaması, son kaynaktan 8 tip PDF/DXF/DAE; bağımsız format okuyucuları; native/model ve mevcut akış regresyonları geçti. Kaynak/runtime ve temiz ZIP açılışı ayrıca kontrol edildi. Eski raporlar Arsiv-V8 altında tarihsel olarak korunur.

Canlı uygulamaya montaj bu turda yapılmadı. Mevcut kapalı host servisleri aynıdır. Kontroller yerel Chromium/SwiftShader ve dosya okuyucularıdır; dış CAD uygulaması veya imalat/statik onayı değildir. Güncel kaynakta bu talep için açık iş yoktur; sonraki adım kullanıcıyla ince ayarlardır.
