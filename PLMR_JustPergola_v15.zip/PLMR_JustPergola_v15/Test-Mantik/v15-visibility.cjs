const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');const root=process.argv[2];
const prefix=fs.readFileSync(root+'/Test-Mantik/v11-model-matrix.cjs','utf8').split('const types=')[0];const c=Function('require','process',prefix+'return c;')(require,process);
const raw={...c.PulumurGeometry.SAMPLE_INPUT,__pergola:{series:'Avila',railType:'Linear',pergolaType:'Lean',layoutPlanId:'single'}};
const before=c.PulumurGeometry.buildDrawing(raw),available=c.PLMRPergolaDimensions.measurements(before);assert(available.length);
const id=available[0].id;raw.__dimensionVisibility={main:true,intermediate:true,hiddenIds:{[id]:true}};
const after=c.PulumurGeometry.buildDrawing(raw);assert(after.entities.some(e=>e.hiddenDimension&&c.PLMRPergolaDimensions.describe(after,e).id===id));
assert(c.PLMRPergolaDimensions.measurements(after).some(m=>m.id===id),'Hidden dimension disappears from the show/hide menu');
console.log('PASS hidden dimension remains available to show again');
