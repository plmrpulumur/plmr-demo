# PLMR JustPergola V7 — 7.0.0

09.11.2026. Güncel kabulün tek girişi `Test-Mantik/KABUL.md`; entegrasyon haritası `BAGLANTI_REHBERI.md`, statik buton envanteri `BUTTON_MAP.json`dir. Başlangıç V6 ZIP SHA256 `f6127adb385277c147a35828c842976566db8f1fcdcdda94bc56b56ddda0cbaa`. Özgün V6 ve kullanıcı örneği değiştirilmedi. Canlı uygulamaya yükleme yapılmadı.

## Bu sürümde

- Üçgen doğrama, ara kayıt, cam, oluk ve kapak extrusionlarında yansımadan sonra ters kalan yüz yönleri düzeltildi. Gerçek sahnede ve bağımsız DAE okuyucusunda 13 mesh’in açık kenarı olmadığı, kenar yönlerinin tutarlı ve hacimlerinin dışa dönük olduğu doğrulandı.
- Sacın paralel oturma düzlemi, 30 mm derinlikteki yatay kayıtların gerçek üst köşe zarfına göre türetilir. Kayıt merkezini oturma kotu sayan eski hesapta üst köşe saca giriyordu; en yüksek köşeye sıfır temasla oturur. Yeni sac kalınlığı veya keyfi boşluk eklenmedi.
- Kumaş sistem başına tek sürekli indexed mesh oldu. Katlama aralıkları ortak Antero hesabını kullanır; taşıyıcı üstünde temas platosu vardır. Profil/sac/kumaş temaslarında mevcut perspektif derinlik tamponunda materyal poligon ofseti kullanılır. Fiziksel koordinatlara veya DAE noktalarına boşluk/ofset eklenmez. Dış görünüşte eski taşıyıcı çizgileri temizlendi.
- Yan kayıt ve yan destek üst görünüş referansı her sistemin kendi ön oluk datumundan alınır. Gönderilen 4500/5200 mm, 13 mm bağımsız grup aralıklı, arka hizalı örnekte sağ kayıt artık −700..4400 yerine 0..5100 mm’dir. Sol kayıt 0..4400 mm kalır. Dış yüzler ön dikmeyle hem yüzdür. V49 ön hizalı 4 referans durumunun yan kayıt poligonları korunur.
- Geçersiz eski `-3` renk değeri kayıtta korunur; 2D native güçlü paleti 3D’de uygulanır. Geçerli RAL/hex değişmez. Yeşil üçgenler 55 mm derinlik / dış raydan 5 mm net aralık kuralını korur.
- Ölçü menüsü V34 kategori/poz/yön/tekil ölçü ve karma seçim mantığını kullanır. Aynı native görünürlük verisi 2D/3D/kayıt/çıktıyı besler. Üç mm/inch ölçü katmanı korunur. Görünen IPR adları `PERGOLA · POZ n` oldu; eski iç grup/zone kimlikleri değiştirilmedi.
- Gerçek ortak `PLMR_2D_Logo_V1.svg` ve V34 firma-logo sağlayıcısı kullanılır; önizleme blok çizgi kalınlığını doğru okur. Logo yolları ve firma logosu önceliği bağlantı rehberinde kayıtlıdır.
- DXF güncel `cadDrawing` yolu üzerinden çıkar. DXF/DAE proje kodu–revizyon adlandırması ortak V34 fonksiyonuna bağlıdır. DXF/PDF indirmek artık gereksiz native reconciliation/history işlemi oluşturmaz; committed model okunur. DAE gerçek poz grupları ve mm birim ile alınır.

## Çalıştırma / geliştirme

ZIP’i tamamen çıkarıp `Uygulama/index.html` açın. 3D için WebGL gerekir. Sunucu/npm kurulumu çalışma için gerekmez. Kaynak düzenleme `Development_Protocol/peri01`, `source`, `shared` içindedir; `Uygulama` generated çıktıdır.

```bash
python3 Development_Protocol/build.py
python3 Test-Mantik/verify-source.py .
node Test-Mantik/v7-model.cjs .
# Playwright ve Chromium test ortamında bulunmalı; config executablePath ve args içerir.
# PLMR_CHROMIUM_CONFIG ve PLMR_TEST_OUTPUT değişkenlerini ayarlayın.
node Test-Mantik/v7-browser.cjs .
node Test-Mantik/v7-regression.cjs .
node Test-Mantik/v7-interaction.cjs .
node Test-Mantik/v7-compatibility.cjs .
node Test-Mantik/v7-lifecycle.cjs .
node Test-Mantik/v7-acceptance.cjs . /mutlak/yol/MUSTERI-PROJE-LOCAL-R01.plmr
node Test-Mantik/v7-v49-placement.cjs . /mutlak/yol/PLMR_JustPergola_v2
python3 Test-Mantik/exports.py "$PLMR_TEST_OUTPUT"
python3 Test-Mantik/v7-export-geometry.py "$PLMR_TEST_OUTPUT"
python3 Development_Protocol/package.py /mutlak/yol/plmr_justpergola_v7.zip
```

Özgün kullanıcı örneği ve önceki tam paketler teslimin içine kopyalanmadı. Son iki native karşılaştırma komutunun dış referansları argümanla verilmelidir. `Test-Mantik/Arsiv-*` tarihsel kanıttır; güncel kabul değildir. Kaynak/runtime eşitliği `SOURCE_SHA256.json`, kabul dosyaları `ACCEPTANCE_SOURCES_SHA256.json`, ZIP içeriği kendini dışlayan `PACKAGE_SHA256.json` ile bağlıdır.

## Korunan davranış ve sınır

Güncel ortak mouse/zone/snap, 5,2 saniyelik kumaş hareketi, otomatik ray/dikme hesabı, PLMR Calculator taslak aktarımı, yan kayıt iç/dış ayarı, duvar/parapet Push/Pull, tüm 7 yerleşim, eski proje açma, undo/redo ve varsayılana dönme korunur. Taşı/Kopyala/Döndür ve ayrı proje bilgi editörü geri getirilmedi.

Ortak hosta gerçek montaj, sunucu kaydı, firma yetkisi, üretim paketi ve cephe ürün motorları bu teslimin kapsamı değildir. V49 özgün ZIP mevcut değildi; doğrulanmış V2 native donmuş kaynak ve tarihsel V49 byte-parite kaydı kullanıldı. Sac kalınlığı native kaynakta tanımlı değildir; sıfır kalınlıklı çift yüzlü sınır olarak kalır. Testler Chromium/SwiftShader yerel WebGL ve bağımsız dosya okumasıdır; bütün GPU’larda mutlak görüntü garantisi, AutoCAD/SketchUp uygulamasıyla ithalat testi veya imalat/statik onayı değildir.
