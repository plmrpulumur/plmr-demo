# V7 görsel inceleme kapsamı

Gerçek Chromium/SwiftShader sahnesinde kullanıcının iki bağımsız, arka hizalı sistemi açıldı. İlk genel görünüş ve dört gerçek pointer orbit görünüşü incelendi. Eğik üst bakışta kumaş boyunca eski sarı taşıyıcı izleri ve arka sac üzerindeki kayıt köşe çizgisi yeniden üretildi. Son yerel çizim sırası/stencil düzeltmesinden sonra aynı eğik üst bakış tekrar incelendi: kumaş yüzeyleri kesintisiz, sac destek teması temiz, öndeki mavi raylar ve yeşil doğramalar görünür kaldı. Parçaların native ölçüleri değiştirilmedi; sac oturma kotu gerçek destek üst köşesinden hesaplanır.

Tam kapalı görünüş, ara katlama, güncel ölçü menüsü, renkli 2D üst/ön/yan görünüş ve ortak logo kontrol edildi. PDF ayrıca bağımsız PyMuPDF ile tek sayfa olarak render edilip antet/logo/poz adları incelendi. Üçgen dış yüzlerinin kapanması yalnız görsele dayanmaz: sahne ve DAE kenar/hacim testi ayrıca vardır. Kamera/görünürlük işlemleri native modele yazmaz.

İç çalışma ekran görüntüleri, gerçek örnek proje dosyası ve test indirmeleri ZIP'e konulmadı. Raporlar tekrar çalıştırılabilir test kaynaklarıyla sunulur. Bu inceleme farklı GPU/sürücülerin tamamında mutlak görüntü garantisi değildir.
