PLMR JustPergola V7 · 7.0.0
ZIP'i tamamen çıkarın; Uygulama/index.html açın. 3D için WebGL gerekir.

Mouse: sol tuş döndür, sağ tuş kaydır, tekerlek/orta tuş yakınlaştır–uzaklaştır.
Zone Oluştur: üzerine gelince mavi vurgulanır; yan okla tavan/cephe/poz/tekil filtre.
Ayarlar: Üst Trapez Sac EVET/HAYIR ve Arka Taşıyıcı Duvar/Çelik eklendi.
Çelik arka açıklıklar da benzersiz Poz/Zone kodları taşır.
Yerleşim Seç: yedi native şema. Turuncu kenar ön oluğu gösterir.
Arka hiza örneği: ':' bağımsız gruplar + açılımda ;NO.
Push/Pull: yüz seç; mouse veya ölçü + Enter. Profiller de hizalama hedefidir.
Alt hizalamayı geçici kapatır; Shift mevcut hedefi kilitler; Escape iptal eder.
Kapat: tek kumaşı oluğa uzatır. Tam Aç: arkaya katlar. Ortak süre 5,2 saniye.
Kumaş taşıyıcıları alttadır; kapalı üst yüzeyde izleri görünmez.
Yeşil doğrama: 55mm derinlik, dış raydan dışa doğru 5mm net aralık.
Ayarlar içindeki PLMR Calculator dış taslağa aktarır; Uygula tek işlem kaydeder.
mm/inch ve ölçü filtreleri ortaktır. PDF (2D), DXF, DAE ve .plmr kayıt.
Taşı/Kopyala/Döndür ve ek proje bilgi düzenleyicisi yoktur.

Bağımsız pergola çizim paketidir; gerçek host/cephe montajı henüz bağlı değildir.
Yeni: kapalı doğramalar, sistem başına doğru yan kayıt hizası, kararlı temas yüzleri, güncel ölçü menüsü ve gerçek ortak logo.
Bağlantı haritası: BAGLANTI_REHBERI.md.
Kaynak, doğrulanan kapsam ve sınırlar: DEVIR_NOTU.md / Test-Mantik/KABUL.md.
