"""Independent DXF/Collada reader: no renderer or native geometry functions."""
from pathlib import Path
from collections import Counter
import json,sys,xml.etree.ElementTree as ET
folder=Path(sys.argv[1]);ns={'c':'http://www.collada.org/2005/11/COLLADASchema'}
root=ET.parse(folder/'edited.dae').getroot();solids=[];carriers=[]
for geo in root.findall('c:library_geometries/c:geometry',ns):
    name=geo.attrib.get('name','')
    is_carrier='kumas_tasiyici' in name.lower()
    if not is_carrier and not any(s in name.lower() for s in ['triangle-frame','gutter-cap','oluk_gutter']):continue
    mesh=geo.find('c:mesh',ns);arrays={s.attrib['id']:[float(v) for v in s.find('c:float_array',ns).text.split()] for s in mesh.findall('c:source',ns)}
    source=mesh.find('c:vertices/c:input',ns).attrib['source'][1:];a=arrays[source];points=[a[i:i+3] for i in range(0,len(a),3)]
    edges=Counter();directions=Counter();volume=0;triangle_count=0
    for triangles in mesh.findall('c:triangles',ns):
        inputs=triangles.findall('c:input',ns);stride=1+max(int(i.attrib.get('offset',0)) for i in inputs)
        offset=int(next(i for i in inputs if i.attrib['semantic']=='VERTEX').attrib.get('offset',0))
        raw=list(map(int,triangles.find('c:p',ns).text.split()));indices=raw[offset::stride]
        for i in range(0,len(indices),3):
            v=[points[j] for j in indices[i:i+3]];keys=[tuple(round(x*1000) for x in p) for p in v]
            assert len(set(keys))==3,(name,'degenerate');triangle_count+=1
            a,b,c=v;volume+=(a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6
            for j in range(3):
                p,q=keys[j],keys[(j+1)%3];key=tuple(sorted((p,q)));edges[key]+=1;directions[key]+=1 if p<q else -1
    assert all(n==2 for n in edges.values()),(name,'open/nonmanifold')
    assert all(n==0 for n in directions.values()),(name,'winding')
    assert volume>0,(name,'inward')
    (carriers if is_carrier else solids).append({'name':name,'triangles':triangle_count,'signedVolumeMm3':volume,'closed':True})
assert len(solids)>=10,len(solids)
assert len(carriers)>=8,len(carriers)
rows=(folder/'edited.dxf').read_text().splitlines();pairs=[(k.strip(),v) for k,v in zip(rows[::2],rows[1::2])]
assert any(k=='9' and v=='$INSUNITS' and pairs[i+1]==('70','4') for i,(k,v) in enumerate(pairs)), 'mm DXF units'
texts=[v for k,v in pairs if k in ['1','3']];assert not any('IPR-' in v for v in texts),'visible IPR text'
assert any(v=='PLMR - LOGO' for k,v in pairs if k=='2'),'shared logo block'
assert any(v=='OLCULENDIRME_MM' for k,v in pairs if k in ['2','8'])
print(json.dumps({'status':'PASS','scope':'independent XML/DXF parse; no external CAD application','closedExportedSolids':solids,'closedCarrierMeshes':len(carriers),'dxfMm':True,'noVisibleIPR':True,'sharedLogoBlock':True},indent=2))
