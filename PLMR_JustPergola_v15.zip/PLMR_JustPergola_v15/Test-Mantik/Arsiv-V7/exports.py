"""Independent structural checks of downloads, not a CAD import certification."""
from pathlib import Path
import json, math, sys, xml.etree.ElementTree as ET
p = Path(sys.argv[1])
ns = {'c':'http://www.collada.org/2005/11/COLLADASchema'}
root = ET.parse(p / 'edited.dae').getroot()
assert root.tag.endswith('COLLADA')
unit = root.find('c:asset/c:unit', ns)
assert unit is not None and float(unit.attrib['meter']) == .001
arrays = root.findall('.//c:float_array', ns)
for a in arrays:
    values = [float(v) for v in a.text.split()]
    assert len(values) == int(a.attrib['count']) and all(map(math.isfinite, values))
geometries = root.findall('c:library_geometries/c:geometry', ns)
assert len(geometries) > 20
ids = [e.attrib['id'] for e in root.iter() if 'id' in e.attrib]
assert len(ids) == len(set(ids))
for e in root.iter():
    for key in ['url','source','target']:
        ref = e.attrib.get(key, '')
        if ref.startswith('#'):
            assert ref[1:] in ids, ref
pdf = (p / 'edited.pdf').read_bytes()
assert pdf.startswith(b'%PDF') and pdf.rstrip().endswith(b'%%EOF')
try:
    from pypdf import PdfReader
    pages = len(PdfReader(p / 'edited.pdf').pages)
    assert pages >= 1
except ModuleNotFoundError:
    pages = 'not inspected with pypdf'
dxf = (p / 'edited.dxf').read_text().splitlines()
assert len(dxf) % 2 == 0
pairs = list(zip(dxf[::2], dxf[1::2]))
assert tuple(v.strip() for v in pairs[-1]) == ('0', 'EOF')
assert any(code.strip() == '2' and value == 'ENTITIES' for code,value in pairs)
print(json.dumps({'status':'PASS','dae':{'geometryCount':len(geometries),'unit':'mm','finiteArrays':len(arrays),'uniqueIds':True,'referencesResolved':True},'pdfPages':pages,'dxfPairs':len(pairs),'scope':'structural checks; no external CAD import'},indent=2))
