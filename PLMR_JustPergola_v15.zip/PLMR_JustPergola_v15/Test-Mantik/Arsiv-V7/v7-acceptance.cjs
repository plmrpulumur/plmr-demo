/* V7 user-reported scenario. The original sample is an external, read-only input. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright':'playwright');
const root=path.resolve(process.argv[2]),sample=path.resolve(process.argv[3]),out=path.resolve(process.env.PLMR_TEST_OUTPUT||'results');fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=await chromium.launch(JSON.parse(fs.readFileSync(process.env.PLMR_CHROMIUM_CONFIG)));
 const page=await browser.newPage({viewport:{width:1560,height:960},acceptDownloads:true});page.setDefaultTimeout(15000);
 const results=[],errors=[],failed=[];let step='load';
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.on('requestfailed',r=>failed.push(r.url()));
 const settle=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 const state=()=>page.evaluate(()=>PLMRJustPergolaApp.inspect());
 const record=(name,data={})=>{results.push({name,status:'VERIFIED',...data});console.log('PASS',name);};
 async function output(id,name){const event=page.waitForEvent('download');await page.locator(id).click();const file=await event;await file.saveAs(path.join(out,name));return file.suggestedFilename();}
 async function menu(){if(!await page.locator('#pergolaDimensionFilter').isVisible())await page.locator('#rrV11DimensionsBtnArrow').click();}
 try{
  await page.goto('file://'+root+'/Uygulama/index.html');
  await page.locator('#projectImportInput').setInputFiles(sample);
  await page.waitForFunction(()=>PLMRJustPergolaApp.inspect().parts?.length>0);await settle();
  let s=await state();assert(s.webgl);assert.equal(s.model.topology.raw.opening,'4500;5200;NO');
  const tracks=s.parts.filter(p=>p.kind==='glass-track');assert.equal(tracks.length,2);
  for(const [which,end]of [['0',4400],['right',5100]]){
   const track=tracks.find(p=>p.id.endsWith('-'+which));assert(track);
   assert(Math.abs(track.start[2])<.001);assert(Math.abs(track.end[2]-end)<.001);
   const post=s.parts.filter(p=>p.kind==='post').sort((a,b)=>a.start[0]-b.start[0])[which==='0'?0:4];
   assert(Math.abs(track.end[2]-post.bounds.min[2])<.01);
   assert(Math.abs((which==='0'?track.bounds.min[0]-post.bounds.min[0]:track.bounds.max[0]-post.bounds.max[0]))<.01);
  }
  record('Original independent rear-aligned sample: side tracks end at their own post rear face',{trackEndpoints:tracks.map(t=>({start:t.start,end:t.end}))});
  step='solids';const solids=await page.evaluate(()=>PLMRJustPergolaApp.inspectSolids());assert(solids.length>10);
  for(const solid of solids){assert.equal(solid.boundaryEdges,0,solid.name);assert.equal(solid.nonManifoldEdges,0,solid.name);assert.equal(solid.inconsistentEdges,0,solid.name);assert(solid.signedVolume>0,solid.name);}
  assert.equal(s.fabric.length,2);assert(s.fabric.every(f=>f.continuous&&f.spans.length>4));
  fs.writeFileSync(path.join(out,'solid-topology.json'),JSON.stringify(solids,null,2));
  record('Actual triangle frames, mullions, glazing, gutters and caps have closed, consistently outward topology',{meshes:solids.length,weldToleranceMm:.001});
  step='colors';assert.equal(s.model.drawingOptions.structureColor,'-3');
  for(const [kind,color]of Object.entries({'rail':'#0000ff','post':'#ff00ff','glass-track':'#d35400','triangle-frame':'#00bf00','gutter':'#ff0000'}))assert(s.meshRecords.some(m=>m.kind===kind&&[1,3,5].every(i=>Math.abs(parseInt(m.color.slice(i,i+2),16)-parseInt(color.slice(i,i+2),16))<=1)),kind);
  const text=await page.evaluate(()=>PLMRPergolaNative.drawing().entities.filter(e=>e.type==='text').map(e=>e.value).join('\n'));
  assert(!/IPR[- ]?0[12]/.test(text));assert(/PERGOLA · POZ 2/.test(text));
  record('Invalid paint is preserved as data and renders the native distinct palette; visible IPR codes removed');
  step='filters';await menu();await page.locator('[data-dimension-filter=all]').check();await settle();
  await page.locator('[data-dimension-filter=roofs]').uncheck();await settle();
  assert((await state()).measurements.filter(m=>['width','depth','height'].includes(m.key)).every(m=>!m.visible));
  assert(await page.evaluate(()=>PLMRPergolaNative.drawing().entities.filter(e=>e.type==='dimension'&&PLMRPergolaDimensions.describe(PLMRPergolaNative.drawing(),e).key==='width').every(e=>e.hiddenDimension)));
  await page.locator('[data-dimension-filter=roofs]').check();await settle();
  await page.locator('#pergolaDimensionFilter details[data-position="roof-main:1"] > summary').click();
  await page.locator('[data-dimension="roof-main:1:width"]').uncheck();await settle();
  s=await state();assert(s.measurements.find(m=>m.id==='roof-main|0|width').visible);assert(!s.measurements.find(m=>m.id==='roof-main|1|width').visible);
  assert(await page.evaluate(()=>PLMRPergolaNative.drawing().entities.filter(e=>e.edit?.dimId==='top_system_2_width').every(e=>e.hiddenDimension)));
  await page.locator('#pergolaDimensionFilter details[data-measurements="roof-main:1"] > summary').click();
  const one=page.locator('[data-measurement-id="roof-main|top_ray_spacing_1_0"]');await one.uncheck();await settle();
  assert(!(await state()).measurements.find(m=>m.id==='roof-main|top_ray_spacing_1_0').visible);
  assert(await page.evaluate(()=>PLMRPergolaNative.drawing().entities.find(e=>e.edit?.dimId==='top_ray_spacing_1_0').hiddenDimension));
  assert(await page.locator('[data-dimension="roof-main:1"]').evaluate(n=>n.indeterminate));
  await page.screenshot({path:path.join(out,'hierarchical-filter.png')});
  record('Current hierarchical categories, position width, individual native spacing and mixed checkbox drive both views');
  step='filter persistence';await page.keyboard.press('Escape');
  const savedDimensions=await page.evaluate(()=>PLMRPergolaScene.read().dimensions);
  await output('#rrV15ProjectDownload','filtered.plmr');
  await page.locator('#rrV11DimensionsBtn').click();await settle();
  await page.locator('#projectImportInput').setInputFiles(path.join(out,'filtered.plmr'));await settle();
  assert.deepEqual(await page.evaluate(()=>PLMRPergolaScene.read().dimensions),savedDimensions);
  await menu();await page.locator('[data-dimension-filter=all]').uncheck();await page.locator('[data-dimension-filter=all]').check();
  await page.locator('details[data-information] > summary').click();await page.locator('[data-dimension=information]').uncheck();await settle();
  assert(await page.evaluate(()=>PLMRPergolaNative.drawing().entities.filter(e=>e.presentationRole==='product-name').every(e=>e.hiddenInformation)));
  await page.locator('[data-dimension=information]').check();await page.keyboard.press('Escape');await settle();
  record('Dimension and individual filters survive native save/reopen; Information uses native name annotations');
  step='logo exports';const before=await page.evaluate(()=>JSON.stringify(PulumurProjectState.getModel()));
  const logo=await page.evaluate(()=>{const d=PLMRPergolaNative.drawing();return {name:d.metadata.companyDrawingLogo,count:d.blocks['PLMR - LOGO'].entities.length,closed:d.blocks['PLMR - LOGO'].entities.every(e=>e.closed),widths:d.blocks['PLMR - LOGO'].entities.map(e=>e.strokeWidth)};});
  assert.equal(logo.name,'PLMR_2D_Logo_V1');assert.equal(logo.count,6);assert(logo.closed);assert(logo.widths.every(n=>n===.76));
  const expected=await page.evaluate(()=>PLMRDrawingOutputNames.safeName(PLMRPergolaDocument.projectInfo(PLMRPergolaNative.legacy().formData),'dxf'));
  await page.locator('#rrV45Mode2DBtn').click();const dxfName=await output('#rrV45DxfBtn','edited.dxf');assert.equal(dxfName,expected);
  await output('#rrV45Pdf2dBtn','edited.pdf');await page.screenshot({path:path.join(out,'native-2d.png')});
  await page.locator('#rrV45Mode3DBtn').click();await settle();const daeName=await output('#rrV45DaeBtn','edited.dae');assert.equal(daeName,expected.replace(/\.dxf$/,'.dae'));
  assert.equal(await page.evaluate(()=>JSON.stringify(PulumurProjectState.getModel())),before);
  record('Actual V34 logo, project-revision DXF/DAE filenames, CAD policy and real PDF/DXF/DAE downloads',{logo,filenames:{dxf:dxfName,dae:daeName}});
  step='camera contacts';await page.screenshot({path:path.join(out,'contacts-start.png')});
  const canvas=page.locator('#model3d > canvas'),box=await canvas.boundingBox();
  for(let i=0;i<4;i++){
   await page.mouse.move(box.x+box.width*.42,box.y+box.height*.45);await page.mouse.down();await page.mouse.move(box.x+box.width*.42+120,box.y+box.height*.45+(i%2?35:-20),{steps:18});await page.mouse.up();await page.waitForTimeout(180);await settle();
   await page.screenshot({path:path.join(out,'contacts-orbit-'+i+'.png')});
  }
  await page.mouse.move(box.x+box.width*.42,box.y+box.height*.4);await page.mouse.down();await page.mouse.move(box.x+box.width*.42,box.y+box.height*.4-250,{steps:24});await page.mouse.up();await page.waitForTimeout(220);await settle();
  let contacts=await page.evaluate(()=>PLMRJustPergolaApp.inspectContacts());
  for(let attempt=0;attempt<6&&!contacts.contacts.flat().filter(c=>c.name.startsWith('Kumaş taşıyıcı')).every(c=>c.depthWrite);attempt++){
   await page.locator('[data-legacy-id=toolbarZoomInBtn]').click();await page.mouse.move(box.x+box.width*.42,box.y+box.height*.35);await page.mouse.down();await page.mouse.move(box.x+box.width*.42,box.y+box.height*.35-250,{steps:18});await page.mouse.up();await page.waitForTimeout(150);await settle();contacts=await page.evaluate(()=>PLMRJustPergolaApp.inspectContacts());
  }
  assert.equal(contacts.depthBits,24);assert(contacts.contacts.flat().filter(c=>c.name.startsWith('Kumaş taşıyıcı')).every(c=>c.depthWrite),'carrier remains opaque from below');
  await page.screenshot({path:path.join(out,'carriers-underside.png')});
  assert.equal(await page.evaluate(()=>JSON.stringify(PulumurProjectState.getModel())),before);
  assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);
  record('Four exterior orbit views and the opaque carrier underside render without errors; native project unchanged');
  fs.writeFileSync(path.join(out,'v7-acceptance.json'),JSON.stringify({status:'PASS',environment:'Chromium 151 / ANGLE SwiftShader / file://',results,errors,failedResources:failed},null,2));
 }catch(error){await page.screenshot({path:path.join(out,'failure.png')}).catch(()=>{});fs.writeFileSync(path.join(out,'failure.json'),JSON.stringify({step,error:error.stack,results,errors,failed},null,2));throw error;}
 finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
