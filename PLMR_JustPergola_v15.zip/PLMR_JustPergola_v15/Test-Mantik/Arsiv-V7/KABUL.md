# V7 geçerli kabul matrisi

Tek güncel giriş budur. Tarihsel `Arsiv-V2` … `Arsiv-V6` raporları bu sürümün kabulü sayılmaz. Yerel Chromium 151 / ANGLE SwiftShader / file:// kullanıldı; denetleyiciler sadece okur. Kullanıcı işlemleri gerçek buton, form, klavye ve pointer üzerinden yapıldı.

| Talep / işlem | Beklenen ve korunan sonuç | Kanıt |
|---|---|---|
| Gerçek örneği aç; yan kayıtları 2D/3D incele | 4500/5200 arka hizalı sistemlerde 4400/5100 bitiş; dış yüzler ön dikmeyle aynı | `v7-acceptance.json`; `v49-placement.json`; `v7-model.json` |
| V49 yerleşimini koru | Tek/çoklu/artan açılım ön hizalı 4 durumda native yan kayıt poligonları aynı | `v49-placement.json` |
| Üçgen ve kapakların dış yüzleri | Gerçek 13 mesh’te açık/nonmanifold/yön tutarsız kenar yok; pozitif signed volume | `solid-topology.json`; `export-geometry.json` |
| Profil/sac/kumaş temas izleri | Kayıt üst köşe zarfına oturan sac; fiziksel parçaları değiştirmeyen yerel derinlik/stencil sırası; tek sürekli kumaş; üstten ve orbit kontrol | `v7-acceptance.json`; `v7-interaction.json`; `VISUAL_REVIEW.md` |
| Güçlü profil renkleri | Geçersiz -3 ham değer korunur; native ayırt edici renkler; geçerli boya çalışır | `v7-acceptance.json`; `v7-browser.json` |
| Güncel ölçü filtresi | Kategoriler, poz/yön, tekil ara ölçü, karma durum; 2D/3D aynı veri, kayıt sonrası aynı | `v7-acceptance.json`; `v7-regression.json` |
| Ortak logo / görünür poz adı | Aynı 6 kapalı logo konturu; IPR yalnız iç kimlik; görünen POZ adları | `v7-acceptance.json`; `export-geometry.json`; `V7_SHARED_ORIGINS.json` |
| DXF/DAE indir; PDF indir | Proje–revizyon adı, CAD palette yolu, mm / katman / grup / kapalı export mesh; indirme modeli yazmaz | `v7-acceptance.json`; `exports-sample.json`; `export-geometry.json`; `exports-current.json`; `exports-steel.json` |
| Güncel mouse, zone hover ve filtre; Push/Pull hizala | Ortak kamera, mavi vurgu, profil yüzüne snap; Alt/Shift/Escape ve native commit | `v7-interaction.json`; `v7-browser.json` |
| Kumaşı aç/kapat | Taşıyıcı altta, sistem başına tek kumaş, ortak Antero hız/yönü; native model değişmez | `v7-browser.json`; `v7-interaction.json` |
| Ayarlar / Calculator / eski kayıt / undo–redo | Taslak iptali, atomiklik, eski V1/V3/V5 kayıtlar ve kimlikler korunur | `v7-regression.json`; `v7-compatibility.json`; `v7-browser.json` |
| 7 yerleşim, otomatik ray/dikme, duvar/parapet/çelik | Mevcut native hesap ve zone sahipliği korunur | `v7-model.json`; `v7-interaction.json`; `v7-browser.json` |
| Sahneyi 13 kez yeniden çiz | Üç ısınma sonrası geometri/texture ve canvas/kök sayısı sabit | `v7-lifecycle.json` |
| Temiz bağlantı hazırlığı | Gerçek buton kaynağı, veri akışı, logo yolu ve yaşam döngüsü sınırı kayıtlı | `../BAGLANTI_REHBERI.md`; `../BUTTON_MAP.json` |
| Kaynak / build / teslim | 87 JS syntax; 122 runtime dosya byte eşitliği; provider hash; ZIP CRC/hash; temiz çıkarıp WebGL açma | `source-check.json`; `package-check.json`; `package-smoke.json` |

Toplam: 47 tarayıcı senaryo grubu, 17 native model durumu, 4 V49 yerleşim karşılaştırması. Bağımsız DAE kontrolü 13 üçgen/cam/oluk/kapak katısını ve 18 kumaş taşıyıcı katısını tekrar doğrular. Bu sayılar işlev/mühendislik kapsamı puanı değildir.

Kapsam dışı: canlı host/firma entegrasyonu, dış CAD uygulamasıyla import ve üretim/statik onayı. Gerçek kullanıcı dosyası teste dışarıdan salt okunur girdi olarak verildi; teslimde kişisel örnek kayıt ve iç çalışma ekran görüntüsü yoktur. `VISUAL_REVIEW.md` hangi görünümlerin incelendiğini açıklar.
