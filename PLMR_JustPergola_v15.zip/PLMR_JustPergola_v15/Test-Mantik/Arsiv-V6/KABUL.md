# V6 güncel kabul — 09.11.2026

Tek güncel giriş bu dosyadır. Eski raporlar `Arsiv-*` altındadır. Kaynak bağı `ACCEPTANCE_SOURCES_SHA256.json`; köken `Development_Protocol/V6_SHARED_ORIGINS.json`.

| Talep / gerçek kullanıcı işlemi | Beklenen ve doğrulanan davranış | Kanıt |
|---|---|---|
| Mouse sol/sağ/tekerlek | V34 .08 damping, orbit/pan/dolly; kareler ilerler, model değişmez | v6-interaction.json |
| Zone üstüne gel/çık | Mavi .018→.16; çıkışta normal; fiziksel parça önceliği | v6-interaction.json |
| Profil ekle, Push/Pull yaklaş | Native 2D'den yatay profil eklenir; gerçek profil alt yüzüne snap; Alt iptal | v6-interaction.json |
| Aç/kapat ve ters hareket | Ortak Antero 5200ms saati; ara katlanma; model aynı | v6-interaction.json |
| Arka mekanizma | Gerçek dünya sınırında duvarla sıfır temas; native plan/yan/3D ortak zarf | v6-interaction.json, v6-model.json |
| Üçgen ve diğer profiller | Gerçek mesh ile 5mm dış aralık/55mm derinlik; travers130; kayıt/dikme hizası | v6-interaction.json, v6-browser.json, v6-model.json |
| Trapez/izler/renk | Sac üst normal ve ayrı renk; örtülü kumaş taşıyıcı birleşimi; kapalı görüntü incelemesi | v6-interaction.json |
| Sac seçeneği ve çelik | Ayarlar native 2D/3D'yi değiştirir; yeniden açmada false ve çelik profiller korunur | v6-compatibility.json |
| Arka çelik zone | Dikme iç yüzleri/kiriş altından ölçülür; çoklu sistemde benzersiz yapısal ID; UID/kod kayıtla korunur ve cephe filtresini izler | v6-compatibility.json, v6-model.json |
| Yerleşim kartları | Yedi kart UI'den uygulanır; şema native; açıklamalar sarılır; arka hiza doğru; bozuk ':' atomik ret | v6-interaction.json |
| Önceki düzenlemeler/kayıt | Auto ray/post, seçenekler, Calculator, profil seç/kaydır, undo/redo, V1/V3/V5 açma | v6-browser.json, v6-regression.json, v6-compatibility.json |
| Ölçü/çıktı | Fiziksel birim değişmez; standart ve çelik PDF/DXF/DAE yapısı doğru | v6-model.json, exports-current.json, exports-steel.json |
| Kaynak/paket | 81 JS syntax, 115 dosya kaynak eşleşmesi; CRC/hash ve temiz WebGL açılışı | source-check.json, package-smoke.json, package-check.json |

18 ana + 10 regresyon + 8 etkileşim + 3 kayıt/çıktı = **39 kontrol grubu**. Ayrıca **17 CPU/model senaryosu** ve yedi kartın hizaları kontrol edildi. Tekrarlar sayılmadı. Chromium 151 / ANGLE SwiftShader / file:// / 1560×960. Console hatası yok; ana ve etkileşim akışlarında başarısız varlık yükü yok. Kısa temiz paket açılışı 1440×900.

Görsel inceleme: kapalı kumaş, katlanma ara durumu, mavi zone hover, sarılmış açıklamalı kartlar ve PDF sayfaları açılıp incelendi. İç ekran görüntüleri pakete eklenmedi.

Başlıca gerçek kök nedenler: eksik kamera kare döngüsü; profile özgü snap referanslarının olmaması; 850ms ayrı hareket; sacın aşağı bakan yüzü/FrontSide; mekanizmanın tüm zarfının ray ek noktasının arkasına konması; elle çizilmiş yanlış yerleşim kartı; saf ':' girdisini reddeden ilk-sayı kontrolü; steel profileHeight NaN. Arka zone ID'si sistem kimliği bulunmayan standart düzende açık fallback ile benzersizleştirildi.

Test düzeltmeleri: native commit sonrasında iki RAF ile render tamamlanması beklenir; filtre mixed ise önce check, sonra uncheck; source ve world koordinatları karıştırılmaz. Snap mevcut V34 18px tutma kuralında ilk karşılaşılan alt profil yüzünü korur; beklenen gerçek temas yüzüyle karşılaştırıldı. Bunlar model değiştirerek testi geçirme işlemleri değildir.

Sınırlar: gerçek FinalProcess host entegrasyonu, cephe montajı ve native arka cephe profil editörü bu bağımsız aşamada yoktur. Desteklenmeyen arka edit ön cepheyi değiştirmez. Eğimli parapetler native 2D editöründedir. Donanım GPU/mobil performansı, CAD yazılımında import, üretim ve canlı servis doğrulaması yapılmadı.
