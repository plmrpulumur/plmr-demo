# PLMR JustPergola V6 — 6.0.0

09.11.2026. Güncel kabulün tek girişi `Test-Mantik/KABUL.md`.
Başlangıç `plmr_justpergola_v5.zip`, SHA256 `f49fc34f6ca1c225a94041e4c6ef06de097793521fdc0ace170e8e56eb70a6e7`. Özgün V5 korunur. V6 ayrı çalışma kopyasıdır; canlıya yüklenmedi.

## Çalıştırma ve kaynak

ZIP'i tamamen çıkarın; `Uygulama/index.html` açın. Sunucu/npm gerekmez; 3D WebGL gerektirir.

- `Development_Protocol/peri01`: yetkili native ProjectModel, doğrulama, 2D geometri, history, kayıt ve export.
- `Development_Protocol/source`: pergola arayüzü ve native modelden türetilmiş 3D. `pergola-parts.js` salt okunur projeksiyondur.
- `Development_Protocol/shared`: ortak antet, birim ve Antero hareketi. `shared/v34/scene-interaction.js` ortak kamera ayarı ve V34'ten birebir çıkarılan zone vurgusunu sağlar. `scene-reference-geometry.js` gerçek mesh yüz düzlemlerini mevcut snap politikasına bağlar.
- `V34_SHARED_ORIGINS.json` başlangıç referans hashleri; `V34_ADAPTER_STATUS.json` güncel uyarlama/silme durumu; `V6_SHARED_ORIGINS.json` kamera/hover/hareket/hizalama kökeni. `V4_SHARED_ORIGINS.json` kullanılan eski ortak antet/tarih/motor köken kaydıdır.
- `Uygulama` yalnız build çıktısıdır; ayrı elle yama yapılmaz. `SOURCE_SHA256.json`, `Test-Mantik/ACCEPTANCE_SOURCES_SHA256.json` ve kendisini dışarıda bırakan `PACKAGE_SHA256.json` kaynak–kanıt–teslim bağını kurar.

```bash
python3 Development_Protocol/build.py
python3 Test-Mantik/verify-source.py .
node Test-Mantik/v6-model.cjs .
# Playwright/Chromium mevcut olmalı. Config JSON'u executablePath ve args içerir.
# PLMR_CHROMIUM_CONFIG ve PLMR_TEST_OUTPUT ortam değişkenlerini ayarlayın.
node Test-Mantik/v6-browser.cjs .
node Test-Mantik/v6-regression.cjs .
node Test-Mantik/v6-interaction.cjs .
node Test-Mantik/v6-compatibility.cjs .
python3 Test-Mantik/exports.py "$PLMR_TEST_OUTPUT"
python3 Development_Protocol/package.py /mutlak/yol/plmr_justpergola_v6.zip
```

## Son geçerli kararlar ve V6 değişiklikleri

Kamera güncel V34 ayarını kullanır: damping .08, ekrana göre pan, sol tuş döndürme, orta tuş/tekerlek yakınlaştırma ve sağ tuş kaydırma. V5'te damping ayarı ve onu her karede ilerleten döngü eksikti; sürekli aktif 3D döngüsü eklendi. 2D'de/gizli sayfada durur; tekrar görünürken model değişmeden devam eder. Kamera ve animasyon kalıcı model/history yazmaz.

Zone hover, V34 cephe davranışındaki mavi renkle (#38bdf8) .018 pasiften .16 vurguya geçer. Çıkışta/filtrede vurgu temizlenir; fiziksel profil önceliği korunur. Kullanıcının mavi zone talebi pergola tavanında da aynı ortak vurguyla uygulanır; V34 tavan seçicisinin turuncu rengini buraya taşımak amaçlanmadı. Benzersiz Poz adı/UID, tavan/cephe/poz/tekil filtre ve kod araması korunur.

Push/Pull, mevcut V34 11 piksel yakalama / 18 piksel bırakma, Alt bypass ve Shift kilit mantığını korur. Sadece tüm ürün zarfına değil gerçek ray/dikme/kayıt ve eklenen yatay profil yüzlerine de referans verir. Referanslar gerçek mesh matrislerinden okunur, ana modele kopyalanmaz. Yeni geometride referans önbelleği geçersizleşir. Komşu duvar/parapet çakışma kontrolü ve native 2D hücre/segment commit yolu korunur.

Kumaş aç/kapat artık özgün ortak Antero animationDuration/Clock/Progress sağlayıcısını ve 5200ms süresini kullanır. Eski bağımsız 850ms hareketi kaldırıldı. Kapat=oluğa uzatma, Tam Aç=arkaya toplama; her sistemde tek en boyunca kumaş. Kumaş taşıyıcı üstünü örter, sarkma taşıyıcı yüzünden sonra başlar. Polygon offset eş düzlemdeki yüzlerin renk çakışmasını azaltır. Kapalı kumaşın üstündeki taşıyıcı izleri giderildi; gerçek taşıyıcılar kumaş altında kalır, silinmez.

Trapez sacın ters üçgen yüz yönü ve varsayılan tek yüz materyali üstten görünmesini engelliyordu. Üst normal ve DoubleSide düzeltildi; ayrı gri-mavi (#8296a8) varsayılan renk verildi. Ayarlar → Üst Trapez Sac EVET/HAYIR hem 2D hem 3D'ye bağlıdır. Native kalıcı alan `frontView.trapezSheetEnabled`; eski kayıtlarda true varsayılır. Açık kapalı kumaştan bağımsız sabit sac yerleşimi ve düzenlenmiş native sınırlar korunur.

Arka ray mekanizmasının eski adaptörü tüm prizmayı ray başlangıcının arkasına koyarak duvarın içine taşıyordu. Native `rearMechanismEnvelope` artık 2D yan görünüş ile 3D'nin tek sahibidir. Native üst blok sınırından 92×346mm plan zarfı ve native yan bloktan 150mm normal yükseklik alınır. Arka yüz destek ön düzlemine dik ve sıfır temaslıdır; üst/alt yüz ray eğimini izler. 2D yan görünüşte eski farklı blok yerleşimi yerine aynı fiziksel zarf kullanılır; üst görünüş blok konturları korunur. Trapezin yan görünüş yüz çizgisi de aynı ray üst kotunu izler. Bunlar sade dış zarflardır, ayrıntılı mekanik/üretim CAD'i değildir.

Üçgen doğramanın 55mm derinliği ve dış ray yüzünden dışarı doğru net 5mm mesafesi gerçek oluşmuş mesh sınırlarıyla kontrol edildi. Mesafe ekranda daha görünür olsun diye fiziksel ölçü abartılmadı. Travers 130mm, yan kayıt sağ/sol/ofset/uzunluk ve ön dikmeyle varsayılan yüz hizası korunur. Native canlı profil renkleri aynı sağlayıcıyla 3D'ye geçer.

Ayarlar → Arka Taşıyıcı Duvar/Çelik mevcut native rearSupport alanına bağlanır; ikinci model yoktur. Çelikte arka dikme/kirişin gerçek açıklıkları zone olur. Her sistem ayrı stabil yapısal anahtarla adlandırılır; birden çok sistemde aynı UID/kod üretilmez. Kiriş alt yüksekliği ve dikme iç yüzleri zone ölçüsünü belirler. Çelik modunda 2D üst/yan görünüşte eski dolu duvar taraması artık çizilmez; duvar hücreleri kayıt içinde korunur ve Duvar seçimine dönünce geri kullanılır. Çelik kiriş üzerindeki native düzenleyici erişimi korunur. Native çelik profil metadata'sındaki uygulanamaz dikme profileHeight NaN değeri kaldırıldı; kiriş yüksekliği gerçek değer olarak kalır.

Yerleşim kartlarının şemaları elle tahmin edilmiş dikdörtgenler yerine native parserdan ölçekli üretilir. Açıklamalar sarılır ve ön oluk turuncuyla belirtilir. Yedi seçenek vardır. Arka hiza native kural gereği ':' bağımsız grupları ve açılım ;NO ile örneklenir. Saf ':' genişliklerinin preflight'ta yanlış reddedilmesi düzeltildi: ilk sayıyı okuyan eski kontrol yalnız ';' ayırıyordu. Geçersiz kolon/boşluk girdileri hâlâ native doğrulamada atomik reddedilir.

## Korunan önceki kararlar ve kayıt

Native hesap/ProjectModel tek kalıcı kaynaktır. Otomatik ray/dikme, manuel sayıdan temizleyerek otomatiğe dönüş; motor/kumanda/kumaş/LED, standart dışı su çıkışı; Ayarlar içindeki Calculator taslağı ve tek undo işlemi korunur. Güncel ortak antet/metadata, mm–inch katmanları/filtreleri ve PDF/DXF/DAE/native .plmr çıktıları korunur. Proje bilgileri ek düzenleyicisi ve Taşı/Kopyala/Döndür aktif komutları geri eklenmedi. Eski kopya/poz verileri pasif uyumlulukla korunur; veri silen migration/reset yoktur. V5 devir ayrıntısı `Test-Mantik/Arsiv-V5/DEVIR_NOTU_V5.md` içindedir.

## Gerçek doğrulama ve sınırlar

18 ana, 10 regresyon, 8 etkileşim ve 3 kayıt/çıktı **kontrol grubu** geçti; ayrıca 17 CPU/model senaryosu ve yedi kartın native hizası kontrol edildi. Tekrar koşuları ayrı kapsam sayılmadı. Ortam Chromium 151 / ANGLE SwiftShader, file://, 1560×960. 81 JS sözdizimi, 115 runtime kaynak eşleşmesi; gerçek indirilen standart/çelik PDF–DXF–DAE dosyalarında bağımsız yapı kontrolü. Kapalı kumaş, ara katlanma, zone hover, yerleşim kartları ve PDF sayfaları gerçekten açılıp incelendi.

Test senkronizasyonu model commit'i ile sonraki render karesini ayırır; bekleyen sahneyi eski veriyle karşılaştırmaz. Karışık filtre durumunda önce tam seçip sonra kapatma uygulanır. Farklı koordinat uzayları (source/world) ayrı ölçülür. Bunlar ürün doğrulamasını atlamak için state değiştirme değildir.

Temiz çıkarma/WebGL açılışı `Test-Mantik/package-smoke.json`; dosya eşleşmesi ve CRC/hash sonucu `package-check.json`. İç tarayıcı ekran görüntüleri veya Chromium/cache teslimde yoktur. V5/V4/V3/V2 kanıtları tarihsel arşivdir.

Bu bağımsız çizim paketi henüz FinalProcess ortak ekranına canlı olarak kurulmadı. Ortak kamera/hover/hareket ve inference sınırları hazırdır; gerçek host montajının ayrıca doğrulanması gerekir. Cephe ürünlerinin gerçek montajı hâlâ bağlı değildir; Çoklu Ürün Ekle/Sil önceki açık sınırını korur. Arka çelik zone'ları ölçü/kimlik/filtre taşır; desteklenmeyen native arka profil düzenlemesi yanlışlıkla ön cepheye yönlendirilmez. Eğimli parapetler native 2D editörünü kullanır. Donanım GPU/mobil, harici CAD import, üretim uygunluğu ve bulut/teklif/AR/paylaşım servisleri sınanmadı.

V6 kapsamındaki zorunlu güncellemede açık hata yoktur. Sonraki adım kullanıcı incelemesidir.
