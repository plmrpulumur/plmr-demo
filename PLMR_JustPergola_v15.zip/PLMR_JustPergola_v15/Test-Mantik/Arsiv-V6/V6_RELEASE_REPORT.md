# V6 değişiklik raporu

V5 üzerindeki kamera, zone hover, hizalama, hareket ve görünürlük sorunları düzeltildi. Kamera V34 ayarıyla her karede ilerler; zone'lar mavi belirginleşir. Snap gerçek profil yüzlerini de kullanır. Kumaş Antero'nun ortak 5200ms saatini kullanır; kapalı üst yüzeyde taşıyıcı izleri giderildi.

Trapez sacın yüz yönü düzeltildi ve görünür ayrı renk verildi. Native sac aç/kapat ve duvar/çelik seçimi eklendi. Çelik arka açıklıklar benzersiz, kalıcı zone olur; 2D’de kalan eski duvar taraması kaldırılarak 3D ile eşlendi, duvar verisi korundu. Mekanizma native ortak zarfla duvar önünde hemyüzdür; aynı yan görünüş kullanılır. Üçgenin net 5mm dış aralığı gerçek mesh üzerinde doğrulandı.

Yerleşim kartları native veriden çizilir, açıklamalar sarılır. Yanlış arka hiza örneği ve saf ':' girişinin ön kontrolde reddedilmesi düzeltildi. Eski kayıtlar korunur; eklenen seçenek varsayılan true ile tamamlanır.

39 gerçek tarayıcı kontrol grubu ve 17 CPU/model senaryosu geçti; standart/çelik PDF–DXF–DAE bağımsız kontrolden geçti. Güncel kabul Test-Mantik/KABUL.md. Kaynak ve runtime eşleşir; canlı host/cephe montajı henüz yapılmadı.
