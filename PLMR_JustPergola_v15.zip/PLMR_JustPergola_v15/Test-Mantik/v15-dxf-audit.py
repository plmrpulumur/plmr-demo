"""Independent ezdxf audit; reference interpreter is NOT an AutoCAD reactor test."""
import json, math, sys
from pathlib import Path
import ezdxf
folder=Path(sys.argv[1]);baseline=Path(sys.argv[2]) if len(sys.argv)>2 else None
names=['Lean','Lean-Suspend','Curve','Curve-Quad','Curve-Quad-Wing']
results=[]
def snaps(assoc):
    groups=[]
    for t in assoc.xtags.subclasses[1]:
        if t.code==1 and t.value=='AcDbOsnapPointRef':groups.append({})
        elif groups:groups[-1][t.code]=t.value
    return groups

def resolve(doc,ref):
    g=doc.entitydb[ref[331]];kind=g.dxftype();param=ref[40]
    if kind=='LINE':
        a,b=g.dxf.start,g.dxf.end
        assert ref[91]==0 and ref[73]==0
    else:
        assert kind=='LWPOLYLINE'
        ps=list(g.get_points('xy'));marker=ref[91]
        assert ref[73]==2 and 1<=marker<=len(ps)-(not g.closed)
        a,b=ps[marker-1],ps[marker%len(ps)]
        param=param-(marker-1)
    assert -1e-7<=param<=1+1e-7
    p=(a[0]+param*(b[0]-a[0]),a[1]+param*(b[1]-a[1]),0)
    assert math.dist(p,ref[10])<.002,('WCS reference disagrees with actual edge',p,ref)
    return p
for name in names:
    doc=ezdxf.readfile(folder/(name+'.dxf'));audit=doc.audit();assert not audit.errors
    dims=list(doc.modelspace().query('DIMENSION'));assocs=[e for e in doc.objects if e.dxftype()=='DIMASSOC']
    assert len(dims)>3 and assocs
    assert doc.header['$DIMASSOC']==2
    for d in dims:
        assert d.dxf.text=='<> mm' and d.get_measurement()>0
    nearest=0
    linked=set()
    for assoc in assocs:
        tags=assoc.xtags.subclasses[1];h=next(t.value for t in tags if t.code==330)
        dim=doc.entitydb[h];linked.add(h)
        assert dim.dxftype()=='DIMENSION' and dim.get_extension_dict().get('ACAD_DIMASSOC') is assoc
        assert assoc.dxf.handle in dim.get_reactors()
        assert any(t.code==90 and t.value==3 for t in tags)
        refs=snaps(assoc);assert len(refs)==2
        for ref,base in zip(refs,[dim.dxf.defpoint2,dim.dxf.defpoint3]):
            p=resolve(doc,ref);g=doc.entitydb[ref[331]]
            assert assoc.dxf.handle in g.get_reactors()
            angle=math.radians(dim.dxf.get('angle',0));u=(math.cos(angle),math.sin(angle))
            error=(p[0]-base.x)*u[0]+(p[1]-base.y)*u[1]
            assert abs(error)<.002,('Wrong measured coordinate',name,error)
            nearest+=ref[72]==10
    # Move only a real profile vertex. Decode existing DIMASSOC references,
    # update the dimension and regenerate its anonymous block with ezdxf.
    # This proves reference resolution, not native CAD automatic notifications.
    example=None
    for assoc in assocs:
        refs=snaps(assoc)
        if any(r[72]!=1 for r in refs) or refs[0][331]!=refs[1][331]:continue
        g=doc.entitydb[refs[0][331]]
        if g.dxftype()!='LWPOLYLINE':continue
        h=next(t.value for t in assoc.xtags.subclasses[1] if t.code==330);dim=doc.entitydb[h]
        if abs(dim.dxf.get('angle',0))>.001:continue
        before=dim.get_measurement();ps=list(g.get_points());ref=refs[1];i=int(round(ref[40]))%len(ps)
        ps[i]=(ps[i][0]+125,*ps[i][1:]);g.set_points(ps)
        resolved=[]
        for r in refs:
            # Recorded WCS is the pre-edit location, so resolve param directly.
            vs=list(g.get_points('xy'));j=r[91]-1;t=r[40]-j;a,b=vs[j],vs[(j+1)%len(vs)]
            resolved.append((a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]),0))
        dim.dxf.defpoint2,dim.dxf.defpoint3=resolved;after=dim.get_measurement()
        assert abs(after-before-125)<.002
        dim.render();example={'beforeMm':before,'afterMm':after,'scope':'geometry edit + explicit DIMASSOC reference interpreter + ezdxf render; not native CAD STRETCH'};break
    assert example
    old=None
    if baseline:
        olddoc=ezdxf.readfile(baseline/(name+'.dxf'));old=sum(e.dxftype()=='DIMASSOC' for e in olddoc.objects)
    results.append({'product':name,'dimensions':len(dims),'associations':len(assocs),'baselineAssociations':old,'nearestEdgeReferences':nearest,'unassociatedDimensions':len(dims)-len(linked),'referenceResolution':example,'auditErrors':len(audit.errors)})
report={'status':'PASS','scope':'DXF structure and correct physical edge references; native AutoCAD STRETCH NOT TESTED','results':results}
(folder/'v15-dxf-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','dimensions':sum(x['dimensions'] for x in results),'associations':sum(x['associations'] for x in results),'baselineAssociations':sum(x['baselineAssociations'] or 0 for x in results)},ensure_ascii=False))
