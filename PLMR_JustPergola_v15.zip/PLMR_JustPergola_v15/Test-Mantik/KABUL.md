# V15 güncel kabul kaydı

Durum: **DEVELOPMENT / kısmi doğrulama**. Zorunlu CAD ve ticari entegrasyon kabulleri açık. Bu dosya güncel kanıtların girişidir. V11–V14 isimli eski JSON kayıtları tarihsel kanıttır; yalnız `v15-output` altındaki yeni koşu kayıtları V15 değerlendirmesine aittir.

| Kabul | Gerçek durum | Kanıt |
|---|---|---|
| Kaynak, JS sözdizimi, kaynak–dağıtım eşleşmesi | PASS | `v15-output/source-check.json` |
| 2 seri × 9 ürün × 7 yerleşim | PASS, 126 standart + 126 çelik + 126 camlı model | `v15-output/model-matrix*.json` |
| Ray +30 mm / sürekli Curve-Quad +30/+30; montaj delikleri; sağ görünüş varlığı/arka görünüş yerleşimi | PASS, 63 vaka / 2009 assertion | `v15-output/v12-acceptance.json` |
| Gerçek V14–V15 fiziksel 2D/3D karşılaştırması | PASS, 63 ürün/yerleşim | `v15-output/v15-native-parity.json` |
| Çoklu görünüş sahipliği/yerleşimi | PASS, 56 vaka | `v15-output/v11-multiple-views.json` |
| Curve-Quad plan adı merkezi | PASS, 14 poz | `v15-output/v14-top-centering.json` |
| mm/inch/çift gösterim DXF | PASS, 27 ürün/birim vakası | `v15-output/v14-dxf-unit-matrix.json` |
| Gerçek DIMENSION, sözlük/handle/reactor ve fiziksel koordinat referansları | PASS, 5 DXF / 70 ölçü / 33 ilişki | `v15-output/v15-dxf-audit.json` |
| Bütün ölçülerin doğru geometriye CAD düzeyinde bağlanması | **AÇIK: 37 ölçü bağlantısız; mevcut 33 ilişkinin AutoCAD davranışı da sınanmadı** | `v15-output/v15-dxf-audit.json`, `DXF_ACIK_ISLER.md` |
| Geometriye STRETCH, AutoCAD kayıt/aç, DIMREGEN | NOT TESTED; AutoCAD yok | `autocad/KABUL.md` |
| Çelik seç → sil → yenile → undo → redo → kaydet → kapat → aç | PASS, gerçek fare/klavye/form/dosya/Chromium WebGL | `v15-output/v15-browser.json`, `v15-browser-2d.json` |
| Ara ölçü ve native seçili ölçü gizle/göster, gizliliği kaydet/aç, 2D/3D/DXF | PASS, gerçek arayüz | aynı kayıt |
| Ürün seçimi, iptal, kayıt, çıktı ve WebGL regresyonu | PASS, 30 ürün/yerleşim senaryosu, 9 kayıt/çıktı ailesi | `v15-output/v15-products.json` |
| Native DXF/PDF/DAE bağımsız ayrıştırma | PASS, 9 ürün | `v15-output/v15-formats.json` |
| Yenilemede GPU sayaçları | PASS, sabit sahnede 7 örnekte kararlı; genel performans garantisi değil | `v15-output/v15-products.json` |
| V51 çizim motoru ürün seçicisi, ana snapshot, geçmiş, kilit, yerel .plmr kayıt/aç, native SVG ve görüntü aktarımı | PASS, gerçek motor + sentetik üst bağlam | `v15-output/v15-integration-browser.json` |
| Gerçek kullanıcı/firma ile ana React uygulaması → Supabase kayıt → revizyon → teklif/üretim | **BLOCKED**; yeni ticari ürün sözleşmeleri ve yeniden derlenebilir ana istemci kaynağı eksik | `../Entegrasyon/COMMERCIAL_MAPPING.md` |
| Yayımdaki sunucu firma/rol mantığı | Salt okunur kaynak incelemesi + sentetik backend ile 5 birim kontrolü PASS | `v15-output/v15-edge-audit.json` |
| Gerçek PIN, kullanıcı/rol/firma E2E, sunucu yarış testi | NOT TESTED; kimlikli test oturumu kullanılmadı | `../Entegrasyon/SUPABASE_INCELEME.md` |
| ZIP CRC, manifest, temiz çıkarma ve açılış | PASS, temiz çıkarma + aynı kaynaktan yeniden build + gerçek WebGL akışı | `v15-output/package-check.json`, `package-smoke.json` |

WebGL ortamı: Linux Chromium, ANGLE/SwiftShader yazılımsal renderer. Donanım GPU performansı veya fiziksel cihaz kabulü değildir. Görsel inceleme: üretilen Lean ve Curve-Quad PDF'leri açılıp incelendi; referans DXF'nin özgün koordinatları değiştirilmedi. Üretim/statiğe uygunluk onayı verilmedi.

## Yeniden çalıştırma

Mantık/kaynak/CAD:

```sh
python3 -m pip install -r Test-Mantik/requirements.txt
python3 Test-Mantik/run-v15-checks.py --full --out work/checks
# V14 ayrı çıkarılmışsa fiziksel karşılaştırma:
python3 Test-Mantik/run-v15-checks.py --baseline /path/to/PLMR_JustPergola_v14 --out work/checks
```

Gerçek tarayıcı için `Test-Mantik` içinde `npm ci` ve `npx playwright install chromium` çalıştırın. Paket kökünden HTTP sunucusu açın. `PLMR_CHROMIUM_CONFIG`, Playwright launch seçeneklerini içeren yerel JSON dosyasıdır; Linux doğrulamasında `/usr/bin/chromium`, `--no-sandbox`, `--enable-unsafe-swiftshader`, `--use-angle=swiftshader` kullanıldı. Bu dosya teslim edilen uygulamanın gereksinimi değildir.

```sh
PLMR_TEST_URL=http://localhost:8000/Uygulama/index.html PLMR_TEST_OUTPUT=work/browser PLMR_CHROMIUM_CONFIG=work/chromium.json node Test-Mantik/v15-browser.cjs .
PLMR_TEST_URL=http://localhost:8000/Uygulama/index.html PLMR_TEST_OUTPUT=work/products PLMR_CHROMIUM_CONFIG=work/chromium.json node Test-Mantik/v15-products.cjs .
python3 Test-Mantik/v15-formats.py work/products
```

Ana entegrasyon tarayıcı testi, mevcut V51 motorunu çalıştırır ve parent bağlamını test için sağlar; gerçek Supabase oturumu veya ticari kayıt başarısı olarak raporlanamaz. Komutlar `BAGLANTI_REHBERI.md` içindedir.

## Başarısız denemelerin ayrımı

- Eski V9 tarayıcı testi, V11'den sonra değişmiş mekanizma mesh'ini BoxGeometry sayıyordu. Bu eski beklenti başarısız kaldı; kaynakta eski mesh geri getirilmedi. V15 ürün/montaj ve dosya testleri kullanıldı.
- V11 native hash testi hem özgün V14'te hem V15'te aynı hash ile başarısız. V14'ün dinamik metin değişikliklerini kapsamayan tarihsel fixture, güncel geometri bozulması kanıtı değildi. Gerçek V14 kaynaklarıyla 63 fiziksel karşılaştırma yapıldı.
- İlk bireysel ölçü testi, gizli 3D ölçünün listede kalmasını bekliyordu. Mevcut motor gizli native ölçüyü hiç üretmiyor. Önce görünür olduğunun ve sonra görünür eşinin kalmadığının kontrolüyle, gerçek gizleme/kayıt/gösterme akışı doğrulandı.
- Native hizalı DIMENSION tipini ezdxf ile yenileme deneyi beklenen diyagonal değeri üretmedi. Bu değişiklik teslim kaynağına alınmadı; mevcut sabit açılı doğrusal ölçü yazımı korundu. Gerçek hizalı/açısal CAD kabulü açık.
